# Booch
UPDATE npc_vendor SET ExtendedCost = 1432 WHERE item = 34033;
UPDATE npc_vendor SET ExtendedCost = 2279 WHERE item =25831;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32039;
UPDATE npc_vendor SET ExtendedCost = 21 WHERE item = 32040;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32041;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32042;
UPDATE npc_vendor SET ExtendedCost = 24 WHERE item = 32043;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32004;
UPDATE npc_vendor SET ExtendedCost = 21 WHERE item = 32005;
UPDATE npc_vendor SET ExtendedCost = 21 WHERE item = 32006;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32007;
UPDATE npc_vendor SET ExtendedCost = 24 WHERE item = 32008;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32009;
UPDATE npc_vendor SET ExtendedCost = 21 WHERE item = 32010;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32011;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32012;
UPDATE npc_vendor SET ExtendedCost = 24 WHERE item = 32013;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32029;
UPDATE npc_vendor SET ExtendedCost = 21 WHERE item = 32030;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32031;
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = 32032;
UPDATE npc_vendor SET ExtendedCost = 24 WHERE item = 32033;
UPDATE npc_vendor SET ExtendedCost = 2279 WHERE item = '25830';
UPDATE npc_vendor SET ExtendedCost = 2278 WHERE item = '25831';
UPDATE npc_vendor SET ExtendedCost = 2281 WHERE item = '25832';
UPDATE npc_vendor SET ExtendedCost = 2277 WHERE item = '25833';
UPDATE npc_vendor SET ExtendedCost = 2279 WHERE item = '25834';
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = '31992';
UPDATE npc_vendor SET ExtendedCost = 21 WHERE item = '31993';
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = '31995';
UPDATE npc_vendor SET ExtendedCost = 24 WHERE item = '31996';
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = '31997';
UPDATE npc_vendor SET ExtendedCost = 21 WHERE item = '31998';
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = '31999';
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = '32000';
UPDATE npc_vendor SET ExtendedCost = 24 WHERE item = '32001';
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = '32002';
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = '32020';
UPDATE npc_vendor SET ExtendedCost = 21 WHERE item = '32021';
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = '32022';
UPDATE npc_vendor SET ExtendedCost = 22 WHERE item = '32023';
UPDATE npc_vendor SET ExtendedCost = 24 WHERE item = '32024';
UPDATE npc_vendor SET ExtendedCost = 133 WHERE item = '32026';
UPDATE npc_vendor SET ExtendedCost = 21 WHERE item = '32027';
UPDATE npc_vendor SET ExtendedCost = 2289 WHERE item = '35327';
UPDATE npc_vendor SET ExtendedCost = 1432 WHERE item = '33671';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33672';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33673';
UPDATE npc_vendor SET ExtendedCost = 1435 WHERE item = '33674';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33675';
UPDATE npc_vendor SET ExtendedCost = 1432 WHERE item = '33690';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33691';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33692';
UPDATE npc_vendor SET ExtendedCost = 1435 WHERE item = '33693';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33694';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33695';
UPDATE npc_vendor SET ExtendedCost = 1432 WHERE item = '33696';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33697';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33698';
UPDATE npc_vendor SET ExtendedCost = 1435 WHERE item = '33699';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33722';
UPDATE npc_vendor SET ExtendedCost = 1432 WHERE item = '33723';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33724';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33725';
UPDATE npc_vendor SET ExtendedCost = 1435 WHERE item = '33726';
UPDATE npc_vendor SET ExtendedCost = 1664 WHERE item = '33727';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33749';
UPDATE npc_vendor SET ExtendedCost = 1432 WHERE item = '33750';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33751';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33752';
UPDATE npc_vendor SET ExtendedCost = 1435 WHERE item = '33753';
UPDATE npc_vendor SET ExtendedCost = 1435 WHERE item = '33757';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33758';
UPDATE npc_vendor SET ExtendedCost = 1432 WHERE item = '33759';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33760';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33761';
UPDATE npc_vendor SET ExtendedCost = 1432 WHERE item = '33767';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33768';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33769';
UPDATE npc_vendor SET ExtendedCost = 1435 WHERE item = '33770';
UPDATE npc_vendor SET ExtendedCost = 1431 WHERE item = '33771';
UPDATE npc_vendor SET ExtendedCost = 2261 WHERE item = '28624';

# KiriX
UPDATE `item_template` SET `BuyPrice`=10000,`SellPrice`=2500 WHERE `entry`=34413;
UPDATE `item_template` SET `BuyPrice`=5000,`SellPrice`=1250 WHERE `entry`=34262;
UPDATE `item_template` SET `BuyPrice`=5000,`SellPrice`=1250 WHERE `entry`=34261;
UPDATE `item_template` SET `BuyPrice`=5000,`SellPrice`=1250 WHERE `entry`=34262;
UPDATE `npc_vendor` SET `ExtendedCost`='2261' WHERE (`item`='28624');
UPDATE `npc_vendor` SET `ExtendedCost`='2283' WHERE (`item`='34033');
UPDATE `npc_vendor` SET `ExtendedCost`='2285' WHERE (`item`='33771');
UPDATE `npc_vendor` SET `ExtendedCost`='1435' WHERE (`item`='33770');
UPDATE `npc_vendor` SET `ExtendedCost`='2285' WHERE (`item`='33769');
UPDATE `npc_vendor` SET `ExtendedCost`='2285' WHERE (`item`='33768');
UPDATE `npc_vendor` SET `ExtendedCost`='2283' WHERE (`item`='33767');
UPDATE `npc_vendor` SET `ExtendedCost`='2285' WHERE (`item`='33761');
UPDATE `npc_vendor` SET `ExtendedCost`='2285' WHERE (`item`='33760');
UPDATE `npc_vendor` SET `ExtendedCost`='2283' WHERE (`item`='33759');
UPDATE `npc_vendor` SET `ExtendedCost`='2285' WHERE (`item`='33758'); -- 1875
UPDATE `npc_vendor` SET `ExtendedCost`=1435 WHERE `item`=33757; -- 1500/2000
UPDATE `npc_vendor` SET `ExtendedCost`=1435 WHERE `item`=33753;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33752;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33751;
UPDATE `npc_vendor` SET `ExtendedCost`=2283 WHERE `item`=33750; -- 1125
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33749;
UPDATE `npc_vendor` SET `ExtendedCost`=1435 WHERE `item`=33726;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33725;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33724;
UPDATE `npc_vendor` SET `ExtendedCost`=2283 WHERE `item`=33723;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33722;
UPDATE `npc_vendor` SET `ExtendedCost`=1435 WHERE `item`=33699;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33698;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33697;
UPDATE `npc_vendor` SET `ExtendedCost`=2283 WHERE `item`=33696;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33695;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33694;
UPDATE `npc_vendor` SET `ExtendedCost`=1435 WHERE `item`=33693;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33692;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33691; -- 1875
UPDATE `npc_vendor` SET `ExtendedCost`=2283 WHERE `item`=33690; -- 1125
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33675;
UPDATE `npc_vendor` SET `ExtendedCost`=1435 WHERE `item`=33674; -- 1500/2000
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33673;
UPDATE `item_template` SET `BuyPrice`='5000',`SellPrice`='1250' WHERE (`entry`='34319');
UPDATE `npc_vendor` SET `ExtendedCost`=1994 WHERE `item`=31775;
UPDATE `npc_vendor` SET `ExtendedCost`=2283 WHERE `item`=33671;
UPDATE `item_template` SET `BuyPrice`='100000' WHERE (`entry`='33976');
UPDATE `item_template` SET `BuyPrice`='1000000' WHERE (`entry`='33977');
UPDATE `npc_vendor` SET `ExtendedCost`=2275 WHERE `item`=34008;
UPDATE `npc_vendor` SET `ExtendedCost`=2273 WHERE `item`=34028;
UPDATE `npc_vendor` SET `ExtendedCost`=2285 WHERE `item`=33672;
UPDATE `npc_vendor` SET `ExtendedCost`=2283 WHERE `item`=34033;
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32029; -- 1630
UPDATE `npc_vendor` SET `ExtendedCost`='1342' WHERE (`entry`='26091') AND (`item`='32029');
UPDATE `npc_vendor` SET `ExtendedCost`='1342' WHERE (`entry`='26092') AND (`item`='32029');
UPDATE `npc_vendor` SET `ExtendedCost`=24 WHERE `item`=32013;
UPDATE `npc_vendor` SET `ExtendedCost`='1346' WHERE (`entry`='26091') AND (`item`='32013');
UPDATE `npc_vendor` SET `ExtendedCost`='1346' WHERE (`entry`='26092') AND (`item`='32013');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32012;
UPDATE `npc_vendor` SET `ExtendedCost`='1345' WHERE (`entry`='26091') AND (`item`='32012');
UPDATE `npc_vendor` SET `ExtendedCost`='1345' WHERE (`entry`='26092') AND (`item`='32012');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32011;
UPDATE `npc_vendor` SET `ExtendedCost`='1344' WHERE (`entry`='26091') AND (`item`='32011');
UPDATE `npc_vendor` SET `ExtendedCost`='1344' WHERE (`entry`='26092') AND (`item`='32011');
UPDATE `npc_vendor` SET `ExtendedCost`=21 WHERE `item`=32010; -- 978
UPDATE `npc_vendor` SET `ExtendedCost`='1343' WHERE (`entry`='26091') AND (`item`='32010');
UPDATE `npc_vendor` SET `ExtendedCost`='1343' WHERE (`entry`='26092') AND (`item`='32010');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32009;
UPDATE `npc_vendor` SET `ExtendedCost`='1342' WHERE (`entry`='26091') AND (`item`='32009');
UPDATE `npc_vendor` SET `ExtendedCost`='1342' WHERE (`entry`='26092') AND (`item`='32009');
UPDATE `npc_vendor` SET `ExtendedCost`=24 WHERE `item`=32008; -- 1304
UPDATE `npc_vendor` SET `ExtendedCost`='1346' WHERE (`entry`='26091') AND (`item`='32008'); -- 30248
UPDATE `npc_vendor` SET `ExtendedCost`='1346' WHERE (`entry`='26092') AND (`item`='32008');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32007;
UPDATE `npc_vendor` SET `ExtendedCost`='1345' WHERE (`entry`='26091') AND (`item`='32007'); -- 30245
UPDATE `npc_vendor` SET `ExtendedCost`='1345' WHERE (`entry`='26092') AND (`item`='32007');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32006;
UPDATE `npc_vendor` SET `ExtendedCost`='1344' WHERE (`entry`='26091') AND (`item`='32006'); -- 30242
UPDATE `npc_vendor` SET `ExtendedCost`='1344' WHERE (`entry`='26092') AND (`item`='32006');
UPDATE `npc_vendor` SET `ExtendedCost`=21 WHERE `item`=32005;
UPDATE `npc_vendor` SET `ExtendedCost`='1343' WHERE (`entry`='26091') AND (`item`='32005'); -- 30239
UPDATE `npc_vendor` SET `ExtendedCost`='1343' WHERE (`entry`='26092') AND (`item`='32005');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32004;
UPDATE `npc_vendor` SET `ExtendedCost`='1342' WHERE (`entry`='26091') AND (`item`='32004'); -- 30236
UPDATE `npc_vendor` SET `ExtendedCost`='1342' WHERE (`entry`='26092') AND (`item`='32004');
UPDATE `npc_vendor` SET `ExtendedCost`=2283 WHERE `item`=34033; -- 1125
UPDATE `npc_vendor` SET `ExtendedCost`=21 WHERE `item`=32030;
UPDATE `npc_vendor` SET `ExtendedCost`='1343' WHERE (`entry`='26091') AND (`item`='32030'); -- 30239
UPDATE `npc_vendor` SET `ExtendedCost`='1343' WHERE (`entry`='26092') AND (`item`='32030');
UPDATE `npc_vendor` SET `ExtendedCost`=24 WHERE `item`=32033;
UPDATE `npc_vendor` SET `ExtendedCost`='1346' WHERE (`entry`='26091') AND (`item`='32033'); -- 30248
UPDATE `npc_vendor` SET `ExtendedCost`='1346' WHERE (`entry`='26092') AND (`item`='32033');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32032; -- 1630
UPDATE `npc_vendor` SET `ExtendedCost`='1345' WHERE (`entry`='26091') AND (`item`='32032'); -- 30245
UPDATE `npc_vendor` SET `ExtendedCost`='1345' WHERE (`entry`='26092') AND (`item`='32032');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32031;
UPDATE `npc_vendor` SET `ExtendedCost`='1344' WHERE (`entry`='26091') AND (`item`='32031'); -- 30242
UPDATE `npc_vendor` SET `ExtendedCost`='1344' WHERE (`entry`='26092') AND (`item`='32031');
UPDATE `npc_vendor` SET `ExtendedCost`=24 WHERE `item`=32043; -- 1304
UPDATE `npc_vendor` SET `ExtendedCost`='1346' WHERE (`entry`='26091') AND (`item`='32043'); -- 30248
UPDATE `npc_vendor` SET `ExtendedCost`='1346' WHERE (`entry`='26092') AND (`item`='32043');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32042;
UPDATE `npc_vendor` SET `ExtendedCost`='1345' WHERE (`entry`='26091') AND (`item`='32042'); -- 30245
UPDATE `npc_vendor` SET `ExtendedCost`='1345' WHERE (`entry`='26092') AND (`item`='32042');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32041;
UPDATE `npc_vendor` SET `ExtendedCost`='1344' WHERE (`entry`='26091') AND (`item`='32041'); -- 30242
UPDATE `npc_vendor` SET `ExtendedCost`='1344' WHERE (`entry`='26092') AND (`item`='32041');
UPDATE `npc_vendor` SET `ExtendedCost`=21 WHERE `item`=32040; -- 978
UPDATE `npc_vendor` SET `ExtendedCost`='1343' WHERE (`entry`='26091') AND (`item`='32040'); -- 30239
UPDATE `npc_vendor` SET `ExtendedCost`='1343' WHERE (`entry`='26092') AND (`item`='32040');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32039;
UPDATE `npc_vendor` SET `ExtendedCost`='1342' WHERE (`entry`='26091') AND (`item`='32039'); -- 30236
UPDATE `npc_vendor` SET `ExtendedCost`='1342' WHERE (`entry`='26092') AND (`item`='32039');
UPDATE `npc_vendor` SET `ExtendedCost`='1200' WHERE (`entry`='26090') AND (`item`='25831');
UPDATE `npc_vendor` SET `ExtendedCost`=2283 WHERE `item`=34033; -- 1125
DELETE FROM `npc_vendor` WHERE (`item`='6265');
UPDATE `npc_vendor` SET `ExtendedCost`=423 WHERE `item`=29469;
UPDATE `npc_vendor` SET `ExtendedCost`=1188 WHERE `item`=28886;
UPDATE `npc_vendor` SET `ExtendedCost`=1188 WHERE `item`=28887;
UPDATE `npc_vendor` SET `ExtendedCost`=1188 WHERE `item`=28888;
UPDATE `npc_vendor` SET `ExtendedCost`=1188 WHERE `item`=28889;
DELETE FROM `npc_vendor` WHERE (`item`='35728');
DELETE FROM `npc_vendor` WHERE (`item`='35729');
DELETE FROM `npc_vendor` WHERE (`item`='35730');
DELETE FROM `npc_vendor` WHERE (`item`='35731');
UPDATE `npc_vendor` SET `ExtendedCost`=298 WHERE `item`=28557;
UPDATE `npc_vendor` SET `ExtendedCost`=2248 WHERE `item`=33067;
UPDATE `npc_vendor` SET `ExtendedCost`=2248 WHERE `item`=33065;
UPDATE `npc_vendor` SET `ExtendedCost`=2248 WHERE `item`=33068;
UPDATE `npc_vendor` SET `ExtendedCost`=2248 WHERE `item`=33066;
UPDATE `npc_vendor` SET `ExtendedCost`=129 WHERE `item`=33056;
UPDATE `npc_vendor` SET `ExtendedCost`=129 WHERE `item`=33064;
UPDATE `npc_vendor` SET `ExtendedCost`=129 WHERE `item`=33057;
UPDATE `npc_vendor` SET `ExtendedCost`=2269 WHERE `item`=28379;
UPDATE `npc_vendor` SET `ExtendedCost`=2269 WHERE `item`=28380;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29369;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29367; -- 29434/25
UPDATE `npc_vendor` SET `ExtendedCost`=115 WHERE `item`=28240;
DELETE FROM `npc_vendor` WHERE (`item`='29287');
DELETE FROM `npc_vendor` WHERE (`item`='29290');
DELETE FROM `npc_vendor` WHERE (`item`='29279');
DELETE FROM `npc_vendor` WHERE (`item`='29283');
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29375;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29382;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29373;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29379;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29368;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29374;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29381;
UPDATE `npc_vendor` SET `ExtendedCost`=1027 WHERE `item`=29370; -- 29434/41
UPDATE `npc_vendor` SET `ExtendedCost`=1027 WHERE `item`=29376;
UPDATE `npc_vendor` SET `ExtendedCost`=1027 WHERE `item`=29383;
UPDATE `npc_vendor` SET `ExtendedCost`=172 WHERE `item`=32979;
UPDATE `npc_vendor` SET `ExtendedCost`='2347' WHERE (`entry`='26089') AND (`item`='32979');
UPDATE `npc_vendor` SET `ExtendedCost`=169 WHERE `item`=32980;
UPDATE `npc_vendor` SET `ExtendedCost`='1015' WHERE (`entry`='26089') AND (`item`='32980');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26301') AND (`item`='32981');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26301') AND (`item`='32799');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26301') AND (`item`='32811');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26301') AND (`item`='32787');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26301') AND (`item`='32807');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26301') AND (`item`='32820');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26301') AND (`item`='32795');
DELETE FROM `npc_vendor` WHERE (`entry`='26301') AND (`item`='30067');
UPDATE `npc_vendor` SET `ExtendedCost`=1040 WHERE `item`=32090; -- 29434/50
UPDATE `npc_vendor` SET `ExtendedCost`=1040 WHERE `item`=32089;
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26305') AND (`item`='32798');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26305') AND (`item`='32786');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26305') AND (`item`='32810');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26305') AND (`item`='32800');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26305') AND (`item`='32788');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26305') AND (`item`='32812');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26305') AND (`item`='32802');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26305') AND (`item`='32790');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26305') AND (`item`='32814');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26305') AND (`item`='32808');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26305') AND (`item`='32796');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26305') AND (`item`='32821');
UPDATE `npc_vendor` SET `ExtendedCost`='1342' WHERE (`entry`='26305') AND (`item`='30144');
UPDATE `npc_vendor` SET `ExtendedCost`='1344' WHERE (`entry`='26305') AND (`item`='30146');
UPDATE `npc_vendor` SET `ExtendedCost`='1345' WHERE (`entry`='26305') AND (`item`='30148');
UPDATE `npc_vendor` SET `ExtendedCost`='1346' WHERE (`entry`='26305') AND (`item`='30149');
UPDATE `npc_vendor` SET `ExtendedCost`='1343' WHERE (`entry`='26305') AND (`item`='30145');
UPDATE `npc_vendor` SET `ExtendedCost`=1040 WHERE `item`=32088;
UPDATE `npc_vendor` SET `ExtendedCost`=1040 WHERE `item`=32087;
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26306') AND (`item`='32997');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26306') AND (`item`='32998');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26306') AND (`item`='32999');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26306') AND (`item`='32809');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26306') AND (`item`='32797');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26306') AND (`item`='32785');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26306') AND (`item`='32816');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26306') AND (`item`='32803');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26306') AND (`item`='32791');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26306') AND (`item`='32817');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26306') AND (`item`='32804');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26306') AND (`item`='32792');
UPDATE `npc_vendor` SET `ExtendedCost`=1040 WHERE `item`=32085;
UPDATE `npc_vendor` SET `ExtendedCost`=1040 WHERE `item`=32086;
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26308') AND (`item`='32801');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26308') AND (`item`='32813');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26308') AND (`item`='32789');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26308') AND (`item`='32988');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26308') AND (`item`='32989');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26308') AND (`item`='32990');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26308') AND (`item`='32805');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26308') AND (`item`='32818');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26308') AND (`item`='32793');
UPDATE `npc_vendor` SET `ExtendedCost`='172' WHERE (`entry`='26308') AND (`item`='32806');
UPDATE `npc_vendor` SET `ExtendedCost`='169' WHERE (`entry`='26308') AND (`item`='32819');
UPDATE `npc_vendor` SET `ExtendedCost`='171' WHERE (`entry`='26308') AND (`item`='32794');
UPDATE `npc_vendor` SET `ExtendedCost`=1040 WHERE `item`=32084;
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=33313;
UPDATE `npc_vendor` SET `ExtendedCost`=21 WHERE `item`=31958;
UPDATE `npc_vendor` SET `ExtendedCost`=26 WHERE `item`=31959;
UPDATE `npc_vendor` SET `ExtendedCost`=133 WHERE `item`=31965;
UPDATE `npc_vendor` SET `ExtendedCost`=26 WHERE `item`=31986; -- 3261
UPDATE `npc_vendor` SET `ExtendedCost`=26 WHERE `item`=31966;
UPDATE `npc_vendor` SET `ExtendedCost`=21 WHERE `item`=31978; -- 978
UPDATE `npc_vendor` SET `ExtendedCost`=148 WHERE `item`=32963; -- 2739
UPDATE `npc_vendor` SET `ExtendedCost`=26 WHERE `item`=31984;
UPDATE `npc_vendor` SET `ExtendedCost`=21 WHERE `item`=31985;
UPDATE `npc_vendor` SET `ExtendedCost`=26 WHERE `item`=32014;
UPDATE `npc_vendor` SET `ExtendedCost`=26 WHERE `item`=32025;
UPDATE `npc_vendor` SET `ExtendedCost`=133 WHERE `item`=32026; -- 2283
UPDATE `npc_vendor` SET `ExtendedCost`=21 WHERE `item`=32027;
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=33309; -- 1630
UPDATE `npc_vendor` SET `ExtendedCost`=21 WHERE `item`=32961;
UPDATE `npc_vendor` SET `ExtendedCost`=133 WHERE `item`=32028;
UPDATE `npc_vendor` SET `ExtendedCost`=148 WHERE `item`=32964;
UPDATE `npc_vendor` SET `ExtendedCost`=133 WHERE `item`=32044;
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=32045;
UPDATE `npc_vendor` SET `ExtendedCost`=21 WHERE `item`=32046;
UPDATE `npc_vendor` SET `ExtendedCost`=133 WHERE `item`=32052;
UPDATE `npc_vendor` SET `ExtendedCost`=148 WHERE `item`=32053;
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=32962; -- 870
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=32054;
UPDATE `npc_vendor` SET `ExtendedCost`=26 WHERE `item`=32055;
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=33937;
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=33077;
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=33949;
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=33946;
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=33943;
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=33076;
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=33940;
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=33952;
UPDATE `npc_vendor` SET `ExtendedCost`=146 WHERE `item`=33078;
UPDATE `npc_vendor` SET `ExtendedCost`=1642 WHERE `item`=29388;
UPDATE `npc_vendor` SET `ExtendedCost`=1642 WHERE `item`=29389;
UPDATE `npc_vendor` SET `ExtendedCost`=1642 WHERE `item`=29390;
UPDATE `npc_vendor` SET `ExtendedCost`=1040 WHERE `item`=29275;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29270;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29273;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29272;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29269;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29271;
UPDATE `npc_vendor` SET `ExtendedCost`=1015 WHERE `item`=29274;
UPDATE `npc_vendor` SET `ExtendedCost`=1037 WHERE `item`=29267;
UPDATE `npc_vendor` SET `ExtendedCost`=1037 WHERE `item`=29268;
UPDATE `npc_vendor` SET `ExtendedCost`=115 WHERE `item`=30350;
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=30486;
UPDATE `npc_vendor` SET `ExtendedCost`='1332' WHERE (`entry`='26091') AND (`item`='30486');
UPDATE `npc_vendor` SET `ExtendedCost`='1332' WHERE (`entry`='26092') AND (`item`='30486');
UPDATE `npc_vendor` SET `ExtendedCost`='21' WHERE (`entry`='26308') AND (`item`='30487');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=30488;
UPDATE `npc_vendor` SET `ExtendedCost`='1334' WHERE (`entry`='26091') AND (`item`='30488');
UPDATE `npc_vendor` SET `ExtendedCost`='1334' WHERE (`entry`='26092') AND (`item`='30488');
UPDATE `npc_vendor` SET `ExtendedCost`=22 WHERE `item`=30489;
UPDATE `npc_vendor` SET `ExtendedCost`='1335' WHERE (`entry`='26091') AND (`item`='30489');
UPDATE `npc_vendor` SET `ExtendedCost`='1335' WHERE (`entry`='26092') AND (`item`='30489');
UPDATE `npc_vendor` SET `ExtendedCost`=24 WHERE `item`=30490;
UPDATE `npc_vendor` SET `ExtendedCost`='1336' WHERE (`entry`='26091') AND (`item`='30490');
UPDATE `npc_vendor` SET `ExtendedCost`='1336' WHERE (`entry`='26092') AND (`item`='30490');
UPDATE `npc_vendor` SET `ExtendedCost`=1334 WHERE `item`=30120;
UPDATE `npc_vendor` SET `ExtendedCost`=1332 WHERE `item`=30118;
UPDATE `npc_vendor` SET `ExtendedCost`=1332 WHERE `item`=30113;
UPDATE `npc_vendor` SET `ExtendedCost`=1333 WHERE `item`=30119;
UPDATE `npc_vendor` SET `ExtendedCost`=1334 WHERE `item`=30115;
UPDATE `npc_vendor` SET `ExtendedCost`=1335 WHERE `item`=30121;
UPDATE `npc_vendor` SET `ExtendedCost`=1333 WHERE `item`=30114;
UPDATE `npc_vendor` SET `ExtendedCost`=1335 WHERE `item`=30116;
UPDATE `npc_vendor` SET `ExtendedCost`=1336 WHERE `item`=30122;
UPDATE `npc_vendor` SET `ExtendedCost`=1336 WHERE `item`=30117;
UPDATE `npc_vendor` SET `ExtendedCost`=423 WHERE `item`=29471;
REPLACE INTO `npc_trainer` VALUE (915, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (916, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (917, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (918, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (1234, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (1411, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (2122, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (2130, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (3155, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (3170, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (3327, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (3328, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (3401, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (3594, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (3599, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (4163, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (4214, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (4215, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (4582, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (4583, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (4584, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (5165, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (5166, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (5167, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (13283, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (16279, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (16684, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (16685, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (16686, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (4990, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (5960, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (5968, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (16759, 674, 285, 0, 0, 10);
REPLACE INTO `npc_trainer` VALUE (15285, 674, 285, 0, 0, 10);
UPDATE `creature_template` SET `faction_A`='14',`faction_H`='14' WHERE (`entry`='11466');

# Sevift
replace into `npc_trainer` (`entry`, `spell`, `spellcost`, `reqskill`, `reqskillvalue`, `reqlevel`) values('17222','4036','10','0','0','5');
replace into `npc_trainer` (`entry`, `spell`, `spellcost`, `reqskill`, `reqskillvalue`, `reqlevel`) values('1702','4036','10','0','0','5');
replace into `npc_trainer` (`entry`, `spell`, `spellcost`, `reqskill`, `reqskillvalue`, `reqlevel`) values('16668','4036','10','0','0','5');
replace into `npc_trainer` (`entry`, `spell`, `spellcost`, `reqskill`, `reqskillvalue`, `reqlevel`) values('11028','4036','10','0','0','5');
replace into `npc_trainer` (`entry`, `spell`, `spellcost`, `reqskill`, `reqskillvalue`, `reqlevel`) values('17634','4036','10','0','0','5');
replace into `npc_trainer` (`entry`, `spell`, `spellcost`, `reqskill`, `reqskillvalue`, `reqlevel`) values('17637','4036','10','0','0','5');
replace into `npc_trainer` (`entry`, `spell`, `spellcost`, `reqskill`, `reqskillvalue`, `reqlevel`) values('11025','4036','10','0','0','5');
replace into `npc_trainer` (`entry`, `spell`, `spellcost`, `reqskill`, `reqskillvalue`, `reqlevel`) values('11026','4036','10','0','0','5');
replace into `npc_trainer` (`entry`, `spell`, `spellcost`, `reqskill`, `reqskillvalue`, `reqlevel`) values('2857','4036','10','0','0','5');

# QUEST
UPDATE `quest_template` SET `RequiredRaces` = 1101 WHERE `entry` = 9465;
UPDATE `quest_template` SET `RequiredRaces` = 1101 WHERE `entry` = 9464;
UPDATE `quest_template` SET `RequiredRaces` = 1101 WHERE `entry` = 9462;
UPDATE `quest_template` SET `Details` = 'You should know that The Prophet has been asking for you, having heard of your success in your trial. The creation of your fire totem will have to wait until you have spoken with him.$B$BThis is a rare honor; you must hurry to the Exodar to see him at once! ' WHERE `entry` = 9461;
UPDATE `creature_template` SET `npcflag` = 3, `attackpower` = 1500, `baseattacktime` = 2000, `flags` = 768, `class` = 0, `type` = 4, `flag1` = 0, `spell1` = 0, `mingold` = 0, `maxgold` = 0, `mechanic_immune_mask` = 0, `ScriptName` = '' WHERE `entry` = 17205;


DELETE FROM `db_version`;
INSERT INTO `db_version` VALUES ('YTDB_094_R41.03_rev5735');

UPDATE `creature_template` SET `ScriptName`='' WHERE `entry` in ('6172','6177','17542','17768');
