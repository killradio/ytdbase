# Slavik
UPDATE creature_template SET mechanic_immune_mask=0x1 WHERE rank =1;
UPDATE creature_template SET mechanic_immune_mask=0x1 WHERE rank =2;
UPDATE creature_template SET mechanic_immune_mask=0x1 WHERE rank >3;
UPDATE creature_template SET mechanic_immune_mask=0x4CB3F5B WHERE rank =3;

# KiriX
DELETE FROM `spell_scripts` WHERE (`id`='7356');
DELETE FROM `creature` WHERE (`id`='5676');
UPDATE `creature` SET `MovementType`='0' WHERE (`id`='15949');

# Y2kCat
UPDATE `creature_template` SET `faction_A`='1824',`faction_H`='1824',`type`='7' WHERE entry in (23489,23146,23144,23146,23348,23291,23344,22253,22274,22252,23150,23140,23340,23166);
UPDATE `creature_template` SET `minlevel`='73',`maxlevel`='73',`minhealth`='8700',`maxhealth`='8700',`faction_A`='1824',`faction_H`='1824',`mindmg`='191',`maxdmg`='333',`attackpower`='1836',`baseattacktime`='1435',`rangeattacktime`='1684',`minrangedmg`='328.696',`maxrangedmg`='458.231',`rangedattackpower`='100',`type`='7' WHERE (`entry`='23284');
UPDATE `creature_template` SET `minlevel`='68',`maxlevel`='68',`minhealth`='8700',`maxhealth`='8700',`mindmg`='191',`maxdmg`='333',`attackpower`='1836',`baseattacktime`='1435',`rangeattacktime`='1684',`minrangedmg`='328.696',`maxrangedmg`='458.231',`rangedattackpower`='100',`type`='7' WHERE (`entry`='23144');
UPDATE `creature_template` SET `minlevel`='69',`maxlevel`='71',`minhealth`='8700',`maxhealth`='8700',`faction_A`='1824',`faction_H`='1824',`mindmg`='191',`maxdmg`='333',`attackpower`='1836',`baseattacktime`='1435',`rangeattacktime`='1684',`minrangedmg`='328.696',`maxrangedmg`='458.231',`rangedattackpower`='100',`type`='7' WHERE (`entry`='23150');
UPDATE `creature_template` SET `minlevel`='71',`maxlevel`='71',`minhealth`='8700',`maxhealth`='8700',`faction_A`='1824',`faction_H`='1824',`mindmg`='191',`maxdmg`='333',`attackpower`='1836',`baseattacktime`='1435',`rangeattacktime`='1684',`minrangedmg`='328.696',`maxrangedmg`='458.231',`rangedattackpower`='100',`type`='7' WHERE (`entry`='23148');
UPDATE `creature_template` SET `minlevel`='71',`maxlevel`='71',`minhealth`='8700',`maxhealth`='8700',`faction_A`='1824',`faction_H`='1824',`mindmg`='191',`maxdmg`='333',`attackpower`='1836',`baseattacktime`='1435',`rangeattacktime`='1684',`minrangedmg`='328.696',`maxrangedmg`='458.231',`rangedattackpower`='100',`type`='7' WHERE (`entry`='23145');
UPDATE `creature` SET `position_x`='-5142.29',`position_y`='576.74',`position_z`='84.192',`orientation`='1.3942',`spawntimesecs`='1200' WHERE (`guid`='285122');

# GO
DELETE FROM `gameobject` WHERE `guid` IN (783609);
UPDATE `gameobject_template` SET `data3`='0' WHERE entry in (103015,103016,180502,180529,180534,180666,180667);

# NPC
REPLACE INTO `creature` (`guid`, `id`, `map`, `modelid`, `equipment_id`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`, `spawndist`, `currentwaypoint`, `spawn_position_x`, `spawn_position_y`, `spawn_position_z`, `spawn_orientation`, `curhealth`, `curmana`, `DeathState`, `MovementType`) VALUES (52963, 13117, 489, 0, 0, 1027.08, 1386.95, 340.823, 2.57223, 3540, 5, 0, 1027.08, 1386.95, 340.823, 2.57223, 6400, 4868, 0, 0);
DELETE FROM `pickpocketing_loot_template` WHERE (`entry`=6466) AND (`item`=7208);
INSERT INTO `pickpocketing_loot_template` (`entry`, `item`, `ChanceOrRef`, `QuestChanceOrGroup`, `mincount`, `maxcount`, `freeforall`, `lootcondition`, `condition_value1`, `condition_value2`) VALUES (6466, 7208, 100, 0, 1, 1, 0, 0, 0, 0);
UPDATE `creature_template` SET `mindmg`='90',`maxdmg`='120' WHERE (`entry`='23591');
UPDATE `creature_template` SET `mindmg`='90',`maxdmg`='120' WHERE (`entry`='4348');
UPDATE `creature_template` SET `mindmg`='90',`maxdmg`='120',`rank`='0' WHERE (`entry`='4394');

# LOTAR
UPDATE `quest_template` SET `Details` = 'This pendant brings back memories of a different time. A better time.$B$BUnfortunately, memories are the last thing I need right now.$B$BI want you to bury this by the runestone in the Scorched Grove. It was there that I first met the treant elder. Put my old friend\'s memory to rest.', `OfferRewardText` = 'I no longer belong to this world and must admit defeat. The land has forever changed and nothing will ever be the same.$B$BLeave the pendant here with me, $N. Maybe one day, long after the elves are gone, a new tree will grow on this very spot - amongst a burnt forest and the husks of dead treants.', `ReqCreatureOrGOId1` = 0, `ReqCreatureOrGOCount1` = 0 WHERE `entry` = 10166;

# wasilevs
REPLACE INTO creature VALUES (78204,22024,530,0,0,-3392.87,2316.39,64.3241,2.18721,900,0,0,-3392.87,2316.39,64.3241,0,5700,2991,0,0);


DELETE FROM `db_version`;
INSERT INTO `db_version` VALUES ('YTDB_092_r33_FINAL_rev5356');
