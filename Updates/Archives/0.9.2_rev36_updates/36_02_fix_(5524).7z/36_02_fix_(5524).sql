# sasmeo
INSERT IGNORE INTO `game_event_creature` ( `guid` , `event` ) VALUES ('284616', '6');
UPDATE `creature_template` SET `npcflag` = 130 WHERE `entry` = 4963;

# KiriX
UPDATE `quest_template` SET `RewOrReqMoney`='132000',`RewMoneyMaxLevel`='114000' WHERE (`entry`='11071');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='49800' WHERE (`entry`='11068');
UPDATE creature SET spawn_position_x = '-4633.099609', spawn_position_y = '-13065.332031', spawn_position_z = '-14.517163', spawn_orientation = '0.089507',position_x = '-4633.099609', position_y = '-13065.332031', position_z = '-14.517163', orientation = '0.089507' WHERE guid = '71388';
UPDATE creature SET spawn_position_x = '-3862.145996', spawn_position_y = '-13124.474609', spawn_position_z = '7.613234', spawn_orientation = '1.877917',position_x = '-3862.145996', position_y = '-13124.474609', position_z = '7.613234', orientation = '1.877917' WHERE guid = '78476';
UPDATE `creature_template` SET `modelid_A2`='17000',`modelid_H2`='17000' WHERE (`entry`='17392');
UPDATE `creature_template` SET `modelid_A2`='17019',`modelid_H2`='17019' WHERE (`entry`='17391');
UPDATE `creature_template` SET `faction_H`='7' WHERE (`entry`='2543');
UPDATE `quest_template` SET `QuestLevel`='10' WHERE (`entry`='2983');
UPDATE `quest_template` SET `QuestLevel`='10' WHERE (`entry`='9468');
UPDATE `quest_template` SET `QuestLevel`='10' WHERE (`entry`='9467');
UPDATE `quest_template` SET `QuestLevel`='10' WHERE (`entry`='9461');
UPDATE `quest_template` SET `QuestLevel`='10' WHERE (`entry`='9555');
UPDATE `quest_template` SET `QuestLevel`='10' WHERE (`entry`='9462');

# LOTAR
UPDATE `quest_template` SET `RewOrReqMoney` = 22500 WHERE `entry` = 2994;
UPDATE `quest_template` SET `ReqItemCount1` = 4 WHERE `entry` = 969;
UPDATE `quest_template` SET `OfferRewardText` = 'Oh my! This information explains quite a lot about Thaurissan.$B$BThere is much more to learn!' WHERE `entry` = 3701;
UPDATE `quest_template` SET `RewOrReqMoney` = 7500 WHERE `entry` = 2770;


# QUEST
UPDATE `quest_template` SET `NextQuestId` = 1645, `NextQuestInChain` = 1645 WHERE `entry` = 2997;
UPDATE `quest_template` SET `ExclusiveGroup` = 0 WHERE `entry` = 1646;


# NPC
DELETE FROM creature WHERE guid = '74150';
DELETE FROM creature_addon WHERE guid = '74150';
DELETE FROM creature_movement WHERE id = '74150';
INSERT INTO `creature` (`guid`,`id`,`map`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`spawn_position_x`,`spawn_position_y`,`spawn_position_z`,`spawn_orientation`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(70820, 18700, 558, 0, 0, 13.3855, -413.138, 26.5893, 3.11681, 7200, 0, 0, 13.3855, -413.138, 26.5893, 0, 6100, 0, 0, 0),
(70821, 18700, 558, 0, 0, 11.7981, -370.773, 24.5529, 3.09325, 7200, 0, 0, 11.7981, -370.773, 24.5529, 0, 5716, 0, 0, 0),
(57612, 18700, 558, 0, 0, 9.44731, -370.659, 24.6429, 3.04612, 7200, 0, 0, 9.44731, -370.659, 24.6429, 0, 6100, 0, 0, 0),
(81113, 18700, 558, 0, 0, 20.3404, -413.31, 26.59, 3.11681, 7200, 0, 0, 20.3404, -413.31, 26.59, 0, 5716, 0, 0, 0),
(81114, 18700, 558, 0, 0, 17.7402, -413.246, 26.5898, 3.11681, 7200, 0, 0, 17.7402, -413.246, 26.5898, 0, 4566, 0, 0, 0),
(81115, 18700, 558, 0, 0, 15.3559, -413.187, 26.5896, 3.11681, 7200, 0, 0, 15.3559, -413.187, 26.5896, 0, 5716, 0, 0, 0),
(81116, 18700, 558, 0, 0, 15.2231, -370.938, 24.4219, 3.09325, 7200, 0, 0, 15.2231, -370.938, 24.4219, 0, 4566, 0, 0, 0),
(81117, 18700, 558, 0, 0, 18.3829, -371.091, 24.3011, 3.09325, 7200, 0, 0, 18.3829, -371.091, 24.3011, 0, 4183, 0, 0, 0),
(81118, 18700, 558, 0, 0, 10.3393, -367.845, 26.5833, 3.16, 7200, 0, 0, 10.3393, -367.845, 26.5833, 0, 5333, 0, 0, 0),
(81119, 18700, 558, 0, 0, 13.2728, -367.791, 26.5835, 3.16, 7200, 0, 0, 13.2728, -367.791, 26.5835, 0, 6100, 0, 0, 0),
(81120, 18700, 558, 0, 0, 16.2918, -367.735, 26.5839, 3.16, 7200, 0, 0, 16.2918, -367.735, 26.5839, 0, 5333, 0, 0, 0),
(81121, 18700, 558, 0, 0, 19.9452, -367.668, 26.5844, 3.16, 7200, 0, 0, 19.9452, -367.668, 26.5844, 0, 3800, 0, 0, 0),
(81122, 18700, 558, 0, 0, 10.9688, -365.182, 26.5915, 3.07361, 7200, 0, 0, 10.9688, -365.182, 26.5915, 0, 4183, 0, 0, 0),
(81123, 18700, 558, 0, 0, 13.8845, -365.14, 26.5923, 3.15608, 7200, 0, 0, 13.8845, -365.14, 26.5923, 0, 4183, 0, 0, 0),
(81124, 18700, 558, 0, 0, 16.3457, -365.105, 26.5926, 3.15608, 7200, 0, 0, 16.3457, -365.105, 26.5926, 0, 5333, 0, 0, 0),
(81125, 18700, 558, 0, 0, 20.1928, -365.049, 26.593, 3.15608, 7200, 0, 0, 20.1928, -365.049, 26.593, 0, 3800, 0, 0, 0),
(81126, 18700, 558, 0, 0, 11.2097, -362.039, 26.6031, 3.10895, 7200, 0, 0, 11.2097, -362.039, 26.6031, 0, 5716, 0, 0, 0),
(81127, 18700, 558, 0, 0, 14.8277, -362.03, 26.6031, 3.1443, 7200, 0, 0, 14.8277, -362.03, 26.6031, 0, 5333, 0, 0, 0),
(81128, 18700, 558, 0, 0, 17.8112, -362.022, 26.6031, 3.1443, 7200, 0, 0, 17.8112, -362.022, 26.6031, 0, 4183, 0, 0, 0),
(81129, 18700, 558, 0, 0, 21.1727, -362.013, 26.6031, 3.1443, 7200, 0, 0, 21.1727, -362.013, 26.6031, 0, 6100, 0, 0, 0),
(81130, 18700, 558, 0, 0, -37.2885, -369.826, 26.584, 3.16785, 7200, 0, 0, -37.2885, -369.826, 26.584, 0, 5333, 0, 0, 0),
(81131, 18700, 558, 0, 0, -33.6402, -369.73, 25.4159, 3.16785, 7200, 0, 0, -33.6402, -369.73, 25.4159, 0, 4183, 0, 0, 0),
(81132, 18700, 558, 0, 0, -29.1958, -369.613, 25.513, 3.16785, 7200, 0, 0, -29.1958, -369.613, 25.513, 0, 4950, 0, 0, 0),
(81134, 18700, 558, 0, 0, -25.687, -369.521, 25.5896, 3.16785, 7200, 0, 0, -25.687, -369.521, 25.5896, 0, 3800, 0, 0, 0),
(81135, 18700, 558, 0, 0, -21.757, -369.54, 25.5731, 3.21891, 7200, 0, 0, -21.757, -369.54, 25.5731, 0, 5333, 0, 0, 0),
(81136, 18700, 558, 0, 0, -37.2453, -366.131, 26.5876, 3.13251, 7200, 0, 0, -37.2453, -366.131, 26.5876, 0, 4183, 0, 0, 0),
(81137, 18700, 558, 0, 0, -32.2729, -366.098, 26.5876, 3.14822, 7200, 0, 0, -32.2729, -366.098, 26.5876, 0, 4950, 0, 0, 0),
(81138, 18700, 558, 0, 0, -28.4255, -366.072, 26.5876, 3.14822, 7200, 0, 0, -28.4255, -366.072, 26.5876, 0, 4950, 0, 0, 0),
(81139, 18700, 558, 0, 0, -24.7851, -366.048, 26.5876, 3.14822, 7200, 0, 0, -24.7851, -366.048, 26.5876, 0, 4183, 0, 0, 0),
(81140, 18700, 558, 0, 0, -20.7937, -366.022, 26.5847, 3.14822, 7200, 0, 0, -20.7937, -366.022, 26.5847, 0, 4950, 0, 0, 0),
(81141, 18700, 558, 0, 0, -36.9046, -363.46, 26.5947, 3.14429, 7200, 0, 0, -36.9046, -363.46, 26.5947, 0, 4183, 0, 0, 0),
(81142, 18700, 558, 0, 0, -32.0041, -363.447, 26.5919, 3.14429, 7200, 0, 0, -32.0041, -363.447, 26.5919, 0, 3800, 0, 0, 0),
(81143, 18700, 558, 0, 0, -27.8146, -363.436, 26.5919, 3.14429, 7200, 0, 0, -27.8146, -363.436, 26.5919, 0, 3800, 0, 0, 0),
(81144, 18700, 558, 0, 0, -24.0346, -363.426, 26.5919, 3.14429, 7200, 0, 0, -24.0346, -363.426, 26.5919, 0, 5333, 0, 0, 0),
(81145, 18700, 558, 0, 0, -20.2322, -363.415, 26.5875, 3.14429, 7200, 0, 0, -20.2322, -363.415, 26.5875, 0, 4566, 0, 0, 0),
(81146, 18700, 558, 0, 0, -37.456, -360.591, 26.5988, 3.16785, 7200, 0, 0, -37.456, -360.591, 26.5988, 0, 4183, 0, 0, 0),
(81147, 18700, 558, 0, 0, -31.6799, -361.025, 26.5963, 3.22676, 7200, 0, 0, -31.6799, -361.025, 26.5963, 0, 5333, 0, 0, 0),
(81148, 18700, 558, 0, 0, -27.863, -360.714, 26.5963, 3.22283, 7200, 0, 0, -27.863, -360.714, 26.5963, 0, 4950, 0, 0, 0),
(81149, 18700, 558, 0, 0, -23.7129, -361.121, 26.595, 3.10109, 7200, 0, 0, -23.7129, -361.121, 26.595, 0, 4950, 0, 0, 0),
(81150, 18700, 558, 0, 0, -19.3739, -361.297, 26.5889, 3.10109, 7200, 0, 0, -19.3739, -361.297, 26.5889, 0, 4950, 0, 0, 0),
(81151, 18700, 558, 0, 0, -35.6524, -405.391, 26.0455, 3.1168, 7200, 0, 0, -35.6524, -405.391, 26.0455, 0, 5716, 0, 0, 0),
(81152, 18700, 558, 0, 0, -31.0413, -405.506, 25.4184, 3.1168, 7200, 0, 0, -31.0413, -405.506, 25.4184, 0, 3800, 0, 0, 0),
(81153, 18700, 558, 0, 0, -25.8679, -405.634, 25.5255, 3.1168, 7200, 0, 0, -25.8679, -405.634, 25.5255, 0, 5716, 0, 0, 0),
(81154, 18700, 558, 0, 0, -21.9316, -405.732, 25.607, 3.1168, 7200, 0, 0, -21.9316, -405.732, 25.607, 0, 4950, 0, 0, 0),
(81155, 18700, 558, 0, 0, -35.8812, -407.988, 26.5881, 3.17571, 7200, 0, 0, -35.8812, -407.988, 26.5881, 0, 4566, 0, 0, 0),
(81156, 18700, 558, 0, 0, -30.0299, -408.448, 26.5883, 3.04219, 7200, 0, 0, -30.0299, -408.448, 26.5883, 0, 4566, 0, 0, 0),
(81157, 18700, 558, 0, 0, -25.1928, -408.816, 26.5883, 3.06575, 7200, 0, 0, -25.1928, -408.816, 26.5883, 0, 4950, 0, 0, 0),
(81158, 18700, 558, 0, 0, -21.2307, -409.117, 26.5854, 3.06575, 7200, 0, 0, -21.2307, -409.117, 26.5854, 0, 3800, 0, 0, 0),
(81159, 18700, 558, 0, 0, -36.2515, -411.432, 26.5998, 3.05005, 7200, 0, 0, -36.2515, -411.432, 26.5998, 0, 4183, 0, 0, 0),
(81160, 18700, 558, 0, 0, -30.8562, -411.927, 26.5998, 3.05005, 7200, 0, 0, -30.8562, -411.927, 26.5998, 0, 4566, 0, 0, 0),
(81161, 18700, 558, 0, 0, -24.9769, -412.467, 26.5998, 3.05005, 7200, 0, 0, -24.9769, -412.467, 26.5998, 0, 3800, 0, 0, 0),
(81162, 18700, 558, 0, 0, -21.0402, -412.316, 26.595, 3.05397, 7200, 0, 0, -21.0402, -412.316, 26.595, 0, 3800, 0, 0, 0),
(81163, 18700, 558, 0, 0, -33.501, -409.557, 26.5931, 2.98721, 7200, 0, 0, -33.501, -409.557, 26.5931, 0, 4950, 0, 0, 0),
(81164, 18700, 558, 0, 0, -32.9775, -406.968, 26.5841, 3.04612, 7200, 0, 0, -32.9775, -406.968, 26.5841, 0, 5333, 0, 0, 0),
(81165, 18700, 558, 0, 0, -28.0837, -407.224, 26.5841, 3.08931, 7200, 0, 0, -28.0837, -407.224, 26.5841, 0, 3800, 0, 0, 0),
(81166, 18700, 558, 0, 0, -28.3511, -411.037, 26.5958, 2.92203, 7200, 0, 0, -28.3511, -411.037, 26.5958, 0, 4183, 0, 0, 0),
(81168, 18700, 558, 0, 0, -23.4497, -410.532, 26.5944, 3.25189, 7200, 0, 0, -23.4497, -410.532, 26.5944, 0, 3800, 0, 0, 0),
(81169, 18700, 558, 0, 0, -23.2358, -406.71, 26.4469, 3.3108, 7200, 0, 0, -23.2358, -406.71, 26.4469, 0, 6100, 0, 0, 0);
UPDATE creature SET spawn_position_x = '-234.587891', spawn_position_y = '-686.836548', spawn_position_z = '19.582905', spawn_orientation = '5.507184',position_x = '-234.587891', position_y = '-686.836548', position_z = '19.582905', orientation = '5.507184' WHERE guid = '54996';
UPDATE `creature_template` SET `faction_A` = 14, `faction_H` = 14, `mindmg` = 1200, `maxdmg` = 1700, `minrangedmg` = 300, `maxrangedmg` = 420 WHERE `entry` = 17942;
DELETE FROM creature WHERE guid = '279225';
DELETE FROM creature_addon WHERE guid = '279225';
DELETE FROM creature_movement WHERE id = '279225';
DELETE FROM creature WHERE guid = '279226';
DELETE FROM creature_addon WHERE guid = '279226';
DELETE FROM creature_movement WHERE id = '279226';
DELETE FROM creature WHERE guid = '279227';
DELETE FROM creature_addon WHERE guid = '279227';
DELETE FROM creature_movement WHERE id = '279227';
DELETE FROM creature WHERE guid = '279228';
DELETE FROM creature_addon WHERE guid = '279228';
DELETE FROM creature_movement WHERE id = '279228';
DELETE FROM creature WHERE guid = '279229';
DELETE FROM creature_addon WHERE guid = '279229';
DELETE FROM creature_movement WHERE id = '279229';
DELETE FROM creature WHERE guid = '279230';
DELETE FROM creature_addon WHERE guid = '279230';
DELETE FROM creature_movement WHERE id = '279230';
DELETE FROM creature WHERE guid = '279231';
DELETE FROM creature_addon WHERE guid = '279231';
DELETE FROM creature_movement WHERE id = '279231';
DELETE FROM creature WHERE guid = '279232';
DELETE FROM creature_addon WHERE guid = '279232';
DELETE FROM creature_movement WHERE id = '279232';
DELETE FROM creature WHERE guid = '279233';
DELETE FROM creature_addon WHERE guid = '279233';
DELETE FROM creature_movement WHERE id = '279233';
DELETE FROM creature WHERE guid = '279234';
DELETE FROM creature_addon WHERE guid = '279234';
DELETE FROM creature_movement WHERE id = '279234';
UPDATE creature SET spawn_position_x = '-2789.213623', spawn_position_y = '8328.614258', spawn_position_z = '-94.057877', spawn_orientation = '6.185153',position_x = '-2789.213623', position_y = '8328.614258', position_z = '-94.057877', orientation = '6.185153' WHERE guid = '71704';
UPDATE creature SET spawn_position_x = '-2787.726807', spawn_position_y = '8343.354492', spawn_position_z = '-94.055382', spawn_orientation = '5.784602',position_x = '-2787.726807', position_y = '8343.354492', position_z = '-94.055382', orientation = '5.784602' WHERE guid = '71684';
DELETE FROM `creature_addon` WHERE (`guid`=61698);
DELETE FROM `creature` WHERE (`guid`=61698);
DELETE FROM `creature_addon` WHERE (`guid`=61716);
DELETE FROM `creature` WHERE (`guid`=61716);
DELETE FROM `creature` WHERE `id`=13876;
DELETE FROM `creature` WHERE `id`=16044;
DELETE FROM `creature` WHERE `id`=16045;
DELETE FROM `creature` WHERE `id`=16046;
DELETE FROM `creature` WHERE `id`=16047;
DELETE FROM `creature` WHERE `id`=16048;
DELETE FROM `creature` WHERE `id`=16465;
DELETE FROM `creature` WHERE `id`=16466;
DELETE FROM `creature` WHERE `id`=17047;
DELETE FROM `creature` WHERE `id`=17689;
DELETE FROM `creature` WHERE `id`=17696;
DELETE FROM `creature` WHERE `id`=17698;
DELETE FROM `creature_addon` WHERE (`guid`=70840);
DELETE FROM `creature` WHERE (`guid`=70840);
DELETE FROM `creature_addon` WHERE (`guid`=70841);
DELETE FROM `creature` WHERE (`guid`=70841);
DELETE FROM `creature` WHERE `id`=18263;
DELETE FROM `creature_addon` WHERE (`guid`=105181);
DELETE FROM `creature` WHERE (`guid`=105181);
DELETE FROM `creature_addon` WHERE (`guid`=59315);
DELETE FROM `creature_addon` WHERE (`guid`=59322);
DELETE FROM `creature_addon` WHERE (`guid`=59324);
DELETE FROM `creature_addon` WHERE (`guid`=60066);
DELETE FROM `creature_addon` WHERE (`guid`=73134);
DELETE FROM `creature` WHERE `id`=19656;
DELETE FROM `creature_addon` WHERE (`guid`=105371);
DELETE FROM `creature` WHERE (`guid`=105371);
DELETE FROM `creature_addon` WHERE (`guid`=105303);
DELETE FROM `creature` WHERE (`guid`=105303);
DELETE FROM `creature` WHERE `id`=20226;
DELETE FROM `creature_addon` WHERE (`guid`=63903);
DELETE FROM `creature` WHERE (`guid`=63903);
DELETE FROM `creature` WHERE `id`=20296;
DELETE FROM `creature` WHERE `id`=21039;
DELETE FROM `creature_addon` WHERE (`guid`=63403);
DELETE FROM `creature` WHERE (`guid`=63403);
DELETE FROM `creature` WHERE `id`=21241;
DELETE FROM `creature` WHERE `id`=21252;
DELETE FROM `creature` WHERE `id`=21261;
DELETE FROM `creature` WHERE `id`=21262;
DELETE FROM `creature` WHERE `id`=21310;
DELETE FROM `creature` WHERE `id`=21052;
UPDATE `creature_template` SET `minlevel` = 15, `maxlevel` = 17, `minhealth` = 3500, `maxhealth` = 3600, `mindmg` = 300, `maxdmg` = 500, `minrangedmg` = 50, `maxrangedmg` = 100, `mingold` = 0, `maxgold` = 0 WHERE `entry` = 21348;
DELETE FROM `creature` WHERE `id`=21429;
DELETE FROM `creature` WHERE `id`=21443;
DELETE FROM `creature_addon` WHERE (`guid`=67500);
DELETE FROM `creature` WHERE (`guid`=67500);
DELETE FROM `creature_addon` WHERE (`guid`=67501);
DELETE FROM `creature` WHERE (`guid`=67501);
DELETE FROM `creature_addon` WHERE (`guid`=67504);
DELETE FROM `creature` WHERE (`guid`=67504);
DELETE FROM `creature_addon` WHERE (`guid`=67505);
DELETE FROM `creature` WHERE (`guid`=67505);
DELETE FROM `creature_addon` WHERE (`guid`=67506);
DELETE FROM `creature` WHERE (`guid`=67506);
DELETE FROM `creature_addon` WHERE (`guid`=77307);
DELETE FROM `creature` WHERE (`guid`=77307);
DELETE FROM `creature_addon` WHERE (`guid`=67507);
DELETE FROM `creature` WHERE (`guid`=67507);
DELETE FROM `creature` WHERE (`guid`=283486);
DELETE FROM `creature` WHERE `id`=21898;
DELETE FROM `creature_addon` WHERE (`guid`=87759);
DELETE FROM `creature` WHERE (`guid`=87759);
DELETE FROM `creature_addon` WHERE (`guid`=87757);
DELETE FROM `creature` WHERE (`guid`=87757);
DELETE FROM `creature_addon` WHERE (`guid`=76417);
DELETE FROM `creature` WHERE (`guid`=76417);
DELETE FROM `creature_addon` WHERE (`guid`=58701);
DELETE FROM `creature` WHERE (`guid`=58701);
DELETE FROM `creature` WHERE `id`=23450;
UPDATE `creature_template` SET `maxhealth` = 130000, `mindmg` = 1000, `maxdmg` = 2500 WHERE `entry` = 18411;
UPDATE `creature_template` SET `mindmg` = 1000, `maxdmg` = 2500 WHERE `entry` = 20216;
UPDATE `creature_template` SET `mindmg` = 1000, `maxdmg` = 2500 WHERE `entry` = 20555;
UPDATE `creature_template` SET `mindmg` = 1000, `maxdmg` = 2500 WHERE `entry` = 20600;
UPDATE `creature_template` SET `mindmg` = 1000, `maxdmg` = 2500 WHERE `entry` = 21514;
UPDATE `creature_template` SET `mindmg` = 150, `maxdmg` = 300 WHERE `entry` = 19733;
UPDATE `creature_template` SET `mindmg` = 150, `maxdmg` = 300 WHERE `entry` = 18115;
UPDATE `creature_template` SET `mindmg` = 150, `maxdmg` = 300 WHERE `entry` = 18116;
UPDATE `creature_template` SET `mindmg` = 100, `maxdmg` = 250 WHERE `entry` = 18129;
UPDATE `creature_template` SET `mindmg` = 350, `maxdmg` = 550 WHERE `entry` = 18127;
UPDATE `creature_template` SET `minlevel` = 64, `maxlevel` = 64, `minhealth` = 4500, `maxhealth` = 5200 WHERE `entry` = 21869;
UPDATE `creature_template` SET `minlevel` = 64, `maxlevel` = 64, `minhealth` = 3500, `maxhealth` = 4200 WHERE `entry` = 21870;
DELETE FROM `creature` WHERE `id`=22517;
DELETE FROM `creature` WHERE `id`=22829;
DELETE FROM `creature` WHERE `id`=25173;
DELETE FROM creature WHERE guid = '87107';
DELETE FROM creature_addon WHERE guid = '87107';
DELETE FROM creature_movement WHERE id = '87107';
DELETE FROM creature WHERE guid = '87105';
DELETE FROM creature_addon WHERE guid = '87105';
DELETE FROM creature_movement WHERE id = '87105';
DELETE FROM creature WHERE guid = '87106';
DELETE FROM creature_addon WHERE guid = '87106';
DELETE FROM creature_movement WHERE id = '87106';
DELETE FROM creature WHERE guid = '87116';
DELETE FROM creature_addon WHERE guid = '87116';
DELETE FROM creature_movement WHERE id = '87116';
DELETE FROM creature WHERE guid = '87115';
DELETE FROM creature_addon WHERE guid = '87115';
DELETE FROM creature_movement WHERE id = '87115';
DELETE FROM creature WHERE guid = '87114';
DELETE FROM creature_addon WHERE guid = '87114';
DELETE FROM creature_movement WHERE id = '87114';
DELETE FROM creature WHERE guid = '87112';
DELETE FROM creature_addon WHERE guid = '87112';
DELETE FROM creature_movement WHERE id = '87112';
DELETE FROM creature WHERE guid = '87113';
DELETE FROM creature_addon WHERE guid = '87113';
DELETE FROM creature_movement WHERE id = '87113';
DELETE FROM creature WHERE guid = '87111';
DELETE FROM creature_addon WHERE guid = '87111';
DELETE FROM creature_movement WHERE id = '87111';
DELETE FROM creature WHERE guid = '87109';
DELETE FROM creature_addon WHERE guid = '87109';
DELETE FROM creature_movement WHERE id = '87109';
DELETE FROM creature WHERE guid = '87110';
DELETE FROM creature_addon WHERE guid = '87110';
DELETE FROM creature_movement WHERE id = '87110';
DELETE FROM creature WHERE guid = '87108';
DELETE FROM creature_addon WHERE guid = '87108';
DELETE FROM creature_movement WHERE id = '87108';
DELETE FROM creature WHERE guid = '283325';
DELETE FROM creature_addon WHERE guid = '283325';
DELETE FROM creature_movement WHERE id = '283325';
DELETE FROM creature WHERE guid = '64149';
DELETE FROM creature_addon WHERE guid = '64149';
DELETE FROM creature_movement WHERE id = '64149';
DELETE FROM creature WHERE guid = '64019';
DELETE FROM creature_addon WHERE guid = '64019';
DELETE FROM creature_movement WHERE id = '64019';
DELETE FROM creature WHERE guid = '283479';
DELETE FROM creature_addon WHERE guid = '283479';
DELETE FROM creature_movement WHERE id = '283479';
DELETE FROM creature WHERE guid = '283487';
DELETE FROM creature_addon WHERE guid = '283487';
DELETE FROM creature_movement WHERE id = '283487';
DELETE FROM creature WHERE guid = '283478';
DELETE FROM creature_addon WHERE guid = '283478';
DELETE FROM creature_movement WHERE id = '283478';
DELETE FROM creature WHERE guid = '283484';
DELETE FROM creature_addon WHERE guid = '283484';
DELETE FROM creature_movement WHERE id = '283484';
DELETE FROM creature WHERE guid = '283464';
DELETE FROM creature_addon WHERE guid = '283464';
DELETE FROM creature_movement WHERE id = '283464';
DELETE FROM creature WHERE guid = '283483';
DELETE FROM creature_addon WHERE guid = '283483';
DELETE FROM creature_movement WHERE id = '283483';
DELETE FROM creature WHERE guid = '283463';
DELETE FROM creature_addon WHERE guid = '283463';
DELETE FROM creature_movement WHERE id = '283463';
DELETE FROM creature WHERE guid = '283477';
DELETE FROM creature_addon WHERE guid = '283477';
DELETE FROM creature_movement WHERE id = '283477';
DELETE FROM creature WHERE guid = '283482';
DELETE FROM creature_addon WHERE guid = '283482';
DELETE FROM creature_movement WHERE id = '283482';
DELETE FROM creature WHERE guid = '283485';
DELETE FROM creature_addon WHERE guid = '283485';
DELETE FROM creature_movement WHERE id = '283485';
UPDATE creature SET spawn_position_x = '-3654.520508', spawn_position_y = '5137.247559', spawn_position_z = '-22.749603', spawn_orientation = '4.382509',position_x = '-3654.520508', position_y = '5137.247559', position_z = '-22.749603', orientation = '4.382509' WHERE guid = '73936';
UPDATE creature SET spawn_position_x = '-3668.440186', spawn_position_y = '5134.252930', spawn_position_z = '-22.366709', spawn_orientation = '4.924429',position_x = '-3668.440186', position_y = '5134.252930', position_z = '-22.366709', orientation = '4.924429' WHERE guid = '73926';
UPDATE creature SET spawn_position_x = '-3685.285889', spawn_position_y = '5114.232910', spawn_position_z = '-22.282557', spawn_orientation = '5.085431',position_x = '-3685.285889', position_y = '5114.232910', position_z = '-22.282557', orientation = '5.085431' WHERE guid = '73924';
UPDATE creature SET spawn_position_x = '-3679.503906', spawn_position_y = '5102.560547', spawn_position_z = '-21.588871', spawn_orientation = '4.924426',position_x = '-3679.503906', position_y = '5102.560547', position_z = '-21.588871', orientation = '4.924426' WHERE guid = '73950';
UPDATE creature SET spawn_position_x = '-3691.262939', spawn_position_y = '5095.234863', spawn_position_z = '-21.168114', spawn_orientation = '3.557834',position_x = '-3691.262939', position_y = '5095.234863', position_z = '-21.168114', orientation = '3.557834' WHERE guid = '73951';
UPDATE creature SET spawn_position_x = '-3709.692871', spawn_position_y = '5094.458496', spawn_position_z = '-21.290617', spawn_orientation = '3.703133',position_x = '-3709.692871', position_y = '5094.458496', position_z = '-21.290617', orientation = '3.703133' WHERE guid = '73967';
UPDATE creature SET spawn_position_x = '-3730.704346', spawn_position_y = '5099.586426', spawn_position_z = '-20.303230', spawn_orientation = '5.607718',position_x = '-3730.704346', position_y = '5099.586426', position_z = '-20.303230', orientation = '5.607718' WHERE guid = '73966';
UPDATE `creature_template` SET `minhealth` = 3500, `maxhealth` = 3500, `mingold` = 910, `maxgold` = 1000 WHERE `entry` = 10738;


# GO
UPDATE `gameobject_template` SET `type` = 27, `data0` = 18961 WHERE `entry` = 181575;
UPDATE `gameobject_template` SET `flags` = 40 WHERE `entry` = 181056;


DELETE FROM `db_version`;
INSERT INTO `db_version` VALUES ('YTDB_092_r36.02_rev5524');

REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (177964, 3, 1027, 'Fathom Stone', 0, 4, 0.5, 43, 177964, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
