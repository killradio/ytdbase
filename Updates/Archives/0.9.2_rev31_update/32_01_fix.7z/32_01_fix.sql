# Susanin
#������� �� �������
DELETE FROM `quest_start_scripts` WHERE `id`='1222';
DELETE FROM `quest_start_scripts` WHERE `id`='1270';
DELETE FROM `creature_movement` WHERE `id`='102310';
#���������� ��� ����������� ���������������� �������
UPDATE `quest_template` SET `MinLevel`='30' WHERE `entry`='1222';
UPDATE `quest_template` SET `MinLevel`='33' WHERE `entry`='1270';
UPDATE `quest_template` SET `type`='84' WHERE `entry`='1222';
UPDATE `quest_template` SET `QuestFlags`='0' WHERE `entry`='1222';
UPDATE `quest_template` SET `SpecialFlags`='2' WHERE `entry`='1222';
UPDATE `quest_template` SET `StartScript`='1222' WHERE `entry`='1222';
UPDATE `creature_template` SET `Faction_A`='35' WHERE `entry`='4880';
UPDATE `creature_template` SET `Faction_H`='35' WHERE `entry`='4880';
UPDATE `quest_template` SET `type`='84' WHERE `entry`='1270';
UPDATE `quest_template` SET `QuestFlags`='0' WHERE `entry`='1270';
UPDATE `quest_template` SET `SpecialFlags`='2' WHERE `entry`='1270';
UPDATE `quest_template` SET `StartScript`='1270' WHERE `entry`='1270';
#������� 1222
INSERT INTO `quest_start_scripts` VALUES ('1222', '1', '0', '0', '0', 'You must protect me from monsters, who are living in this forest!', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1222', '2', '3', '0', '14000', '','-2674.531494', '-3440.478516', '33.686016', '3.434529');
INSERT INTO `quest_start_scripts` VALUES ('1222', '16', '3', '0', '15000', '','-2711.173096', '-3435.059082', '33.192623', '2.978998');
INSERT INTO `quest_start_scripts` VALUES ('1222', '51', '3', '0', '13000', '','-2734.044434', '-3456.115967', '33.225353', '3.882206');
INSERT INTO `quest_start_scripts` VALUES ('1222', '104', '3', '0', '8000', '','-2749.636230', '-3457.256348', '32.824886', '2.649130');
INSERT INTO `quest_start_scripts` VALUES ('1222', '112', '3', '0', '6000', '','-2762.254883', '-3457.771484', '30.681337', '6.014560');
INSERT INTO `quest_start_scripts` VALUES ('1222', '118', '3', '0', '5000', '','-2776.997559', '-3456.120117', '30.248436', '3.030047');
INSERT INTO `quest_start_scripts` VALUES ('1222', '123', '3', '0', '8000', '','-2805.488525', '-3450.274170', '29.062374', '2.488124');
INSERT INTO `quest_start_scripts` VALUES ('1222', '131', '3', '0', '3000', '','-2809.769043', '-3447.138672', '30.094843', '2.543103');
INSERT INTO `quest_start_scripts` VALUES ('1222', '134', '3', '0', '6000', '','-2824.001221', '-3440.616211', '33.404976', '5.987076');
INSERT INTO `quest_start_scripts` VALUES ('1222', '160', '3', '0', '7000', '','-2840.204346', '-3439.018066', '34.100788', '3.014341');
INSERT INTO `quest_start_scripts` VALUES ('1222', '167', '3', '0', '21000', '','-2878.485596', '-3482.807129', '34.361977', '4.025108');
INSERT INTO `quest_start_scripts` VALUES ('1222', '188', '3', '0', '11000', '','-2878.352783', '-3511.508545', '34.482594', '4.716259');
INSERT INTO `quest_start_scripts` VALUES ('1222', '199', '0', '0', '0', 'This part of forest are very danger for us. We must be a careful!', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1222', '199', '3', '0', '3000', '','-2873.988037', '-3514.844238', '34.529823', '5.623396');
INSERT INTO `quest_start_scripts` VALUES ('1222', '202', '3', '0', '2000', '','-2866.706055', '-3519.056641', '36.367378', '5.690155');
INSERT INTO `quest_start_scripts` VALUES ('1222', '205', '3', '0', '11000', '','-2850.745361', '-3539.384033', '36.457321', '5.405055');
INSERT INTO `quest_start_scripts` VALUES ('1222', '220', '3', '0', '9000', '','-2844.493896', '-3557.697021', '35.558750', '5.033561');
INSERT INTO `quest_start_scripts` VALUES ('1222', '230', '3', '0', '8000', '','-2841.362305', '-3574.592041', '35.505569', '4.998217');
INSERT INTO `quest_start_scripts` VALUES ('1222', '240', '3', '0', '8000', '','-2841.125244', '-3596.947754', '36.769871', '5.269182');
INSERT INTO `quest_start_scripts` VALUES ('1222', '250', '0', '0', '0', 'Kill two monsters, who stay near Bogbean plant and then I gather a bogbean.', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1222', '280', '3', '0', '5000', '','-2828.833252', '-3597.302734', '31.289093', '6.250928');
INSERT INTO `quest_start_scripts` VALUES ('1222', '285', '3', '0', '3000', '','-2822.131592', '-3596.328125', '31.268417', '0.097333');
INSERT INTO `quest_start_scripts` VALUES ('1222', '288', '0', '0', '0', 'I am gathering a bogbean. It takes some time.', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1222', '290', '1', '69', '0', '', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1222', '320', '3', '0', '3000', '','-2829.083740', '-3597.819336', '31.307018', '3.344955');
INSERT INTO `quest_start_scripts` VALUES ('1222', '323', '3', '0', '12000', '','-2859.278076', '-3602.328125', '42.297970', '3.215364');
INSERT INTO `quest_start_scripts` VALUES ('1222', '335', '3', '0', '7000', '','-2881.640137', '-3601.284180', '42.211067', '0.242631');
INSERT INTO `quest_start_scripts` VALUES ('1222', '342', '3', '0', '8000', '','-2904.039063', '-3601.350342', '34.969025', '3.219289');
INSERT INTO `quest_start_scripts` VALUES ('1222', '372', '3', '0', '7000', '','-2907.598877', '-3612.729736', '34.243378', '4.413094');
INSERT INTO `quest_start_scripts` VALUES ('1222', '380', '7', '1222', '10', '', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1222', '380', '0', '0', '0', 'Thanks you for help.', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1222', '385', '3', '0', '0', '','-2646.860107', '-3435.469971', '35.174599', '6.122950');
#������� 1270
INSERT INTO `quest_start_scripts` VALUES ('1270', '1', '0', '0', '0', 'You must protect me from monsters, who are living in this forest!', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1270', '2', '3', '0', '14000', '','-2674.531494', '-3440.478516', '33.686016', '3.434529');
INSERT INTO `quest_start_scripts` VALUES ('1270', '16', '3', '0', '15000', '','-2711.173096', '-3435.059082', '33.192623', '2.978998');
INSERT INTO `quest_start_scripts` VALUES ('1270', '51', '3', '0', '13000', '','-2734.044434', '-3456.115967', '33.225353', '3.882206');
INSERT INTO `quest_start_scripts` VALUES ('1270', '104', '3', '0', '8000', '','-2749.636230', '-3457.256348', '32.824886', '2.649130');
INSERT INTO `quest_start_scripts` VALUES ('1270', '112', '3', '0', '6000', '','-2762.254883', '-3457.771484', '30.681337', '6.014560');
INSERT INTO `quest_start_scripts` VALUES ('1270', '118', '3', '0', '5000', '','-2776.997559', '-3456.120117', '30.248436', '3.030047');
INSERT INTO `quest_start_scripts` VALUES ('1270', '123', '3', '0', '8000', '','-2805.488525', '-3450.274170', '29.062374', '2.488124');
INSERT INTO `quest_start_scripts` VALUES ('1270', '131', '3', '0', '3000', '','-2809.769043', '-3447.138672', '30.094843', '2.543103');
INSERT INTO `quest_start_scripts` VALUES ('1270', '134', '3', '0', '6000', '','-2824.001221', '-3440.616211', '33.404976', '5.987076');
INSERT INTO `quest_start_scripts` VALUES ('1270', '160', '3', '0', '7000', '','-2840.204346', '-3439.018066', '34.100788', '3.014341');
INSERT INTO `quest_start_scripts` VALUES ('1270', '167', '3', '0', '21000', '','-2878.485596', '-3482.807129', '34.361977', '4.025108');
INSERT INTO `quest_start_scripts` VALUES ('1270', '188', '3', '0', '11000', '','-2878.352783', '-3511.508545', '34.482594', '4.716259');
INSERT INTO `quest_start_scripts` VALUES ('1270', '199', '0', '0', '0', 'This part of forest are very danger for us. We must be a careful!', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1270', '199', '3', '0', '3000', '','-2873.988037', '-3514.844238', '34.529823', '5.623396');
INSERT INTO `quest_start_scripts` VALUES ('1270', '202', '3', '0', '2000', '','-2866.706055', '-3519.056641', '36.367378', '5.690155');
INSERT INTO `quest_start_scripts` VALUES ('1270', '205', '3', '0', '11000', '','-2850.745361', '-3539.384033', '36.457321', '5.405055');
INSERT INTO `quest_start_scripts` VALUES ('1270', '220', '3', '0', '9000', '','-2844.493896', '-3557.697021', '35.558750', '5.033561');
INSERT INTO `quest_start_scripts` VALUES ('1270', '230', '3', '0', '8000', '','-2841.362305', '-3574.592041', '35.505569', '4.998217');
INSERT INTO `quest_start_scripts` VALUES ('1270', '240', '3', '0', '8000', '','-2841.125244', '-3596.947754', '36.769871', '5.269182');
INSERT INTO `quest_start_scripts` VALUES ('1270', '250', '0', '0', '0', 'Kill two monsters, who stay near Bogbean plant and then I gather a bogbean.', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1270', '280', '3', '0', '5000', '','-2828.833252', '-3597.302734', '31.289093', '6.250928');
INSERT INTO `quest_start_scripts` VALUES ('1270', '285', '3', '0', '3000', '','-2822.131592', '-3596.328125', '31.268417', '0.097333');
INSERT INTO `quest_start_scripts` VALUES ('1270', '288', '0', '0', '0', 'I am gathering a bogbean. It takes some time.', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1270', '290', '1', '69', '0', '', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1270', '320', '3', '0', '3000', '','-2829.083740', '-3597.819336', '31.307018', '3.344955');
INSERT INTO `quest_start_scripts` VALUES ('1270', '323', '3', '0', '12000', '','-2859.278076', '-3602.328125', '42.297970', '3.215364');
INSERT INTO `quest_start_scripts` VALUES ('1270', '335', '3', '0', '7000', '','-2881.640137', '-3601.284180', '42.211067', '0.242631');
INSERT INTO `quest_start_scripts` VALUES ('1270', '342', '3', '0', '8000', '','-2904.039063', '-3601.350342', '34.969025', '3.219289');
INSERT INTO `quest_start_scripts` VALUES ('1270', '372', '3', '0', '7000', '','-2907.598877', '-3612.729736', '34.243378', '4.413094');
INSERT INTO `quest_start_scripts` VALUES ('1270', '380', '7', '1222', '10', '', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1270', '380', '0', '0', '0', 'Thanks you for help.', '0', '0', '0', '0');
INSERT INTO `quest_start_scripts` VALUES ('1270', '385', '3', '0', '0', '','-2646.860107', '-3435.469971', '35.174599', '6.122950');

# Slavik
SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `dbc` (
  `entry` int(11) NOT NULL default '0',
  `go` char(255) default NULL,
  PRIMARY KEY  (`entry`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `dbc` VALUES ('1', 'Anvil');
INSERT INTO `dbc` VALUES ('2', 'Loom');
INSERT INTO `dbc` VALUES ('3', 'Forge');
INSERT INTO `dbc` VALUES ('4', 'Cooking Fire');
INSERT INTO `dbc` VALUES ('5', 'Shards of Myzrael');
INSERT INTO `dbc` VALUES ('6', 'Winterhoof Water Well');
INSERT INTO `dbc` VALUES ('7', 'Thunderhorn Water Well');
INSERT INTO `dbc` VALUES ('8', 'Wildmane Water Well');
INSERT INTO `dbc` VALUES ('9', 'Tribal Fire');
INSERT INTO `dbc` VALUES ('10', 'Machine Shop');
INSERT INTO `dbc` VALUES ('11', 'Shadowglen Moonwell');
INSERT INTO `dbc` VALUES ('12', 'Starbreeze Village Moonwell');
INSERT INTO `dbc` VALUES ('13', 'Pools of Arlithrien Moonwell');
INSERT INTO `dbc` VALUES ('14', 'Oracle Glade Moonwell');
INSERT INTO `dbc` VALUES ('15', 'Venture Co. Airport');
INSERT INTO `dbc` VALUES ('16', 'Venture Co. Wagon (Blue)');
INSERT INTO `dbc` VALUES ('17', 'Venture Co. Wagon (Red)');
INSERT INTO `dbc` VALUES ('18', 'NG-5 Explosives (Red)');
INSERT INTO `dbc` VALUES ('19', 'NG-5 Explosives (Blue)');
INSERT INTO `dbc` VALUES ('20', 'Flame of Uzel');
INSERT INTO `dbc` VALUES ('21', 'Ashenvale Moonwell');
INSERT INTO `dbc` VALUES ('22', 'Seaworn Altar');
INSERT INTO `dbc` VALUES ('23', 'Nearby Tubers');
INSERT INTO `dbc` VALUES ('43', 'Undercity Summoning Circle');
INSERT INTO `dbc` VALUES ('63', 'Shaman Shrine');
INSERT INTO `dbc` VALUES ('83', 'Stormwind Summoning Circle');
INSERT INTO `dbc` VALUES ('103', 'Barrens Summoning Circle');
INSERT INTO `dbc` VALUES ('123', 'Mirror Lake Waterfall');
INSERT INTO `dbc` VALUES ('143', 'Talon Den');
INSERT INTO `dbc` VALUES ('163', 'Xavian Waterfall');
INSERT INTO `dbc` VALUES ('164', 'Stone of Outer Binding');
INSERT INTO `dbc` VALUES ('183', 'Mana Rift Disturbance');
INSERT INTO `dbc` VALUES ('203', 'Orgrimmar Summoning Circle');
INSERT INTO `dbc` VALUES ('223', 'Ruins of Stardust Fountain');
INSERT INTO `dbc` VALUES ('224', 'Quilboar Watering Hole');
INSERT INTO `dbc` VALUES ('225', 'Water Purity - Silverpine');
INSERT INTO `dbc` VALUES ('226', 'Spring Well');
INSERT INTO `dbc` VALUES ('243', 'Temple of the Moon Fountain');
INSERT INTO `dbc` VALUES ('263', 'Jintha\'Alor Altar');
INSERT INTO `dbc` VALUES ('264', 'Pirate Ship Bilge');
INSERT INTO `dbc` VALUES ('283', 'Equinex Monolith');
INSERT INTO `dbc` VALUES ('303', 'Witherbark Village');
INSERT INTO `dbc` VALUES ('304', 'Shadra\'Alor Altar');
INSERT INTO `dbc` VALUES ('323', 'Sandsorrow Watch Water Hole');
INSERT INTO `dbc` VALUES ('343', 'Hatetalon Stones');
INSERT INTO `dbc` VALUES ('363', 'Echeyakee\'s Lair');
INSERT INTO `dbc` VALUES ('383', 'The Dead Tree');
INSERT INTO `dbc` VALUES ('403', 'Makeshift Helipad');
INSERT INTO `dbc` VALUES ('423', 'Circle of Aquementas');
INSERT INTO `dbc` VALUES ('424', 'Sanctum of the Fallen God');
INSERT INTO `dbc` VALUES ('443', 'the First Tide Pool');
INSERT INTO `dbc` VALUES ('444', 'the Second Tide Pool');
INSERT INTO `dbc` VALUES ('445', 'the Third Tide Pool');
INSERT INTO `dbc` VALUES ('446', 'the Fourth Tide Pool');
INSERT INTO `dbc` VALUES ('463', 'Gorishi Hive Hatchery');
INSERT INTO `dbc` VALUES ('483', 'Miblon Snarltooth');
INSERT INTO `dbc` VALUES ('503', 'Gadgetzan Graveyard');
INSERT INTO `dbc` VALUES ('523', 'the ruins of Irontree Woods');
INSERT INTO `dbc` VALUES ('543', 'Black Forge');
INSERT INTO `dbc` VALUES ('563', 'Golakka Crater');
INSERT INTO `dbc` VALUES ('583', 'Tomb of the Seven');
INSERT INTO `dbc` VALUES ('603', 'Flat Un\'Goro Rock');
INSERT INTO `dbc` VALUES ('604', 'Preserved Threshadon Carcass');
INSERT INTO `dbc` VALUES ('623', 'Black Anvil');
INSERT INTO `dbc` VALUES ('643', 'Gorishi Silithid Crystal');
INSERT INTO `dbc` VALUES ('644', 'Corrupted Moonwell');
INSERT INTO `dbc` VALUES ('663', 'Alchemy Lab');
INSERT INTO `dbc` VALUES ('683', 'Unforged Seal of Ascension');
INSERT INTO `dbc` VALUES ('703', 'Auberdine Moonwell');
INSERT INTO `dbc` VALUES ('704', 'Blackwood Furbolg North Bonfire');
INSERT INTO `dbc` VALUES ('705', 'Cliffspring River Waterfall');
INSERT INTO `dbc` VALUES ('723', 'Fire Plume Ridge Hot Spot');
INSERT INTO `dbc` VALUES ('743', 'Urok\'s Tribute Pile');
INSERT INTO `dbc` VALUES ('763', 'Andorhal Silo Temporal Rift');
INSERT INTO `dbc` VALUES ('783', 'Stone of Shy-Rotam');
INSERT INTO `dbc` VALUES ('803', 'Sacred Fire of Life');
INSERT INTO `dbc` VALUES ('804', 'Scarlet Crusade Forward Camp');
INSERT INTO `dbc` VALUES ('805', 'Andorhal Tower');
INSERT INTO `dbc` VALUES ('823', 'Scholomance Viewing Room');
INSERT INTO `dbc` VALUES ('843', 'the Jaedenar Corrupt Moon Well');
INSERT INTO `dbc` VALUES ('863', 'Umi\'s Friend');
INSERT INTO `dbc` VALUES ('883', 'Moonwell');
INSERT INTO `dbc` VALUES ('903', 'Fire Plume Ridge Lava Lake');
INSERT INTO `dbc` VALUES ('923', 'the crate in the center of the Northridge Lumber Mill');
INSERT INTO `dbc` VALUES ('943', 'Moonkin Stone');
INSERT INTO `dbc` VALUES ('944', 'Darrowshire Town Square');
INSERT INTO `dbc` VALUES ('963', 'Bright Light Beam');
INSERT INTO `dbc` VALUES ('983', 'Mark of Detonation');
INSERT INTO `dbc` VALUES ('1003', 'Cliffspring Falls Cave Mouth');
INSERT INTO `dbc` VALUES ('1004', 'Dreadmist Peak Pool');
INSERT INTO `dbc` VALUES ('1023', 'The Dead Goliaths');
INSERT INTO `dbc` VALUES ('1043', 'Shrine of Remulos');
INSERT INTO `dbc` VALUES ('1063', 'Foulweald Totem Mound');
INSERT INTO `dbc` VALUES ('1083', 'Dire Pool');
INSERT INTO `dbc` VALUES ('1103', 'Maraudon Portal');
INSERT INTO `dbc` VALUES ('1123', 'Horde Globe of Scrying');
INSERT INTO `dbc` VALUES ('1143', 'Eastern Crater');
INSERT INTO `dbc` VALUES ('1144', 'Western Crater');
INSERT INTO `dbc` VALUES ('1145', 'Snowfall Graveyard');
INSERT INTO `dbc` VALUES ('1163', 'Alliance Globe of Scrying');
INSERT INTO `dbc` VALUES ('1164', 'Dun Baldar Courtyard');
INSERT INTO `dbc` VALUES ('1165', 'Frostwolf Keep Courtyard');
INSERT INTO `dbc` VALUES ('1184', 'East Crater');
INSERT INTO `dbc` VALUES ('1185', 'West Crater');
INSERT INTO `dbc` VALUES ('1203', 'Orange Crystal Pool');
INSERT INTO `dbc` VALUES ('1223', 'Onyxia\'s Flame Breath');
INSERT INTO `dbc` VALUES ('1243', 'Kroshius\' Remains');
INSERT INTO `dbc` VALUES ('1263', 'Pedestal of Immol\'thar');
INSERT INTO `dbc` VALUES ('1264', 'Circle of Dark Summoning');
INSERT INTO `dbc` VALUES ('1283', 'The Great Ossuary');
INSERT INTO `dbc` VALUES ('1284', 'Terrordale Haunting Spirit');
INSERT INTO `dbc` VALUES ('1303', 'Aerie Peak Town Center');
INSERT INTO `dbc` VALUES ('1323', 'Uther\'s Tomb Statue');
INSERT INTO `dbc` VALUES ('1324', 'Grom\'s Monument');
INSERT INTO `dbc` VALUES ('1343', 'Pagle\'s Pointe');
INSERT INTO `dbc` VALUES ('1344', 'Altar of Zanza');
INSERT INTO `dbc` VALUES ('1345', 'Southshore');
INSERT INTO `dbc` VALUES ('1346', 'Bones of Grakkarond');
INSERT INTO `dbc` VALUES ('1347', 'Forsaken Stink Bomb');
INSERT INTO `dbc` VALUES ('1348', 'Drop-Off Point');
INSERT INTO `dbc` VALUES ('1349', 'Swirling Maelstrom');
INSERT INTO `dbc` VALUES ('1350', 'High Chief Winterfall\'s Cave');
INSERT INTO `dbc` VALUES ('1351', 'Firework Launcher');
INSERT INTO `dbc` VALUES ('1352', 'Cluster Launcher');
INSERT INTO `dbc` VALUES ('1353', 'Greater Moonlight');
INSERT INTO `dbc` VALUES ('1354', 'Voone\'s Chamber');
INSERT INTO `dbc` VALUES ('1355', 'Alzzin\'s Chamber');
INSERT INTO `dbc` VALUES ('1356', 'The Crimson Throne');
INSERT INTO `dbc` VALUES ('1357', 'Ras Frostwhisper\'s Chamber');
INSERT INTO `dbc` VALUES ('1358', 'The Beast\'s Chamber');
INSERT INTO `dbc` VALUES ('1359', 'Haunted Locus');
INSERT INTO `dbc` VALUES ('1360', 'Blackrock Depths Arena');
INSERT INTO `dbc` VALUES ('1361', '[PH] Crystal Corpse');
INSERT INTO `dbc` VALUES ('1362', 'Icebellow Anvil');
INSERT INTO `dbc` VALUES ('1363', 'Eversong Runestone');
INSERT INTO `dbc` VALUES ('1364', 'Consecrated Earth');
INSERT INTO `dbc` VALUES ('1365', 'Midsummer Bonfire');
INSERT INTO `dbc` VALUES ('1366', 'Maypole');
INSERT INTO `dbc` VALUES ('1367', 'Altar of Aggonar');
INSERT INTO `dbc` VALUES ('1368', 'Bones of Aggonar');
INSERT INTO `dbc` VALUES ('1369', 'School of Red Snapper');
INSERT INTO `dbc` VALUES ('1370', 'Krun Spinebreaker\'s Corpse');
INSERT INTO `dbc` VALUES ('1371', 'Thalanaar Moonwell');
INSERT INTO `dbc` VALUES ('1372', 'Concealed Control Panel');
INSERT INTO `dbc` VALUES ('1373', 'Altar of Naias');
INSERT INTO `dbc` VALUES ('1374', 'Discreet Location');
INSERT INTO `dbc` VALUES ('1375', 'Rune of Summoning');
INSERT INTO `dbc` VALUES ('1376', 'Fel Brazier');
INSERT INTO `dbc` VALUES ('1377', 'you to be in Traitor\'s Cove while the Naga Flag is up.');
INSERT INTO `dbc` VALUES ('1378', 'Sedai\'s Corpse');
INSERT INTO `dbc` VALUES ('1379', 'Nazzivus Monument');
INSERT INTO `dbc` VALUES ('1380', 'Impact Site Crystal');
INSERT INTO `dbc` VALUES ('1381', 'Altered Bloodmyst Crystal');
INSERT INTO `dbc` VALUES ('1382', 'Axxarien Crystal');
INSERT INTO `dbc` VALUES ('1383', 'the southern end of the Master\'s Terrace');
INSERT INTO `dbc` VALUES ('1384', 'Medivh\'s Telescope');
INSERT INTO `dbc` VALUES ('1385', 'Alonsus Chapel Eternal Flame');
INSERT INTO `dbc` VALUES ('1386', 'Bloodmyst Waterfall');
INSERT INTO `dbc` VALUES ('1387', 'Steam Pump Controls');
INSERT INTO `dbc` VALUES ('1388', 'Windyreed Hut');
INSERT INTO `dbc` VALUES ('1389', 'Earthen Brand');
INSERT INTO `dbc` VALUES ('1390', 'Underground Water Source');
INSERT INTO `dbc` VALUES ('1391', 'Boha\'mu Ruins Stairs');
INSERT INTO `dbc` VALUES ('1392', 'Daggerfen Rock');
INSERT INTO `dbc` VALUES ('1393', 'Burning Blade pyre in the Burning Blade Ruins.');
INSERT INTO `dbc` VALUES ('1394', 'Ysiel\'s Balcony');
INSERT INTO `dbc` VALUES ('1395', 'Blazing Warmaul Pyre');
INSERT INTO `dbc` VALUES ('1396', 'Veil Shalas Totem');
INSERT INTO `dbc` VALUES ('1397', 'Trampled Skeleton');
INSERT INTO `dbc` VALUES ('1398', 'Alliance Cannon');
INSERT INTO `dbc` VALUES ('1399', 'Horde Blade Thrower');
INSERT INTO `dbc` VALUES ('1400', 'Legion Antenna');
INSERT INTO `dbc` VALUES ('1401', 'Scorched Grove Runestone');
INSERT INTO `dbc` VALUES ('1402', 'Bookcase');
INSERT INTO `dbc` VALUES ('1403', 'Weapon Rack');
INSERT INTO `dbc` VALUES ('1404', 'Dresser');
INSERT INTO `dbc` VALUES ('1405', 'Footlocker');
INSERT INTO `dbc` VALUES ('1406', 'Ruined Alliance Siege Tower');
INSERT INTO `dbc` VALUES ('1407', 'Uncontrolled Scrap Reaver X6000');
INSERT INTO `dbc` VALUES ('1408', 'Kirin\'Var Rune');
INSERT INTO `dbc` VALUES ('1409', 'Archmage Vargoth\'s Orb');
INSERT INTO `dbc` VALUES ('1410', 'Elrendar Falls');
INSERT INTO `dbc` VALUES ('1411', 'Dragon Skeleton');
INSERT INTO `dbc` VALUES ('1412', 'Ethereal Teleport Pad');
INSERT INTO `dbc` VALUES ('1413', 'Arklon Brazier');
INSERT INTO `dbc` VALUES ('1414', 'Void Stone');
INSERT INTO `dbc` VALUES ('1415', 'Manaforge B\'naar Pipe');
INSERT INTO `dbc` VALUES ('1416', 'Draenei Banner');
INSERT INTO `dbc` VALUES ('1417', 'Earthbinder\'s Circle');
INSERT INTO `dbc` VALUES ('1418', 'Salhadaar\'s Power Conduit');
INSERT INTO `dbc` VALUES ('1419', 'Socrethar\'s Teleporter');
INSERT INTO `dbc` VALUES ('1420', 'Eco-Dome Suthron Generator');
INSERT INTO `dbc` VALUES ('1421', 'you to be closer to Manaforge Ultris');
INSERT INTO `dbc` VALUES ('1422', 'Northmaul Tower');
INSERT INTO `dbc` VALUES ('1423', 'Altar of Shadows');
INSERT INTO `dbc` VALUES ('1424', 'Shadowmoon Tuber Mound');
INSERT INTO `dbc` VALUES ('1425', 'Rokgah Bloodgrip');
INSERT INTO `dbc` VALUES ('1426', 'Mana Loom');
INSERT INTO `dbc` VALUES ('1427', 'Ancient Draenei Altar');
INSERT INTO `dbc` VALUES ('1428', 'Ogre Building Entrance');
INSERT INTO `dbc` VALUES ('1429', 'Blade\'s Edge Arakkoa Circle');
INSERT INTO `dbc` VALUES ('1430', 'Lashh\'an Spell Circle');
INSERT INTO `dbc` VALUES ('1431', 'Vekh\'nir Circle of Power');
INSERT INTO `dbc` VALUES ('1432', 'you to be at the end of the bridge.');
INSERT INTO `dbc` VALUES ('1433', 'Torgos\'s Bane');
INSERT INTO `dbc` VALUES ('1434', 'Vekh\'nir Spell Circle');
INSERT INTO `dbc` VALUES ('1435', 'you to be standing next to Gul\'dan at the Altar of Damnation.');
INSERT INTO `dbc` VALUES ('1436', 'Legion Hold Teleporter');
INSERT INTO `dbc` VALUES ('1437', 'Ruuan\'ok Oracle Circle');
INSERT INTO `dbc` VALUES ('1438', 'Legion Communication Device');
INSERT INTO `dbc` VALUES ('1439', 'Foreman Razelcraz');
INSERT INTO `dbc` VALUES ('1440', 'Portal at Marshlight Lake');
INSERT INTO `dbc` VALUES ('1441', 'Blade\'s Edge - Quest - Bird Spying');
INSERT INTO `dbc` VALUES ('1442', 'Malukaz\'s Candles');
INSERT INTO `dbc` VALUES ('1443', 'Bleeding Hollow Forge');
INSERT INTO `dbc` VALUES ('1444', 'Marmot Den');
INSERT INTO `dbc` VALUES ('1445', 'Gehenna Teleporter');
INSERT INTO `dbc` VALUES ('1446', 'Force Commander Gorax\'s Corpse');
INSERT INTO `dbc` VALUES ('1447', 'Zeth\'Gor Tower');
INSERT INTO `dbc` VALUES ('1448', 'Unguarded Summoning Site');
INSERT INTO `dbc` VALUES ('1449', 'Locked Wyvern Cage');
INSERT INTO `dbc` VALUES ('1450', 'Gorgrom\'s Corpse');
INSERT INTO `dbc` VALUES ('1451', 'Death\'s Door Fel Cannon');
INSERT INTO `dbc` VALUES ('1452', 'Writhing Mound Summoning Circle');
INSERT INTO `dbc` VALUES ('1453', 'Altar of Goc and that Goc has not been summoned');
INSERT INTO `dbc` VALUES ('1454', 'The Raven\'s Claw');
INSERT INTO `dbc` VALUES ('1455', 'Arakkoa Shrine');
INSERT INTO `dbc` VALUES ('1456', 'Soulgrinder\'s Altar');
INSERT INTO `dbc` VALUES ('1457', 'Shartuul\'s Transporter Platform');
INSERT INTO `dbc` VALUES ('1458', 'Shipwreck Debris');
INSERT INTO `dbc` VALUES ('1459', 'Blackhoof Village Windmill');
INSERT INTO `dbc` VALUES ('1460', 'Grimtotem Tent');
INSERT INTO `dbc` VALUES ('1461', 'Hyal Family Monument');
INSERT INTO `dbc` VALUES ('1462', 'Burning Troll Hut');
INSERT INTO `dbc` VALUES ('1463', 'Entrance to Onyxia\'s Lair');
INSERT INTO `dbc` VALUES ('1464', 'Swamplight Manor Dock');
INSERT INTO `dbc` VALUES ('1471', 'Standing at the Booth Counter');
INSERT INTO `dbc` VALUES ('1478', 'Brewfest - Mug Request');

update gameobject_template set type=8 where name in (select go from dbc) and type<>8 ;
update gameobject_template set data0=(select entry from dbc where dbc.go=gameobject_template.name) where name in (select go from dbc) and type=8 ;
update gameobject_template set data1=10 where name in (select go from dbc) and type=8 ;
drop table dbc;


# QUEST
DELETE FROM `creature_questrelation` WHERE `quest` = 9380;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 9380;
DELETE FROM `quest_template` WHERE `entry` = 9380;
UPDATE quest_template SET RewMoneyMaxLevel = 0 WHERE entry = '10056';
# Redeeming the Dead � �������� ������ ����������� ��� ��������! �����!
INSERT IGNORE INTO `spell_script_target` VALUES ('31225', '1', '17768');
UPDATE quest_template SET QuestFlags = 1 WHERE entry = '1738';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1050' WHERE (`entry`='2358');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='630' WHERE (`entry`='9568');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='850', `RewOrReqMoney`='540' WHERE (`entry`='7702');
UPDATE `quest_template` SET `RewMoneyMaxLevel` = '0' WHERE `quest_template`.`entry` =8554;

-- �������� ����� � ������������ � ������ 2.3 � ��
UPDATE `quest_template` SET `RewChoiceItemId1`='34416',`RewChoiceItemId2`='34417',`RewChoiceItemCount1`='1',`RewChoiceItemCount2`='1' WHERE (`entry`='4267');

# ITEM
UPDATE `item_template` SET `BuyPrice`='10000' WHERE `entry` in (33012);
UPDATE `item_template` SET `BuyPrice`='20000' WHERE `entry` in (33014);
UPDATE `item_template` SET `ScriptName`='' WHERE (`entry`='6712');
UPDATE `item_template` SET `ScriptName`='' WHERE (`entry`='25653');
# Mysterious Shell ��������� �� 1 ����� http://www.wowhead.com/?item=34582
UPDATE `item_template` SET `BuyCount` = '200' WHERE `entry` =34582;
# Auchenai Healing Potion, Auchenai Mana Potion
UPDATE `item_template` SET `ExtendedCost`='1992' WHERE `entry` in (32947, 32948);
# Cenarion Healing Salve, Cenarion Mana Salve
UPDATE `item_template` SET `BuyCount`='3', `ExtendedCost`='1963' WHERE `entry` in (32904, 32903);
# y2kcat
UPDATE `item_template` SET `entry`='6265',`class`='15',`subclass`='1',`unk0`='-1',`name`='Soul Shard',`displayid`='6689',`Quality`='1',`Flags`='0',`BuyCount`='1',`BuyPrice`='0',`SellPrice`='0',`InventoryType`='0',`AllowableClass`='-1',`AllowableRace`='-1',`ItemLevel`='10',`RequiredLevel`='0',`RequiredSkill`='0',`RequiredSkillRank`='0',`requiredspell`='0',`requiredhonorrank`='0',`RequiredCityRank`='0',`RequiredReputationFaction`='0',`RequiredReputationRank`='0',`maxcount`='0',`stackable`='1',`ContainerSlots`='0',`stat_type1`='0',`stat_value1`='0',`stat_type2`='0',`stat_value2`='0',`stat_type3`='0',`stat_value3`='0',`stat_type4`='0',`stat_value4`='0',`stat_type5`='0',`stat_value5`='0',`stat_type6`='0',`stat_value6`='0',`stat_type7`='0',`stat_value7`='0',`stat_type8`='0',`stat_value8`='0',`stat_type9`='0',`stat_value9`='0',`stat_type10`='0',`stat_value10`='0',`dmg_min1`='0',`dmg_max1`='0',`dmg_type1`='0',`dmg_min2`='0',`dmg_max2`='0',`dmg_type2`='0',`dmg_min3`='0',`dmg_max3`='0',`dmg_type3`='0',`dmg_min4`='0',`dmg_max4`='0',`dmg_type4`='0',`dmg_min5`='0',`dmg_max5`='0',`dmg_type5`='0',`armor`='0',`holy_res`='0',`fire_res`='0',`nature_res`='0',`frost_res`='0',`shadow_res`='0',`arcane_res`='0',`delay`='0',`ammo_type`='0',`RangedModRange`='0',`spellid_1`='0',`spelltrigger_1`='0',`spellcharges_1`='0',`spellppmRate_1`='0',`spellcooldown_1`='-1',`spellcategory_1`='0',`spellcategorycooldown_1`='-1',`spellid_2`='0',`spelltrigger_2`='0',`spellcharges_2`='0',`spellppmRate_2`='0',`spellcooldown_2`='-1',`spellcategory_2`='0',`spellcategorycooldown_2`='-1',`spellid_3`='0',`spelltrigger_3`='0',`spellcharges_3`='0',`spellppmRate_3`='0',`spellcooldown_3`='-1',`spellcategory_3`='0',`spellcategorycooldown_3`='-1',`spellid_4`='0',`spelltrigger_4`='0',`spellcharges_4`='0',`spellppmRate_4`='0',`spellcooldown_4`='-1',`spellcategory_4`='0',`spellcategorycooldown_4`='-1',`spellid_5`='0',`spelltrigger_5`='0',`spellcharges_5`='0',`spellppmRate_5`='0',`spellcooldown_5`='-1',`spellcategory_5`='0',`spellcategorycooldown_5`='-1',`bonding`='1',`description`='',`PageText`='0',`LanguageID`='0',`PageMaterial`='0',`startquest`='0',`lockid`='0',`Material`='-1',`sheath`='0',`RandomProperty`='0',`RandomSuffix`='0',`block`='0',`itemset`='0',`MaxDurability`='0',`area`='0',`Map`='0',`BagFamily`='4',`TotemCategory`='0',`socketColor_1`='0',`socketContent_1`='0',`socketColor_2`='0',`socketContent_2`='0',`socketColor_3`='0',`socketContent_3`='0',`socketBonus`='0',`GemProperties`='0',`ExtendedCost`='0',`RequiredArenaRank`='0',`RequiredDisenchantSkill`='-1',`ArmorDamageModifier`='0',`ScriptName`='',`DisenchantID`='0',`FoodType`='0',`minMoneyLoot`='0',`maxMoneyLoot`='0',`Duration`='0' WHERE (`entry`='6265');
UPDATE `item_template` SET `entry`='22244',`class`='1',`subclass`='1',`unk0`='-1',`name`='Box of Souls',`displayid`='20913',`Quality`='2',`Flags`='0',`BuyCount`='1',`BuyPrice`='4000',`SellPrice`='1000',`InventoryType`='18',`AllowableClass`='256',`AllowableRace`='-1',`ItemLevel`='30',`RequiredLevel`='0',`RequiredSkill`='0',`RequiredSkillRank`='0',`requiredspell`='0',`requiredhonorrank`='0',`RequiredCityRank`='0',`RequiredReputationFaction`='0',`RequiredReputationRank`='0',`maxcount`='0',`stackable`='1',`ContainerSlots`='16',`stat_type1`='0',`stat_value1`='0',`stat_type2`='0',`stat_value2`='0',`stat_type3`='0',`stat_value3`='0',`stat_type4`='0',`stat_value4`='0',`stat_type5`='0',`stat_value5`='0',`stat_type6`='0',`stat_value6`='0',`stat_type7`='0',`stat_value7`='0',`stat_type8`='0',`stat_value8`='0',`stat_type9`='0',`stat_value9`='0',`stat_type10`='0',`stat_value10`='0',`dmg_min1`='0',`dmg_max1`='0',`dmg_type1`='0',`dmg_min2`='0',`dmg_max2`='0',`dmg_type2`='0',`dmg_min3`='0',`dmg_max3`='0',`dmg_type3`='0',`dmg_min4`='0',`dmg_max4`='0',`dmg_type4`='0',`dmg_min5`='0',`dmg_max5`='0',`dmg_type5`='0',`armor`='0',`holy_res`='0',`fire_res`='0',`nature_res`='0',`frost_res`='0',`shadow_res`='0',`arcane_res`='0',`delay`='0',`ammo_type`='0',`RangedModRange`='0',`spellid_1`='0',`spelltrigger_1`='0',`spellcharges_1`='0',`spellppmRate_1`='0',`spellcooldown_1`='-1',`spellcategory_1`='0',`spellcategorycooldown_1`='-1',`spellid_2`='0',`spelltrigger_2`='0',`spellcharges_2`='0',`spellppmRate_2`='0',`spellcooldown_2`='-1',`spellcategory_2`='0',`spellcategorycooldown_2`='-1',`spellid_3`='0',`spelltrigger_3`='0',`spellcharges_3`='0',`spellppmRate_3`='0',`spellcooldown_3`='-1',`spellcategory_3`='0',`spellcategorycooldown_3`='-1',`spellid_4`='0',`spelltrigger_4`='0',`spellcharges_4`='0',`spellppmRate_4`='0',`spellcooldown_4`='-1',`spellcategory_4`='0',`spellcategorycooldown_4`='-1',`spellid_5`='0',`spelltrigger_5`='0',`spellcharges_5`='0',`spellppmRate_5`='0',`spellcooldown_5`='-1',`spellcategory_5`='0',`spellcategorycooldown_5`='-1',`bonding`='1',`description`='',`PageText`='0',`LanguageID`='0',`PageMaterial`='0',`startquest`='0',`lockid`='0',`Material`='8',`sheath`='0',`RandomProperty`='0',`RandomSuffix`='0',`block`='0',`itemset`='0',`MaxDurability`='0',`area`='0',`Map`='0',`BagFamily`='4',`TotemCategory`='0',`socketColor_1`='0',`socketContent_1`='0',`socketColor_2`='0',`socketContent_2`='0',`socketColor_3`='0',`socketContent_3`='0',`socketBonus`='0',`GemProperties`='0',`ExtendedCost`='0',`RequiredArenaRank`='0',`RequiredDisenchantSkill`='-1',`ArmorDamageModifier`='0',`ScriptName`='',`DisenchantID`='0',`FoodType`='0',`minMoneyLoot`='0',`maxMoneyLoot`='0',`Duration`='0' WHERE (`entry`='22244');
UPDATE `item_template` SET `entry`='21342',`class`='1',`subclass`='1',`unk0`='-1',`name`='Core Felcloth Bag',`displayid`='33942',`Quality`='4',`Flags`='0',`BuyCount`='1',`BuyPrice`='320000',`SellPrice`='80000',`InventoryType`='18',`AllowableClass`='256',`AllowableRace`='-1',`ItemLevel`='60',`RequiredLevel`='0',`RequiredSkill`='0',`RequiredSkillRank`='0',`requiredspell`='0',`requiredhonorrank`='0',`RequiredCityRank`='0',`RequiredReputationFaction`='0',`RequiredReputationRank`='0',`maxcount`='0',`stackable`='1',`ContainerSlots`='28',`stat_type1`='0',`stat_value1`='0',`stat_type2`='0',`stat_value2`='0',`stat_type3`='0',`stat_value3`='0',`stat_type4`='0',`stat_value4`='0',`stat_type5`='0',`stat_value5`='0',`stat_type6`='0',`stat_value6`='0',`stat_type7`='0',`stat_value7`='0',`stat_type8`='0',`stat_value8`='0',`stat_type9`='0',`stat_value9`='0',`stat_type10`='0',`stat_value10`='0',`dmg_min1`='0',`dmg_max1`='0',`dmg_type1`='0',`dmg_min2`='0',`dmg_max2`='0',`dmg_type2`='0',`dmg_min3`='0',`dmg_max3`='0',`dmg_type3`='0',`dmg_min4`='0',`dmg_max4`='0',`dmg_type4`='0',`dmg_min5`='0',`dmg_max5`='0',`dmg_type5`='0',`armor`='0',`holy_res`='0',`fire_res`='0',`nature_res`='0',`frost_res`='0',`shadow_res`='0',`arcane_res`='0',`delay`='0',`ammo_type`='0',`RangedModRange`='0',`spellid_1`='0',`spelltrigger_1`='0',`spellcharges_1`='0',`spellppmRate_1`='0',`spellcooldown_1`='-1',`spellcategory_1`='0',`spellcategorycooldown_1`='-1',`spellid_2`='0',`spelltrigger_2`='0',`spellcharges_2`='0',`spellppmRate_2`='0',`spellcooldown_2`='-1',`spellcategory_2`='0',`spellcategorycooldown_2`='-1',`spellid_3`='0',`spelltrigger_3`='0',`spellcharges_3`='0',`spellppmRate_3`='0',`spellcooldown_3`='-1',`spellcategory_3`='0',`spellcategorycooldown_3`='-1',`spellid_4`='0',`spelltrigger_4`='0',`spellcharges_4`='0',`spellppmRate_4`='0',`spellcooldown_4`='-1',`spellcategory_4`='0',`spellcategorycooldown_4`='-1',`spellid_5`='0',`spelltrigger_5`='0',`spellcharges_5`='0',`spellppmRate_5`='0',`spellcooldown_5`='-1',`spellcategory_5`='0',`spellcategorycooldown_5`='-1',`bonding`='2',`description`='',`PageText`='0',`LanguageID`='0',`PageMaterial`='0',`startquest`='0',`lockid`='0',`Material`='8',`sheath`='0',`RandomProperty`='0',`RandomSuffix`='0',`block`='0',`itemset`='0',`MaxDurability`='0',`area`='0',`Map`='0',`BagFamily`='4',`TotemCategory`='0',`socketColor_1`='0',`socketContent_1`='0',`socketColor_2`='0',`socketContent_2`='0',`socketColor_3`='0',`socketContent_3`='0',`socketBonus`='0',`GemProperties`='0',`ExtendedCost`='0',`RequiredArenaRank`='0',`RequiredDisenchantSkill`='-1',`ArmorDamageModifier`='0',`ScriptName`='',`DisenchantID`='0',`FoodType`='0',`minMoneyLoot`='0',`maxMoneyLoot`='0',`Duration`='0' WHERE (`entry`='21342');

 

# EVENT
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'4' FROM `creature` WHERE `id`=10445;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'4' FROM `creature` WHERE `id`=14843;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'4' FROM `creature` WHERE `id`=14871;
INSERT IGNORE INTO `game_event_gameobject` SELECT `guid`,'4' FROM `gameobject` WHERE `id`=180524;
INSERT IGNORE INTO `game_event_gameobject` SELECT `guid`,'2' FROM `gameobject` WHERE `id`=178647;
INSERT IGNORE INTO `game_event_gameobject` SELECT `guid`,'26' FROM `gameobject` WHERE `id`=186189;

# NPC
UPDATE `creature_template` SET `faction_A`='7' WHERE (`entry`='3094');
UPDATE `creature_template` SET `faction_A`='35',`faction_H`='35' WHERE (`entry`='10445');
# �� ������
DELETE FROM `creature` WHERE `id`=5112;
INSERT INTO `creature` (`guid`,`id`,`map`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`spawn_position_x`,`spawn_position_y`,`spawn_position_z`,`spawn_orientation`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(9574, 5112, 0, 0, 1469, -4842.02, -856.877, 501.914, 4.77793, 600, 0, 0, -4842.02, -856.877, 501.914, 0, 6100, 0, 0, 0);
# KiriX
UPDATE `creature` SET `spawn_position_x` = '-9953.174805', `spawn_position_y` = '491.623444', `spawn_position_z` = '31.376043', `spawn_orientation` = '1.927368',`position_x` = '-9953.174805', `position_y` = '491.623444', `position_z` = '31.376043', `orientation` = '1.927368' WHERE `guid` = '4213';
UPDATE `creature` SET `spawn_position_x` = '-10503.267578', `spawn_position_y` = '1016.793274', `spawn_position_z` = '95.613571', `spawn_orientation` = '4.491720',`position_x` = '-10503.267578', `position_y` = '1016.793274', `position_z` = '95.613571', `orientation` = '4.491720' WHERE `guid` = '280842';
UPDATE `item_template` SET `Quality`='3',`stat_type1`='7',`stat_value1`='11',`dmg_min1`='45',`dmg_max1`='68' WHERE (`entry`='5187');
-- �� � ��� �� ������ �� �������� ��
UPDATE `creature_template` SET `minhealth`='2900',`maxhealth`='2900' WHERE (`entry`='7009');
#���� ������ 1000, ������� - 11000
update creature_template set maxhealth=11000 where `entry`=23191 ;
#���������� ����� ( � ������� )
update creature_template set mindmg=2500 where `entry`=21232 ;
update creature_template set mindmg=3200 where `entry`=21263 ;
update creature_template set mindmg=1000 where `entry`=21806 ;
update creature_template set mindmg=1500 where `entry`=21920 ;
update creature_template set mindmg=1800 where `entry`=22140 ;
DELETE FROM `creature` WHERE `guid` = '68843';
DELETE FROM `creature_addon` WHERE `guid` = '68843';
DELETE FROM `creature` WHERE `guid` = '70924';
DELETE FROM `creature_addon` WHERE `guid` = '70924';
-- ����� �� �� ������� ����, �������... ������ ���������� �������� � �� �������� � ��� ���� �� ������, �.�. �� ���� ��� ����� ��� ������
UPDATE `creature_template` SET `minlevel`='20',`maxlevel`='25',`minhealth`='240',`maxhealth`='350' WHERE (`entry`='6412');
-- ����� ���� �� ������ ���� ������ �� ��� ����������
DELETE FROM `creature` WHERE `guid` = '2383';
DELETE FROM `creature_addon` WHERE `guid` = '2383';
DELETE FROM `creature_movement` WHERE `id` = '2383';
-- � ����� 2.3 ��� ������ �� �����. ������ � ��
UPDATE `creature_template` SET `minlevel`='30',`minhealth`='730',`rank`='0' WHERE (`entry`='314');
-- ���������� �������� � ������� �������������
UPDATE `creature_template` SET `minhealth`='120',`maxhealth`='140',`faction_A`='7',`faction_H`='7' WHERE (`entry`='1553');
DELETE FROM `creature` WHERE `guid` = '70768';
DELETE FROM `creature_addon` WHERE `guid` = '70768';
DELETE FROM `creature` WHERE `guid` = '70834';
DELETE FROM `creature_addon` WHERE `guid` = '70834';


# GO
UPDATE `gameobject_template` SET `flags`='2' WHERE `entry` in (178244,178245,178246);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(71770, 178244, 0, -9225.42, -2694.12, 89.086, -1.16937, 0, 0, 0.551937, -0.833886, 5, 100, 1),
(71771, 178244, 0, -9227.89, -2696.93, 89.086, -0.872665, 0, 0, 0.422618, -0.906308, 5, 100, 1),
(71772, 178244, 0, -9231.58, -2698.62, 89.086, -0.750491, 0, 0, 0.366501, -0.930418, 5, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(71773, 178246, 0, -9232.72, -2705.1, 89.086, 0.890118, 0, 0, 0.430511, 0.902585, 7200, 100, 1),
(71774, 178246, 0, -9233.62, -2701.74, 89.086, -0.331612, 0, 0, 0.165048, -0.986286, 7200, 100, 1);
# ������ � ������ - ��� ���������!
DELETE FROM `gameobject` WHERE `id`=93192;
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(16395, 93192, 1, 3472.46, -103, 3.499, 0.581, 0, 0, 0, 0, 600, 0, 1),
(193760, 93192, 1, 3475.48, -62.3688, 4.92209, 2.67016, 0, 0, 0, 0, 300, 0, 1);
# ����� �� ����� ������ �������� � �� ����� ������ ���������:
UPDATE `gameobject_template` SET `faction` = '1375', `flags` = '32' WHERE `entry` in (183970, 183971, 183972, 183973, 183977, 183978, 183979, 183980, 185917, 185918);
# ���-�� ��������� �� �������� � ������� �� ����� ������
UPDATE `gameobject_template` SET `faction` = '35' WHERE `entry` in (180087, 180088, 180089, 180090, 180091);

# y2kcat
# �� ��� ������. ����� �� ���������� � ������� ���������, ����� � ����, ��� ������ �������� ��� ���������=0, �� �� ���� ��������, ��� ���� �����=2 ��� ������ ���� �� ��������., �� �� �� �������� (�� �������), ����� ������ ������� �� ��� �������� ���� ��� ������
UPDATE `quest_template` SET `RequiredRaces`='512',`QuestFlags`='9',`ReqSpellCast1`='30099' WHERE (`entry`='9484');
UPDATE `item_template` SET `spellid_1`='30099' WHERE (`entry`='23697');
# ���� �������� � ����� ����
UPDATE `quest_template` SET `RequiredRaces`='512',`QuestFlags`='11',`ReqSpellCast1`='30102' WHERE (`entry`='9486');
UPDATE `item_template` SET `spellid_1`='30102' WHERE (`entry`='23702');
# �������� - �������� - ������ � ������ �� ����
DELETE FROM `gameobject_loot_template` WHERE entry in (184940,184941);

# Jode
DELETE FROM `game_graveyard_zone` WHERE ghost_zone = 3607;
INSERT INTO `game_graveyard_zone` (id,ghost_zone,`faction`) VALUES
(969,3607,0);#Zangarmarsh, PvP GY<-Coilfang Reservoir: Serpentshrine Cavern
DELETE FROM `game_graveyard_zone` WHERE ghost_zone = 3606;
INSERT INTO `game_graveyard_zone` (id,ghost_zone,`faction`) VALUES
(1249,3606,0);#Tanaris, CoT<-Hyjal Summit
#Quests for taming Blood Elves hunts pets /�������� ��������� ������ ����
UPDATE quest_template SET ReqSpellCast1=30099 WHERE entry=9484;#Tame Crazed Dragonhawk
UPDATE quest_template SET ReqSpellCast1=30102 WHERE entry=9486;#Tame Elder Springpaw
UPDATE quest_template SET ReqSpellCast1=30105 WHERE entry=9485;#Tame Mistbat
UPDATE item_template SET spellid_1=30099 WHERE entry=23697;#Taming Rod (Tame Crazed Dragonhawk)
UPDATE item_template SET spellid_1=30102 WHERE entry=23702;#Taming Rod (Elder Springpaw)
UPDATE item_template SET spellid_1=30105 WHERE entry=23703;#Taming Rod (Tame Mistbat)

# KiriX -  �������� ������ � DM
DELETE FROM `creature` WHERE `guid` = '103949';
DELETE FROM `creature_addon` WHERE `guid` = '103949';
DELETE FROM `creature_movement` WHERE `id` = '103949';
DELETE FROM `creature` WHERE `guid` = '289363';
DELETE FROM `creature_addon` WHERE `guid` = '289363';
DELETE FROM `creature_movement` WHERE `id` = '289363';
DELETE FROM `creature` WHERE `guid` = '284500';
DELETE FROM `creature_addon` WHERE `guid` = '284500';
DELETE FROM `creature_movement` WHERE `id` = '284500';
DELETE FROM `creature` WHERE `guid` = '103945';
DELETE FROM `creature_addon` WHERE `guid` = '103945';
DELETE FROM `creature_movement` WHERE `id` = '103945';
DELETE FROM `creature` WHERE `guid` = '284493';
DELETE FROM `creature_addon` WHERE `guid` = '284493';
DELETE FROM `creature_movement` WHERE `id` = '284493';
DELETE FROM `creature` WHERE `guid` = '289362';
DELETE FROM `creature_addon` WHERE `guid` = '289362';
DELETE FROM `creature_movement` WHERE `id` = '289362';
DELETE FROM `creature` WHERE `guid` = '103950';
DELETE FROM `creature_addon` WHERE `guid` = '103950';
DELETE FROM `creature_movement` WHERE `id` = '103950';
DELETE FROM `creature` WHERE `guid` = '289340';
DELETE FROM `creature_addon` WHERE `guid` = '289340';
DELETE FROM `creature_movement` WHERE `id` = '289340';
DELETE FROM `creature` WHERE `guid` = '284499';
DELETE FROM `creature_addon` WHERE `guid` = '284499';
DELETE FROM `creature_movement` WHERE `id` = '284499';
DELETE FROM `creature` WHERE `guid` = '103948';
DELETE FROM `creature_addon` WHERE `guid` = '103948';
DELETE FROM `creature_movement` WHERE `id` = '103948';
DELETE FROM `creature` WHERE `guid` = '282564';
DELETE FROM `creature_addon` WHERE `guid` = '282564';
DELETE FROM `creature_movement` WHERE `id` = '282564';
DELETE FROM `creature` WHERE `guid` = '289338';
DELETE FROM `creature_addon` WHERE `guid` = '289338';
DELETE FROM `creature_movement` WHERE `id` = '289338';
DELETE FROM `creature` WHERE `guid` = '289360';
DELETE FROM `creature_addon` WHERE `guid` = '289360';
DELETE FROM `creature_movement` WHERE `id` = '289360';
DELETE FROM `creature` WHERE `guid` = '284494';
DELETE FROM `creature_addon` WHERE `guid` = '284494';
DELETE FROM `creature_movement` WHERE `id` = '284494';
DELETE FROM `creature` WHERE `guid` = '289336';
DELETE FROM `creature_addon` WHERE `guid` = '289336';
DELETE FROM `creature_movement` WHERE `id` = '289336';
DELETE FROM `creature` WHERE `guid` = '282562';
DELETE FROM `creature_addon` WHERE `guid` = '282562';
DELETE FROM `creature_movement` WHERE `id` = '282562';
DELETE FROM `creature` WHERE `guid` = '289366';
DELETE FROM `creature_addon` WHERE `guid` = '289366';
DELETE FROM `creature_movement` WHERE `id` = '289366';
DELETE FROM `creature` WHERE `guid` = '284506';
DELETE FROM `creature_addon` WHERE `guid` = '284506';
DELETE FROM `creature_movement` WHERE `id` = '284506';
DELETE FROM `creature` WHERE `guid` = '282568';
DELETE FROM `creature_addon` WHERE `guid` = '282568';
DELETE FROM `creature_movement` WHERE `id` = '282568';
DELETE FROM `creature` WHERE `guid` = '103956';
DELETE FROM `creature_addon` WHERE `guid` = '103956';
DELETE FROM `creature_movement` WHERE `id` = '103956';
DELETE FROM `creature` WHERE `guid` = '284498';
DELETE FROM `creature_addon` WHERE `guid` = '284498';
DELETE FROM `creature_movement` WHERE `id` = '284498';
DELETE FROM `creature` WHERE `guid` = '284508';
DELETE FROM `creature_addon` WHERE `guid` = '284508';
DELETE FROM `creature_movement` WHERE `id` = '284508';
DELETE FROM `creature` WHERE `guid` = '284507';
DELETE FROM `creature_addon` WHERE `guid` = '284507';
DELETE FROM `creature_movement` WHERE `id` = '284507';
DELETE FROM `creature` WHERE `guid` = '282559';
DELETE FROM `creature_addon` WHERE `guid` = '282559';
DELETE FROM `creature_movement` WHERE `id` = '282559';
DELETE FROM `creature` WHERE `guid` = '103942';
DELETE FROM `creature_addon` WHERE `guid` = '103942';
DELETE FROM `creature_movement` WHERE `id` = '103942';
DELETE FROM `creature` WHERE `guid` = '289357';
DELETE FROM `creature_addon` WHERE `guid` = '289357';
DELETE FROM `creature_movement` WHERE `id` = '289357';
DELETE FROM `creature` WHERE `guid` = '289333';
DELETE FROM `creature_addon` WHERE `guid` = '289333';
DELETE FROM `creature_movement` WHERE `id` = '289333';
DELETE FROM `creature` WHERE `guid` = '289356';
DELETE FROM `creature_addon` WHERE `guid` = '289356';
DELETE FROM `creature_movement` WHERE `id` = '289356';
DELETE FROM `creature` WHERE `guid` = '282572';
DELETE FROM `creature_addon` WHERE `guid` = '282572';
DELETE FROM `creature_movement` WHERE `id` = '282572';
DELETE FROM `creature` WHERE `guid` = '284502';
DELETE FROM `creature_addon` WHERE `guid` = '284502';
DELETE FROM `creature_movement` WHERE `id` = '284502';
DELETE FROM `creature` WHERE `guid` = '284505';
DELETE FROM `creature_addon` WHERE `guid` = '284505';
DELETE FROM `creature_movement` WHERE `id` = '284505';
DELETE FROM `creature` WHERE `guid` = '289341';
DELETE FROM `creature_addon` WHERE `guid` = '289341';
DELETE FROM `creature_movement` WHERE `id` = '289341';
DELETE FROM `creature` WHERE `guid` = '282567';
DELETE FROM `creature_addon` WHERE `guid` = '282567';
DELETE FROM `creature_movement` WHERE `id` = '282567';
DELETE FROM `creature` WHERE `guid` = '103951';
DELETE FROM `creature_addon` WHERE `guid` = '103951';
DELETE FROM `creature_movement` WHERE `id` = '103951';
DELETE FROM `creature` WHERE `guid` = '284495';
DELETE FROM `creature_addon` WHERE `guid` = '284495';
DELETE FROM `creature_movement` WHERE `id` = '284495';
DELETE FROM `creature` WHERE `guid` = '282563';
DELETE FROM `creature_addon` WHERE `guid` = '282563';
DELETE FROM `creature_movement` WHERE `id` = '282563';
DELETE FROM `creature` WHERE `guid` = '289361';
DELETE FROM `creature_addon` WHERE `guid` = '289361';
DELETE FROM `creature_movement` WHERE `id` = '289361';
DELETE FROM `creature` WHERE `guid` = '103947';
DELETE FROM `creature_addon` WHERE `guid` = '103947';
DELETE FROM `creature_movement` WHERE `id` = '103947';
DELETE FROM `creature` WHERE `guid` = '282560';
DELETE FROM `creature_addon` WHERE `guid` = '282560';
DELETE FROM `creature_movement` WHERE `id` = '282560';
DELETE FROM `creature` WHERE `guid` = '103944';
DELETE FROM `creature_addon` WHERE `guid` = '103944';
DELETE FROM `creature_movement` WHERE `id` = '103944';
DELETE FROM `creature` WHERE `guid` = '289358';
DELETE FROM `creature_addon` WHERE `guid` = '289358';
DELETE FROM `creature_movement` WHERE `id` = '289358';
DELETE FROM `creature` WHERE `guid` = '289334';
DELETE FROM `creature_addon` WHERE `guid` = '289334';
DELETE FROM `creature_movement` WHERE `id` = '289334';
DELETE FROM `creature` WHERE `guid` = '103949';
DELETE FROM `creature_addon` WHERE `guid` = '103949';
DELETE FROM `creature_movement` WHERE `id` = '103949';
DELETE FROM `creature` WHERE `guid` = '289363';
DELETE FROM `creature_addon` WHERE `guid` = '289363';
DELETE FROM `creature_movement` WHERE `id` = '289363';
DELETE FROM `creature` WHERE `guid` = '284500';
DELETE FROM `creature_addon` WHERE `guid` = '284500';
DELETE FROM `creature_movement` WHERE `id` = '284500';
DELETE FROM `creature` WHERE `guid` = '103945';
DELETE FROM `creature_addon` WHERE `guid` = '103945';
DELETE FROM `creature_movement` WHERE `id` = '103945';
DELETE FROM `creature` WHERE `guid` = '284493';
DELETE FROM `creature_addon` WHERE `guid` = '284493';
DELETE FROM `creature_movement` WHERE `id` = '284493';
DELETE FROM `creature` WHERE `guid` = '289362';
DELETE FROM `creature_addon` WHERE `guid` = '289362';
DELETE FROM `creature_movement` WHERE `id` = '289362';
DELETE FROM `creature` WHERE `guid` = '103950';
DELETE FROM `creature_addon` WHERE `guid` = '103950';
DELETE FROM `creature_movement` WHERE `id` = '103950';
DELETE FROM `creature` WHERE `guid` = '289340';
DELETE FROM `creature_addon` WHERE `guid` = '289340';
DELETE FROM `creature_movement` WHERE `id` = '289340';
DELETE FROM `creature` WHERE `guid` = '284499';
DELETE FROM `creature_addon` WHERE `guid` = '284499';
DELETE FROM `creature_movement` WHERE `id` = '284499';
DELETE FROM `creature` WHERE `guid` = '103948';
DELETE FROM `creature_addon` WHERE `guid` = '103948';
DELETE FROM `creature_movement` WHERE `id` = '103948';
DELETE FROM `creature` WHERE `guid` = '282564';
DELETE FROM `creature_addon` WHERE `guid` = '282564';
DELETE FROM `creature_movement` WHERE `id` = '282564';
DELETE FROM `creature` WHERE `guid` = '289338';
DELETE FROM `creature_addon` WHERE `guid` = '289338';
DELETE FROM `creature_movement` WHERE `id` = '289338';
DELETE FROM `creature` WHERE `guid` = '289360';
DELETE FROM `creature_addon` WHERE `guid` = '289360';
DELETE FROM `creature_movement` WHERE `id` = '289360';
DELETE FROM `creature` WHERE `guid` = '284494';
DELETE FROM `creature_addon` WHERE `guid` = '284494';
DELETE FROM `creature_movement` WHERE `id` = '284494';
DELETE FROM `creature` WHERE `guid` = '289336';
DELETE FROM `creature_addon` WHERE `guid` = '289336';
DELETE FROM `creature_movement` WHERE `id` = '289336';
DELETE FROM `creature` WHERE `guid` = '282562';
DELETE FROM `creature_addon` WHERE `guid` = '282562';
DELETE FROM `creature_movement` WHERE `id` = '282562';
DELETE FROM `creature` WHERE `guid` = '289366';
DELETE FROM `creature_addon` WHERE `guid` = '289366';
DELETE FROM `creature_movement` WHERE `id` = '289366';
DELETE FROM `creature` WHERE `guid` = '284506';
DELETE FROM `creature_addon` WHERE `guid` = '284506';
DELETE FROM `creature_movement` WHERE `id` = '284506';
DELETE FROM `creature` WHERE `guid` = '282568';
DELETE FROM `creature_addon` WHERE `guid` = '282568';
DELETE FROM `creature_movement` WHERE `id` = '282568';
DELETE FROM `creature` WHERE `guid` = '103956';
DELETE FROM `creature_addon` WHERE `guid` = '103956';
DELETE FROM `creature_movement` WHERE `id` = '103956';
DELETE FROM `creature` WHERE `guid` = '284498';
DELETE FROM `creature_addon` WHERE `guid` = '284498';
DELETE FROM `creature_movement` WHERE `id` = '284498';
DELETE FROM `creature` WHERE `guid` = '284508';
DELETE FROM `creature_addon` WHERE `guid` = '284508';
DELETE FROM `creature_movement` WHERE `id` = '284508';
DELETE FROM `creature` WHERE `guid` = '284507';
DELETE FROM `creature_addon` WHERE `guid` = '284507';
DELETE FROM `creature_movement` WHERE `id` = '284507';
DELETE FROM `creature` WHERE `guid` = '282559';
DELETE FROM `creature_addon` WHERE `guid` = '282559';
DELETE FROM `creature_movement` WHERE `id` = '282559';
DELETE FROM `creature` WHERE `guid` = '103942';
DELETE FROM `creature_addon` WHERE `guid` = '103942';
DELETE FROM `creature_movement` WHERE `id` = '103942';
DELETE FROM `creature` WHERE `guid` = '289357';
DELETE FROM `creature_addon` WHERE `guid` = '289357';
DELETE FROM `creature_movement` WHERE `id` = '289357';
DELETE FROM `creature` WHERE `guid` = '289333';
DELETE FROM `creature_addon` WHERE `guid` = '289333';
DELETE FROM `creature_movement` WHERE `id` = '289333';
DELETE FROM `creature` WHERE `guid` = '289356';
DELETE FROM `creature_addon` WHERE `guid` = '289356';
DELETE FROM `creature_movement` WHERE `id` = '289356';
DELETE FROM `creature` WHERE `guid` = '282572';
DELETE FROM `creature_addon` WHERE `guid` = '282572';
DELETE FROM `creature_movement` WHERE `id` = '282572';
# ����, �����, ��� �������� ��� ����� ����� ������ �����...
