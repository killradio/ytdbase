# � ��� ��������� ���� ��������
UPDATE `creature` SET `spawn_position_x` = '-11199.677734', `spawn_position_y` = '1588.673462', `spawn_position_z` = '27.975277', `spawn_orientation` = '1.063860',`position_x` = '-11199.677734', `position_y` = '1588.673462', `position_z` = '27.975277', `orientation` = '1.063860' WHERE `guid` = '1559';
UPDATE `creature` SET `spawn_position_x` = '-11119.814453', `spawn_position_y` = '-3357.797607', `spawn_position_z` = '55.527317', `spawn_orientation` = '2.382082',`position_x` = '-11119.814453', `position_y` = '-3357.797607', `position_z` = '55.527317', `orientation` = '2.382082' WHERE `guid` = '1691';
UPDATE `creature` SET `spawn_position_x` = '-11083.443359', `spawn_position_y` = '1521.069092', `spawn_position_z` = '29.869698', `spawn_orientation` = '1.627696',`position_x` = '-11083.443359', `position_y` = '1521.069092', `position_z` = '29.869698', `orientation` = '1.627696' WHERE `guid` = '1754';
UPDATE `creature` SET `spawn_position_x` = '-10116.756836', `spawn_position_y` = '-2810.268066', `spawn_position_z` = '22.188940', `spawn_orientation` = '0.052771',`position_x` = '-10116.756836', `position_y` = '-2810.268066', `position_z` = '22.188940', `orientation` = '0.052771' WHERE `guid` = '3732';
UPDATE `creature` SET `spawn_position_x` = '-9859.721680', `spawn_position_y` = '-226.423218', `spawn_position_z` = '35.922344', `spawn_orientation` = '0.545298',`position_x` = '-9859.721680', `position_y` = '-226.423218', `position_z` = '35.922344', `orientation` = '0.545298' WHERE `guid` = '4221';
UPDATE `creature` SET `spawn_position_x` = '-9495.049805', `spawn_position_y` = '395.520996', `spawn_position_z` = '51.948986', `spawn_orientation` = '1.530975',`position_x` = '-9495.049805', `position_y` = '395.520996', `position_z` = '51.948986', `orientation` = '1.530975' WHERE `guid` = '23374';
UPDATE `creature` SET `spawn_position_x` = '-6500.604004', `spawn_position_y` = '-1297.372803', `spawn_position_z` = '136.186844', `spawn_orientation` = '6.236329',`position_x` = '-6500.604004', `position_y` = '-1297.372803', `position_z` = '136.186844', `orientation` = '6.236329' WHERE `guid` = '7547';
UPDATE `creature` SET `spawn_position_x` = '-6469.900391', `spawn_position_y` = '-1311.157715', `spawn_position_z` = '131.594040', `spawn_orientation` = '2.206613',`position_x` = '-6469.900391', `position_y` = '-1311.157715', `position_z` = '131.594040', `orientation` = '2.206613' WHERE `guid` = '7610';
UPDATE `creature` SET `spawn_position_x` = '-5174.798340', `spawn_position_y` = '587.117920', `spawn_position_z` = '405.511627', `spawn_orientation` = '0.276270',`position_x` = '-5174.798340', `position_y` = '587.117920', `position_z` = '405.511627', `orientation` = '0.276270' WHERE `guid` = '9141';
UPDATE `creature` SET `spawn_position_x` = '-1687.406982', `spawn_position_y` = '-1796.654175', `spawn_position_z` = '100.414001', `spawn_orientation` = '3.898852',`position_x` = '-1687.406982', `position_y` = '-1796.654175', `position_z` = '100.414001', `orientation` = '3.898852' WHERE `guid` = '11299';
UPDATE `creature` SET `spawn_position_x` = '-532.011292', `spawn_position_y` = '-4171.104980', `spawn_position_z` = '215.766907', `spawn_orientation` = '0.039729',`position_x` = '-532.011292', `position_y` = '-4171.104980', `position_z` = '215.766907', `orientation` = '0.039729' WHERE `guid` = '12668';
UPDATE `creature` SET `spawn_position_x` = '986.952271', `spawn_position_y` = '711.416931', `spawn_position_z` = '60.974998', `spawn_orientation` = '3.208304',`position_x` = '986.952271', `position_y` = '711.416931', `position_z` = '60.974998', `orientation` = '3.208304' WHERE `guid` = '14896';
UPDATE `creature` SET `spawn_position_x` = '2895.859863', `spawn_position_y` = '-1548.460327', `spawn_position_z` = '145.804001', `spawn_orientation` = '5.461495',`position_x` = '2895.859863', `position_y` = '-1548.460327', `position_z` = '145.804001', `orientation` = '5.461495' WHERE `guid` = '18716';
UPDATE `creature` SET `spawn_position_x` = '-7955.761230', `spawn_position_y` = '-5474.719727', `spawn_position_z` = '7.529000', `spawn_orientation` = '2.999930',`position_x` = '-7955.761230', `position_y` = '-5474.719727', `position_z` = '7.529000', `orientation` = '2.999930' WHERE `guid` = '21037';
UPDATE `creature` SET `spawn_position_x` = '-4130.502441', `spawn_position_y` = '-2229.284424', `spawn_position_z` = '51.248783', `spawn_orientation` = '2.248365',`position_x` = '-4130.502441', `position_y` = '-2229.284424', `position_z` = '51.248783', `orientation` = '2.248365' WHERE `guid` = '27191';
UPDATE `creature` SET `spawn_position_x` = '-4135.763184', `spawn_position_y` = '-2228.660156', `spawn_position_z` = '51.441372', `spawn_orientation` = '0.705058',`position_x` = '-4135.763184', `position_y` = '-2228.660156', `position_z` = '51.441372', `orientation` = '0.705058' WHERE `guid` = '27188';
UPDATE `creature` SET `spawn_position_x` = '-4078.962158', `spawn_position_y` = '-2143.534180', `spawn_position_z` = '50.182999', `spawn_orientation` = '4.697000',`position_x` = '-4078.962158', `position_y` = '-2143.534180', `position_z` = '50.182999', `orientation` = '4.697000' WHERE `guid` = '27253';
UPDATE `creature` SET `spawn_position_x` = '-3906.984131', `spawn_position_y` = '-2860.911865', `spawn_position_z` = '46.436501', `spawn_orientation` = '4.787298',`position_x` = '-3906.984131', `position_y` = '-2860.911865', `position_z` = '46.436501', `orientation` = '4.787298' WHERE `guid` = '27486';
UPDATE `creature` SET `spawn_position_x` = '-3905.289063', `spawn_position_y` = '-2872.854248', `spawn_position_z` = '46.475285', `spawn_orientation` = '3.679888',`position_x` = '-3905.289063', `position_y` = '-2872.854248', `position_z` = '46.475285', `orientation` = '3.679888' WHERE `guid` = '281851';
UPDATE `creature` SET `spawn_position_x` = '-1685.829956', `spawn_position_y` = '-4328.213379', `spawn_position_z` = '3.379624', `spawn_orientation` = '0.045270',`position_x` = '-1685.829956', `position_y` = '-4328.213379', `position_z` = '3.379624', `orientation` = '0.045270' WHERE `guid` = '32038';
UPDATE `creature` SET `spawn_position_x` = '1041.022461', `spawn_position_y` = '-2230.502197', `spawn_position_z` = '91.714317', `spawn_orientation` = '0.161876',`position_x` = '1041.022461', `position_y` = '-2230.502197', `position_z` = '91.714317', `orientation` = '0.161876' WHERE `guid` = '39424';
UPDATE `creature` SET `spawn_position_x` = '1649.720703', `spawn_position_y` = '102.769852', `spawn_position_z` = '110.786331', `spawn_orientation` = '1.195969',`position_x` = '1649.720703', `position_y` = '102.769852', `position_z` = '110.786331', `orientation` = '1.195969' WHERE `guid` = '40228';
UPDATE `creature` SET `spawn_position_x` = '-701.049866', `spawn_position_y` = '2745.525146', `spawn_position_z` = '87.565399', `spawn_orientation` = '1.573127',`position_x` = '-701.049866', `position_y` = '2745.525146', `position_z` = '87.565399', `orientation` = '1.573127' WHERE `guid` = '285839';
UPDATE `creature` SET `spawn_position_x` = '-706.793213', `spawn_position_y` = '2745.466797', `spawn_position_z` = '87.565399', `spawn_orientation` = '0.991932',`position_x` = '-706.793213', `position_y` = '2745.466797', `position_z` = '87.565399', `orientation` = '0.991932' WHERE `guid` = '285842';
UPDATE `creature` SET `spawn_position_x` = '-703.734253', `spawn_position_y` = '2753.727295', `spawn_position_z` = '87.565399', `spawn_orientation` = '1.702718',`position_x` = '-703.734253', `position_y` = '2753.727295', `position_z` = '87.565399', `orientation` = '1.702718' WHERE `guid` = '285840';
UPDATE `creature` SET `spawn_position_x` = '1387.314575', `spawn_position_y` = '-1525.971558', `spawn_position_z` = '59.204041', `spawn_orientation` = '5.196098',`position_x` = '1387.314575', `position_y` = '-1525.971558', `position_z` = '59.204041', `orientation` = '5.196098' WHERE `guid` = '285808';
UPDATE `creature` SET `spawn_position_x` = '1384.257568', `spawn_position_y` = '-1512.432617', `spawn_position_z` = '58.752388', `spawn_orientation` = '1.693222',`position_x` = '1384.257568', `position_y` = '-1512.432617', `position_z` = '58.752388', `orientation` = '1.693222' WHERE `guid` = '285810';
UPDATE `creature` SET `spawn_position_x` = '1377.709961', `spawn_position_y` = '-1516.739868', `spawn_position_z` = '59.410278', `spawn_orientation` = '3.224749',`position_x` = '1377.709961', `position_y` = '-1516.739868', `position_z` = '59.410278', `orientation` = '3.224749' WHERE `guid` = '285811';
UPDATE `creature` SET `spawn_position_x` = '-13594.147461', `spawn_position_y` = '-233.341354', `spawn_position_z` = '22.030397', `spawn_orientation` = '1.326472',`position_x` = '-13594.147461', `position_y` = '-233.341354', `position_z` = '22.030397', `orientation` = '1.326472' WHERE `guid` = '285769';
UPDATE `creature` SET `spawn_position_x` = '-3265.020996', `spawn_position_y` = '-1954.919312', `spawn_position_z` = '96.715317', `spawn_orientation` = '1.097223',`position_x` = '-3265.020996', `position_y` = '-1954.919312', `position_z` = '96.715317', `orientation` = '1.097223' WHERE `guid` = '285761';
UPDATE `creature` SET `spawn_position_x` = '-3262.557129', `spawn_position_y` = '-1969.481445', `spawn_position_z` = '94.625664', `spawn_orientation` = '5.212709',`position_x` = '-3262.557129', `position_y` = '-1969.481445', `position_z` = '94.625664', `orientation` = '5.212709' WHERE `guid` = '285758';
UPDATE `creature` SET `spawn_position_x` = '-3271.460205', `spawn_position_y` = '-1976.156616', `spawn_position_z` = '92.573105', `spawn_orientation` = '4.772885',`position_x` = '-3271.460205', `position_y` = '-1976.156616', `position_z` = '92.573105', `orientation` = '4.772885' WHERE `guid` = '285759';
UPDATE `creature` SET `spawn_position_x` = '-3280.384521', `spawn_position_y` = '-1969.978394', `spawn_position_z` = '94.418518', `spawn_orientation` = '3.543738',`position_x` = '-3280.384521', `position_y` = '-1969.978394', `position_z` = '94.418518', `orientation` = '3.543738' WHERE `guid` = '285763';
UPDATE `creature` SET `spawn_position_x` = '-3280.519287', `spawn_position_y` = '-1858.976196', `spawn_position_z` = '93.143982', `spawn_orientation` = '0.857672',`position_x` = '-3280.519287', `position_y` = '-1858.976196', `position_z` = '93.143982', `orientation` = '0.857672' WHERE `guid` = '285749';
UPDATE `creature` SET `spawn_position_x` = '-3298.833740', `spawn_position_y` = '-1864.023804', `spawn_position_z` = '93.833740', `spawn_orientation` = '2.990028',`position_x` = '-3298.833740', `position_y` = '-1864.023804', `position_z` = '93.833740', `orientation` = '2.990028' WHERE `guid` = '285755';
UPDATE `creature` SET `spawn_position_x` = '-3284.322998', `spawn_position_y` = '-1870.064941', `spawn_position_z` = '92.956490', `spawn_orientation` = '5.570062',`position_x` = '-3284.322998', `position_y` = '-1870.064941', `position_z` = '92.956490', `orientation` = '5.570062' WHERE `guid` = '285760';
UPDATE `creature` SET `spawn_position_x` = '-3277.554199', `spawn_position_y` = '-1863.313110', `spawn_position_z` = '92.882500', `spawn_orientation` = '0.174377',`position_x` = '-3277.554199', `position_y` = '-1863.313110', `position_z` = '92.882500', `orientation` = '0.174377' WHERE `guid` = '285756';
UPDATE `creature` SET `spawn_position_x` = '-3210.154785', `spawn_position_y` = '-1845.795044', `spawn_position_z` = '94.648186', `spawn_orientation` = '0.861597',`position_x` = '-3210.154785', `position_y` = '-1845.795044', `position_z` = '94.648186', `orientation` = '0.861597' WHERE `guid` = '285754';
UPDATE `creature` SET `spawn_position_x` = '-3223.246826', `spawn_position_y` = '-1848.803223', `spawn_position_z` = '93.897194', `spawn_orientation` = '2.503079',`position_x` = '-3223.246826', `position_y` = '-1848.803223', `position_z` = '93.897194', `orientation` = '2.503079' WHERE `guid` = '285750';
UPDATE `creature` SET `spawn_position_x` = '-3223.104248', `spawn_position_y` = '-1859.556763', `spawn_position_z` = '93.459229', `spawn_orientation` = '4.372327',`position_x` = '-3223.104248', `position_y` = '-1859.556763', `position_z` = '93.459229', `orientation` = '4.372327' WHERE `guid` = '285757';
UPDATE `creature` SET `spawn_position_x` = '-3226.811523', `spawn_position_y` = '-1854.005249', `spawn_position_z` = '93.135910', `spawn_orientation` = '6.151255',`position_x` = '-3226.811523', `position_y` = '-1854.005249', `position_z` = '93.135910', `orientation` = '6.151255' WHERE `guid` = '285754';
UPDATE `creature` SET `spawn_position_x` = '-3212.452637', `spawn_position_y` = '-1847.990479', `spawn_position_z` = '95.309875', `spawn_orientation` = '0.751643',`position_x` = '-3212.452637', `position_y` = '-1847.990479', `position_z` = '95.309875', `orientation` = '0.751643' WHERE `guid` = '285752';
UPDATE `creature` SET `spawn_position_x` = '-3213.874023', `spawn_position_y` = '-1855.224121', `spawn_position_z` = '95.214661', `spawn_orientation` = '5.746777',`position_x` = '-3213.874023', `position_y` = '-1855.224121', `position_z` = '95.214661', `orientation` = '5.746777' WHERE `guid` = '285753';
UPDATE `creature` SET `spawn_position_x` = '-3224.085693', `spawn_position_y` = '-1860.264771', `spawn_position_z` = '93.270821', `spawn_orientation` = '5.232341',`position_x` = '-3224.085693', `position_y` = '-1860.264771', `position_z` = '93.270821', `orientation` = '5.232341' WHERE `guid` = '285757';
UPDATE `creature` SET `spawn_position_x` = '-3223.639648', `spawn_position_y` = '-1848.122803', `spawn_position_z` = '93.840050', `spawn_orientation` = '1.756953',`position_x` = '-3223.639648', `position_y` = '-1848.122803', `position_z` = '93.840050', `orientation` = '1.756953' WHERE `guid` = '285750';
UPDATE `creature` SET `spawn_position_x` = '-2014.890259', `spawn_position_y` = '7106.224609', `spawn_position_z` = '21.485115', `spawn_orientation` = '2.752063',`position_x` = '-2014.890259', `position_y` = '7106.224609', `position_z` = '21.485115', `orientation` = '2.752063' WHERE `guid` = '285426';
UPDATE `creature` SET `spawn_position_x` = '-2049.373779', `spawn_position_y` = '7121.423828', `spawn_position_z` = '25.384920', `spawn_orientation` = '2.897360',`position_x` = '-2049.373779', `position_y` = '7121.423828', `position_z` = '25.384920', `orientation` = '2.897360' WHERE `guid` = '102318';
UPDATE `creature` SET `spawn_position_x` = '-2017.333618', `spawn_position_y` = '7104.959473', `spawn_position_z` = '21.751690', `spawn_orientation` = '2.999461',`position_x` = '-2017.333618', `position_y` = '7104.959473', `position_z` = '21.751690', `orientation` = '2.999461' WHERE `guid` = '285439';
UPDATE `creature` SET `spawn_position_x` = '-2029.552002', `spawn_position_y` = '7067.815430', `spawn_position_z` = '23.083633', `spawn_orientation` = '1.534690',`position_x` = '-2029.552002', `position_y` = '7067.815430', `position_z` = '23.083633', `orientation` = '1.534690' WHERE `guid` = '102324';
UPDATE `creature` SET `spawn_position_x` = '-2021.829346', `spawn_position_y` = '7030.943359', `spawn_position_z` = '22.947134', `spawn_orientation` = '1.848849',`position_x` = '-2021.829346', `position_y` = '7030.943359', `position_z` = '22.947134', `orientation` = '1.848849' WHERE `guid` = '285411';
UPDATE `creature` SET `spawn_position_x` = '-2026.925903', `spawn_position_y` = '7107.344727', `spawn_position_z` = '22.611383', `spawn_orientation` = '2.674349',`position_x` = '-2026.925903', `position_y` = '7107.344727', `position_z` = '22.611383', `orientation` = '2.674349' WHERE `guid` = '285433';
UPDATE `creature` SET `spawn_position_x` = '-2037.741089', `spawn_position_y` = '7119.784668', `spawn_position_z` = '22.702032', `spawn_orientation` = '2.898188',`position_x` = '-2037.741089', `position_y` = '7119.784668', `position_z` = '22.702032', `orientation` = '2.898188' WHERE `guid` = '285431';
UPDATE `creature` SET `spawn_position_x` = '-2022.418579', `spawn_position_y` = '7135.561035', `spawn_position_z` = '22.664305', `spawn_orientation` = '3.432260',`position_x` = '-2022.418579', `position_y` = '7135.561035', `position_z` = '22.664305', `orientation` = '3.432260' WHERE `guid` = '285425';
UPDATE `creature` SET `spawn_position_x` = '2707.225586', `spawn_position_y` = '-3430.578613', `spawn_position_z` = '267.688782', `spawn_orientation` = '1.782857',`position_x` = '2707.225586', `position_y` = '-3430.578613', `position_z` = '267.688782', `orientation` = '1.782857' WHERE `guid` = '284223';
UPDATE `creature` SET `spawn_position_x` = '2723.975830', `spawn_position_y` = '-3431.463135', `spawn_position_z` = '267.688782', `spawn_orientation` = '1.884175',`position_x` = '2723.975830', `position_y` = '-3431.463135', `position_z` = '267.688782', `orientation` = '1.884175' WHERE `guid` = '284218';
UPDATE `creature` SET `spawn_position_x` = '2686.350830', `spawn_position_y` = '-3430.086182', `spawn_position_z` = '267.689575', `spawn_orientation` = '1.251930',`position_x` = '2686.350830', `position_y` = '-3430.086182', `position_z` = '267.689575', `orientation` = '1.251930' WHERE `guid` = '284222';
UPDATE `creature` SET `spawn_position_x` = '2698.528076', `spawn_position_y` = '-3430.000000', `spawn_position_z` = '267.689880', `spawn_orientation` = '1.805636',`position_x` = '2698.528076', `position_y` = '-3430.000000', `position_z` = '267.689880', `orientation` = '1.805636' WHERE `guid` = '284219';
UPDATE `creature` SET `spawn_position_x` = '2675.403076', `spawn_position_y` = '-3431.255615', `spawn_position_z` = '267.689880', `spawn_orientation` = '1.373666',`position_x` = '2675.403076', `position_y` = '-3431.255615', `position_z` = '267.689880', `orientation` = '1.373666' WHERE `guid` = '284220';
UPDATE `creature` SET `spawn_position_x` = '2662.430420', `spawn_position_y` = '-3430.441895', `spawn_position_z` = '267.689880', `spawn_orientation` = '1.090922',`position_x` = '2662.430420', `position_y` = '-3430.441895', `position_z` = '267.689880', `orientation` = '1.090922' WHERE `guid` = '284221';
UPDATE `creature` SET `spawn_position_x` = '3260.010254', `spawn_position_y` = '-3221.522949', `spawn_position_z` = '294.063477', `spawn_orientation` = '2.638061',`position_x` = '3260.010254', `position_y` = '-3221.522949', `position_z` = '294.063477', `orientation` = '2.638061' WHERE `guid` = '284240';
DELETE FROM `creature` WHERE `guid` = '285326';
DELETE FROM `creature_addon` WHERE `guid` = '285326';
DELETE FROM `creature_movement` WHERE `id` = '285326';
DELETE FROM `creature` WHERE `guid` = '285324';
DELETE FROM `creature_addon` WHERE `guid` = '285324';
DELETE FROM `creature_movement` WHERE `id` = '285324';
DELETE FROM `creature` WHERE `guid` = '285325';
DELETE FROM `creature_addon` WHERE `guid` = '285325';
DELETE FROM `creature_movement` WHERE `id` = '285325';
UPDATE `creature` SET `spawn_position_x` = '3174.163574', `spawn_position_y` = '-3166.808350', `spawn_position_z` = '294.063477', `spawn_orientation` = '5.465494',`position_x` = '3174.163574', `position_y` = '-3166.808350', `position_z` = '294.063477', `orientation` = '5.465494' WHERE `guid` = '285323';
DELETE FROM `creature` WHERE `guid` = '285330';
DELETE FROM `creature_addon` WHERE `guid` = '285330';
DELETE FROM `creature_movement` WHERE `id` = '285330';
DELETE FROM `creature` WHERE `guid` = '285329';
DELETE FROM `creature_addon` WHERE `guid` = '285329';
DELETE FROM `creature_movement` WHERE `id` = '285329';
DELETE FROM `creature` WHERE `guid` = '285327';
DELETE FROM `creature_addon` WHERE `guid` = '285327';
DELETE FROM `creature_movement` WHERE `id` = '285327';
DELETE FROM `creature` WHERE `guid` = '285333';
DELETE FROM `creature_addon` WHERE `guid` = '285333';
DELETE FROM `creature_movement` WHERE `id` = '285333';
DELETE FROM `creature` WHERE `guid` = '285331';
DELETE FROM `creature_addon` WHERE `guid` = '285331';
DELETE FROM `creature_movement` WHERE `id` = '285331';
UPDATE `creature` SET `spawn_position_x` = '3182.643311', `spawn_position_y` = '-3154.577393', `spawn_position_z` = '294.063477', `spawn_orientation` = '0.258303',`position_x` = '3182.643311', `position_y` = '-3154.577393', `position_z` = '294.063477', `orientation` = '0.258303' WHERE `guid` = '284254';
DELETE FROM `creature` WHERE `guid` = '285332';
DELETE FROM `creature_addon` WHERE `guid` = '285332';
DELETE FROM `creature_movement` WHERE `id` = '285332';
DELETE FROM `creature` WHERE `guid` = '285337';
DELETE FROM `creature_addon` WHERE `guid` = '285337';
DELETE FROM `creature_movement` WHERE `id` = '285337';
DELETE FROM `creature` WHERE `guid` = '285336';
DELETE FROM `creature_addon` WHERE `guid` = '285336';
DELETE FROM `creature_movement` WHERE `id` = '285336';
DELETE FROM `creature` WHERE `guid` = '285338';
DELETE FROM `creature_addon` WHERE `guid` = '285338';
DELETE FROM `creature_movement` WHERE `id` = '285338';
DELETE FROM `creature` WHERE `guid` = '285339';
DELETE FROM `creature_addon` WHERE `guid` = '285339';
DELETE FROM `creature_movement` WHERE `id` = '285339';
DELETE FROM `creature` WHERE `guid` = '285340';
DELETE FROM `creature_addon` WHERE `guid` = '285340';
DELETE FROM `creature_movement` WHERE `id` = '285340';
DELETE FROM `creature` WHERE `guid` = '285341';
DELETE FROM `creature_addon` WHERE `guid` = '285341';
DELETE FROM `creature_movement` WHERE `id` = '285341';
DELETE FROM `creature` WHERE `guid` = '285342';
DELETE FROM `creature_addon` WHERE `guid` = '285342';
DELETE FROM `creature_movement` WHERE `id` = '285342';
DELETE FROM `creature` WHERE `guid` = '285343';
DELETE FROM `creature_addon` WHERE `guid` = '285343';
DELETE FROM `creature_movement` WHERE `id` = '285343';
UPDATE `creature` SET `spawn_position_x` = '3171.927734', `spawn_position_y` = '-3143.022949', `spawn_position_z` = '294.063568', `spawn_orientation` = '3.038612',`position_x` = '3171.927734', `position_y` = '-3143.022949', `position_z` = '294.063568', `orientation` = '3.038612' WHERE `guid` = '285344';
DELETE FROM `creature` WHERE `guid` = '285322';
DELETE FROM `creature_addon` WHERE `guid` = '285322';
DELETE FROM `creature_movement` WHERE `id` = '285322';
DELETE FROM `creature` WHERE `guid` = '285319';
DELETE FROM `creature_addon` WHERE `guid` = '285319';
DELETE FROM `creature_movement` WHERE `id` = '285319';
DELETE FROM `creature` WHERE `guid` = '285321';
DELETE FROM `creature_addon` WHERE `guid` = '285321';
DELETE FROM `creature_movement` WHERE `id` = '285321';
DELETE FROM `creature` WHERE `guid` = '285318';
DELETE FROM `creature_addon` WHERE `guid` = '285318';
DELETE FROM `creature_movement` WHERE `id` = '285318';
DELETE FROM `creature` WHERE `guid` = '285317';
DELETE FROM `creature_addon` WHERE `guid` = '285317';
DELETE FROM `creature_movement` WHERE `id` = '285317';
DELETE FROM `creature` WHERE `guid` = '285310';
DELETE FROM `creature_addon` WHERE `guid` = '285310';
DELETE FROM `creature_movement` WHERE `id` = '285310';
DELETE FROM `creature` WHERE `guid` = '285312';
DELETE FROM `creature_addon` WHERE `guid` = '285312';
DELETE FROM `creature_movement` WHERE `id` = '285312';
DELETE FROM `creature` WHERE `guid` = '285311';
DELETE FROM `creature_addon` WHERE `guid` = '285311';
DELETE FROM `creature_movement` WHERE `id` = '285311';
DELETE FROM `creature` WHERE `guid` = '285313';
DELETE FROM `creature_addon` WHERE `guid` = '285313';
DELETE FROM `creature_movement` WHERE `id` = '285313';
DELETE FROM `creature` WHERE `guid` = '285314';
DELETE FROM `creature_addon` WHERE `guid` = '285314';
DELETE FROM `creature_movement` WHERE `id` = '285314';
DELETE FROM `creature` WHERE `guid` = '285315';
DELETE FROM `creature_addon` WHERE `guid` = '285315';
DELETE FROM `creature_movement` WHERE `id` = '285315';
DELETE FROM `creature` WHERE `guid` = '285316';
DELETE FROM `creature_addon` WHERE `guid` = '285316';
DELETE FROM `creature_movement` WHERE `id` = '285316';
DELETE FROM `creature` WHERE `guid` = '285299';
DELETE FROM `creature_addon` WHERE `guid` = '285299';
DELETE FROM `creature_movement` WHERE `id` = '285299';
DELETE FROM `creature` WHERE `guid` = '285300';
DELETE FROM `creature_addon` WHERE `guid` = '285300';
DELETE FROM `creature_movement` WHERE `id` = '285300';
DELETE FROM `creature` WHERE `guid` = '285298';
DELETE FROM `creature_addon` WHERE `guid` = '285298';
DELETE FROM `creature_movement` WHERE `id` = '285298';
DELETE FROM `creature` WHERE `guid` = '285297';
DELETE FROM `creature_addon` WHERE `guid` = '285297';
DELETE FROM `creature_movement` WHERE `id` = '285297';
DELETE FROM `creature` WHERE `guid` = '285293';
DELETE FROM `creature_addon` WHERE `guid` = '285293';
DELETE FROM `creature_movement` WHERE `id` = '285293';
DELETE FROM `creature` WHERE `guid` = '285294';
DELETE FROM `creature_addon` WHERE `guid` = '285294';
DELETE FROM `creature_movement` WHERE `id` = '285294';
DELETE FROM `creature` WHERE `guid` = '285295';
DELETE FROM `creature_addon` WHERE `guid` = '285295';
DELETE FROM `creature_movement` WHERE `id` = '285295';
DELETE FROM `creature` WHERE `guid` = '285303';
DELETE FROM `creature_addon` WHERE `guid` = '285303';
DELETE FROM `creature_movement` WHERE `id` = '285303';
DELETE FROM `creature` WHERE `guid` = '285302';
DELETE FROM `creature_addon` WHERE `guid` = '285302';
DELETE FROM `creature_movement` WHERE `id` = '285302';
DELETE FROM `creature` WHERE `guid` = '285301';
DELETE FROM `creature_addon` WHERE `guid` = '285301';
DELETE FROM `creature_movement` WHERE `id` = '285301';
DELETE FROM `creature` WHERE `guid` = '285304';
DELETE FROM `creature_addon` WHERE `guid` = '285304';
DELETE FROM `creature_movement` WHERE `id` = '285304';
DELETE FROM `creature` WHERE `guid` = '285305';
DELETE FROM `creature_addon` WHERE `guid` = '285305';
DELETE FROM `creature_movement` WHERE `id` = '285305';
DELETE FROM `creature` WHERE `guid` = '285306';
DELETE FROM `creature_addon` WHERE `guid` = '285306';
DELETE FROM `creature_movement` WHERE `id` = '285306';
DELETE FROM `creature` WHERE `guid` = '285307';
DELETE FROM `creature_addon` WHERE `guid` = '285307';
DELETE FROM `creature_movement` WHERE `id` = '285307';
DELETE FROM `creature` WHERE `guid` = '285308';
DELETE FROM `creature_addon` WHERE `guid` = '285308';
DELETE FROM `creature_movement` WHERE `id` = '285308';
UPDATE `creature` SET `spawn_position_x` = '3144.594727', `spawn_position_y` = '-3145.537842', `spawn_position_z` = '294.063568', `spawn_orientation` = '3.286012',`position_x` = '3144.594727', `position_y` = '-3145.537842', `position_z` = '294.063568', `orientation` = '3.286012' WHERE `guid` = '285309';
DELETE FROM `creature` WHERE `guid` = '285271';
DELETE FROM `creature_addon` WHERE `guid` = '285271';
DELETE FROM `creature_movement` WHERE `id` = '285271';
DELETE FROM `creature` WHERE `guid` = '285274';
DELETE FROM `creature_addon` WHERE `guid` = '285274';
DELETE FROM `creature_movement` WHERE `id` = '285274';
DELETE FROM `creature` WHERE `guid` = '285267';
DELETE FROM `creature_addon` WHERE `guid` = '285267';
DELETE FROM `creature_movement` WHERE `id` = '285267';
DELETE FROM `creature` WHERE `guid` = '285268';
DELETE FROM `creature_addon` WHERE `guid` = '285268';
DELETE FROM `creature_movement` WHERE `id` = '285268';
UPDATE `creature` SET `spawn_position_x` = '3127.765381', `spawn_position_y` = '-3116.962402', `spawn_position_z` = '293.612183', `spawn_orientation` = '5.367313',`position_x` = '3127.765381', `position_y` = '-3116.962402', `position_z` = '293.612183', `orientation` = '5.367313' WHERE `guid` = '285277';
DELETE FROM `creature` WHERE `guid` = '285286';
DELETE FROM `creature_addon` WHERE `guid` = '285286';
DELETE FROM `creature_movement` WHERE `id` = '285286';
DELETE FROM `creature` WHERE `guid` = '285287';
DELETE FROM `creature_addon` WHERE `guid` = '285287';
DELETE FROM `creature_movement` WHERE `id` = '285287';
DELETE FROM `creature` WHERE `guid` = '285288';
DELETE FROM `creature_addon` WHERE `guid` = '285288';
DELETE FROM `creature_movement` WHERE `id` = '285288';
DELETE FROM `creature` WHERE `guid` = '285273';
DELETE FROM `creature_addon` WHERE `guid` = '285273';
DELETE FROM `creature_movement` WHERE `id` = '285273';
DELETE FROM `creature` WHERE `guid` = '285290';
DELETE FROM `creature_addon` WHERE `guid` = '285290';
DELETE FROM `creature_movement` WHERE `id` = '285290';
DELETE FROM `creature` WHERE `guid` = '285285';
DELETE FROM `creature_addon` WHERE `guid` = '285285';
DELETE FROM `creature_movement` WHERE `id` = '285285';
DELETE FROM `creature` WHERE `guid` = '285291';
DELETE FROM `creature_addon` WHERE `guid` = '285291';
DELETE FROM `creature_movement` WHERE `id` = '285291';
DELETE FROM `creature` WHERE `guid` = '285289';
DELETE FROM `creature_addon` WHERE `guid` = '285289';
DELETE FROM `creature_movement` WHERE `id` = '285289';
DELETE FROM `creature` WHERE `guid` = '285281';
DELETE FROM `creature_addon` WHERE `guid` = '285281';
DELETE FROM `creature_movement` WHERE `id` = '285281';
DELETE FROM `creature` WHERE `guid` = '285276';
DELETE FROM `creature_addon` WHERE `guid` = '285276';
DELETE FROM `creature_movement` WHERE `id` = '285276';
DELETE FROM `creature` WHERE `guid` = '285282';
DELETE FROM `creature_addon` WHERE `guid` = '285282';
DELETE FROM `creature_movement` WHERE `id` = '285282';
DELETE FROM `creature` WHERE `guid` = '285283';
DELETE FROM `creature_addon` WHERE `guid` = '285283';
DELETE FROM `creature_movement` WHERE `id` = '285283';
DELETE FROM `creature` WHERE `guid` = '285279';
DELETE FROM `creature_addon` WHERE `guid` = '285279';
DELETE FROM `creature_movement` WHERE `id` = '285279';
UPDATE `creature` SET `spawn_position_x` = '3116.892334', `spawn_position_y` = '-3132.235107', `spawn_position_z` = '294.063049', `spawn_orientation` = '5.893535',`position_x` = '3116.892334', `position_y` = '-3132.235107', `position_z` = '294.063049', `orientation` = '5.893535' WHERE `guid` = '285270';
UPDATE `creature` SET `spawn_position_x` = '3114.223877', `spawn_position_y` = '-3139.612305', `spawn_position_z` = '294.063049', `spawn_orientation` = '6.140934',`position_x` = '3114.223877', `position_y` = '-3139.612305', `position_z` = '294.063049', `orientation` = '6.140934' WHERE `guid` = '285278';
UPDATE `creature` SET `spawn_position_x` = '3114.887939', `spawn_position_y` = '-3144.837891', `spawn_position_z` = '294.063049', `spawn_orientation` = '5.284852',`position_x` = '3114.887939', `position_y` = '-3144.837891', `position_z` = '294.063049', `orientation` = '5.284852' WHERE `guid` = '285280';
DELETE FROM `creature` WHERE `guid` = '285284';
DELETE FROM `creature_addon` WHERE `guid` = '285284';
DELETE FROM `creature_movement` WHERE `id` = '285284';
UPDATE `creature` SET `spawn_position_x` = '3136.144287', `spawn_position_y` = '-3302.142578', `spawn_position_z` = '293.628601', `spawn_orientation` = '0.611730',`position_x` = '3136.144287', `position_y` = '-3302.142578', `position_z` = '293.628601', `orientation` = '0.611730' WHERE `guid` = '284157';
UPDATE `creature` SET `spawn_position_x` = '3122.153809', `spawn_position_y` = '-3300.134033', `spawn_position_z` = '293.628723', `spawn_orientation` = '2.500612',`position_x` = '3122.153809', `position_y` = '-3300.134033', `position_z` = '293.628723', `orientation` = '2.500612' WHERE `guid` = '284156';
UPDATE `creature` SET `spawn_position_x` = '3113.724121', `spawn_position_y` = '-3319.019287', `spawn_position_z` = '293.628662', `spawn_orientation` = '2.720522',`position_x` = '3113.724121', `position_y` = '-3319.019287', `position_z` = '293.628662', `orientation` = '2.720522' WHERE `guid` = '284158';
DELETE FROM `creature` WHERE `guid` = '284751';
DELETE FROM `creature_addon` WHERE `guid` = '284751';
DELETE FROM `creature_movement` WHERE `id` = '284751';
UPDATE `creature` SET `spawn_position_x` = '-5113.863281', `spawn_position_y` = '679.422913', `spawn_position_z` = '104.518250', `spawn_orientation` = '4.533279',`position_x` = '-5113.863281', `position_y` = '679.422913', `position_z` = '104.518250', `orientation` = '4.533279' WHERE `guid` = '283929';
DELETE FROM `creature` WHERE `guid` = '283727';
DELETE FROM `creature_addon` WHERE `guid` = '283727';
DELETE FROM `creature_movement` WHERE `id` = '283727';
DELETE FROM `creature` WHERE `guid` = '283754';
DELETE FROM `creature_addon` WHERE `guid` = '283754';
DELETE FROM `creature_movement` WHERE `id` = '283754';
DELETE FROM `creature` WHERE `guid` = '283752';
DELETE FROM `creature_addon` WHERE `guid` = '283752';
DELETE FROM `creature_movement` WHERE `id` = '283752';
DELETE FROM `creature` WHERE `guid` = '283753';
DELETE FROM `creature_addon` WHERE `guid` = '283753';
DELETE FROM `creature_movement` WHERE `id` = '283753';
DELETE FROM `creature` WHERE `guid` = '283532';
DELETE FROM `creature_addon` WHERE `guid` = '283532';
DELETE FROM `creature_movement` WHERE `id` = '283532';
DELETE FROM `creature` WHERE `guid` = '283537';
DELETE FROM `creature_addon` WHERE `guid` = '283537';
DELETE FROM `creature_movement` WHERE `id` = '283537';
DELETE FROM `creature` WHERE `guid` = '283533';
DELETE FROM `creature_addon` WHERE `guid` = '283533';
DELETE FROM `creature_movement` WHERE `id` = '283533';
DELETE FROM `creature` WHERE `guid` = '283534';
DELETE FROM `creature_addon` WHERE `guid` = '283534';
DELETE FROM `creature_movement` WHERE `id` = '283534';
DELETE FROM `creature` WHERE `guid` = '283348';
DELETE FROM `creature_addon` WHERE `guid` = '283348';
DELETE FROM `creature_movement` WHERE `id` = '283348';
DELETE FROM `creature` WHERE `guid` = '283538';
DELETE FROM `creature_addon` WHERE `guid` = '283538';
DELETE FROM `creature_movement` WHERE `id` = '283538';
DELETE FROM `creature` WHERE `guid` = '283324';
DELETE FROM `creature_addon` WHERE `guid` = '283324';
DELETE FROM `creature_movement` WHERE `id` = '283324';
DELETE FROM `creature` WHERE `guid` = '283539';
DELETE FROM `creature_addon` WHERE `guid` = '283539';
DELETE FROM `creature_movement` WHERE `id` = '283539';
UPDATE `creature` SET `spawn_position_x` = '-2352.811035', `spawn_position_y` = '3232.441895', `spawn_position_z` = '-3.375449', `spawn_orientation` = '3.292132',`position_x` = '-2352.811035', `position_y` = '3232.441895', `position_z` = '-3.375449', `orientation` = '3.292132' WHERE `guid` = '283535';
UPDATE `creature` SET `spawn_position_x` = '-284.241302', `spawn_position_y` = '-530.428528', `spawn_position_z` = '49.184017', `spawn_orientation` = '2.632760',`position_x` = '-284.241302', `position_y` = '-530.428528', `position_z` = '49.184017', `orientation` = '2.632760' WHERE `guid` = '103940';
UPDATE `creature` SET `spawn_position_x` = '-205.441910', `spawn_position_y` = '-505.146362', `spawn_position_z` = '52.054722', `spawn_orientation` = '2.672890',`position_x` = '-205.441910', `position_y` = '-505.146362', `position_z` = '52.054722', `orientation` = '2.672890' WHERE `guid` = '284501';
UPDATE `creature` SET `spawn_position_x` = '-162.875931', `spawn_position_y` = '-396.884186', `spawn_position_z` = '56.825138', `spawn_orientation` = '3.374991',`position_x` = '-162.875931', `position_y` = '-396.884186', `position_z` = '56.825138', `orientation` = '3.374991' WHERE `guid` = '282565';
UPDATE `creature` SET `spawn_position_x` = '-188.269424', `spawn_position_y` = '-475.657074', `spawn_position_z` = '54.044994', `spawn_orientation` = '1.601125',`position_x` = '-188.269424', `position_y` = '-475.657074', `position_z` = '54.044994', `orientation` = '1.601125' WHERE `guid` = '289335';
DELETE FROM `creature` WHERE `guid` = '289353';
DELETE FROM `creature_addon` WHERE `guid` = '289353';
DELETE FROM `creature_movement` WHERE `id` = '289353';
DELETE FROM `creature` WHERE `guid` = '284491';
DELETE FROM `creature_addon` WHERE `guid` = '284491';
DELETE FROM `creature_movement` WHERE `id` = '284491';
DELETE FROM `creature` WHERE `guid` = '289330';
DELETE FROM `creature_addon` WHERE `guid` = '289330';
DELETE FROM `creature_movement` WHERE `id` = '289330';
DELETE FROM `creature` WHERE `guid` = '282558';
DELETE FROM `creature_addon` WHERE `guid` = '282558';
DELETE FROM `creature_movement` WHERE `id` = '282558';
DELETE FROM `creature` WHERE `guid` = '289352';
DELETE FROM `creature_addon` WHERE `guid` = '289352';
DELETE FROM `creature_movement` WHERE `id` = '289352';
DELETE FROM `creature` WHERE `guid` = '284490';
DELETE FROM `creature_addon` WHERE `guid` = '284490';
DELETE FROM `creature_movement` WHERE `id` = '284490';
DELETE FROM `creature` WHERE `guid` = '282557';
DELETE FROM `creature_addon` WHERE `guid` = '282557';
DELETE FROM `creature_movement` WHERE `id` = '282557';
DELETE FROM `creature` WHERE `guid` = '289329';
DELETE FROM `creature_addon` WHERE `guid` = '289329';
DELETE FROM `creature_movement` WHERE `id` = '289329';
UPDATE `creature` SET `spawn_position_x` = '9017.324219', `spawn_position_y` = '-6274.828125', `spawn_position_z` = '20.252151', `spawn_orientation` = '4.591376',`position_x` = '9017.324219', `position_y` = '-6274.828125', `position_z` = '20.252151', `orientation` = '4.591376' WHERE `guid` = '280129';
UPDATE `creature` SET `spawn_position_x` = '9008.995117', `spawn_position_y` = '-6126.400879', `spawn_position_z` = '30.004398', `spawn_orientation` = '5.848798',`position_x` = '9008.995117', `position_y` = '-6126.400879', `position_z` = '30.004398', `orientation` = '5.848798' WHERE `guid` = '56582';
UPDATE `creature` SET `spawn_position_x` = '9086.461914', `spawn_position_y` = '-6161.434570', `spawn_position_z` = '37.237148', `spawn_orientation` = '3.161173',`position_x` = '9086.461914', `position_y` = '-6161.434570', `position_z` = '37.237148', `orientation` = '3.161173' WHERE `guid` = '280127';
UPDATE `creature` SET `spawn_position_x` = '220.664001', `spawn_position_y` = '1074.004639', `spawn_position_z` = '-60.720051', `spawn_orientation` = '0.085950',`position_x` = '220.664001', `position_y` = '1074.004639', `position_z` = '-60.720051', `orientation` = '0.085950' WHERE `guid` = '280096';
UPDATE `creature` SET `spawn_position_x` = '-217.095840', `spawn_position_y` = '2162.500488', `spawn_position_z` = '79.765190', `spawn_orientation` = '1.416844',`position_x` = '-217.095840', `position_y` = '2162.500488', `position_z` = '79.765190', `orientation` = '1.416844' WHERE `guid` = '51724';
UPDATE `creature` SET `spawn_position_x` = '-767.085449', `spawn_position_y` = '-50.188808', `spawn_position_z` = '-29.931101', `spawn_orientation` = '2.346969',`position_x` = '-767.085449', `position_y` = '-50.188808', `position_z` = '-29.931101', `orientation` = '2.346969' WHERE `guid` = '103939';
UPDATE `creature` SET `spawn_position_x` = '-754.125427', `spawn_position_y` = '-58.006367', `spawn_position_z` = '-29.930733', `spawn_orientation` = '6.234689',`position_x` = '-754.125427', `position_y` = '-58.006367', `position_z` = '-29.930733', `orientation` = '6.234689' WHERE `guid` = '103977';
UPDATE `creature` SET `spawn_position_x` = '-758.113342', `spawn_position_y` = '-66.716415', `spawn_position_z` = '-29.931799', `spawn_orientation` = '5.072299',`position_x` = '-758.113342', `position_y` = '-66.716415', `position_z` = '-29.931799', `orientation` = '5.072299' WHERE `guid` = '279729';
DELETE FROM `creature` WHERE `guid` = '283699';
DELETE FROM `creature_addon` WHERE `guid` = '283699';
DELETE FROM `creature_movement` WHERE `id` = '283699';
UPDATE `creature` SET `spawn_position_x` = '245.351624', `spawn_position_y` = '143.290512', `spawn_position_z` = '109.659943', `spawn_orientation` = '1.588596',`position_x` = '245.351624', `position_y` = '143.290512', `position_z` = '109.659943', `orientation` = '1.588596' WHERE `guid` = '103700';
DELETE FROM `creature` WHERE `guid` = '103670';
DELETE FROM `creature_addon` WHERE `guid` = '103670';
DELETE FROM `creature_movement` WHERE `id` = '103670';
DELETE FROM `creature` WHERE `guid` = '103025';
DELETE FROM `creature_addon` WHERE `guid` = '103025';
DELETE FROM `creature_movement` WHERE `id` = '103025';
DELETE FROM `creature` WHERE `guid` = '103028';
DELETE FROM `creature_addon` WHERE `guid` = '103028';
DELETE FROM `creature_movement` WHERE `id` = '103028';
DELETE FROM `creature` WHERE `guid` = '283316';
DELETE FROM `creature_addon` WHERE `guid` = '283316';
DELETE FROM `creature_movement` WHERE `id` = '283316';
DELETE FROM `creature` WHERE `guid` = '103029';
DELETE FROM `creature_addon` WHERE `guid` = '103029';
DELETE FROM `creature_movement` WHERE `id` = '103029';
UPDATE `creature` SET `spawn_position_x` = '3749.374268', `spawn_position_y` = '2361.455322', `spawn_position_z` = '111.579796', `spawn_orientation` = '1.289722',`position_x` = '3749.374268', `position_y` = '2361.455322', `position_z` = '111.579796', `orientation` = '1.289722' WHERE `guid` = '103027';
UPDATE `creature` SET `spawn_position_x` = '3744.509033', `spawn_position_y` = '2365.457764', `spawn_position_z` = '111.300575', `spawn_orientation` = '0.763506',`position_x` = '3744.509033', `position_y` = '2365.457764', `position_z` = '111.300575', `orientation` = '0.763506' WHERE `guid` = '103024';
DELETE FROM `creature` WHERE `guid` = '283318';
DELETE FROM `creature_addon` WHERE `guid` = '283318';
DELETE FROM `creature_movement` WHERE `id` = '283318';
DELETE FROM `creature` WHERE `guid` = '103023';
DELETE FROM `creature_addon` WHERE `guid` = '103023';
DELETE FROM `creature_movement` WHERE `id` = '103023';
DELETE FROM `creature` WHERE `guid` = '283317';
DELETE FROM `creature_addon` WHERE `guid` = '283317';
DELETE FROM `creature_movement` WHERE `id` = '283317';
DELETE FROM `creature` WHERE `guid` = '283314';
DELETE FROM `creature_addon` WHERE `guid` = '283314';
DELETE FROM `creature_movement` WHERE `id` = '283314';
UPDATE `creature` SET `spawn_position_x` = '3769.065674', `spawn_position_y` = '2382.225098', `spawn_position_z` = '111.941673', `spawn_orientation` = '3.547743',`position_x` = '3769.065674', `position_y` = '2382.225098', `position_z` = '111.941673', `orientation` = '3.547743' WHERE `guid` = '103026';
UPDATE `creature` SET `spawn_position_x` = '3767.429199', `spawn_position_y` = '2368.728516', `spawn_position_z` = '111.797722', `spawn_orientation` = '2.734855',`position_x` = '3767.429199', `position_y` = '2368.728516', `position_z` = '111.797722', `orientation` = '2.734855' WHERE `guid` = '283312';
UPDATE `creature` SET `spawn_position_x` = '3750.566162', `spawn_position_y` = '2387.461670', `spawn_position_z` = '111.808052', `spawn_orientation` = '3.850121',`position_x` = '3750.566162', `position_y` = '2387.461670', `position_z` = '111.808052', `orientation` = '3.850121' WHERE `guid` = '283315';
UPDATE `creature` SET `spawn_position_x` = '-11079.645508', `spawn_position_y` = '-1998.241455', `spawn_position_z` = '113.856705', `spawn_orientation` = '2.571083',`position_x` = '-11079.645508', `position_y` = '-1998.241455', `position_z` = '113.856705', `orientation` = '2.571083' WHERE `guid` = '102878';
UPDATE `creature` SET `spawn_position_x` = '-1614.152466', `spawn_position_y` = '104.018501', `spawn_position_z` = '-17.648645', `spawn_orientation` = '5.340701',`position_x` = '-1614.152466', `position_y` = '104.018501', `position_z` = '-17.648645', `orientation` = '5.340701' WHERE `guid` = '102621';
UPDATE `creature` SET `spawn_position_x` = '-6477.769531', `spawn_position_y` = '-1313.590576', `spawn_position_z` = '133.039108', `spawn_orientation` = '2.713195',`position_x` = '-6477.769531', `position_y` = '-1313.590576', `position_z` = '133.039108', `orientation` = '2.713195' WHERE `guid` = '7272';
UPDATE `creature` SET `spawn_position_x` = '-1615.379883', `spawn_position_y` = '5396.595703', `spawn_position_z` = '-36.735092', `spawn_orientation` = '4.601567',`position_x` = '-1615.379883', `position_y` = '5396.595703', `position_z` = '-36.735092', `orientation` = '4.601567' WHERE `guid` = '67870';
UPDATE `creature` SET `spawn_position_x` = '-918.010864', `spawn_position_y` = '1967.749023', `spawn_position_z` = '67.130463', `spawn_orientation` = '4.567852',`position_x` = '-918.010864', `position_y` = '1967.749023', `position_z` = '67.130463', `orientation` = '4.567852' WHERE `guid` = '60422';
UPDATE `creature` SET `spawn_position_x` = '-3715.125977', `spawn_position_y` = '5372.120117', `spawn_position_z` = '-8.228696', `spawn_orientation` = '6.070079',`position_x` = '-3715.125977', `position_y` = '5372.120117', `position_z` = '-8.228696', `orientation` = '6.070079' WHERE `guid` = '80388';
UPDATE `creature` SET `spawn_position_x` = '-3731.752197', `spawn_position_y` = '5371.355469', `spawn_position_z` = '-8.524940', `spawn_orientation` = '4.852714',`position_x` = '-3731.752197', `position_y` = '5371.355469', `position_z` = '-8.524940', `orientation` = '4.852714' WHERE `guid` = '80085';
UPDATE `creature` SET `spawn_position_x` = '-3729.105225', `spawn_position_y` = '5389.704102', `spawn_position_z` = '-3.692450', `spawn_orientation` = '4.408967',`position_x` = '-3729.105225', `position_y` = '5389.704102', `position_z` = '-3.692450', `orientation` = '4.408967' WHERE `guid` = '80387';
UPDATE `creature` SET `spawn_position_x` = '10133.689453', `spawn_position_y` = '-6058.441895', `spawn_position_z` = '25.571301', `spawn_orientation` = '3.151647',`position_x` = '10133.689453', `position_y` = '-6058.441895', `position_z` = '25.571301', `orientation` = '3.151647' WHERE `guid` = '78171';
UPDATE `creature` SET `spawn_position_x` = '7161.438965', `spawn_position_y` = '-6607.041504', `spawn_position_z` = '60.659248', `spawn_orientation` = '5.452671',`position_x` = '7161.438965', `position_y` = '-6607.041504', `position_z` = '60.659248', `orientation` = '5.452671' WHERE `guid` = '78584';
UPDATE `creature` SET `spawn_position_x` = '-1712.129272', `spawn_position_y` = '5836.437500', `spawn_position_z` = '148.657837', `spawn_orientation` = '3.573559',`position_x` = '-1712.129272', `position_y` = '5836.437500', `position_z` = '148.657837', `orientation` = '3.573559' WHERE `guid` = '78320';
UPDATE `creature` SET `spawn_position_x` = '-1735.093872', `spawn_position_y` = '5835.372559', `spawn_position_z` = '148.657745', `spawn_orientation` = '5.136063',`position_x` = '-1735.093872', `position_y` = '5835.372559', `position_z` = '148.657745', `orientation` = '5.136063' WHERE `guid` = '78318';
UPDATE `creature` SET `spawn_position_x` = '10385.809570', `spawn_position_y` = '-6201.406738', `spawn_position_z` = '32.189049', `spawn_orientation` = '4.603306',`position_x` = '10385.809570', `position_y` = '-6201.406738', `position_z` = '32.189049', `orientation` = '4.603306' WHERE `guid` = '70456';
UPDATE `creature` SET `spawn_position_x` = '10462.119141', `spawn_position_y` = '-6458.944824', `spawn_position_z` = '25.675491', `spawn_orientation` = '4.131600',`position_x` = '10462.119141', `position_y` = '-6458.944824', `position_z` = '25.675491', `orientation` = '4.131600' WHERE `guid` = '78062';
UPDATE `creature` SET `spawn_position_x` = '10471.442383', `spawn_position_y` = '-6467.420898', `spawn_position_z` = '20.718117', `spawn_orientation` = '5.545316',`position_x` = '10471.442383', `position_y` = '-6467.420898', `position_z` = '20.718117', `orientation` = '5.545316' WHERE `guid` = '69609';
UPDATE `creature` SET `spawn_position_x` = '10455.095703', `spawn_position_y` = '-6462.573730', `spawn_position_z` = '25.936443', `spawn_orientation` = '3.687850',`position_x` = '10455.095703', `position_y` = '-6462.573730', `position_z` = '25.936443', `orientation` = '3.687850' WHERE `guid` = '78049';
UPDATE `creature` SET `spawn_position_x` = '10432.668945', `spawn_position_y` = '-6434.875000', `spawn_position_z` = '41.534840', `spawn_orientation` = '1.959974',`position_x` = '10432.668945', `position_y` = '-6434.875000', `position_z` = '41.534840', `orientation` = '1.959974' WHERE `guid` = '78048';
UPDATE `creature` SET `spawn_position_x` = '9198.661133', `spawn_position_y` = '-7217.060059', `spawn_position_z` = '3.376063', `spawn_orientation` = '4.442277',`position_x` = '9198.661133', `position_y` = '-7217.060059', `position_z` = '3.376063', `orientation` = '4.442277' WHERE `guid` = '77684';
UPDATE `creature` SET `spawn_position_x` = '-3374.416260', `spawn_position_y` = '2774.062500', `spawn_position_z` = '118.035545', `spawn_orientation` = '0.115182',`position_x` = '-3374.416260', `position_y` = '2774.062500', `position_z` = '118.035545', `orientation` = '0.115182' WHERE `guid` = '77161';
UPDATE `creature` SET `spawn_position_x` = '-3316.267578', `spawn_position_y` = '2791.147461', `spawn_position_z` = '123.578148', `spawn_orientation` = '0.421487',`position_x` = '-3316.267578', `position_y` = '2791.147461', `position_z` = '123.578148', `orientation` = '0.421487' WHERE `guid` = '75601';
UPDATE `creature` SET `spawn_position_x` = '-3338.749512', `spawn_position_y` = '2807.367432', `spawn_position_z` = '127.956451', `spawn_orientation` = '1.320768',`position_x` = '-3338.749512', `position_y` = '2807.367432', `position_z` = '127.956451', `orientation` = '1.320768' WHERE `guid` = '73665';
UPDATE `creature` SET `spawn_position_x` = '-3379.871826', `spawn_position_y` = '2718.006104', `spawn_position_z` = '130.558258', `spawn_orientation` = '5.271321',`position_x` = '-3379.871826', `position_y` = '2718.006104', `position_z` = '130.558258', `orientation` = '5.271321' WHERE `guid` = '77166';
DELETE FROM `creature` WHERE `guid` = '77168';
DELETE FROM `creature_addon` WHERE `guid` = '77168';
DELETE FROM `creature_movement` WHERE `id` = '77168';
UPDATE `creature` SET `spawn_position_x` = '-3416.774658', `spawn_position_y` = '2725.641602', `spawn_position_z` = '125.897270', `spawn_orientation` = '2.549916',`position_x` = '-3416.774658', `position_y` = '2725.641602', `position_z` = '125.897270', `orientation` = '2.549916' WHERE `guid` = '73653';
UPDATE `creature` SET `spawn_position_x` = '-3432.216553', `spawn_position_y` = '2728.243896', `spawn_position_z` = '128.215347', `spawn_orientation` = '2.997593',`position_x` = '-3432.216553', `position_y` = '2728.243896', `position_z` = '128.215347', `orientation` = '2.997593' WHERE `guid` = '73655';
UPDATE `creature` SET `spawn_position_x` = '-3458.639160', `spawn_position_y` = '2724.756836', `spawn_position_z` = '131.859940', `spawn_orientation` = '3.508101',`position_x` = '-3458.639160', `position_y` = '2724.756836', `position_z` = '131.859940', `orientation` = '3.508101' WHERE `guid` = '77167';
UPDATE `creature` SET `spawn_position_x` = '-4073.226074', `spawn_position_y` = '2174.046143', `spawn_position_z` = '107.503410', `spawn_orientation` = '4.182251',`position_x` = '-4073.226074', `position_y` = '2174.046143', `position_z` = '107.503410', `orientation` = '4.182251' WHERE `guid` = '77096';
UPDATE `creature` SET `spawn_position_x` = '-4005.561523', `spawn_position_y` = '1747.750977', `spawn_position_z` = '97.194893', `spawn_orientation` = '3.686132',`position_x` = '-4005.561523', `position_y` = '1747.750977', `position_z` = '97.194893', `orientation` = '3.686132' WHERE `guid` = '76891';
UPDATE `creature` SET `spawn_position_x` = '-3891.701172', `spawn_position_y` = '1383.217896', `spawn_position_z` = '43.072453', `spawn_orientation` = '5.153617',`position_x` = '-3891.701172', `position_y` = '1383.217896', `position_z` = '43.072453', `orientation` = '5.153617' WHERE `guid` = '73556';
UPDATE `creature` SET `spawn_position_x` = '-3866.228760', `spawn_position_y` = '1419.196411', `spawn_position_z` = '42.409618', `spawn_orientation` = '6.217831',`position_x` = '-3866.228760', `position_y` = '1419.196411', `position_z` = '42.409618', `orientation` = '6.217831' WHERE `guid` = '73559';
UPDATE `creature` SET `spawn_position_x` = '-4010.051025', `spawn_position_y` = '1012.906921', `spawn_position_z` = '19.716413', `spawn_orientation` = '0.765252',`position_x` = '-4010.051025', `position_y` = '1012.906921', `position_z` = '19.716413', `orientation` = '0.765252' WHERE `guid` = '76593';
UPDATE `creature` SET `spawn_position_x` = '-3184.787842', `spawn_position_y` = '1090.639282', `spawn_position_z` = '71.044922', `spawn_orientation` = '2.660894',`position_x` = '-3184.787842', `position_y` = '1090.639282', `position_z` = '71.044922', `orientation` = '2.660894' WHERE `guid` = '76306';
UPDATE `creature` SET `spawn_position_x` = '-3188.334473', `spawn_position_y` = '1082.553589', `spawn_position_z` = '70.208054', `spawn_orientation` = '3.210673',`position_x` = '-3188.334473', `position_y` = '1082.553589', `position_z` = '70.208054', `orientation` = '3.210673' WHERE `guid` = '76185';
UPDATE `creature` SET `spawn_position_x` = '-3172.572510', `spawn_position_y` = '1092.294312', `spawn_position_z` = '72.973854', `spawn_orientation` = '4.753983',`position_x` = '-3172.572510', `position_y` = '1092.294312', `position_z` = '72.973854', `orientation` = '4.753983' WHERE `guid` = '76166';
UPDATE `creature` SET `spawn_position_x` = '-3175.056885', `spawn_position_y` = '1078.866333', `spawn_position_z` = '72.106384', `spawn_orientation` = '2.783083',`position_x` = '-3175.056885', `position_y` = '1078.866333', `position_z` = '72.106384', `orientation` = '2.783083' WHERE `guid` = '76266';
UPDATE `creature` SET `spawn_position_x` = '-2910.466797', `spawn_position_y` = '1540.102417', `spawn_position_z` = '10.849545', `spawn_orientation` = '0.078266',`position_x` = '-2910.466797', `position_y` = '1540.102417', `position_z` = '10.849545', `orientation` = '0.078266' WHERE `guid` = '76118';
UPDATE `creature` SET `spawn_position_x` = '-2936.385986', `spawn_position_y` = '1538.566040', `spawn_position_z` = '6.391804', `spawn_orientation` = '3.420135',`position_x` = '-2936.385986', `position_y` = '1538.566040', `position_z` = '6.391804', `orientation` = '3.420135' WHERE `guid` = '75968';
UPDATE `creature` SET `spawn_position_x` = '-2934.192383', `spawn_position_y` = '1525.632080', `spawn_position_z` = '6.143850', `spawn_orientation` = '3.675390',`position_x` = '-2934.192383', `position_y` = '1525.632080', `position_z` = '6.143850', `orientation` = '3.675390' WHERE `guid` = '76049';
UPDATE `creature` SET `spawn_position_x` = '-2931.888184', `spawn_position_y` = '1532.957031', `spawn_position_z` = '9.317682', `spawn_orientation` = '6.035513',`position_x` = '-2931.888184', `position_y` = '1532.957031', `position_z` = '9.317682', `orientation` = '6.035513' WHERE `guid` = '75960';
UPDATE `creature` SET `spawn_position_x` = '-3143.834961', `spawn_position_y` = '2245.025146', `spawn_position_z` = '61.732479', `spawn_orientation` = '3.735556',`position_x` = '-3143.834961', `position_y` = '2245.025146', `position_z` = '61.732479', `orientation` = '3.735556' WHERE `guid` = '75778';
UPDATE `creature` SET `spawn_position_x` = '-3141.450195', `spawn_position_y` = '2165.802979', `spawn_position_z` = '72.720604', `spawn_orientation` = '4.935431',`position_x` = '-3141.450195', `position_y` = '2165.802979', `position_z` = '72.720604', `orientation` = '4.935431' WHERE `guid` = '75776';
UPDATE `creature` SET `spawn_position_x` = '-3150.694092', `spawn_position_y` = '2646.963867', `spawn_position_z` = '62.582153', `spawn_orientation` = '1.214416',`position_x` = '-3150.694092', `position_y` = '2646.963867', `position_z` = '62.582153', `orientation` = '1.214416' WHERE `guid` = '75588';
UPDATE `creature` SET `spawn_position_x` = '-3138.983887', `spawn_position_y` = '2636.497314', `spawn_position_z` = '63.565243', `spawn_orientation` = '5.773653',`position_x` = '-3138.983887', `position_y` = '2636.497314', `position_z` = '63.565243', `orientation` = '5.773653' WHERE `guid` = '75156';
UPDATE `creature` SET `spawn_position_x` = '-3156.913574', `spawn_position_y` = '2646.302734', `spawn_position_z` = '83.744896', `spawn_orientation` = '3.668784',`position_x` = '-3156.913574', `position_y` = '2646.302734', `position_z` = '83.744896', `orientation` = '3.668784' WHERE `guid` = '75624';
UPDATE `creature` SET `spawn_position_x` = '-3154.801514', `spawn_position_y` = '2626.603271', `spawn_position_z` = '74.463196', `spawn_orientation` = '4.375642',`position_x` = '-3154.801514', `position_y` = '2626.603271', `position_z` = '74.463196', `orientation` = '4.375642' WHERE `guid` = '75663';
UPDATE `creature` SET `spawn_position_x` = '-3153.892578', `spawn_position_y` = '2631.535645', `spawn_position_z` = '61.826378', `spawn_orientation` = '4.662313',`position_x` = '-3153.892578', `position_y` = '2631.535645', `position_z` = '61.826378', `orientation` = '4.662313' WHERE `guid` = '75155';
UPDATE `creature` SET `spawn_position_x` = '-3176.759033', `spawn_position_y` = '2641.630859', `spawn_position_z` = '63.386852', `spawn_orientation` = '2.906949',`position_x` = '-3176.759033', `position_y` = '2641.630859', `position_z` = '63.386852', `orientation` = '2.906949' WHERE `guid` = '75624';
UPDATE `creature` SET `spawn_position_x` = '-3176.294434', `spawn_position_y` = '2618.368896', `spawn_position_z` = '62.967236', `spawn_orientation` = '4.725146',`position_x` = '-3176.294434', `position_y` = '2618.368896', `position_z` = '62.967236', `orientation` = '4.725146' WHERE `guid` = '75663';
UPDATE `creature` SET `spawn_position_x` = '-3221.438721', `spawn_position_y` = '2606.408447', `spawn_position_z` = '62.157574', `spawn_orientation` = '1.677801',`position_x` = '-3221.438721', `position_y` = '2606.408447', `position_z` = '62.157574', `orientation` = '1.677801' WHERE `guid` = '75580';
UPDATE `creature` SET `spawn_position_x` = '-3163.001221', `spawn_position_y` = '2921.629150', `spawn_position_z` = '97.132011', `spawn_orientation` = '0.631809',`position_x` = '-3163.001221', `position_y` = '2921.629150', `position_z` = '97.132011', `orientation` = '0.631809' WHERE `guid` = '77191';
UPDATE `creature` SET `spawn_position_x` = '-3135.545654', `spawn_position_y` = '2920.331787', `spawn_position_z` = '89.682091', `spawn_orientation` = '4.825838',`position_x` = '-3135.545654', `position_y` = '2920.331787', `position_z` = '89.682091', `orientation` = '4.825838' WHERE `guid` = '75607';
UPDATE `creature` SET `spawn_position_x` = '-3121.349854', `spawn_position_y` = '2946.534180', `spawn_position_z` = '92.797791', `spawn_orientation` = '0.011348',`position_x` = '-3121.349854', `position_y` = '2946.534180', `position_z` = '92.797791', `orientation` = '0.011348' WHERE `guid` = '75604';
UPDATE `creature` SET `spawn_position_x` = '-4067.181152', `spawn_position_y` = '1912.304932', `spawn_position_z` = '75.491249', `spawn_orientation` = '4.234746',`position_x` = '-4067.181152', `position_y` = '1912.304932', `position_z` = '75.491249', `orientation` = '4.234746' WHERE `guid` = '75266';
UPDATE `creature` SET `spawn_position_x` = '-1676.095825', `spawn_position_y` = '5361.244141', `spawn_position_z` = '-44.522141', `spawn_orientation` = '4.235973',`position_x` = '-1676.095825', `position_y` = '5361.244141', `position_z` = '-44.522141', `orientation` = '4.235973' WHERE `guid` = '74968';
UPDATE `creature` SET `spawn_position_x` = '-1680.151855', `spawn_position_y` = '5369.859863', `spawn_position_z` = '-41.622711', `spawn_orientation` = '1.463518',`position_x` = '-1680.151855', `position_y` = '5369.859863', `position_z` = '-41.622711', `orientation` = '1.463518' WHERE `guid` = '68207';
UPDATE `creature` SET `spawn_position_x` = '1001.893127', `spawn_position_y` = '7454.370117', `spawn_position_z` = '22.944191', `spawn_orientation` = '1.918549',`position_x` = '1001.893127', `position_y` = '7454.370117', `position_z` = '22.944191', `orientation` = '1.918549' WHERE `guid` = '65060';
UPDATE `creature` SET `spawn_position_x` = '1014.553711', `spawn_position_y` = '7456.314941', `spawn_position_z` = '23.092661', `spawn_orientation` = '1.989235',`position_x` = '1014.553711', `position_y` = '7456.314941', `position_z` = '23.092661', `orientation` = '1.989235' WHERE `guid` = '65058';
UPDATE `creature` SET `spawn_position_x` = '1021.693542', `spawn_position_y` = '7458.981934', `spawn_position_z` = '23.070585', `spawn_orientation` = '2.028504',`position_x` = '1021.693542', `position_y` = '7458.981934', `position_z` = '23.070585', `orientation` = '2.028504' WHERE `guid` = '74865';
DELETE FROM `creature` WHERE `guid` = '74770';
DELETE FROM `creature_addon` WHERE `guid` = '74770';
DELETE FROM `creature_movement` WHERE `id` = '74770';
DELETE FROM `creature` WHERE `guid` = '74816';
DELETE FROM `creature_addon` WHERE `guid` = '74816';
DELETE FROM `creature_movement` WHERE `id` = '74816';
DELETE FROM `creature` WHERE `guid` = '74813';
DELETE FROM `creature_addon` WHERE `guid` = '74813';
DELETE FROM `creature_movement` WHERE `id` = '74813';
DELETE FROM `creature` WHERE `guid` = '74784';
DELETE FROM `creature_addon` WHERE `guid` = '74784';
DELETE FROM `creature_movement` WHERE `id` = '74784';
UPDATE `creature` SET `spawn_position_x` = '-3311.455322', `spawn_position_y` = '5200.014648', `spawn_position_z` = '-20.894014', `spawn_orientation` = '0.528907',`position_x` = '-3311.455322', `position_y` = '5200.014648', `position_z` = '-20.894014', `orientation` = '0.528907' WHERE `guid` = '74159';
UPDATE `creature` SET `spawn_position_x` = '-3386.680664', `spawn_position_y` = '5219.152344', `spawn_position_z` = '-20.536745', `spawn_orientation` = '0.117697',`position_x` = '-3386.680664', `position_y` = '5219.152344', `position_z` = '-20.536745', `orientation` = '0.117697' WHERE `guid` = '74174';
DELETE FROM `creature` WHERE `guid` = '74174';
DELETE FROM `creature_addon` WHERE `guid` = '74174';
DELETE FROM `creature_movement` WHERE `id` = '74174';
DELETE FROM `creature` WHERE `guid` = '74114';
DELETE FROM `creature_addon` WHERE `guid` = '74114';
DELETE FROM `creature_movement` WHERE `id` = '74114';
DELETE FROM `creature` WHERE `guid` = '74116';
DELETE FROM `creature_addon` WHERE `guid` = '74116';
DELETE FROM `creature_movement` WHERE `id` = '74116';
DELETE FROM `creature` WHERE `guid` = '74117';
DELETE FROM `creature_addon` WHERE `guid` = '74117';
DELETE FROM `creature_movement` WHERE `id` = '74117';
DELETE FROM `creature` WHERE `guid` = '74146';
DELETE FROM `creature_addon` WHERE `guid` = '74146';
DELETE FROM `creature_movement` WHERE `id` = '74146';
DELETE FROM `creature` WHERE `guid` = '74115';
DELETE FROM `creature_addon` WHERE `guid` = '74115';
DELETE FROM `creature_movement` WHERE `id` = '74115';
DELETE FROM `creature` WHERE `guid` = '74120';
DELETE FROM `creature_addon` WHERE `guid` = '74120';
DELETE FROM `creature_movement` WHERE `id` = '74120';
DELETE FROM `creature` WHERE `guid` = '74127';
DELETE FROM `creature_addon` WHERE `guid` = '74127';
DELETE FROM `creature_movement` WHERE `id` = '74127';
DELETE FROM `creature` WHERE `guid` = '74118';
DELETE FROM `creature_addon` WHERE `guid` = '74118';
DELETE FROM `creature_movement` WHERE `id` = '74118';
DELETE FROM `creature` WHERE `guid` = '74121';
DELETE FROM `creature_addon` WHERE `guid` = '74121';
DELETE FROM `creature_movement` WHERE `id` = '74121';
DELETE FROM `creature` WHERE `guid` = '74124';
DELETE FROM `creature_addon` WHERE `guid` = '74124';
DELETE FROM `creature_movement` WHERE `id` = '74124';
DELETE FROM `creature` WHERE `guid` = '74139';
DELETE FROM `creature_addon` WHERE `guid` = '74139';
DELETE FROM `creature_movement` WHERE `id` = '74139';
DELETE FROM `creature` WHERE `guid` = '74140';
DELETE FROM `creature_addon` WHERE `guid` = '74140';
DELETE FROM `creature_movement` WHERE `id` = '74140';
DELETE FROM `creature` WHERE `guid` = '74130';
DELETE FROM `creature_addon` WHERE `guid` = '74130';
DELETE FROM `creature_movement` WHERE `id` = '74130';
DELETE FROM `creature` WHERE `guid` = '74129';
DELETE FROM `creature_addon` WHERE `guid` = '74129';
DELETE FROM `creature_movement` WHERE `id` = '74129';
DELETE FROM `creature` WHERE `guid` = '74123';
DELETE FROM `creature_addon` WHERE `guid` = '74123';
DELETE FROM `creature_movement` WHERE `id` = '74123';
DELETE FROM `creature` WHERE `guid` = '74125';
DELETE FROM `creature_addon` WHERE `guid` = '74125';
DELETE FROM `creature_movement` WHERE `id` = '74125';
DELETE FROM `creature` WHERE `guid` = '74126';
DELETE FROM `creature_addon` WHERE `guid` = '74126';
DELETE FROM `creature_movement` WHERE `id` = '74126';
DELETE FROM `creature` WHERE `guid` = '74141';
DELETE FROM `creature_addon` WHERE `guid` = '74141';
DELETE FROM `creature_movement` WHERE `id` = '74141';
DELETE FROM `creature` WHERE `guid` = '74133';
DELETE FROM `creature_addon` WHERE `guid` = '74133';
DELETE FROM `creature_movement` WHERE `id` = '74133';
DELETE FROM `creature` WHERE `guid` = '74145';
DELETE FROM `creature_addon` WHERE `guid` = '74145';
DELETE FROM `creature_movement` WHERE `id` = '74145';
DELETE FROM `creature` WHERE `guid` = '74143';
DELETE FROM `creature_addon` WHERE `guid` = '74143';
DELETE FROM `creature_movement` WHERE `id` = '74143';
DELETE FROM `creature` WHERE `guid` = '74219';
DELETE FROM `creature_addon` WHERE `guid` = '74219';
DELETE FROM `creature_movement` WHERE `id` = '74219';
DELETE FROM `creature` WHERE `guid` = '74285';
DELETE FROM `creature_addon` WHERE `guid` = '74285';
DELETE FROM `creature_movement` WHERE `id` = '74285';
DELETE FROM `creature` WHERE `guid` = '74217';
DELETE FROM `creature_addon` WHERE `guid` = '74217';
DELETE FROM `creature_movement` WHERE `id` = '74217';
DELETE FROM `creature` WHERE `guid` = '74284';
DELETE FROM `creature_addon` WHERE `guid` = '74284';
DELETE FROM `creature_movement` WHERE `id` = '74284';
DELETE FROM `creature` WHERE `guid` = '74213';
DELETE FROM `creature_addon` WHERE `guid` = '74213';
DELETE FROM `creature_movement` WHERE `id` = '74213';
DELETE FROM `creature` WHERE `guid` = '74214';
DELETE FROM `creature_addon` WHERE `guid` = '74214';
DELETE FROM `creature_movement` WHERE `id` = '74214';
DELETE FROM `creature` WHERE `guid` = '74216';
DELETE FROM `creature_addon` WHERE `guid` = '74216';
DELETE FROM `creature_movement` WHERE `id` = '74216';
DELETE FROM `creature` WHERE `guid` = '74218';
DELETE FROM `creature_addon` WHERE `guid` = '74218';
DELETE FROM `creature_movement` WHERE `id` = '74218';
DELETE FROM `creature` WHERE `guid` = '74222';
DELETE FROM `creature_addon` WHERE `guid` = '74222';
DELETE FROM `creature_movement` WHERE `id` = '74222';
DELETE FROM `creature` WHERE `guid` = '74271';
DELETE FROM `creature_addon` WHERE `guid` = '74271';
DELETE FROM `creature_movement` WHERE `id` = '74271';
DELETE FROM `creature` WHERE `guid` = '74272';
DELETE FROM `creature_addon` WHERE `guid` = '74272';
DELETE FROM `creature_movement` WHERE `id` = '74272';
DELETE FROM `creature` WHERE `guid` = '74270';
DELETE FROM `creature_addon` WHERE `guid` = '74270';
DELETE FROM `creature_movement` WHERE `id` = '74270';
DELETE FROM `creature` WHERE `guid` = '74274';
DELETE FROM `creature_addon` WHERE `guid` = '74274';
DELETE FROM `creature_movement` WHERE `id` = '74274';
DELETE FROM `creature` WHERE `guid` = '74241';
DELETE FROM `creature_addon` WHERE `guid` = '74241';
DELETE FROM `creature_movement` WHERE `id` = '74241';
DELETE FROM `creature` WHERE `guid` = '74273';
DELETE FROM `creature_addon` WHERE `guid` = '74273';
DELETE FROM `creature_movement` WHERE `id` = '74273';
DELETE FROM `creature` WHERE `guid` = '74221';
DELETE FROM `creature_addon` WHERE `guid` = '74221';
DELETE FROM `creature_movement` WHERE `id` = '74221';
DELETE FROM `creature` WHERE `guid` = '74275';
DELETE FROM `creature_addon` WHERE `guid` = '74275';
DELETE FROM `creature_movement` WHERE `id` = '74275';
DELETE FROM `creature` WHERE `guid` = '74220';
DELETE FROM `creature_addon` WHERE `guid` = '74220';
DELETE FROM `creature_movement` WHERE `id` = '74220';
DELETE FROM `creature` WHERE `guid` = '74215';
DELETE FROM `creature_addon` WHERE `guid` = '74215';
DELETE FROM `creature_movement` WHERE `id` = '74215';
DELETE FROM `creature` WHERE `guid` = '74253';
DELETE FROM `creature_addon` WHERE `guid` = '74253';
DELETE FROM `creature_movement` WHERE `id` = '74253';
DELETE FROM `creature` WHERE `guid` = '74224';
DELETE FROM `creature_addon` WHERE `guid` = '74224';
DELETE FROM `creature_movement` WHERE `id` = '74224';
DELETE FROM `creature` WHERE `guid` = '74282';
DELETE FROM `creature_addon` WHERE `guid` = '74282';
DELETE FROM `creature_movement` WHERE `id` = '74282';
DELETE FROM `creature` WHERE `guid` = '74283';
DELETE FROM `creature_addon` WHERE `guid` = '74283';
DELETE FROM `creature_movement` WHERE `id` = '74283';
DELETE FROM `creature` WHERE `guid` = '74277';
DELETE FROM `creature_addon` WHERE `guid` = '74277';
DELETE FROM `creature_movement` WHERE `id` = '74277';
DELETE FROM `creature` WHERE `guid` = '74278';
DELETE FROM `creature_addon` WHERE `guid` = '74278';
DELETE FROM `creature_movement` WHERE `id` = '74278';
DELETE FROM `creature` WHERE `guid` = '74279';
DELETE FROM `creature_addon` WHERE `guid` = '74279';
DELETE FROM `creature_movement` WHERE `id` = '74279';
DELETE FROM `creature` WHERE `guid` = '74242';
DELETE FROM `creature_addon` WHERE `guid` = '74242';
DELETE FROM `creature_movement` WHERE `id` = '74242';
DELETE FROM `creature` WHERE `guid` = '74243';
DELETE FROM `creature_addon` WHERE `guid` = '74243';
DELETE FROM `creature_movement` WHERE `id` = '74243';
DELETE FROM `creature` WHERE `guid` = '74281';
DELETE FROM `creature_addon` WHERE `guid` = '74281';
DELETE FROM `creature_movement` WHERE `id` = '74281';
DELETE FROM `creature` WHERE `guid` = '74276';
DELETE FROM `creature_addon` WHERE `guid` = '74276';
DELETE FROM `creature_movement` WHERE `id` = '74276';
DELETE FROM `creature` WHERE `guid` = '74137';
DELETE FROM `creature_addon` WHERE `guid` = '74137';
DELETE FROM `creature_movement` WHERE `id` = '74137';
DELETE FROM `creature` WHERE `guid` = '74240';
DELETE FROM `creature_addon` WHERE `guid` = '74240';
DELETE FROM `creature_movement` WHERE `id` = '74240';
DELETE FROM `creature` WHERE `guid` = '74244';
DELETE FROM `creature_addon` WHERE `guid` = '74244';
DELETE FROM `creature_movement` WHERE `id` = '74244';
DELETE FROM `creature` WHERE `guid` = '74280';
DELETE FROM `creature_addon` WHERE `guid` = '74280';
DELETE FROM `creature_movement` WHERE `id` = '74280';
DELETE FROM `creature` WHERE `guid` = '74245';
DELETE FROM `creature_addon` WHERE `guid` = '74245';
DELETE FROM `creature_movement` WHERE `id` = '74245';
DELETE FROM `creature` WHERE `guid` = '74223';
DELETE FROM `creature_addon` WHERE `guid` = '74223';
DELETE FROM `creature_movement` WHERE `id` = '74223';
DELETE FROM `creature` WHERE `guid` = '74225';
DELETE FROM `creature_addon` WHERE `guid` = '74225';
DELETE FROM `creature_movement` WHERE `id` = '74225';
DELETE FROM `creature` WHERE `guid` = '74258';
DELETE FROM `creature_addon` WHERE `guid` = '74258';
DELETE FROM `creature_movement` WHERE `id` = '74258';
DELETE FROM `creature` WHERE `guid` = '74255';
DELETE FROM `creature_addon` WHERE `guid` = '74255';
DELETE FROM `creature_movement` WHERE `id` = '74255';
DELETE FROM `creature` WHERE `guid` = '74259';
DELETE FROM `creature_addon` WHERE `guid` = '74259';
DELETE FROM `creature_movement` WHERE `id` = '74259';
DELETE FROM `creature` WHERE `guid` = '74256';
DELETE FROM `creature_addon` WHERE `guid` = '74256';
DELETE FROM `creature_movement` WHERE `id` = '74256';
DELETE FROM `creature` WHERE `guid` = '74257';
DELETE FROM `creature_addon` WHERE `guid` = '74257';
DELETE FROM `creature_movement` WHERE `id` = '74257';
DELETE FROM `creature` WHERE `guid` = '74269';
DELETE FROM `creature_addon` WHERE `guid` = '74269';
DELETE FROM `creature_movement` WHERE `id` = '74269';
DELETE FROM `creature` WHERE `guid` = '74267';
DELETE FROM `creature_addon` WHERE `guid` = '74267';
DELETE FROM `creature_movement` WHERE `id` = '74267';
DELETE FROM `creature` WHERE `guid` = '74265';
DELETE FROM `creature_addon` WHERE `guid` = '74265';
DELETE FROM `creature_movement` WHERE `id` = '74265';
DELETE FROM `creature` WHERE `guid` = '74268';
DELETE FROM `creature_addon` WHERE `guid` = '74268';
DELETE FROM `creature_movement` WHERE `id` = '74268';
DELETE FROM `creature` WHERE `guid` = '74266';
DELETE FROM `creature_addon` WHERE `guid` = '74266';
DELETE FROM `creature_movement` WHERE `id` = '74266';
DELETE FROM `creature` WHERE `guid` = '74226';
DELETE FROM `creature_addon` WHERE `guid` = '74226';
DELETE FROM `creature_movement` WHERE `id` = '74226';
DELETE FROM `creature` WHERE `guid` = '74238';
DELETE FROM `creature_addon` WHERE `guid` = '74238';
DELETE FROM `creature_movement` WHERE `id` = '74238';
DELETE FROM `creature` WHERE `guid` = '74233';
DELETE FROM `creature_addon` WHERE `guid` = '74233';
DELETE FROM `creature_movement` WHERE `id` = '74233';
DELETE FROM `creature` WHERE `guid` = '74232';
DELETE FROM `creature_addon` WHERE `guid` = '74232';
DELETE FROM `creature_movement` WHERE `id` = '74232';
DELETE FROM `creature` WHERE `guid` = '74230';
DELETE FROM `creature_addon` WHERE `guid` = '74230';
DELETE FROM `creature_movement` WHERE `id` = '74230';
DELETE FROM `creature` WHERE `guid` = '74236';
DELETE FROM `creature_addon` WHERE `guid` = '74236';
DELETE FROM `creature_movement` WHERE `id` = '74236';
DELETE FROM `creature` WHERE `guid` = '74235';
DELETE FROM `creature_addon` WHERE `guid` = '74235';
DELETE FROM `creature_movement` WHERE `id` = '74235';
DELETE FROM `creature` WHERE `guid` = '74231';
DELETE FROM `creature_addon` WHERE `guid` = '74231';
DELETE FROM `creature_movement` WHERE `id` = '74231';
DELETE FROM `creature` WHERE `guid` = '74237';
DELETE FROM `creature_addon` WHERE `guid` = '74237';
DELETE FROM `creature_movement` WHERE `id` = '74237';
DELETE FROM `creature` WHERE `guid` = '74239';
DELETE FROM `creature_addon` WHERE `guid` = '74239';
DELETE FROM `creature_movement` WHERE `id` = '74239';
DELETE FROM `creature` WHERE `guid` = '74234';
DELETE FROM `creature_addon` WHERE `guid` = '74234';
DELETE FROM `creature_movement` WHERE `id` = '74234';
DELETE FROM `creature` WHERE `guid` = '74260';
DELETE FROM `creature_addon` WHERE `guid` = '74260';
DELETE FROM `creature_movement` WHERE `id` = '74260';
DELETE FROM `creature` WHERE `guid` = '74263';
DELETE FROM `creature_addon` WHERE `guid` = '74263';
DELETE FROM `creature_movement` WHERE `id` = '74263';
DELETE FROM `creature` WHERE `guid` = '74261';
DELETE FROM `creature_addon` WHERE `guid` = '74261';
DELETE FROM `creature_movement` WHERE `id` = '74261';
DELETE FROM `creature` WHERE `guid` = '74262';
DELETE FROM `creature_addon` WHERE `guid` = '74262';
DELETE FROM `creature_movement` WHERE `id` = '74262';
DELETE FROM `creature` WHERE `guid` = '74264';
DELETE FROM `creature_addon` WHERE `guid` = '74264';
DELETE FROM `creature_movement` WHERE `id` = '74264';
UPDATE `creature` SET `spawn_position_x` = '-3701.980713', `spawn_position_y` = '4730.285645', `spawn_position_z` = '-18.650492', `spawn_orientation` = '4.201236',`position_x` = '-3701.980713', `position_y` = '4730.285645', `position_z` = '-18.650492', `orientation` = '4.201236' WHERE `guid` = '74057';
UPDATE `creature` SET `spawn_position_x` = '-3853.531006', `spawn_position_y` = '4617.615234', `spawn_position_z` = '-27.309853', `spawn_orientation` = '4.086569',`position_x` = '-3853.531006', `position_y` = '4617.615234', `position_z` = '-27.309853', `orientation` = '4.086569' WHERE `guid` = '74038';
UPDATE `creature` SET `spawn_position_x` = '-3833.146484', `spawn_position_y` = '4662.925781', `spawn_position_z` = '-32.313820', `spawn_orientation` = '1.345528',`position_x` = '-3833.146484', `position_y` = '4662.925781', `position_z` = '-32.313820', `orientation` = '1.345528' WHERE `guid` = '74030';
UPDATE `creature` SET `spawn_position_x` = '-3773.051270', `spawn_position_y` = '4650.119629', `spawn_position_z` = '-20.251141', `spawn_orientation` = '0.744701',`position_x` = '-3773.051270', `position_y` = '4650.119629', `position_z` = '-20.251141', `orientation` = '0.744701' WHERE `guid` = '74028';
UPDATE `creature` SET `spawn_position_x` = '-3788.998047', `spawn_position_y` = '4605.117676', `spawn_position_z` = '-15.798190', `spawn_orientation` = '0.552277',`position_x` = '-3788.998047', `position_y` = '4605.117676', `position_z` = '-15.798190', `orientation` = '0.552277' WHERE `guid` = '87829';
UPDATE `creature` SET `spawn_position_x` = '-3509.529541', `spawn_position_y` = '5149.571777', `spawn_position_z` = '-21.648794', `spawn_orientation` = '3.671659',`position_x` = '-3509.529541', `position_y` = '5149.571777', `position_z` = '-21.648794', `orientation` = '3.671659' WHERE `guid` = '73890';
UPDATE `creature` SET `spawn_position_x` = '-3403.449463', `spawn_position_y` = '4213.317871', `spawn_position_z` = '-8.993786', `spawn_orientation` = '3.572045',`position_x` = '-3403.449463', `position_y` = '4213.317871', `position_z` = '-8.993786', `orientation` = '3.572045' WHERE `guid` = '67548';
UPDATE `creature` SET `spawn_position_x` = '-2979.888184', `spawn_position_y` = '3962.543457', `spawn_position_z` = '2.829905', `spawn_orientation` = '0.113568',`position_x` = '-2979.888184', `position_y` = '3962.543457', `position_z` = '2.829905', `orientation` = '0.113568' WHERE `guid` = '103615';
UPDATE `creature` SET `spawn_position_x` = '-2980.771240', `spawn_position_y` = '3951.202881', `spawn_position_z` = '2.712528', `spawn_orientation` = '3.361191',`position_x` = '-2980.771240', `position_y` = '3951.202881', `position_z` = '2.712528', `orientation` = '3.361191' WHERE `guid` = '75123';
UPDATE `creature` SET `spawn_position_x` = '-2992.327393', `spawn_position_y` = '3951.545898', `spawn_position_z` = '2.283799', `spawn_orientation` = '6.019765',`position_x` = '-2992.327393', `position_y` = '3951.545898', `position_z` = '2.283799', `orientation` = '6.019765' WHERE `guid` = '77291';
UPDATE `creature` SET `spawn_position_x` = '-3681.651855', `spawn_position_y` = '1084.745605', `spawn_position_z` = '67.630989', `spawn_orientation` = '2.804559',`position_x` = '-3681.651855', `position_y` = '1084.745605', `position_z` = '67.630989', `orientation` = '2.804559' WHERE `guid` = '76448';
UPDATE `creature` SET `spawn_position_x` = '-3653.609375', `spawn_position_y` = '1115.884888', `spawn_position_z` = '57.666100', `spawn_orientation` = '1.092389',`position_x` = '-3653.609375', `position_y` = '1115.884888', `position_z` = '57.666100', `orientation` = '1.092389' WHERE `guid` = '76488';
UPDATE `creature` SET `spawn_position_x` = '-3632.463623', `spawn_position_y` = '1099.030518', `spawn_position_z` = '56.330112', `spawn_orientation` = '0.204890',`position_x` = '-3632.463623', `position_y` = '1099.030518', `position_z` = '56.330112', `orientation` = '0.204890' WHERE `guid` = '73525';
UPDATE `creature` SET `spawn_position_x` = '-3574.643799', `spawn_position_y` = '1142.319946', `spawn_position_z` = '45.962490', `spawn_orientation` = '0.554392',`position_x` = '-3574.643799', `position_y` = '1142.319946', `position_z` = '45.962490', `orientation` = '0.554392' WHERE `guid` = '73522';
UPDATE `creature` SET `spawn_position_x` = '-3648.144531', `spawn_position_y` = '1091.914795', `spawn_position_z` = '61.981506', `spawn_orientation` = '3.134425',`position_x` = '-3648.144531', `position_y` = '1091.914795', `position_z` = '61.981506', `orientation` = '3.134425' WHERE `guid` = '76487';
UPDATE `creature` SET `spawn_position_x` = '-3659.692627', `spawn_position_y` = '1105.586670', `spawn_position_z` = '61.155487', `spawn_orientation` = '3.106936',`position_x` = '-3659.692627', `position_y` = '1105.586670', `position_z` = '61.155487', `orientation` = '3.106936' WHERE `guid` = '73524';
UPDATE `creature` SET `spawn_position_x` = '-3670.721191', `spawn_position_y` = '1096.156616', `spawn_position_z` = '65.379669', `spawn_orientation` = '5.702678',`position_x` = '-3670.721191', `position_y` = '1096.156616', `position_z` = '65.379669', `orientation` = '5.702678' WHERE `guid` = '76447';
UPDATE `creature` SET `spawn_position_x` = '-3670.697021', `spawn_position_y` = '1081.377930', `spawn_position_z` = '67.933823', `spawn_orientation` = '0.224523',`position_x` = '-3670.697021', `position_y` = '1081.377930', `position_z` = '67.933823', `orientation` = '0.224523' WHERE `guid` = '73523';
UPDATE `creature` SET `spawn_position_x` = '-3664.819092', `spawn_position_y` = '1072.380981', `spawn_position_z` = '67.799248', `spawn_orientation` = '1.382987',`position_x` = '-3664.819092', `position_y` = '1072.380981', `position_z` = '67.799248', `orientation` = '1.382987' WHERE `guid` = '76486';
UPDATE `creature` SET `spawn_position_x` = '-2667.299072', `spawn_position_y` = '6854.540039', `spawn_position_z` = '-4.896427', `spawn_orientation` = '3.003778',`position_x` = '-2667.299072', `position_y` = '6854.540039', `position_z` = '-4.896427', `orientation` = '3.003778' WHERE `guid` = '73192';
UPDATE `creature` SET `spawn_position_x` = '-2668.331543', `spawn_position_y` = '6830.296875', `spawn_position_z` = '-5.432595', `spawn_orientation` = '4.107264',`position_x` = '-2668.331543', `position_y` = '6830.296875', `position_z` = '-5.432595', `orientation` = '4.107264' WHERE `guid` = '77370';
UPDATE `creature` SET `spawn_position_x` = '-2635.889160', `spawn_position_y` = '6891.030762', `spawn_position_z` = '-1.072706', `spawn_orientation` = '1.291611',`position_x` = '-2635.889160', `position_y` = '6891.030762', `position_z` = '-1.072706', `orientation` = '1.291611' WHERE `guid` = '77372';
UPDATE `creature` SET `spawn_position_x` = '-3399.675293', `spawn_position_y` = '770.545288', `spawn_position_z` = '-32.738541', `spawn_orientation` = '4.132675',`position_x` = '-3399.675293', `position_y` = '770.545288', `position_z` = '-32.738541', `orientation` = '4.132675' WHERE `guid` = '76429';
UPDATE `creature` SET `spawn_position_x` = '-3383.238770', `spawn_position_y` = '780.284851', `spawn_position_z` = '-31.723446', `spawn_orientation` = '5.432510',`position_x` = '-3383.238770', `position_y` = '780.284851', `position_z` = '-31.723446', `orientation` = '5.432510' WHERE `guid` = '76377';
UPDATE `creature` SET `spawn_position_x` = '-3379.918457', `spawn_position_y` = '826.509277', `spawn_position_z` = '-28.141182', `spawn_orientation` = '0.123218',`position_x` = '-3379.918457', `position_y` = '826.509277', `position_z` = '-28.141182', `orientation` = '0.123218' WHERE `guid` = '76426';
UPDATE `creature` SET `spawn_position_x` = '-3377.469238', `spawn_position_y` = '815.541992', `spawn_position_z` = '-26.538885', `spawn_orientation` = '6.037268',`position_x` = '-3377.469238', `position_y` = '815.541992', `position_z` = '-26.538885', `orientation` = '6.037268' WHERE `guid` = '76376';
UPDATE `creature` SET `spawn_position_x` = '-3376.966553', `spawn_position_y` = '802.981567', `spawn_position_z` = '-28.126236', `spawn_orientation` = '6.033340',`position_x` = '-3376.966553', `position_y` = '802.981567', `position_z` = '-28.126236', `orientation` = '6.033340' WHERE `guid` = '73484';
UPDATE `creature` SET `spawn_position_x` = '-3395.495850', `spawn_position_y` = '817.106628', `spawn_position_z` = '-30.196941', `spawn_orientation` = '6.092244',`position_x` = '-3395.495850', `position_y` = '817.106628', `position_z` = '-30.196941', `orientation` = '6.092244' WHERE `guid` = '73485';
UPDATE `creature` SET `spawn_position_x` = '-3374.062744', `spawn_position_y` = '788.986755', `spawn_position_z` = '-27.623398', `spawn_orientation` = '5.530682',`position_x` = '-3374.062744', `position_y` = '788.986755', `position_z` = '-27.623398', `orientation` = '5.530682' WHERE `guid` = '76427';
UPDATE `creature` SET `spawn_position_x` = '-3014.597412', `spawn_position_y` = '6447.375977', `spawn_position_z` = '87.152054', `spawn_orientation` = '4.625356',`position_x` = '-3014.597412', `position_y` = '6447.375977', `position_z` = '87.152054', `orientation` = '4.625356' WHERE `guid` = '73118';
UPDATE `creature` SET `spawn_position_x` = '-3007.289551', `spawn_position_y` = '6421.233887', `spawn_position_z` = '88.089622', `spawn_orientation` = '0.851518',`position_x` = '-3007.289551', `position_y` = '6421.233887', `position_z` = '88.089622', `orientation` = '0.851518' WHERE `guid` = '73111';
UPDATE `creature` SET `spawn_position_x` = '-3000.791748', `spawn_position_y` = '6421.303223', `spawn_position_z` = '88.628204', `spawn_orientation` = '0.018996',`position_x` = '-3000.791748', `position_y` = '6421.303223', `position_z` = '88.628204', `orientation` = '0.018996' WHERE `guid` = '73116';
UPDATE `creature` SET `spawn_position_x` = '-2996.716064', `spawn_position_y` = '6424.940430', `spawn_position_z` = '88.110123', `spawn_orientation` = '2.108155',`position_x` = '-2996.716064', `position_y` = '6424.940430', `position_z` = '88.110123', `orientation` = '2.108155' WHERE `guid` = '73109';
UPDATE `creature` SET `spawn_position_x` = '-3005.984863', `spawn_position_y` = '6432.881836', `spawn_position_z` = '85.845215', `spawn_orientation` = '2.025688',`position_x` = '-3005.984863', `position_y` = '6432.881836', `position_z` = '85.845215', `orientation` = '2.025688' WHERE `guid` = '73113';
UPDATE `creature` SET `spawn_position_x` = '-2999.774658', `spawn_position_y` = '6431.230957', `spawn_position_z` = '85.901192', `spawn_orientation` = '6.023365',`position_x` = '-2999.774658', `position_y` = '6431.230957', `position_z` = '85.901192', `orientation` = '6.023365' WHERE `guid` = '73107';
UPDATE `creature` SET `spawn_position_x` = '-2987.897949', `spawn_position_y` = '6423.230957', `spawn_position_z` = '88.180855', `spawn_orientation` = '0.549139',`position_x` = '-2987.897949', `position_y` = '6423.230957', `position_z` = '88.180855', `orientation` = '0.549139' WHERE `guid` = '73108';
UPDATE `creature` SET `spawn_position_x` = '-2989.666992', `spawn_position_y` = '6432.660645', `spawn_position_z` = '85.173180', `spawn_orientation` = '6.203221',`position_x` = '-2989.666992', `position_y` = '6432.660645', `position_z` = '85.173180', `orientation` = '6.203221' WHERE `guid` = '73120';
DELETE FROM `creature` WHERE `guid` = '73114';
DELETE FROM `creature_addon` WHERE `guid` = '73114';
DELETE FROM `creature_movement` WHERE `id` = '73114';
UPDATE `creature` SET `spawn_position_x` = '-2811.856445', `spawn_position_y` = '6142.765137', `spawn_position_z` = '5.838878', `spawn_orientation` = '1.358576',`position_x` = '-2811.856445', `position_y` = '6142.765137', `position_z` = '5.838878', `orientation` = '1.358576' WHERE `guid` = '73034';
UPDATE `creature` SET `spawn_position_x` = '-2465.160400', `spawn_position_y` = '6267.671387', `spawn_position_z` = '31.032288', `spawn_orientation` = '4.669190',`position_x` = '-2465.160400', `position_y` = '6267.671387', `position_z` = '31.032288', `orientation` = '4.669190' WHERE `guid` = '73003';
UPDATE `creature` SET `spawn_position_x` = '-2458.596924', `spawn_position_y` = '6256.202637', `spawn_position_z` = '30.972195', `spawn_orientation` = '3.695297',`position_x` = '-2458.596924', `position_y` = '6256.202637', `position_z` = '30.972195', `orientation` = '3.695297' WHERE `guid` = '72910';
UPDATE `creature` SET `spawn_position_x` = '-2427.358643', `spawn_position_y` = '6287.430176', `spawn_position_z` = '32.304504', `spawn_orientation` = '1.295905',`position_x` = '-2427.358643', `position_y` = '6287.430176', `position_z` = '32.304504', `orientation` = '1.295905' WHERE `guid` = '73004';
UPDATE `creature` SET `spawn_position_x` = '-2440.111328', `spawn_position_y` = '6271.992676', `spawn_position_z` = '31.281666', `spawn_orientation` = '1.916370',`position_x` = '-2440.111328', `position_y` = '6271.992676', `position_z` = '31.281666', `orientation` = '1.916370' WHERE `guid` = '72881';
UPDATE `creature` SET `spawn_position_x` = '-2446.240234', `spawn_position_y` = '6264.166016', `spawn_position_z` = '31.332975', `spawn_orientation` = '2.591812',`position_x` = '-2446.240234', `position_y` = '6264.166016', `position_z` = '31.332975', `orientation` = '2.591812' WHERE `guid` = '72888';
UPDATE `creature` SET `spawn_position_x` = '-2446.002441', `spawn_position_y` = '6287.173340', `spawn_position_z` = '34.149483', `spawn_orientation` = '4.190098',`position_x` = '-2446.002441', `position_y` = '6287.173340', `position_z` = '34.149483', `orientation` = '4.190098' WHERE `guid` = '72891';
UPDATE `creature` SET `spawn_position_x` = '-2368.854004', `spawn_position_y` = '6424.236328', `spawn_position_z` = '17.298870', `spawn_orientation` = '3.237749',`position_x` = '-2368.854004', `position_y` = '6424.236328', `position_z` = '17.298870', `orientation` = '3.237749' WHERE `guid` = '72995';
UPDATE `creature` SET `spawn_position_x` = '-1841.683594', `spawn_position_y` = '6389.159180', `spawn_position_z` = '52.897087', `spawn_orientation` = '3.921837',`position_x` = '-1841.683594', `position_y` = '6389.159180', `position_z` = '52.897087', `orientation` = '3.921837' WHERE `guid` = '72786';
UPDATE `creature` SET `spawn_position_x` = '-1904.934082', `spawn_position_y` = '6335.222168', `spawn_position_z` = '47.963966', `spawn_orientation` = '5.091630',`position_x` = '-1904.934082', `position_y` = '6335.222168', `position_z` = '47.963966', `orientation` = '5.091630' WHERE `guid` = '72797';
UPDATE `creature` SET `spawn_position_x` = '-1916.037476', `spawn_position_y` = '6356.618652', `spawn_position_z` = '54.060593', `spawn_orientation` = '2.197438',`position_x` = '-1916.037476', `position_y` = '6356.618652', `position_z` = '54.060593', `orientation` = '2.197438' WHERE `guid` = '72801';
UPDATE `creature` SET `spawn_position_x` = '-1811.504639', `spawn_position_y` = '6372.079590', `spawn_position_z` = '45.661732', `spawn_orientation` = '5.102617',`position_x` = '-1811.504639', `position_y` = '6372.079590', `position_z` = '45.661732', `orientation` = '5.102617' WHERE `guid` = '72787';
UPDATE `creature` SET `spawn_position_x` = '-1747.092773', `spawn_position_y` = '6432.425293', `spawn_position_z` = '42.706387', `spawn_orientation` = '0.304671',`position_x` = '-1747.092773', `position_y` = '6432.425293', `position_z` = '42.706387', `orientation` = '0.304671' WHERE `guid` = '72750';
UPDATE `creature` SET `spawn_position_x` = '-1746.285767', `spawn_position_y` = '6456.805176', `spawn_position_z` = '45.949890', `spawn_orientation` = '1.003674',`position_x` = '-1746.285767', `position_y` = '6456.805176', `position_z` = '45.949890', `orientation` = '1.003674' WHERE `guid` = '72735';
UPDATE `creature` SET `spawn_position_x` = '-1239.365234', `spawn_position_y` = '7244.060547', `spawn_position_z` = '57.308765', `spawn_orientation` = '0.050784',`position_x` = '-1239.365234', `position_y` = '7244.060547', `position_z` = '57.308765', `orientation` = '0.050784' WHERE `guid` = '72450';
UPDATE `creature` SET `spawn_position_x` = '-745.134766', `spawn_position_y` = '7763.542969', `spawn_position_z` = '63.611519', `spawn_orientation` = '2.674623',`position_x` = '-745.134766', `position_y` = '7763.542969', `position_z` = '63.611519', `orientation` = '2.674623' WHERE `guid` = '79309';
UPDATE `creature` SET `spawn_position_x` = '-716.813538', `spawn_position_y` = '7754.613281', `spawn_position_z` = '73.381737', `spawn_orientation` = '6.036705',`position_x` = '-716.813538', `position_y` = '7754.613281', `position_z` = '73.381737', `orientation` = '6.036705' WHERE `guid` = '72272';
UPDATE `creature` SET `spawn_position_x` = '-716.800232', `spawn_position_y` = '7697.702148', `spawn_position_z` = '86.779869', `spawn_orientation` = '3.219216',`position_x` = '-716.800232', `position_y` = '7697.702148', `position_z` = '86.779869', `orientation` = '3.219216' WHERE `guid` = '72277';
UPDATE `creature` SET `spawn_position_x` = '-763.819153', `spawn_position_y` = '7720.639648', `spawn_position_z` = '48.122746', `spawn_orientation` = '3.567958',`position_x` = '-763.819153', `position_y` = '7720.639648', `position_z` = '48.122746', `orientation` = '3.567958' WHERE `guid` = '72281';
UPDATE `creature` SET `spawn_position_x` = '-760.559265', `spawn_position_y` = '7857.921875', `spawn_position_z` = '47.715359', `spawn_orientation` = '2.792687',`position_x` = '-760.559265', `position_y` = '7857.921875', `position_z` = '47.715359', `orientation` = '2.792687' WHERE `guid` = '72271';
UPDATE `creature` SET `spawn_position_x` = '-1352.403076', `spawn_position_y` = '8916.344727', `spawn_position_z` = '55.411263', `spawn_orientation` = '2.167258',`position_x` = '-1352.403076', `position_y` = '8916.344727', `position_z` = '55.411263', `orientation` = '2.167258' WHERE `guid` = '72091';
UPDATE `creature` SET `spawn_position_x` = '-1606.412598', `spawn_position_y` = '8447.987305', `spawn_position_z` = '-13.749657', `spawn_orientation` = '3.511555',`position_x` = '-1606.412598', `position_y` = '8447.987305', `position_z` = '-13.749657', `orientation` = '3.511555' WHERE `guid` = '72034';
UPDATE `creature` SET `spawn_position_x` = '-2264.058350', `spawn_position_y` = '8791.888672', `spawn_position_z` = '6.684467', `spawn_orientation` = '0.874694',`position_x` = '-2264.058350', `position_y` = '8791.888672', `position_z` = '6.684467', `orientation` = '0.874694' WHERE `guid` = '71850';
UPDATE `creature` SET `spawn_position_x` = '-2012.314087', `spawn_position_y` = '8087.720215', `spawn_position_z` = '-15.450656', `spawn_orientation` = '2.492800',`position_x` = '-2012.314087', `position_y` = '8087.720215', `position_z` = '-15.450656', `orientation` = '2.492800' WHERE `guid` = '71532';
UPDATE `creature` SET `spawn_position_x` = '-4139.810547', `spawn_position_y` = '-11420.072266', `spawn_position_z` = '-6.806509', `spawn_orientation` = '4.445255',`position_x` = '-4139.810547', `position_y` = '-11420.072266', `position_z` = '-6.806509', `orientation` = '4.445255' WHERE `guid` = '71364';
UPDATE `creature` SET `spawn_position_x` = '-4486.913086', `spawn_position_y` = '-11628.578125', `spawn_position_z` = '11.068957', `spawn_orientation` = '3.126933',`position_x` = '-4486.913086', `position_y` = '-11628.578125', `position_z` = '11.068957', `orientation` = '3.126933' WHERE `guid` = '69272';
UPDATE `creature` SET `spawn_position_x` = '-1265.868286', `spawn_position_y` = '-11406.862305', `spawn_position_z` = '8.044834', `spawn_orientation` = '5.295591',`position_x` = '-1265.868286', `position_y` = '-11406.862305', `position_z` = '8.044834', `orientation` = '5.295591' WHERE `guid` = '68499';
UPDATE `creature` SET `spawn_position_x` = '8693.972656', `spawn_position_y` = '-6331.015137', `spawn_position_z` = '55.966263', `spawn_orientation` = '4.049169',`position_x` = '8693.972656', `position_y` = '-6331.015137', `position_z` = '55.966263', `orientation` = '4.049169' WHERE `guid` = '70592';
UPDATE `creature` SET `spawn_position_x` = '8689.881836', `spawn_position_y` = '-6327.792480', `spawn_position_z` = '55.962158', `spawn_orientation` = '4.045241',`position_x` = '8689.881836', `position_y` = '-6327.792480', `position_z` = '55.962158', `orientation` = '4.045241' WHERE `guid` = '69709';
UPDATE `creature` SET `spawn_position_x` = '8688.891602', `spawn_position_y` = '-6329.070801', `spawn_position_z` = '55.959080', `spawn_orientation` = '4.053096',`position_x` = '8688.891602', `position_y` = '-6329.070801', `position_z` = '55.959080', `orientation` = '4.053096' WHERE `guid` = '69735';
UPDATE `creature` SET `spawn_position_x` = '8679.408203', `spawn_position_y` = '-6336.937500', `spawn_position_z` = '55.935543', `spawn_orientation` = '3.727154',`position_x` = '8679.408203', `position_y` = '-6336.937500', `position_z` = '55.935543', `orientation` = '3.727154' WHERE `guid` = '69740';
UPDATE `creature` SET `spawn_position_x` = '8690.957031', `spawn_position_y` = '-6350.815430', `spawn_position_z` = '55.940647', `spawn_orientation` = '4.720683',`position_x` = '8690.957031', `position_y` = '-6350.815430', `position_z` = '55.940647', `orientation` = '4.720683' WHERE `guid` = '70594';
UPDATE `creature` SET `spawn_position_x` = '8678.205078', `spawn_position_y` = '-6356.912109', `spawn_position_z` = '55.553288', `spawn_orientation` = '2.007131',`position_x` = '8678.205078', `position_y` = '-6356.912109', `position_z` = '55.553288', `orientation` = '2.007131' WHERE `guid` = '69732';
UPDATE `creature` SET `spawn_position_x` = '8697.668945', `spawn_position_y` = '-6362.222656', `spawn_position_z` = '55.854393', `spawn_orientation` = '0.950771',`position_x` = '8697.668945', `position_y` = '-6362.222656', `position_z` = '55.854393', `orientation` = '0.950771' WHERE `guid` = '70588';
UPDATE `creature` SET `spawn_position_x` = '8702.673828', `spawn_position_y` = '-6345.237793', `spawn_position_z` = '56.023197', `spawn_orientation` = '2.030693',`position_x` = '8702.673828', `position_y` = '-6345.237793', `position_z` = '56.023197', `orientation` = '2.030693' WHERE `guid` = '70594';
UPDATE `creature` SET `spawn_position_x` = '8669.281250', `spawn_position_y` = '-6319.170410', `spawn_position_z` = '55.956390', `spawn_orientation` = '4.873832',`position_x` = '8669.281250', `position_y` = '-6319.170410', `position_z` = '55.956390', `orientation` = '4.873832' WHERE `guid` = '69707';
UPDATE `creature` SET `spawn_position_x` = '8682.097656', `spawn_position_y` = '-6311.847168', `spawn_position_z` = '54.766621', `spawn_orientation` = '0.020858',`position_x` = '8682.097656', `position_y` = '-6311.847168', `position_z` = '54.766621', `orientation` = '0.020858' WHERE `guid` = '70560';
UPDATE `creature` SET `spawn_position_x` = '7931.046387', `spawn_position_y` = '-6173.850098', `spawn_position_z` = '20.199488', `spawn_orientation` = '5.969793',`position_x` = '7931.046387', `position_y` = '-6173.850098', `position_z` = '20.199488', `orientation` = '5.969793' WHERE `guid` = '70041';
UPDATE `creature` SET `spawn_position_x` = '7775.945801', `spawn_position_y` = '-6342.817871', `spawn_position_z` = '17.357079', `spawn_orientation` = '2.531221',`position_x` = '7775.945801', `position_y` = '-6342.817871', `position_z` = '17.357079', `orientation` = '2.531221' WHERE `guid` = '70033';
UPDATE `creature` SET `spawn_position_x` = '7744.625488', `spawn_position_y` = '-5949.113281', `spawn_position_z` = '0.010932', `spawn_orientation` = '3.466721',`position_x` = '7744.625488', `position_y` = '-5949.113281', `position_z` = '0.010932', `orientation` = '3.466721' WHERE `guid` = '57148';
UPDATE `creature` SET `spawn_position_x` = '7031.628418', `spawn_position_y` = '-5835.900879', `spawn_position_z` = '49.685795', `spawn_orientation` = '0.821569',`position_x` = '7031.628418', `position_y` = '-5835.900879', `position_z` = '49.685795', `orientation` = '0.821569' WHERE `guid` = '69892';
UPDATE `creature` SET `spawn_position_x` = '7053.253418', `spawn_position_y` = '-5796.717773', `spawn_position_z` = '48.899067', `spawn_orientation` = '4.449609',`position_x` = '7053.253418', `position_y` = '-5796.717773', `position_z` = '48.899067', `orientation` = '4.449609' WHERE `guid` = '69886';
UPDATE `creature` SET `spawn_position_x` = '7003.736328', `spawn_position_y` = '-5680.912598', `spawn_position_z` = '82.669861', `spawn_orientation` = '5.563307',`position_x` = '7003.736328', `position_y` = '-5680.912598', `position_z` = '82.669861', `orientation` = '5.563307' WHERE `guid` = '69829';
UPDATE `creature` SET `spawn_position_x` = '7021.042480', `spawn_position_y` = '-5682.868652', `spawn_position_z` = '82.668907', `spawn_orientation` = '0.497487',`position_x` = '7021.042480', `position_y` = '-5682.868652', `position_z` = '82.668907', `orientation` = '0.497487' WHERE `guid` = '69855';
UPDATE `creature` SET `spawn_position_x` = '7009.408691', `spawn_position_y` = '-5685.054688', `spawn_position_z` = '82.666168', `spawn_orientation` = '3.368118',`position_x` = '7009.408691', `position_y` = '-5685.054688', `position_z` = '82.666168', `orientation` = '3.368118' WHERE `guid` = '69856';
UPDATE `creature` SET `spawn_position_x` = '7012.932129', `spawn_position_y` = '-5691.953125', `spawn_position_z` = '82.667564', `spawn_orientation` = '1.671657',`position_x` = '7012.932129', `position_y` = '-5691.953125', `position_z` = '82.667564', `orientation` = '1.671657' WHERE `guid` = '69842';
DELETE FROM `creature` WHERE `guid` = '57373';
DELETE FROM `creature_addon` WHERE `guid` = '57373';
DELETE FROM `creature_movement` WHERE `id` = '57373';
DELETE FROM `creature` WHERE `guid` = '69854';
DELETE FROM `creature_addon` WHERE `guid` = '69854';
DELETE FROM `creature_movement` WHERE `id` = '69854';
UPDATE `creature` SET `spawn_position_x` = '7055.236816', `spawn_position_y` = '-5703.392090', `spawn_position_z` = '84.423592', `spawn_orientation` = '1.711708',`position_x` = '7055.236816', `position_y` = '-5703.392090', `position_z` = '84.423592', `orientation` = '1.711708' WHERE `guid` = '57372';
UPDATE `creature` SET `spawn_position_x` = '7049.695801', `spawn_position_y` = '-5714.476074', `spawn_position_z` = '84.184410', `spawn_orientation` = '5.850754',`position_x` = '7049.695801', `position_y` = '-5714.476074', `position_z` = '84.184410', `orientation` = '5.850754' WHERE `guid` = '69839';
DELETE FROM `creature` WHERE `guid` = '69836';
DELETE FROM `creature_addon` WHERE `guid` = '69836';
DELETE FROM `creature_movement` WHERE `id` = '69836';
DELETE FROM `creature` WHERE `guid` = '69848';
DELETE FROM `creature_addon` WHERE `guid` = '69848';
DELETE FROM `creature_movement` WHERE `id` = '69848';
UPDATE `creature` SET `spawn_position_x` = '6985.486816', `spawn_position_y` = '-5674.344727', `spawn_position_z` = '81.781067', `spawn_orientation` = '0.958216',`position_x` = '6985.486816', `position_y` = '-5674.344727', `position_z` = '81.781067', `orientation` = '0.958216' WHERE `guid` = '57364';
UPDATE `creature` SET `spawn_position_x` = '6978.495117', `spawn_position_y` = '-5692.655762', `spawn_position_z` = '83.401428', `spawn_orientation` = '4.590681',`position_x` = '6978.495117', `position_y` = '-5692.655762', `position_z` = '83.401428', `orientation` = '4.590681' WHERE `guid` = '69822';
DELETE FROM `creature` WHERE `guid` = '69735';
DELETE FROM `creature_addon` WHERE `guid` = '69735';
DELETE FROM `creature_movement` WHERE `id` = '69735';
UPDATE `creature` SET `spawn_position_x` = '-5268.836914', `spawn_position_y` = '-10831.697266', `spawn_position_z` = '-2.292966', `spawn_orientation` = '4.333366',`position_x` = '-5268.836914', `position_y` = '-10831.697266', `position_z` = '-2.292966', `orientation` = '4.333366' WHERE `guid` = '69322';
UPDATE `creature` SET `spawn_position_x` = '-5265.251465', `spawn_position_y` = '-10832.573242', `spawn_position_z` = '-1.629580', `spawn_orientation` = '4.855150',`position_x` = '-5265.251465', `position_y` = '-10832.573242', `position_z` = '-1.629580', `orientation` = '4.855150' WHERE `guid` = '69321';
UPDATE `creature` SET `spawn_position_x` = '-5037.361328', `spawn_position_y` = '-10778.689453', `spawn_position_z` = '-0.113207', `spawn_orientation` = '4.409464',`position_x` = '-5037.361328', `position_y` = '-10778.689453', `position_z` = '-0.113207', `orientation` = '4.409464' WHERE `guid` = '69331';
UPDATE `creature` SET `spawn_position_x` = '10465.338867', `spawn_position_y` = '-6467.527832', `spawn_position_z` = '21.940285', `spawn_orientation` = '4.799190',`position_x` = '10465.338867', `position_y` = '-6467.527832', `position_z` = '21.940285', `orientation` = '4.799190' WHERE `guid` = '78062';
UPDATE `creature` SET `spawn_position_x` = '-5266.173340', `spawn_position_y` = '-10842.333984', `spawn_position_z` = '-0.185204', `spawn_orientation` = '4.145285',`position_x` = '-5266.173340', `position_y` = '-10842.333984', `position_z` = '-0.185204', `orientation` = '4.145285' WHERE `guid` = '71335';
UPDATE `creature` SET `spawn_position_x` = '-5322.718750', `spawn_position_y` = '-10964.819336', `spawn_position_z` = '0.319877', `spawn_orientation` = '0.451713',`position_x` = '-5322.718750', `position_y` = '-10964.819336', `position_z` = '0.319877', `orientation` = '0.451713' WHERE `guid` = '69313';
UPDATE `creature` SET `spawn_position_x` = '-5330.028320', `spawn_position_y` = '-10954.478516', `spawn_position_z` = '-1.230266', `spawn_orientation` = '1.460950',`position_x` = '-5330.028320', `position_y` = '-10954.478516', `position_z` = '-1.230266', `orientation` = '1.460950' WHERE `guid` = '69317';
UPDATE `creature` SET `spawn_position_x` = '-5263.371582', `spawn_position_y` = '-11048.783203', `spawn_position_z` = '17.064793', `spawn_orientation` = '2.105654',`position_x` = '-5263.371582', `position_y` = '-11048.783203', `position_z` = '17.064793', `orientation` = '2.105654' WHERE `guid` = '71329';
UPDATE `creature` SET `spawn_position_x` = '-2077.165771', `spawn_position_y` = '-11949.289063', `spawn_position_z` = '39.557182', `spawn_orientation` = '0.205755',`position_x` = '-2077.165771', `position_y` = '-11949.289063', `position_z` = '39.557182', `orientation` = '0.205755' WHERE `guid` = '68658';
UPDATE `creature` SET `spawn_position_x` = '-1409.349365', `spawn_position_y` = '-11955.935547', `spawn_position_z` = '14.920979', `spawn_orientation` = '1.390591',`position_x` = '-1409.349365', `position_y` = '-11955.935547', `position_z` = '14.920979', `orientation` = '1.390591' WHERE `guid` = '68620';
UPDATE `creature` SET `spawn_position_x` = '-1598.905273', `spawn_position_y` = '-11361.412109', `spawn_position_z` = '57.745049', `spawn_orientation` = '3.652747',`position_x` = '-1598.905273', `position_y` = '-11361.412109', `position_z` = '57.745049', `orientation` = '3.652747' WHERE `guid` = '70701';
UPDATE `creature` SET `spawn_position_x` = '-1731.072266', `spawn_position_y` = '5834.112793', `spawn_position_z` = '148.658005', `spawn_orientation` = '4.550938',`position_x` = '-1731.072266', `position_y` = '5834.112793', `position_z` = '148.658005', `orientation` = '4.550938' WHERE `guid` = '78318';
DELETE FROM `creature` WHERE `guid` = '78319';
DELETE FROM `creature_addon` WHERE `guid` = '78319';
DELETE FROM `creature_movement` WHERE `id` = '78319';
DELETE FROM `creature` WHERE `guid` = '68223';
DELETE FROM `creature_addon` WHERE `guid` = '68223';
DELETE FROM `creature_movement` WHERE `id` = '68223';
DELETE FROM `creature` WHERE `guid` = '67872';
DELETE FROM `creature_addon` WHERE `guid` = '67872';
DELETE FROM `creature_movement` WHERE `id` = '67872';
DELETE FROM `creature` WHERE `guid` = '67864';
DELETE FROM `creature_addon` WHERE `guid` = '67864';
DELETE FROM `creature_movement` WHERE `id` = '67864';
DELETE FROM `creature` WHERE `guid` = '68218';
DELETE FROM `creature_addon` WHERE `guid` = '68218';
DELETE FROM `creature_movement` WHERE `id` = '68218';
UPDATE `creature` SET `spawn_position_x` = '-1675.598877', `spawn_position_y` = '5371.434570', `spawn_position_z` = '-43.206440', `spawn_orientation` = '2.781625',`position_x` = '-1675.598877', `position_y` = '5371.434570', `position_z` = '-43.206440', `orientation` = '2.781625' WHERE `guid` = '67924';
UPDATE `creature` SET `spawn_position_x` = '-1615.752197', `spawn_position_y` = '5473.288574', `spawn_position_z` = '-3.927212', `spawn_orientation` = '2.290346',`position_x` = '-1615.752197', `position_y` = '5473.288574', `position_z` = '-3.927212', `orientation` = '2.290346' WHERE `guid` = '67901';
UPDATE `creature` SET `spawn_position_x` = '-2534.076416', `spawn_position_y` = '5368.502441', `spawn_position_z` = '27.232813', `spawn_orientation` = '2.398259',`position_x` = '-2534.076416', `position_y` = '5368.502441', `position_z` = '27.232813', `orientation` = '2.398259' WHERE `guid` = '67737';
UPDATE `creature` SET `spawn_position_x` = '-2207.009521', `spawn_position_y` = '3996.260742', `spawn_position_z` = '-15.068604', `spawn_orientation` = '1.466690',`position_x` = '-2207.009521', `position_y` = '3996.260742', `position_z` = '-15.068604', `orientation` = '1.466690' WHERE `guid` = '67383';
UPDATE `creature` SET `spawn_position_x` = '883.997925', `spawn_position_y` = '5238.557129', `spawn_position_z` = '14.159496', `spawn_orientation` = '0.764098',`position_x` = '883.997925', `position_y` = '5238.557129', `position_z` = '14.159496', `orientation` = '0.764098' WHERE `guid` = '66930';
UPDATE `creature` SET `spawn_position_x` = '707.059326', `spawn_position_y` = '5641.815918', `spawn_position_z` = '18.961664', `spawn_orientation` = '1.423477',`position_x` = '707.059326', `position_y` = '5641.815918', `position_z` = '18.961664', `orientation` = '1.423477' WHERE `guid` = '64365';
UPDATE `creature` SET `spawn_position_x` = '700.502747', `spawn_position_y` = '5664.000488', `spawn_position_z` = '19.269518', `spawn_orientation` = '3.791453',`position_x` = '700.502747', `position_y` = '5664.000488', `position_z` = '19.269518', `orientation` = '3.791453' WHERE `guid` = '66874';
UPDATE `creature` SET `spawn_position_x` = '566.268188', `spawn_position_y` = '6167.705566', `spawn_position_z` = '22.654345', `spawn_orientation` = '1.824242',`position_x` = '566.268188', `position_y` = '6167.705566', `position_z` = '22.654345', `orientation` = '1.824242' WHERE `guid` = '66634';
UPDATE `creature` SET `spawn_position_x` = '662.540222', `spawn_position_y` = '6320.670410', `spawn_position_z` = '20.565975', `spawn_orientation` = '2.917921',`position_x` = '662.540222', `position_y` = '6320.670410', `position_z` = '20.565975', `orientation` = '2.917921' WHERE `guid` = '66644';
UPDATE `creature` SET `spawn_position_x` = '658.433533', `spawn_position_y` = '6367.019531', `spawn_position_z` = '19.131954', `spawn_orientation` = '1.253236',`position_x` = '658.433533', `position_y` = '6367.019531', `position_z` = '19.131954', `orientation` = '1.253236' WHERE `guid` = '66607';
UPDATE `creature` SET `spawn_position_x` = '574.710266', `spawn_position_y` = '7899.562500', `spawn_position_z` = '22.891846', `spawn_orientation` = '4.133376',`position_x` = '574.710266', `position_y` = '7899.562500', `position_z` = '22.891846', `orientation` = '4.133376' WHERE `guid` = '66409';
UPDATE `creature` SET `spawn_position_x` = '562.161499', `spawn_position_y` = '7890.748535', `spawn_position_z` = '23.840052', `spawn_orientation` = '0.159262',`position_x` = '562.161499', `position_y` = '7890.748535', `position_z` = '23.840052', `orientation` = '0.159262' WHERE `guid` = '65283';
UPDATE `creature` SET `spawn_position_x` = '-192.012589', `spawn_position_y` = '8625.821289', `spawn_position_z` = '19.167534', `spawn_orientation` = '3.449513',`position_x` = '-192.012589', `position_y` = '8625.821289', `position_z` = '19.167534', `orientation` = '3.449513' WHERE `guid` = '66239';
UPDATE `creature` SET `spawn_position_x` = '-200.326843', `spawn_position_y` = '8622.577148', `spawn_position_z` = '19.033434', `spawn_orientation` = '3.524126',`position_x` = '-200.326843', `position_y` = '8622.577148', `position_z` = '19.033434', `orientation` = '3.524126' WHERE `guid` = '66241';
UPDATE `creature` SET `spawn_position_x` = '-178.496323', `spawn_position_y` = '8625.350586', `spawn_position_z` = '21.143116', `spawn_orientation` = '4.423407',`position_x` = '-178.496323', `position_y` = '8625.350586', `position_z` = '21.143116', `orientation` = '4.423407' WHERE `guid` = '65495';
UPDATE `creature` SET `spawn_position_x` = '-114.844269', `spawn_position_y` = '8892.810547', `spawn_position_z` = '20.629307', `spawn_orientation` = '2.362408',`position_x` = '-114.844269', `position_y` = '8892.810547', `position_z` = '20.629307', `orientation` = '2.362408' WHERE `guid` = '66204';
UPDATE `creature` SET `spawn_position_x` = '-136.538773', `spawn_position_y` = '8937.290039', `spawn_position_z` = '19.622288', `spawn_orientation` = '0.473525',`position_x` = '-136.538773', `position_y` = '8937.290039', `position_z` = '19.622288', `orientation` = '0.473525' WHERE `guid` = '66205';
UPDATE `creature` SET `spawn_position_x` = '210.714279', `spawn_position_y` = '8720.771484', `spawn_position_z` = '18.278269', `spawn_orientation` = '0.784343',`position_x` = '210.714279', `position_y` = '8720.771484', `position_z` = '18.278269', `orientation` = '0.784343' WHERE `guid` = '66123';
UPDATE `creature` SET `spawn_position_x` = '219.872330', `spawn_position_y` = '8736.560547', `spawn_position_z` = '19.702223', `spawn_orientation` = '1.051378',`position_x` = '219.872330', `position_y` = '8736.560547', `position_z` = '19.702223', `orientation` = '1.051378' WHERE `guid` = '66122';
UPDATE `creature` SET `spawn_position_x` = '201.067734', `spawn_position_y` = '8739.833008', `spawn_position_z` = '19.366047', `spawn_orientation` = '2.567197',`position_x` = '201.067734', `position_y` = '8739.833008', `position_z` = '19.366047', `orientation` = '2.567197' WHERE `guid` = '66114';
UPDATE `creature` SET `spawn_position_x` = '192.711090', `spawn_position_y` = '8782.708008', `spawn_position_z` = '22.535915', `spawn_orientation` = '1.990916',`position_x` = '192.711090', `position_y` = '8782.708008', `position_z` = '22.535915', `orientation` = '1.990916' WHERE `guid` = '66120';
UPDATE `creature` SET `spawn_position_x` = '199.948166', `spawn_position_y` = '8765.985352', `spawn_position_z` = '21.722368', `spawn_orientation` = '6.000373',`position_x` = '199.948166', `position_y` = '8765.985352', `position_z` = '21.722368', `orientation` = '6.000373' WHERE `guid` = '66141';
UPDATE `creature` SET `spawn_position_x` = '186.684097', `spawn_position_y` = '8734.261719', `spawn_position_z` = '15.199655', `spawn_orientation` = '2.514364',`position_x` = '186.684097', `position_y` = '8734.261719', `position_z` = '15.199655', `orientation` = '2.514364' WHERE `guid` = '66111';
UPDATE `creature` SET `spawn_position_x` = '189.169540', `spawn_position_y` = '8725.388672', `spawn_position_z` = '12.024505', `spawn_orientation` = '4.521059',`position_x` = '189.169540', `position_y` = '8725.388672', `position_z` = '12.024505', `orientation` = '4.521059' WHERE `guid` = '66119';
UPDATE `creature` SET `spawn_position_x` = '222.191666', `spawn_position_y` = '8768.919922', `spawn_position_z` = '23.633512', `spawn_orientation` = '4.569986',`position_x` = '222.191666', `position_y` = '8768.919922', `position_z` = '23.633512', `orientation` = '4.569986' WHERE `guid` = '66092';
UPDATE `creature` SET `spawn_position_x` = '213.006577', `spawn_position_y` = '8665.738281', `spawn_position_z` = '-14.340104', `spawn_orientation` = '4.156002',`position_x` = '213.006577', `position_y` = '8665.738281', `position_z` = '-14.340104', `orientation` = '4.156002' WHERE `guid` = '66054';
UPDATE `creature` SET `spawn_position_x` = '205.039368', `spawn_position_y` = '8662.753906', `spawn_position_z` = '-9.762454', `spawn_orientation` = '3.621931',`position_x` = '205.039368', `position_y` = '8662.753906', `position_z` = '-9.762454', `orientation` = '3.621931' WHERE `guid` = '66052';
UPDATE `creature` SET `spawn_position_x` = '270.610321', `spawn_position_y` = '8698.411133', `spawn_position_z` = '-2.629969', `spawn_orientation` = '1.217255',`position_x` = '270.610321', `position_y` = '8698.411133', `position_z` = '-2.629969', `orientation` = '1.217255' WHERE `guid` = '66100';
UPDATE `creature` SET `spawn_position_x` = '274.066254', `spawn_position_y` = '8703.738281', `spawn_position_z` = '-1.644067', `spawn_orientation` = '0.934511',`position_x` = '274.066254', `position_y` = '8703.738281', `position_z` = '-1.644067', `orientation` = '0.934511' WHERE `guid` = '66019';
UPDATE `creature` SET `spawn_position_x` = '282.070099', `spawn_position_y` = '8698.915039', `spawn_position_z` = '-1.261644', `spawn_orientation` = '0.074498',`position_x` = '282.070099', `position_y` = '8698.915039', `position_z` = '-1.261644', `orientation` = '0.074498' WHERE `guid` = '66089';
UPDATE `creature` SET `spawn_position_x` = '280.810059', `spawn_position_y` = '8688.836914', `spawn_position_z` = '-1.840418', `spawn_orientation` = '4.869353',`position_x` = '280.810059', `position_y` = '8688.836914', `position_z` = '-1.840418', `orientation` = '4.869353' WHERE `guid` = '66016';
UPDATE `creature` SET `spawn_position_x` = '801.970276', `spawn_position_y` = '8494.589844', `spawn_position_z` = '22.323942', `spawn_orientation` = '0.525696',`position_x` = '801.970276', `position_y` = '8494.589844', `position_z` = '22.323942', `orientation` = '0.525696' WHERE `guid` = '65623';
UPDATE `creature` SET `spawn_position_x` = '766.013367', `spawn_position_y` = '8477.958984', `spawn_position_z` = '23.049620', `spawn_orientation` = '3.035043',`position_x` = '766.013367', `position_y` = '8477.958984', `position_z` = '23.049620', `orientation` = '3.035043' WHERE `guid` = '65976';
UPDATE `creature` SET `spawn_position_x` = '1000.301636', `spawn_position_y` = '8605.915039', `spawn_position_z` = '24.582037', `spawn_orientation` = '1.126783',`position_x` = '1000.301636', `position_y` = '8605.915039', `position_z` = '24.582037', `orientation` = '1.126783' WHERE `guid` = '65636';
UPDATE `creature` SET `spawn_position_x` = '23.683048', `spawn_position_y` = '8339.186523', `spawn_position_z` = '23.694607', `spawn_orientation` = '1.333589',`position_x` = '23.683048', `position_y` = '8339.186523', `position_z` = '23.694607', `orientation` = '1.333589' WHERE `guid` = '65545';
UPDATE `creature` SET `spawn_position_x` = '-41.821159', `spawn_position_y` = '8632.705078', `spawn_position_z` = '20.064936', `spawn_orientation` = '0.905686',`position_x` = '-41.821159', `position_y` = '8632.705078', `position_z` = '20.064936', `orientation` = '0.905686' WHERE `guid` = '65506';
UPDATE `creature` SET `spawn_position_x` = '-76.020569', `spawn_position_y` = '8871.002930', `spawn_position_z` = '20.993097', `spawn_orientation` = '5.010583',`position_x` = '-76.020569', `position_y` = '8871.002930', `position_z` = '20.993097', `orientation` = '5.010583' WHERE `guid` = '65444';
UPDATE `creature` SET `spawn_position_x` = '-74.736099', `spawn_position_y` = '8888.013672', `spawn_position_z` = '22.846352', `spawn_orientation` = '3.506546',`position_x` = '-74.736099', `position_y` = '8888.013672', `position_z` = '22.846352', `orientation` = '3.506546' WHERE `guid` = '66202';
UPDATE `creature` SET `spawn_position_x` = '-92.037552', `spawn_position_y` = '8907.992188', `spawn_position_z` = '24.082205', `spawn_orientation` = '3.760557',`position_x` = '-92.037552', `position_y` = '8907.992188', `position_z` = '24.082205', `orientation` = '3.760557' WHERE `guid` = '65436';
UPDATE `creature` SET `spawn_position_x` = '108.418205', `spawn_position_y` = '8804.431641', `spawn_position_z` = '5.754404', `spawn_orientation` = '3.047155',`position_x` = '108.418205', `position_y` = '8804.431641', `position_z` = '5.754404', `orientation` = '3.047155' WHERE `guid` = '65411';
UPDATE `creature` SET `spawn_position_x` = '121.891693', `spawn_position_y` = '8789.601563', `spawn_position_z` = '1.864969', `spawn_orientation` = '5.611479',`position_x` = '121.891693', `position_y` = '8789.601563', `position_z` = '1.864969', `orientation` = '5.611479' WHERE `guid` = '65417';
UPDATE `creature` SET `spawn_position_x` = '83.035477', `spawn_position_y` = '8298.942383', `spawn_position_z` = '17.967981', `spawn_orientation` = '1.499523',`position_x` = '83.035477', `position_y` = '8298.942383', `position_z` = '17.967981', `orientation` = '1.499523' WHERE `guid` = '65331';
UPDATE `creature` SET `spawn_position_x` = '370.879730', `spawn_position_y` = '8162.913086', `spawn_position_z` = '22.590921', `spawn_orientation` = '0.191517',`position_x` = '370.879730', `position_y` = '8162.913086', `position_z` = '22.590921', `orientation` = '0.191517' WHERE `guid` = '65309';
UPDATE `creature` SET `spawn_position_x` = '1178.654053', `spawn_position_y` = '8143.214355', `spawn_position_z` = '17.995153', `spawn_orientation` = '3.419988',`position_x` = '1178.654053', `position_y` = '8143.214355', `position_z` = '17.995153', `orientation` = '3.419988' WHERE `guid` = '65189';
UPDATE `creature` SET `spawn_position_x` = '1184.563721', `spawn_position_y` = '8296.973633', `spawn_position_z` = '17.708864', `spawn_orientation` = '2.018695',`position_x` = '1184.563721', `position_y` = '8296.973633', `position_z` = '17.708864', `orientation` = '2.018695' WHERE `guid` = '65188';
UPDATE `creature` SET `spawn_position_x` = '326.742218', `spawn_position_y` = '7511.666992', `spawn_position_z` = '21.879755', `spawn_orientation` = '3.266771',`position_x` = '326.742218', `position_y` = '7511.666992', `position_z` = '21.879755', `orientation` = '3.266771' WHERE `guid` = '66440';
UPDATE `creature` SET `spawn_position_x` = '-0.753599', `spawn_position_y` = '7054.658691', `spawn_position_z` = '19.953054', `spawn_orientation` = '3.031491',`position_x` = '-0.753599', `position_y` = '7054.658691', `position_z` = '19.953054', `orientation` = '3.031491' WHERE `guid` = '64980';
UPDATE `creature` SET `spawn_position_x` = '-165.102066', `spawn_position_y` = '7295.135742', `spawn_position_z` = '22.716589', `spawn_orientation` = '4.576931',`position_x` = '-165.102066', `position_y` = '7295.135742', `position_z` = '22.716589', `orientation` = '4.576931' WHERE `guid` = '64871';
UPDATE `creature` SET `spawn_position_x` = '-152.186676', `spawn_position_y` = '7306.879883', `spawn_position_z` = '22.836315', `spawn_orientation` = '0.159066',`position_x` = '-152.186676', `position_y` = '7306.879883', `position_z` = '22.836315', `orientation` = '0.159066' WHERE `guid` = '64962';
UPDATE `creature` SET `spawn_position_x` = '-137.180176', `spawn_position_y` = '7431.827148', `spawn_position_z` = '22.239819', `spawn_orientation` = '5.969008',`position_x` = '-137.180176', `position_y` = '7431.827148', `position_z` = '22.239819', `orientation` = '5.969008' WHERE `guid` = '64885';
UPDATE `creature` SET `spawn_position_x` = '-974.192566', `spawn_position_y` = '5551.755371', `spawn_position_z` = '22.631714', `spawn_orientation` = '6.110788',`position_x` = '-974.192566', `position_y` = '5551.755371', `position_z` = '22.631714', `orientation` = '6.110788' WHERE `guid` = '64653';
UPDATE `creature` SET `spawn_position_x` = '964.349854', `spawn_position_y` = '5212.456543', `spawn_position_z` = '0.587563', `spawn_orientation` = '0.868976',`position_x` = '964.349854', `position_y` = '5212.456543', `position_z` = '0.587563', `orientation` = '0.868976' WHERE `guid` = '64405';
UPDATE `creature` SET `spawn_position_x` = '-142.838043', `spawn_position_y` = '5639.839355', `spawn_position_z` = '21.887020', `spawn_orientation` = '1.419535',`position_x` = '-142.838043', `position_y` = '5639.839355', `position_z` = '21.887020', `orientation` = '1.419535' WHERE `guid` = '64518';
UPDATE `creature` SET `spawn_position_x` = '-131.346344', `spawn_position_y` = '5645.052246', `spawn_position_z` = '23.212008', `spawn_orientation` = '1.160355',`position_x` = '-131.346344', `position_y` = '5645.052246', `position_z` = '23.212008', `orientation` = '1.160355' WHERE `guid` = '64265';
UPDATE `creature` SET `spawn_position_x` = '-120.592201', `spawn_position_y` = '5644.321777', `spawn_position_z` = '23.161255', `spawn_orientation` = '0.952225',`position_x` = '-120.592201', `position_y` = '5644.321777', `position_z` = '23.161255', `orientation` = '0.952225' WHERE `guid` = '64271';
UPDATE `creature` SET `spawn_position_x` = '-126.881668', `spawn_position_y` = '5636.451172', `spawn_position_z` = '23.139818', `spawn_orientation` = '3.995644',`position_x` = '-126.881668', `position_y` = '5636.451172', `position_z` = '23.139818', `orientation` = '3.995644' WHERE `guid` = '64199';
UPDATE `creature` SET `spawn_position_x` = '-128.235809', `spawn_position_y` = '5625.086426', `spawn_position_z` = '21.625565', `spawn_orientation` = '4.439394',`position_x` = '-128.235809', `position_y` = '5625.086426', `position_z` = '21.625565', `orientation` = '4.439394' WHERE `guid` = '64193';
UPDATE `creature` SET `spawn_position_x` = '-127.562607', `spawn_position_y` = '5614.915039', `spawn_position_z` = '20.747145', `spawn_orientation` = '2.978554',`position_x` = '-127.562607', `position_y` = '5614.915039', `position_z` = '20.747145', `orientation` = '2.978554' WHERE `guid` = '64198';
UPDATE `creature` SET `spawn_position_x` = '-130.485123', `spawn_position_y` = '5601.999512', `spawn_position_z` = '21.827484', `spawn_orientation` = '3.383034',`position_x` = '-130.485123', `position_y` = '5601.999512', `position_z` = '21.827484', `orientation` = '3.383034' WHERE `guid` = '64239';
UPDATE `creature` SET `spawn_position_x` = '-137.820328', `spawn_position_y` = '5599.546387', `spawn_position_z` = '22.221231', `spawn_orientation` = '2.295258',`position_x` = '-137.820328', `position_y` = '5599.546387', `position_z` = '22.221231', `orientation` = '2.295258' WHERE `guid` = '64226';
UPDATE `creature` SET `spawn_position_x` = '-156.571350', `spawn_position_y` = '5597.056152', `spawn_position_z` = '23.957611', `spawn_orientation` = '1.423466',`position_x` = '-156.571350', `position_y` = '5597.056152', `position_z` = '23.957611', `orientation` = '1.423466' WHERE `guid` = '64536';
UPDATE `creature` SET `spawn_position_x` = '-169.589966', `spawn_position_y` = '5605.041016', `spawn_position_z` = '22.316910', `spawn_orientation` = '1.521640',`position_x` = '-169.589966', `position_y` = '5605.041016', `position_z` = '22.316910', `orientation` = '1.521640' WHERE `guid` = '64285';
UPDATE `creature` SET `spawn_position_x` = '3453.345215', `spawn_position_y` = '5176.734375', `spawn_position_z` = '-7.797080', `spawn_orientation` = '0.780608',`position_x` = '3453.345215', `position_y` = '5176.734375', `position_z` = '-7.797080', `orientation` = '0.780608' WHERE `guid` = '63675';
UPDATE `creature` SET `spawn_position_x` = '3464.568604', `spawn_position_y` = '5184.729004', `spawn_position_z` = '-5.818280', `spawn_orientation` = '0.042333',`position_x` = '3464.568604', `position_y` = '5184.729004', `position_z` = '-5.818280', `orientation` = '0.042333' WHERE `guid` = '63696';
DELETE FROM `creature` WHERE `guid` = '63708';
DELETE FROM `creature_addon` WHERE `guid` = '63708';
DELETE FROM `creature_movement` WHERE `id` = '63708';
DELETE FROM `creature` WHERE `guid` = '63689';
DELETE FROM `creature_addon` WHERE `guid` = '63689';
DELETE FROM `creature_movement` WHERE `id` = '63689';
DELETE FROM `creature` WHERE `guid` = '63666';
DELETE FROM `creature_addon` WHERE `guid` = '63666';
DELETE FROM `creature_movement` WHERE `id` = '63666';
DELETE FROM `creature` WHERE `guid` = '63670';
DELETE FROM `creature_addon` WHERE `guid` = '63670';
DELETE FROM `creature_movement` WHERE `id` = '63670';
DELETE FROM `creature` WHERE `guid` = '63699';
DELETE FROM `creature_addon` WHERE `guid` = '63699';
DELETE FROM `creature_movement` WHERE `id` = '63699';
DELETE FROM `creature` WHERE `guid` = '63683';
DELETE FROM `creature_addon` WHERE `guid` = '63683';
DELETE FROM `creature_movement` WHERE `id` = '63683';
DELETE FROM `creature` WHERE `guid` = '63674';
DELETE FROM `creature_addon` WHERE `guid` = '63674';
DELETE FROM `creature_movement` WHERE `id` = '63674';
UPDATE `creature` SET `spawn_position_x` = '3483.592285', `spawn_position_y` = '5188.746582', `spawn_position_z` = '3.162524', `spawn_orientation` = '0.120873',`position_x` = '3483.592285', `position_y` = '5188.746582', `position_z` = '3.162524', `orientation` = '0.120873' WHERE `guid` = '63702';
DELETE FROM `creature` WHERE `guid` = '63688';
DELETE FROM `creature_addon` WHERE `guid` = '63688';
DELETE FROM `creature_movement` WHERE `id` = '63688';
DELETE FROM `creature` WHERE `guid` = '63698';
DELETE FROM `creature_addon` WHERE `guid` = '63698';
DELETE FROM `creature_movement` WHERE `id` = '63698';
DELETE FROM `creature` WHERE `guid` = '63701';
DELETE FROM `creature_addon` WHERE `guid` = '63701';
DELETE FROM `creature_movement` WHERE `id` = '63701';
UPDATE `creature` SET `spawn_position_x` = '3430.400635', `spawn_position_y` = '5208.873047', `spawn_position_z` = '-3.172032', `spawn_orientation` = '5.151346',`position_x` = '3430.400635', `position_y` = '5208.873047', `position_z` = '-3.172032', `orientation` = '5.151346' WHERE `guid` = '62441';
UPDATE `creature` SET `spawn_position_x` = '2247.981201', `spawn_position_y` = '2416.190186', `spawn_position_z` = '118.037323', `spawn_orientation` = '0.517419',`position_x` = '2247.981201', `position_y` = '2416.190186', `position_z` = '118.037323', `orientation` = '0.517419' WHERE `guid` = '63728';
UPDATE `creature` SET `spawn_position_x` = '-59.593884', `spawn_position_y` = '5507.062012', `spawn_position_z` = '23.097609', `spawn_orientation` = '0.709604',`position_x` = '-59.593884', `position_y` = '5507.062012', `position_z` = '23.097609', `orientation` = '0.709604' WHERE `guid` = '64200';
UPDATE `creature` SET `spawn_position_x` = '2966.552979', `spawn_position_y` = '5561.889160', `spawn_position_z` = '147.426041', `spawn_orientation` = '1.911597',`position_x` = '2966.552979', `position_y` = '5561.889160', `position_z` = '147.426041', `orientation` = '1.911597' WHERE `guid` = '62364';
UPDATE `creature` SET `spawn_position_x` = '2957.884521', `spawn_position_y` = '5555.070801', `spawn_position_z` = '147.470535', `spawn_orientation` = '5.367348',`position_x` = '2957.884521', `position_y` = '5555.070801', `position_z` = '147.470535', `orientation` = '5.367348' WHERE `guid` = '63543';
UPDATE `creature` SET `spawn_position_x` = '2967.212402', `spawn_position_y` = '5535.224121', `spawn_position_z` = '146.074234', `spawn_orientation` = '5.033554',`position_x` = '2967.212402', `position_y` = '5535.224121', `position_z` = '146.074234', `orientation` = '5.033554' WHERE `guid` = '62621';
UPDATE `creature` SET `spawn_position_x` = '2975.447998', `spawn_position_y` = '5556.607422', `spawn_position_z` = '148.008301', `spawn_orientation` = '1.275424',`position_x` = '2975.447998', `position_y` = '5556.607422', `position_z` = '148.008301', `orientation` = '1.275424' WHERE `guid` = '62640';
UPDATE `creature` SET `spawn_position_x` = '3050.746338', `spawn_position_y` = '5494.509766', `spawn_position_z` = '146.121567', `spawn_orientation` = '4.595728',`position_x` = '3050.746338', `position_y` = '5494.509766', `position_z` = '146.121567', `orientation` = '4.595728' WHERE `guid` = '63604';
UPDATE `creature` SET `spawn_position_x` = '3052.365967', `spawn_position_y` = '5502.974121', `spawn_position_z` = '146.519608', `spawn_orientation` = '1.752587',`position_x` = '3052.365967', `position_y` = '5502.974121', `position_z` = '146.519608', `orientation` = '1.752587' WHERE `guid` = '63548';
UPDATE `creature` SET `spawn_position_x` = '3049.041992', `spawn_position_y` = '5509.856934', `spawn_position_z` = '146.999756', `spawn_orientation` = '2.416249',`position_x` = '3049.041992', `position_y` = '5509.856934', `position_z` = '146.999756', `orientation` = '2.416249' WHERE `guid` = '63582';
UPDATE `creature` SET `spawn_position_x` = '3041.501953', `spawn_position_y` = '5519.023438', `spawn_position_z` = '148.271713', `spawn_orientation` = '2.451591',`position_x` = '3041.501953', `position_y` = '5519.023438', `position_z` = '148.271713', `orientation` = '2.451591' WHERE `guid` = '62642';
UPDATE `creature` SET `spawn_position_x` = '3030.123047', `spawn_position_y` = '5530.957031', `spawn_position_z` = '148.857773', `spawn_orientation` = '2.325927',`position_x` = '3030.123047', `position_y` = '5530.957031', `position_z` = '148.857773', `orientation` = '2.325927' WHERE `guid` = '62370';
UPDATE `creature` SET `spawn_position_x` = '3030.551514', `spawn_position_y` = '5543.037598', `spawn_position_z` = '148.293671', `spawn_orientation` = '1.768294',`position_x` = '3030.551514', `position_y` = '5543.037598', `position_z` = '148.293671', `orientation` = '1.768294' WHERE `guid` = '62371';
UPDATE `creature` SET `spawn_position_x` = '3007.821533', `spawn_position_y` = '5531.307129', `spawn_position_z` = '148.315125', `spawn_orientation` = '3.935993',`position_x` = '3007.821533', `position_y` = '5531.307129', `position_z` = '148.315125', `orientation` = '3.935993' WHERE `guid` = '63583';
UPDATE `creature` SET `spawn_position_x` = '2996.589355', `spawn_position_y` = '5522.553711', `spawn_position_z` = '147.523941', `spawn_orientation` = '3.500097',`position_x` = '2996.589355', `position_y` = '5522.553711', `position_z` = '147.523941', `orientation` = '3.500097' WHERE `guid` = '62622';
UPDATE `creature` SET `spawn_position_x` = '2897.275635', `spawn_position_y` = '5425.079590', `spawn_position_z` = '150.434143', `spawn_orientation` = '0.520311',`position_x` = '2897.275635', `position_y` = '5425.079590', `position_z` = '150.434143', `orientation` = '0.520311' WHERE `guid` = '63530';
UPDATE `creature` SET `spawn_position_x` = '2899.873291', `spawn_position_y` = '5414.938477', `spawn_position_z` = '149.904633', `spawn_orientation` = '5.703939',`position_x` = '2899.873291', `position_y` = '5414.938477', `position_z` = '149.904633', `orientation` = '5.703939' WHERE `guid` = '63529';
UPDATE `creature` SET `spawn_position_x` = '2902.739502', `spawn_position_y` = '5402.197754', `spawn_position_z` = '149.647598', `spawn_orientation` = '4.977448',`position_x` = '2902.739502', `position_y` = '5402.197754', `position_z` = '149.647598', `orientation` = '4.977448' WHERE `guid` = '63556';
UPDATE `creature` SET `spawn_position_x` = '2899.031250', `spawn_position_y` = '5381.749512', `spawn_position_z` = '148.605576', `spawn_orientation` = '5.169869',`position_x` = '2899.031250', `position_y` = '5381.749512', `position_z` = '148.605576', `orientation` = '5.169869' WHERE `guid` = '63554';
UPDATE `creature` SET `spawn_position_x` = '2854.207031', `spawn_position_y` = '5379.843262', `spawn_position_z` = '144.956009', `spawn_orientation` = '3.791496',`position_x` = '2854.207031', `position_y` = '5379.843262', `position_z` = '144.956009', `orientation` = '3.791496' WHERE `guid` = '63557';
UPDATE `creature` SET `spawn_position_x` = '2830.283691', `spawn_position_y` = '5427.536133', `spawn_position_z` = '145.384506', `spawn_orientation` = '2.668377',`position_x` = '2830.283691', `position_y` = '5427.536133', `position_z` = '145.384506', `orientation` = '2.668377' WHERE `guid` = '63558';
UPDATE `creature` SET `spawn_position_x` = '2853.454590', `spawn_position_y` = '5436.038574', `spawn_position_z` = '147.886871', `spawn_orientation` = '2.036132',`position_x` = '2853.454590', `position_y` = '5436.038574', `position_z` = '147.886871', `orientation` = '2.036132' WHERE `guid` = '63532';
UPDATE `creature` SET `spawn_position_x` = '2879.781250', `spawn_position_y` = '5454.020020', `spawn_position_z` = '150.212204', `spawn_orientation` = '1.227169',`position_x` = '2879.781250', `position_y` = '5454.020020', `position_z` = '150.212204', `orientation` = '1.227169' WHERE `guid` = '63550';
UPDATE `creature` SET `spawn_position_x` = '2856.800293', `spawn_position_y` = '5426.501953', `spawn_position_z` = '149.153381', `spawn_orientation` = '2.688008',`position_x` = '2856.800293', `position_y` = '5426.501953', `position_z` = '149.153381', `orientation` = '2.688008' WHERE `guid` = '63555';
DELETE FROM `creature` WHERE `guid` = '63168';
DELETE FROM `creature_addon` WHERE `guid` = '63168';
DELETE FROM `creature_movement` WHERE `id` = '63168';
UPDATE `creature` SET `spawn_position_x` = '1781.782349', `spawn_position_y` = '5610.896973', `spawn_position_z` = '265.419434', `spawn_orientation` = '2.214810',`position_x` = '1781.782349', `position_y` = '5610.896973', `position_z` = '265.419434', `orientation` = '2.214810' WHERE `guid` = '63166';
UPDATE `creature` SET `spawn_position_x` = '2750.686279', `spawn_position_y` = '5279.621094', `spawn_position_z` = '263.279388', `spawn_orientation` = '0.238025',`position_x` = '2750.686279', `position_y` = '5279.621094', `position_z` = '263.279388', `orientation` = '0.238025' WHERE `guid` = '63378';
UPDATE `creature` SET `spawn_position_x` = '2755.454346', `spawn_position_y` = '5287.338867', `spawn_position_z` = '261.486420', `spawn_orientation` = '3.312860',`position_x` = '2755.454346', `position_y` = '5287.338867', `position_z` = '261.486420', `orientation` = '3.312860' WHERE `guid` = '63374';
UPDATE `creature` SET `spawn_position_x` = '2738.392334', `spawn_position_y` = '5283.317871', `spawn_position_z` = '263.779358', `spawn_orientation` = '3.697705',`position_x` = '2738.392334', `position_y` = '5283.317871', `position_z` = '263.779358', `orientation` = '3.697705' WHERE `guid` = '63373';
UPDATE `creature` SET `spawn_position_x` = '2692.094727', `spawn_position_y` = '5283.301758', `spawn_position_z` = '266.810608', `spawn_orientation` = '3.348203',`position_x` = '2692.094727', `position_y` = '5283.301758', `position_z` = '266.810608', `orientation` = '3.348203' WHERE `guid` = '63363';
UPDATE `creature` SET `spawn_position_x` = '2687.978760', `spawn_position_y` = '5266.000977', `spawn_position_z` = '266.820435', `spawn_orientation` = '4.946486',`position_x` = '2687.978760', `position_y` = '5266.000977', `position_z` = '266.820435', `orientation` = '4.946486' WHERE `guid` = '63382';
UPDATE `creature` SET `spawn_position_x` = '2684.806641', `spawn_position_y` = '5241.630859', `spawn_position_z` = '268.564880', `spawn_orientation` = '4.384925',`position_x` = '2684.806641', `position_y` = '5241.630859', `position_z` = '268.564880', `orientation` = '4.384925' WHERE `guid` = '63362';
UPDATE `creature` SET `spawn_position_x` = '2688.895264', `spawn_position_y` = '5193.934082', `spawn_position_z` = '265.862549', `spawn_orientation` = '5.574800',`position_x` = '2688.895264', `position_y` = '5193.934082', `position_z` = '265.862549', `orientation` = '5.574800' WHERE `guid` = '63354';
UPDATE `creature` SET `spawn_position_x` = '2691.590088', `spawn_position_y` = '5267.856934', `spawn_position_z` = '266.931671', `spawn_orientation` = '0.544325',`position_x` = '2691.590088', `position_y` = '5267.856934', `position_z` = '266.931671', `orientation` = '0.544325' WHERE `guid` = '63379';
UPDATE `creature` SET `spawn_position_x` = '2692.817627', `spawn_position_y` = '5294.044922', `spawn_position_z` = '266.455444', `spawn_orientation` = '1.027345',`position_x` = '2692.817627', `position_y` = '5294.044922', `position_z` = '266.455444', `orientation` = '1.027345' WHERE `guid` = '63366';
UPDATE `creature` SET `spawn_position_x` = '2708.288818', `spawn_position_y` = '5313.732910', `spawn_position_z` = '265.857483', `spawn_orientation` = '0.752456',`position_x` = '2708.288818', `position_y` = '5313.732910', `position_z` = '265.857483', `orientation` = '0.752456' WHERE `guid` = '63364';
UPDATE `creature` SET `spawn_position_x` = '2700.685547', `spawn_position_y` = '5287.721191', `spawn_position_z` = '266.025085', `spawn_orientation` = '3.972592',`position_x` = '2700.685547', `position_y` = '5287.721191', `position_z` = '266.025085', `orientation` = '3.972592' WHERE `guid` = '63380';
UPDATE `creature` SET `spawn_position_x` = '2756.884277', `spawn_position_y` = '5277.257324', `spawn_position_z` = '262.747803', `spawn_orientation` = '6.195265',`position_x` = '2756.884277', `position_y` = '5277.257324', `position_z` = '262.747803', `orientation` = '6.195265' WHERE `guid` = '63377';
UPDATE `creature` SET `spawn_position_x` = '2779.746094', `spawn_position_y` = '5277.678711', `spawn_position_z` = '260.906555', `spawn_orientation` = '0.104504',`position_x` = '2779.746094', `position_y` = '5277.678711', `position_z` = '260.906555', `orientation` = '0.104504' WHERE `guid` = '63437';
UPDATE `creature` SET `spawn_position_x` = '2796.541260', `spawn_position_y` = '5276.200195', `spawn_position_z` = '261.092194', `spawn_orientation` = '6.046042',`position_x` = '2796.541260', `position_y` = '5276.200195', `position_z` = '261.092194', `orientation` = '6.046042' WHERE `guid` = '63426';
UPDATE `creature` SET `spawn_position_x` = '2809.152832', `spawn_position_y` = '5269.444336', `spawn_position_z` = '259.393188', `spawn_orientation` = '5.413798',`position_x` = '2809.152832', `position_y` = '5269.444336', `position_z` = '259.393188', `orientation` = '5.413798' WHERE `guid` = '63421';
UPDATE `creature` SET `spawn_position_x` = '2827.687256', `spawn_position_y` = '5281.809570', `spawn_position_z` = '262.670898', `spawn_orientation` = '0.882050',`position_x` = '2827.687256', `position_y` = '5281.809570', `position_z` = '262.670898', `orientation` = '0.882050' WHERE `guid` = '63415';
UPDATE `creature` SET `spawn_position_x` = '2836.692627', `spawn_position_y` = '5281.448242', `spawn_position_z` = '263.541107', `spawn_orientation` = '1.989462',`position_x` = '2836.692627', `position_y` = '5281.448242', `position_z` = '263.541107', `orientation` = '1.989462' WHERE `guid` = '63392';
UPDATE `creature` SET `spawn_position_x` = '2836.480713', `spawn_position_y` = '5268.641113', `spawn_position_z` = '264.419891', `spawn_orientation` = '4.789406',`position_x` = '2836.480713', `position_y` = '5268.641113', `position_z` = '264.419891', `orientation` = '4.789406' WHERE `guid` = '63429';
UPDATE `creature` SET `spawn_position_x` = '2839.936523', `spawn_position_y` = '5248.025391', `spawn_position_z` = '265.696259', `spawn_orientation` = '4.463468',`position_x` = '2839.936523', `position_y` = '5248.025391', `position_z` = '265.696259', `orientation` = '4.463468' WHERE `guid` = '63476';
UPDATE `creature` SET `spawn_position_x` = '2825.796631', `spawn_position_y` = '5229.826172', `spawn_position_z` = '264.529510', `spawn_orientation` = '3.733046',`position_x` = '2825.796631', `position_y` = '5229.826172', `position_z` = '264.529510', `orientation` = '3.733046' WHERE `guid` = '63420';
UPDATE `creature` SET `spawn_position_x` = '2830.640869', `spawn_position_y` = '5224.286133', `spawn_position_z` = '264.616638', `spawn_orientation` = '3.799807',`position_x` = '2830.640869', `position_y` = '5224.286133', `position_z` = '264.616638', `orientation` = '3.799807' WHERE `guid` = '63414';
UPDATE `creature` SET `spawn_position_x` = '2820.764893', `spawn_position_y` = '5219.349121', `spawn_position_z` = '264.580048', `spawn_orientation` = '4.062915',`position_x` = '2820.764893', `position_y` = '5219.349121', `position_z` = '264.580048', `orientation` = '4.062915' WHERE `guid` = '63412';
UPDATE `creature` SET `spawn_position_x` = '2818.530518', `spawn_position_y` = '5207.677734', `spawn_position_z` = '264.862885', `spawn_orientation` = '3.112582',`position_x` = '2818.530518', `position_y` = '5207.677734', `position_z` = '264.862885', `orientation` = '3.112582' WHERE `guid` = '63413';
UPDATE `creature` SET `spawn_position_x` = '2808.412842', `spawn_position_y` = '5207.971191', `spawn_position_z` = '266.230286', `spawn_orientation` = '2.020879',`position_x` = '2808.412842', `position_y` = '5207.971191', `position_z` = '266.230286', `orientation` = '2.020879' WHERE `guid` = '63419';
UPDATE `creature` SET `spawn_position_x` = '2802.274414', `spawn_position_y` = '5210.419922', `spawn_position_z` = '265.976349', `spawn_orientation` = '3.591676',`position_x` = '2802.274414', `position_y` = '5210.419922', `position_z` = '265.976349', `orientation` = '3.591676' WHERE `guid` = '63440';
UPDATE `creature` SET `spawn_position_x` = '2792.169678', `spawn_position_y` = '5213.503906', `spawn_position_z` = '264.966919', `spawn_orientation` = '4.106111',`position_x` = '2792.169678', `position_y` = '5213.503906', `position_z` = '264.966919', `orientation` = '4.106111' WHERE `guid` = '63451';
UPDATE `creature` SET `spawn_position_x` = '2779.974365', `spawn_position_y` = '5198.550781', `spawn_position_z` = '264.602936', `spawn_orientation` = '3.846929',`position_x` = '2779.974365', `position_y` = '5198.550781', `position_z` = '264.602936', `orientation` = '3.846929' WHERE `guid` = '63451';
UPDATE `creature` SET `spawn_position_x` = '2796.696045', `spawn_position_y` = '5192.208984', `spawn_position_z` = '266.301636', `spawn_orientation` = '6.112803',`position_x` = '2796.696045', `position_y` = '5192.208984', `position_z` = '266.301636', `orientation` = '6.112803' WHERE `guid` = '63458';
UPDATE `creature` SET `spawn_position_x` = '2773.752197', `spawn_position_y` = '5154.821289', `spawn_position_z` = '261.082947', `spawn_orientation` = '0.701409',`position_x` = '2773.752197', `position_y` = '5154.821289', `position_z` = '261.082947', `orientation` = '0.701409' WHERE `guid` = '63391';
UPDATE `creature` SET `spawn_position_x` = '2774.564453', `spawn_position_y` = '5163.314453', `spawn_position_z` = '262.071686', `spawn_orientation` = '0.406885',`position_x` = '2774.564453', `position_y` = '5163.314453', `position_z` = '262.071686', `orientation` = '0.406885' WHERE `guid` = '63457';
UPDATE `creature` SET `spawn_position_x` = '2800.886719', `spawn_position_y` = '5179.243652', `spawn_position_z` = '265.028534', `spawn_orientation` = '3.348202',`position_x` = '2800.886719', `position_y` = '5179.243652', `position_z` = '265.028534', `orientation` = '3.348202' WHERE `guid` = '63459';
DELETE FROM `creature` WHERE `guid` = '63425';
DELETE FROM `creature_addon` WHERE `guid` = '63425';
DELETE FROM `creature_movement` WHERE `id` = '63425';
DELETE FROM `creature` WHERE `guid` = '63424';
DELETE FROM `creature_addon` WHERE `guid` = '63424';
DELETE FROM `creature_movement` WHERE `id` = '63424';
DELETE FROM `creature` WHERE `guid` = '63452';
DELETE FROM `creature_addon` WHERE `guid` = '63452';
DELETE FROM `creature_movement` WHERE `id` = '63452';
DELETE FROM `creature` WHERE `guid` = '63449';
DELETE FROM `creature_addon` WHERE `guid` = '63449';
DELETE FROM `creature_movement` WHERE `id` = '63449';
DELETE FROM `creature` WHERE `guid` = '63450';
DELETE FROM `creature_addon` WHERE `guid` = '63450';
DELETE FROM `creature_movement` WHERE `id` = '63450';
DELETE FROM `creature` WHERE `guid` = '63485';
DELETE FROM `creature_addon` WHERE `guid` = '63485';
DELETE FROM `creature_movement` WHERE `id` = '63485';
DELETE FROM `creature` WHERE `guid` = '63443';
DELETE FROM `creature_addon` WHERE `guid` = '63443';
DELETE FROM `creature_movement` WHERE `id` = '63443';
DELETE FROM `creature` WHERE `guid` = '63454';
DELETE FROM `creature_addon` WHERE `guid` = '63454';
DELETE FROM `creature_movement` WHERE `id` = '63454';
DELETE FROM `creature` WHERE `guid` = '63444';
DELETE FROM `creature_addon` WHERE `guid` = '63444';
DELETE FROM `creature_movement` WHERE `id` = '63444';
DELETE FROM `creature` WHERE `guid` = '63453';
DELETE FROM `creature_addon` WHERE `guid` = '63453';
DELETE FROM `creature_movement` WHERE `id` = '63453';
DELETE FROM `creature` WHERE `guid` = '63494';
DELETE FROM `creature_addon` WHERE `guid` = '63494';
DELETE FROM `creature_movement` WHERE `id` = '63494';
DELETE FROM `creature` WHERE `guid` = '63493';
DELETE FROM `creature_addon` WHERE `guid` = '63493';
DELETE FROM `creature_movement` WHERE `id` = '63493';
UPDATE `creature` SET `spawn_position_x` = '2936.213623', `spawn_position_y` = '5142.012207', `spawn_position_z` = '263.924164', `spawn_orientation` = '2.323250',`position_x` = '2936.213623', `position_y` = '5142.012207', `position_z` = '263.924164', `orientation` = '2.323250' WHERE `guid` = '63517';
UPDATE `creature` SET `spawn_position_x` = '2943.284912', `spawn_position_y` = '5145.193848', `spawn_position_z` = '264.590485', `spawn_orientation` = '1.981601',`position_x` = '2943.284912', `position_y` = '5145.193848', `position_z` = '264.590485', `orientation` = '1.981601' WHERE `guid` = '63518';
UPDATE `creature` SET `spawn_position_x` = '2928.842529', `spawn_position_y` = '5149.152832', `spawn_position_z` = '263.915283', `spawn_orientation` = '1.812741',`position_x` = '2928.842529', `position_y` = '5149.152832', `position_z` = '263.915283', `orientation` = '1.812741' WHERE `guid` = '63519';
UPDATE `creature` SET `spawn_position_x` = '2932.707520', `spawn_position_y` = '5155.198730', `spawn_position_z` = '265.269531', `spawn_orientation` = '2.001236',`position_x` = '2932.707520', `position_y` = '5155.198730', `position_z` = '265.269531', `orientation` = '2.001236' WHERE `guid` = '63510';
UPDATE `creature` SET `spawn_position_x` = '2977.850342', `spawn_position_y` = '5139.690430', `spawn_position_z` = '263.417603', `spawn_orientation` = '2.331103',`position_x` = '2977.850342', `position_y` = '5139.690430', `position_z` = '263.417603', `orientation` = '2.331103' WHERE `guid` = '63507';
DELETE FROM `creature` WHERE `guid` = '63525';
DELETE FROM `creature_addon` WHERE `guid` = '63525';
DELETE FROM `creature_movement` WHERE `id` = '63525';
DELETE FROM `creature` WHERE `guid` = '63516';
DELETE FROM `creature_addon` WHERE `guid` = '63516';
DELETE FROM `creature_movement` WHERE `id` = '63516';
UPDATE `creature` SET `spawn_position_x` = '2946.030518', `spawn_position_y` = '5203.321289', `spawn_position_z` = '264.884338', `spawn_orientation` = '2.071922',`position_x` = '2946.030518', `position_y` = '5203.321289', `position_z` = '264.884338', `orientation` = '2.071922' WHERE `guid` = '63501';
UPDATE `creature` SET `spawn_position_x` = '2949.025391', `spawn_position_y` = '5218.486328', `spawn_position_z` = '263.895782', `spawn_orientation` = '1.475019',`position_x` = '2949.025391', `position_y` = '5218.486328', `position_z` = '263.895782', `orientation` = '1.475019' WHERE `guid` = '63521';
UPDATE `creature` SET `spawn_position_x` = '2921.690918', `spawn_position_y` = '5221.284180', `spawn_position_z` = '265.246460', `spawn_orientation` = '3.226458',`position_x` = '2921.690918', `position_y` = '5221.284180', `position_z` = '265.246460', `orientation` = '3.226458' WHERE `guid` = '63498';
UPDATE `creature` SET `spawn_position_x` = '2907.541748', `spawn_position_y` = '5221.494141', `spawn_position_z` = '267.211884', `spawn_orientation` = '2.931933',`position_x` = '2907.541748', `position_y` = '5221.494141', `position_z` = '267.211884', `orientation` = '2.931933' WHERE `guid` = '63475';
DELETE FROM `creature` WHERE `guid` = '63490';
DELETE FROM `creature_addon` WHERE `guid` = '63490';
DELETE FROM `creature_movement` WHERE `id` = '63490';
UPDATE `creature` SET `spawn_position_x` = '2901.790771', `spawn_position_y` = '5207.344727', `spawn_position_z` = '267.773529', `spawn_orientation` = '4.706932',`position_x` = '2901.790771', `position_y` = '5207.344727', `position_z` = '267.773529', `orientation` = '4.706932' WHERE `guid` = '63508';
DELETE FROM `creature` WHERE `guid` = '63509';
DELETE FROM `creature_addon` WHERE `guid` = '63509';
DELETE FROM `creature_movement` WHERE `id` = '63509';
UPDATE `creature` SET `spawn_position_x` = '2890.944092', `spawn_position_y` = '5226.882813', `spawn_position_z` = '269.613922', `spawn_orientation` = '1.184417',`position_x` = '2890.944092', `position_y` = '5226.882813', `position_z` = '269.613922', `orientation` = '1.184417' WHERE `guid` = '63473';
UPDATE `creature` SET `spawn_position_x` = '2881.870361', `spawn_position_y` = '5214.667969', `spawn_position_z` = '268.063019', `spawn_orientation` = '5.409858',`position_x` = '2881.870361', `position_y` = '5214.667969', `position_z` = '268.063019', `orientation` = '5.409858' WHERE `guid` = '63499';
DELETE FROM `creature` WHERE `guid` = '63486';
DELETE FROM `creature_addon` WHERE `guid` = '63486';
DELETE FROM `creature_movement` WHERE `id` = '63486';
DELETE FROM `creature` WHERE `guid` = '63390';
DELETE FROM `creature_addon` WHERE `guid` = '63390';
DELETE FROM `creature_movement` WHERE `id` = '63390';
UPDATE `creature` SET `spawn_position_x` = '2873.655029', `spawn_position_y` = '5201.499023', `spawn_position_z` = '266.837372', `spawn_orientation` = '4.750124',`position_x` = '2873.655029', `position_y` = '5201.499023', `position_z` = '266.837372', `orientation` = '4.750124' WHERE `guid` = '63492';
DELETE FROM `creature` WHERE `guid` = '63463';
DELETE FROM `creature_addon` WHERE `guid` = '63463';
DELETE FROM `creature_movement` WHERE `id` = '63463';
DELETE FROM `creature` WHERE `guid` = '63483';
DELETE FROM `creature_addon` WHERE `guid` = '63483';
DELETE FROM `creature_movement` WHERE `id` = '63483';
DELETE FROM `creature` WHERE `guid` = '63481';
DELETE FROM `creature_addon` WHERE `guid` = '63481';
DELETE FROM `creature_movement` WHERE `id` = '63481';
DELETE FROM `creature` WHERE `guid` = '63474';
DELETE FROM `creature_addon` WHERE `guid` = '63474';
DELETE FROM `creature_movement` WHERE `id` = '63474';
UPDATE `creature` SET `spawn_position_x` = '2880.163574', `spawn_position_y` = '5218.353516', `spawn_position_z` = '268.788086', `spawn_orientation` = '2.425346',`position_x` = '2880.163574', `position_y` = '5218.353516', `position_z` = '268.788086', `orientation` = '2.425346' WHERE `guid` = '63477';
DELETE FROM `creature` WHERE `guid` = '63479';
DELETE FROM `creature_addon` WHERE `guid` = '63479';
DELETE FROM `creature_movement` WHERE `id` = '63479';
UPDATE `creature` SET `spawn_position_x` = '2879.820068', `spawn_position_y` = '5235.562988', `spawn_position_z` = '270.130341', `spawn_orientation` = '2.307536',`position_x` = '2879.820068', `position_y` = '5235.562988', `position_z` = '270.130341', `orientation` = '2.307536' WHERE `guid` = '63482';
DELETE FROM `creature` WHERE `guid` = '63482';
DELETE FROM `creature_addon` WHERE `guid` = '63482';
DELETE FROM `creature_movement` WHERE `id` = '63482';
UPDATE `creature` SET `spawn_position_x` = '2834.713135', `spawn_position_y` = '5232.777832', `spawn_position_z` = '264.608337', `spawn_orientation` = '3.756597',`position_x` = '2834.713135', `position_y` = '5232.777832', `position_z` = '264.608337', `orientation` = '3.756597' WHERE `guid` = '63455';
UPDATE `creature` SET `spawn_position_x` = '2824.329834', `spawn_position_y` = '5230.468262', `spawn_position_z` = '264.575348', `spawn_orientation` = '2.217216',`position_x` = '2824.329834', `position_y` = '5230.468262', `position_z` = '264.575348', `orientation` = '2.217216' WHERE `guid` = '63416';
UPDATE `creature` SET `spawn_position_x` = '2816.132324', `spawn_position_y` = '5223.281250', `spawn_position_z` = '264.558929', `spawn_orientation` = '3.756596',`position_x` = '2816.132324', `position_y` = '5223.281250', `position_z` = '264.558929', `orientation` = '3.756596' WHERE `guid` = '63418';
DELETE FROM `creature` WHERE `guid` = '63405';
DELETE FROM `creature_addon` WHERE `guid` = '63405';
DELETE FROM `creature_movement` WHERE `id` = '63405';
DELETE FROM `creature` WHERE `guid` = '63406';
DELETE FROM `creature_addon` WHERE `guid` = '63406';
DELETE FROM `creature_movement` WHERE `id` = '63406';
DELETE FROM `creature` WHERE `guid` = '63439';
DELETE FROM `creature_addon` WHERE `guid` = '63439';
DELETE FROM `creature_movement` WHERE `id` = '63439';
DELETE FROM `creature` WHERE `guid` = '63407';
DELETE FROM `creature_addon` WHERE `guid` = '63407';
DELETE FROM `creature_movement` WHERE `id` = '63407';
DELETE FROM `creature` WHERE `guid` = '63430';
DELETE FROM `creature_addon` WHERE `guid` = '63430';
DELETE FROM `creature_movement` WHERE `id` = '63430';
DELETE FROM `creature` WHERE `guid` = '63427';
DELETE FROM `creature_addon` WHERE `guid` = '63427';
DELETE FROM `creature_movement` WHERE `id` = '63427';
DELETE FROM `creature` WHERE `guid` = '63408';
DELETE FROM `creature_addon` WHERE `guid` = '63408';
DELETE FROM `creature_movement` WHERE `id` = '63408';
UPDATE `creature` SET `spawn_position_x` = '2837.375977', `spawn_position_y` = '5261.737305', `spawn_position_z` = '264.993805', `spawn_orientation` = '2.079771',`position_x` = '2837.375977', `position_y` = '5261.737305', `position_z` = '264.993805', `orientation` = '2.079771' WHERE `guid` = '63417';
UPDATE `creature` SET `spawn_position_x` = '2827.717041', `spawn_position_y` = '5264.547363', `spawn_position_z` = '263.065674', `spawn_orientation` = '3.497415',`position_x` = '2827.717041', `position_y` = '5264.547363', `position_z` = '263.065674', `orientation` = '3.497415' WHERE `guid` = '63438';
UPDATE `creature` SET `spawn_position_x` = '2820.536865', `spawn_position_y` = '5255.969238', `spawn_position_z` = '261.884460', `spawn_orientation` = '3.183255',`position_x` = '2820.536865', `position_y` = '5255.969238', `position_z` = '261.884460', `orientation` = '3.183255' WHERE `guid` = '63422';
UPDATE `creature` SET `spawn_position_x` = '2824.994385', `spawn_position_y` = '5250.874023', `spawn_position_z` = '263.788422', `spawn_orientation` = '2.880877',`position_x` = '2824.994385', `position_y` = '5250.874023', `position_z` = '263.788422', `orientation` = '2.880877' WHERE `guid` = '283350';
UPDATE `creature` SET `spawn_position_x` = '2797.991455', `spawn_position_y` = '5282.291016', `spawn_position_z` = '261.642731', `spawn_orientation` = '3.733034',`position_x` = '2797.991455', `position_y` = '5282.291016', `position_z` = '261.642731', `orientation` = '3.733034' WHERE `guid` = '63367';
UPDATE `creature` SET `spawn_position_x` = '2793.814697', `spawn_position_y` = '5286.823242', `spawn_position_z` = '262.050415', `spawn_orientation` = '3.941165',`position_x` = '2793.814697', `position_y` = '5286.823242', `position_z` = '262.050415', `orientation` = '3.941165' WHERE `guid` = '63441';
UPDATE `creature` SET `spawn_position_x` = '2808.018311', `spawn_position_y` = '5279.179688', `spawn_position_z` = '260.110779', `spawn_orientation` = '6.128499',`position_x` = '2808.018311', `position_y` = '5279.179688', `position_z` = '260.110779', `orientation` = '6.128499' WHERE `guid` = '63442';
UPDATE `creature` SET `spawn_position_x` = '1779.050903', `spawn_position_y` = '5014.470703', `spawn_position_z` = '171.315872', `spawn_orientation` = '3.086700',`position_x` = '1779.050903', `position_y` = '5014.470703', `position_z` = '171.315872', `orientation` = '3.086700' WHERE `guid` = '62886';
UPDATE `creature` SET `spawn_position_x` = '1810.593872', `spawn_position_y` = '5029.559082', `spawn_position_z` = '170.964493', `spawn_orientation` = '0.773700',`position_x` = '1810.593872', `position_y` = '5029.559082', `position_z` = '170.964493', `orientation` = '0.773700' WHERE `guid` = '62882';
UPDATE `creature` SET `spawn_position_x` = '1822.654297', `spawn_position_y` = '5023.732422', `spawn_position_z` = '173.252563', `spawn_orientation` = '5.568556',`position_x` = '1822.654297', `position_y` = '5023.732422', `position_z` = '173.252563', `orientation` = '5.568556' WHERE `guid` = '62837';
DELETE FROM `creature` WHERE `guid` = '62847';
DELETE FROM `creature_addon` WHERE `guid` = '62847';
DELETE FROM `creature_movement` WHERE `id` = '62847';
UPDATE `creature` SET `spawn_position_x` = '1815.931519', `spawn_position_y` = '5013.036133', `spawn_position_z` = '170.489731', `spawn_orientation` = '4.201968',`position_x` = '1815.931519', `position_y` = '5013.036133', `position_z` = '170.489731', `orientation` = '4.201968' WHERE `guid` = '62848';
UPDATE `creature` SET `spawn_position_x` = '1790.170044', `spawn_position_y` = '5012.571777', `spawn_position_z` = '170.543259', `spawn_orientation` = '3.722875',`position_x` = '1790.170044', `position_y` = '5012.571777', `position_z` = '170.543259', `orientation` = '3.722875' WHERE `guid` = '62855';
UPDATE `creature` SET `spawn_position_x` = '1736.514282', `spawn_position_y` = '4662.144043', `spawn_position_z` = '148.968781', `spawn_orientation` = '2.154406',`position_x` = '1736.514282', `position_y` = '4662.144043', `position_z` = '148.968781', `orientation` = '2.154406' WHERE `guid` = '62938';
UPDATE `creature` SET `spawn_position_x` = '1739.946167', `spawn_position_y` = '4698.531738', `spawn_position_z` = '146.872833', `spawn_orientation` = '1.698875',`position_x` = '1739.946167', `position_y` = '4698.531738', `position_z` = '146.872833', `orientation` = '1.698875' WHERE `guid` = '62914';
UPDATE `creature` SET `spawn_position_x` = '2105.412109', `spawn_position_y` = '4744.590332', `spawn_position_z` = '145.818695', `spawn_orientation` = '2.627305',`position_x` = '2105.412109', `position_y` = '4744.590332', `position_z` = '145.818695', `orientation` = '2.627305' WHERE `guid` = '62969';
UPDATE `creature` SET `spawn_position_x` = '2113.098145', `spawn_position_y` = '4746.314453', `spawn_position_z` = '146.428619', `spawn_orientation` = '0.428188',`position_x` = '2113.098145', `position_y` = '4746.314453', `position_z` = '146.428619', `orientation` = '0.428188' WHERE `guid` = '62968';
UPDATE `creature` SET `spawn_position_x` = '2119.833984', `spawn_position_y` = '4752.991699', `spawn_position_z` = '147.207428', `spawn_orientation` = '1.362812',`position_x` = '2119.833984', `position_y` = '4752.991699', `position_z` = '147.207428', `orientation` = '1.362812' WHERE `guid` = '62993';
UPDATE `creature` SET `spawn_position_x` = '1821.540161', `spawn_position_y` = '5603.589355', `spawn_position_z` = '261.047333', `spawn_orientation` = '2.626488',`position_x` = '1821.540161', `position_y` = '5603.589355', `position_z` = '261.047333', `orientation` = '2.626488' WHERE `guid` = '63132';
UPDATE `creature` SET `spawn_position_x` = '1968.923950', `spawn_position_y` = '5303.484375', `spawn_position_z` = '154.077164', `spawn_orientation` = '0.827724',`position_x` = '1968.923950', `position_y` = '5303.484375', `position_z` = '154.077164', `orientation` = '0.827724' WHERE `guid` = '62787';
UPDATE `creature` SET `spawn_position_x` = '2180.827881', `spawn_position_y` = '5491.118652', `spawn_position_z` = '153.578995', `spawn_orientation` = '5.198902',`position_x` = '2180.827881', `position_y` = '5491.118652', `position_z` = '153.578995', `orientation` = '5.198902' WHERE `guid` = '62708';
DELETE FROM `creature` WHERE `guid` = '62736';
DELETE FROM `creature_addon` WHERE `guid` = '62736';
DELETE FROM `creature_movement` WHERE `id` = '62736';
UPDATE `creature` SET `spawn_position_x` = '2950.014648', `spawn_position_y` = '5496.291992', `spawn_position_z` = '144.933777', `spawn_orientation` = '5.902088',`position_x` = '2950.014648', `position_y` = '5496.291992', `position_z` = '144.933777', `orientation` = '5.902088' WHERE `guid` = '62634';
UPDATE `creature` SET `spawn_position_x` = '2968.501953', `spawn_position_y` = '5522.172852', `spawn_position_z` = '144.622223', `spawn_orientation` = '4.013205',`position_x` = '2968.501953', `position_y` = '5522.172852', `position_z` = '144.622223', `orientation` = '4.013205' WHERE `guid` = '63540';
UPDATE `creature` SET `spawn_position_x` = '3041.409424', `spawn_position_y` = '5447.490234', `spawn_position_z` = '149.505157', `spawn_orientation` = '5.396833',`position_x` = '3041.409424', `position_y` = '5447.490234', `position_z` = '149.505157', `orientation` = '5.396833' WHERE `guid` = '62625';
UPDATE `creature` SET `spawn_position_x` = '3067.320068', `spawn_position_y` = '5453.554688', `spawn_position_z` = '149.753082', `spawn_orientation` = '3.802475',`position_x` = '3067.320068', `position_y` = '5453.554688', `position_z` = '149.753082', `orientation` = '3.802475' WHERE `guid` = '63559';
UPDATE `creature` SET `spawn_position_x` = '3031.723877', `spawn_position_y` = '5538.555176', `spawn_position_z` = '148.192108', `spawn_orientation` = '1.120082',`position_x` = '3031.723877', `position_y` = '5538.555176', `position_z` = '148.192108', `orientation` = '1.120082' WHERE `guid` = '62644';
UPDATE `creature` SET `spawn_position_x` = '3021.586914', `spawn_position_y` = '5556.594238', `spawn_position_z` = '149.868866', `spawn_orientation` = '5.133468',`position_x` = '3021.586914', `position_y` = '5556.594238', `position_z` = '149.868866', `orientation` = '5.133468' WHERE `guid` = '62623';
UPDATE `creature` SET `spawn_position_x` = '3000.612549', `spawn_position_y` = '5490.907715', `spawn_position_z` = '143.199814', `spawn_orientation` = '3.661031',`position_x` = '3000.612549', `position_y` = '5490.907715', `position_z` = '143.199814', `orientation` = '3.661031' WHERE `guid` = '62368';
UPDATE `creature` SET `spawn_position_x` = '2986.487305', `spawn_position_y` = '5461.564453', `spawn_position_z` = '143.203003', `spawn_orientation` = '1.654339',`position_x` = '2986.487305', `position_y` = '5461.564453', `position_z` = '143.203003', `orientation` = '1.654339' WHERE `guid` = '62636';
UPDATE `creature` SET `spawn_position_x` = '3496.277344', `spawn_position_y` = '6760.825684', `spawn_position_z` = '155.927811', `spawn_orientation` = '3.389562',`position_x` = '3496.277344', `position_y` = '6760.825684', `position_z` = '155.927811', `orientation` = '3.389562' WHERE `guid` = '62176';
UPDATE `creature` SET `spawn_position_x` = '3164.906982', `spawn_position_y` = '7062.212891', `spawn_position_z` = '162.709961', `spawn_orientation` = '4.654845',`position_x` = '3164.906982', `position_y` = '7062.212891', `position_z` = '162.709961', `orientation` = '4.654845' WHERE `guid` = '62097';
UPDATE `creature` SET `spawn_position_x` = '3173.613037', `spawn_position_y` = '7067.010254', `spawn_position_z` = '163.041840', `spawn_orientation` = '0.507940',`position_x` = '3173.613037', `position_y` = '7067.010254', `position_z` = '163.041840', `orientation` = '0.507940' WHERE `guid` = '62109';
UPDATE `creature` SET `spawn_position_x` = '3149.954590', `spawn_position_y` = '7064.878418', `spawn_position_z` = '160.543686', `spawn_orientation` = '3.378574',`position_x` = '3149.954590', `position_y` = '7064.878418', `position_z` = '160.543686', `orientation` = '3.378574' WHERE `guid` = '62114';
UPDATE `creature` SET `spawn_position_x` = '3149.881836', `spawn_position_y` = '7101.356934', `spawn_position_z` = '170.877869', `spawn_orientation` = '4.427081',`position_x` = '3149.881836', `position_y` = '7101.356934', `position_z` = '170.877869', `orientation` = '4.427081' WHERE `guid` = '62116';
UPDATE `creature` SET `spawn_position_x` = '3146.943848', `spawn_position_y` = '7097.322266', `spawn_position_z` = '170.543198', `spawn_orientation` = '4.686261',`position_x` = '3146.943848', `position_y` = '7097.322266', `position_z` = '170.543198', `orientation` = '4.686261' WHERE `guid` = '62025';
UPDATE `creature` SET `spawn_position_x` = '3149.282471', `spawn_position_y` = '7091.112305', `spawn_position_z` = '169.648514', `spawn_orientation` = '5.412753',`position_x` = '3149.282471', `position_y` = '7091.112305', `position_z` = '169.648514', `orientation` = '5.412753' WHERE `guid` = '62074';
UPDATE `creature` SET `spawn_position_x` = '3204.010498', `spawn_position_y` = '7108.886719', `spawn_position_z` = '173.851105', `spawn_orientation` = '6.096265',`position_x` = '3204.010498', `position_y` = '7108.886719', `position_z` = '173.851105', `orientation` = '6.096265' WHERE `guid` = '62113';
UPDATE `creature` SET `spawn_position_x` = '3202.434326', `spawn_position_y` = '7117.036133', `spawn_position_z` = '173.855377', `spawn_orientation` = '0.398202',`position_x` = '3202.434326', `position_y` = '7117.036133', `position_z` = '173.855377', `orientation` = '0.398202' WHERE `guid` = '62022';
UPDATE `creature` SET `spawn_position_x` = '3201.187012', `spawn_position_y` = '7128.411133', `spawn_position_z` = '174.207230', `spawn_orientation` = '1.623423',`position_x` = '3201.187012', `position_y` = '7128.411133', `position_z` = '174.207230', `orientation` = '1.623423' WHERE `guid` = '62096';
UPDATE `creature` SET `spawn_position_x` = '3113.790039', `spawn_position_y` = '7125.843262', `spawn_position_z` = '152.837616', `spawn_orientation` = '5.552283',`position_x` = '3113.790039', `position_y` = '7125.843262', `position_z` = '152.837616', `orientation` = '5.552283' WHERE `guid` = '62071';
UPDATE `creature` SET `spawn_position_x` = '3109.680664', `spawn_position_y` = '7130.990234', `spawn_position_z` = '152.394363', `spawn_orientation` = '2.104385',`position_x` = '3109.680664', `position_y` = '7130.990234', `position_z` = '152.394363', `orientation` = '2.104385' WHERE `guid` = '62054';
UPDATE `creature` SET `spawn_position_x` = '3222.036133', `spawn_position_y` = '7136.469727', `spawn_position_z` = '172.547668', `spawn_orientation` = '0.678801',`position_x` = '3222.036133', `position_y` = '7136.469727', `position_z` = '172.547668', `orientation` = '0.678801' WHERE `guid` = '62053';
UPDATE `creature` SET `spawn_position_x` = '3225.918945', `spawn_position_y` = '7129.097168', `spawn_position_z` = '173.350220', `spawn_orientation` = '5.992020',`position_x` = '3225.918945', `position_y` = '7129.097168', `position_z` = '173.350220', `orientation` = '5.992020' WHERE `guid` = '62122';
UPDATE `creature` SET `spawn_position_x` = '3227.314941', `spawn_position_y` = '7120.977539', `spawn_position_z` = '173.139374', `spawn_orientation` = '5.901700',`position_x` = '3227.314941', `position_y` = '7120.977539', `position_z` = '173.139374', `orientation` = '5.901700' WHERE `guid` = '62093';
UPDATE `creature` SET `spawn_position_x` = '3243.882324', `spawn_position_y` = '7120.094238', `spawn_position_z` = '172.161026', `spawn_orientation` = '0.034775',`position_x` = '3243.882324', `position_y` = '7120.094238', `position_z` = '172.161026', `orientation` = '0.034775' WHERE `guid` = '62129';
UPDATE `creature` SET `spawn_position_x` = '3235.612793', `spawn_position_y` = '7108.974121', `spawn_position_z` = '173.172470', `spawn_orientation` = '4.240583',`position_x` = '3235.612793', `position_y` = '7108.974121', `position_z` = '173.172470', `orientation` = '4.240583' WHERE `guid` = '62125';
UPDATE `creature` SET `spawn_position_x` = '3155.473877', `spawn_position_y` = '7060.077148', `spawn_position_z` = '161.152588', `spawn_orientation` = '6.018770',`position_x` = '3155.473877', `position_y` = '7060.077148', `position_z` = '161.152588', `orientation` = '6.018770' WHERE `guid` = '62058';
UPDATE `creature` SET `spawn_position_x` = '3134.632813', `spawn_position_y` = '7089.510742', `spawn_position_z` = '154.794159', `spawn_orientation` = '2.033778',`position_x` = '3134.632813', `position_y` = '7089.510742', `position_z` = '154.794159', `orientation` = '2.033778' WHERE `guid` = '62035';
UPDATE `creature` SET `spawn_position_x` = '3127.884277', `spawn_position_y` = '7104.961426', `spawn_position_z` = '154.804459', `spawn_orientation` = '0.010157',`position_x` = '3127.884277', `position_y` = '7104.961426', `position_z` = '154.804459', `orientation` = '0.010157' WHERE `guid` = '62023';
UPDATE `creature` SET `spawn_position_x` = '3234.201660', `spawn_position_y` = '7084.783691', `spawn_position_z` = '172.358398', `spawn_orientation` = '3.206238',`position_x` = '3234.201660', `position_y` = '7084.783691', `position_z` = '172.358398', `orientation` = '3.206238' WHERE `guid` = '62021';
UPDATE `creature` SET `spawn_position_x` = '3092.720459', `spawn_position_y` = '7131.926758', `spawn_position_z` = '150.064209', `spawn_orientation` = '6.066414',`position_x` = '3092.720459', `position_y` = '7131.926758', `position_z` = '150.064209', `orientation` = '6.066414' WHERE `guid` = '62049';
UPDATE `creature` SET `spawn_position_x` = '3257.646729', `spawn_position_y` = '7164.179688', `spawn_position_z` = '169.883148', `spawn_orientation` = '4.201194',`position_x` = '3257.646729', `position_y` = '7164.179688', `position_z` = '169.883148', `orientation` = '4.201194' WHERE `guid` = '62131';
UPDATE `creature` SET `spawn_position_x` = '3352.336182', `spawn_position_y` = '6594.146484', `spawn_position_z` = '155.108734', `spawn_orientation` = '4.148943',`position_x` = '3352.336182', `position_y` = '6594.146484', `position_z` = '155.108734', `orientation` = '4.148943' WHERE `guid` = '61981';
UPDATE `creature` SET `spawn_position_x` = '-603.693481', `spawn_position_y` = '4821.735840', `spawn_position_z` = '36.693790', `spawn_orientation` = '1.092979',`position_x` = '-603.693481', `position_y` = '4821.735840', `position_z` = '36.693790', `orientation` = '1.092979' WHERE `guid` = '61894';
UPDATE `creature` SET `spawn_position_x` = '-588.779968', `spawn_position_y` = '4806.000488', `spawn_position_z` = '35.029762', `spawn_orientation` = '6.147016',`position_x` = '-588.779968', `position_y` = '4806.000488', `position_z` = '35.029762', `orientation` = '6.147016' WHERE `guid` = '61896';
UPDATE `creature` SET `spawn_position_x` = '243.660995', `spawn_position_y` = '3888.067627', `spawn_position_z` = '83.580559', `spawn_orientation` = '3.117701',`position_x` = '243.660995', `position_y` = '3888.067627', `position_z` = '83.580559', `orientation` = '3.117701' WHERE `guid` = '61329';
UPDATE `creature` SET `spawn_position_x` = '237.683136', `spawn_position_y` = '3908.377686', `spawn_position_z` = '80.930794', `spawn_orientation` = '2.147735',`position_x` = '237.683136', `position_y` = '3908.377686', `position_z` = '80.930794', `orientation` = '2.147735' WHERE `guid` = '61333';
UPDATE `creature` SET `spawn_position_x` = '269.032562', `spawn_position_y` = '3878.576172', `spawn_position_z` = '81.950661', `spawn_orientation` = '2.303607',`position_x` = '269.032562', `position_y` = '3878.576172', `position_z` = '81.950661', `orientation` = '2.303607' WHERE `guid` = '61246';
UPDATE `creature` SET `spawn_position_x` = '-652.106689', `spawn_position_y` = '3704.316406', `spawn_position_z` = '28.996403', `spawn_orientation` = '2.031348',`position_x` = '-652.106689', `position_y` = '3704.316406', `position_z` = '28.996403', `orientation` = '2.031348' WHERE `guid` = '61701';
UPDATE `creature` SET `spawn_position_x` = '-655.908447', `spawn_position_y` = '3723.816406', `spawn_position_z` = '28.991646', `spawn_orientation` = '3.818130',`position_x` = '-655.908447', `position_y` = '3723.816406', `position_z` = '28.991646', `orientation` = '3.818130' WHERE `guid` = '61151';
UPDATE `creature` SET `spawn_position_x` = '-556.322998', `spawn_position_y` = '3759.104248', `spawn_position_z` = '28.995340', `spawn_orientation` = '6.139518',`position_x` = '-556.322998', `position_y` = '3759.104248', `position_z` = '28.995340', `orientation` = '6.139518' WHERE `guid` = '61712';
UPDATE `creature` SET `spawn_position_x` = '-8387.030273', `spawn_position_y` = '286.869904', `spawn_position_z` = '120.885002', `spawn_orientation` = '3.619697',`position_x` = '-8387.030273', `position_y` = '286.869904', `position_z` = '120.885002', `orientation` = '3.619697' WHERE `guid` = '102672';
UPDATE `creature` SET `spawn_position_x` = '-1816.081543', `spawn_position_y` = '5446.823730', `spawn_position_z` = '-12.428179', `spawn_orientation` = '4.639090',`position_x` = '-1816.081543', `position_y` = '5446.823730', `position_z` = '-12.428179', `orientation` = '4.639090' WHERE `guid` = '68213';
UPDATE `creature` SET `spawn_position_x` = '-945.263000', `spawn_position_y` = '1926.293335', `spawn_position_z` = '69.301468', `spawn_orientation` = '3.205693',`position_x` = '-945.263000', `position_y` = '1926.293335', `position_z` = '69.301468', `orientation` = '3.205693' WHERE `guid` = '60430';
UPDATE `creature` SET `spawn_position_x` = '-945.996704', `spawn_position_y` = '1946.180908', `spawn_position_z` = '66.939560', `spawn_orientation` = '1.952984',`position_x` = '-945.996704', `position_y` = '1946.180908', `position_z` = '66.939560', `orientation` = '1.952984' WHERE `guid` = '60433';
UPDATE `creature` SET `spawn_position_x` = '-959.494934', `spawn_position_y` = '1937.447754', `spawn_position_z` = '68.253685', `spawn_orientation` = '5.269708',`position_x` = '-959.494934', `position_y` = '1937.447754', `position_z` = '68.253685', `orientation` = '5.269708' WHERE `guid` = '60432';
UPDATE `creature` SET `spawn_position_x` = '-957.805725', `spawn_position_y` = '1909.146484', `spawn_position_z` = '73.762779', `spawn_orientation` = '0.957870',`position_x` = '-957.805725', `position_y` = '1909.146484', `position_z` = '73.762779', `orientation` = '0.957870' WHERE `guid` = '60431';
UPDATE `creature` SET `spawn_position_x` = '-958.174011', `spawn_position_y` = '1920.930908', `spawn_position_z` = '70.249527', `spawn_orientation` = '0.313843',`position_x` = '-958.174011', `position_y` = '1920.930908', `position_z` = '70.249527', `orientation` = '0.313843' WHERE `guid` = '60430';
UPDATE `creature` SET `spawn_position_x` = '-915.209656', `spawn_position_y` = '1972.822998', `spawn_position_z` = '66.938156', `spawn_orientation` = '5.650019',`position_x` = '-915.209656', `position_y` = '1972.822998', `position_z` = '66.938156', `orientation` = '5.650019' WHERE `guid` = '60428';
UPDATE `creature` SET `spawn_position_x` = '172.251663', `spawn_position_y` = '2271.689697', `spawn_position_z` = '48.305492', `spawn_orientation` = '1.726396',`position_x` = '172.251663', `position_y` = '2271.689697', `position_z` = '48.305492', `orientation` = '1.726396' WHERE `guid` = '60223';
UPDATE `creature` SET `spawn_position_x` = '182.768616', `spawn_position_y` = '2290.248291', `spawn_position_z` = '49.076424', `spawn_orientation` = '3.674185',`position_x` = '182.768616', `position_y` = '2290.248291', `position_z` = '49.076424', `orientation` = '3.674185' WHERE `guid` = '59835';
UPDATE `creature` SET `spawn_position_x` = '2427.852783', `spawn_position_y` = '2872.688477', `spawn_position_z` = '131.413498', `spawn_orientation` = '0.610382',`position_x` = '2427.852783', `position_y` = '2872.688477', `position_z` = '131.413498', `orientation` = '0.610382' WHERE `guid` = '59409';
UPDATE `creature` SET `spawn_position_x` = '2431.793213', `spawn_position_y` = '2586.859375', `spawn_position_z` = '134.610229', `spawn_orientation` = '3.316561',`position_x` = '2431.793213', `position_y` = '2586.859375', `position_z` = '134.610229', `orientation` = '3.316561' WHERE `guid` = '59396';
UPDATE `creature` SET `spawn_position_x` = '2437.365967', `spawn_position_y` = '2609.910400', `spawn_position_z` = '134.365829', `spawn_orientation` = '1.859647',`position_x` = '2437.365967', `position_y` = '2609.910400', `position_z` = '134.365829', `orientation` = '1.859647' WHERE `guid` = '59423';
UPDATE `creature` SET `spawn_position_x` = '2563.878174', `spawn_position_y` = '2495.250244', `spawn_position_z` = '118.782921', `spawn_orientation` = '5.077816',`position_x` = '2563.878174', `position_y` = '2495.250244', `position_z` = '118.782921', `orientation` = '5.077816' WHERE `guid` = '59391';
UPDATE `creature` SET `spawn_position_x` = '2547.272705', `spawn_position_y` = '2470.500000', `spawn_position_z` = '111.292336', `spawn_orientation` = '5.592251',`position_x` = '2547.272705', `position_y` = '2470.500000', `position_z` = '111.292336', `orientation` = '5.592251' WHERE `guid` = '59356';
UPDATE `creature` SET `spawn_position_x` = '2577.219482', `spawn_position_y` = '2430.972412', `spawn_position_z` = '104.860931', `spawn_orientation` = '6.220569',`position_x` = '2577.219482', `position_y` = '2430.972412', `position_z` = '104.860931', `orientation` = '6.220569' WHERE `guid` = '59079';
UPDATE `creature` SET `spawn_position_x` = '2503.185791', `spawn_position_y` = '2298.160889', `spawn_position_z` = '120.779961', `spawn_orientation` = '3.680442',`position_x` = '2503.185791', `position_y` = '2298.160889', `position_z` = '120.779961', `orientation` = '3.680442' WHERE `guid` = '59332';
UPDATE `creature` SET `spawn_position_x` = '2509.898682', `spawn_position_y` = '2299.588379', `spawn_position_z` = '120.765038', `spawn_orientation` = '4.764291',`position_x` = '2509.898682', `position_y` = '2299.588379', `position_z` = '120.765038', `orientation` = '4.764291' WHERE `guid` = '59116';
UPDATE `creature` SET `spawn_position_x` = '2514.893799', `spawn_position_y` = '2299.505615', `spawn_position_z` = '120.619011', `spawn_orientation` = '4.658263',`position_x` = '2514.893799', `position_y` = '2299.505615', `position_z` = '120.619011', `orientation` = '4.658263' WHERE `guid` = '59113';
UPDATE `creature` SET `spawn_position_x` = '2507.907471', `spawn_position_y` = '2306.586914', `spawn_position_z` = '121.859901', `spawn_orientation` = '2.372754',`position_x` = '2507.907471', `position_y` = '2306.586914', `position_z` = '121.859901', `orientation` = '2.372754' WHERE `guid` = '59354';
UPDATE `creature` SET `spawn_position_x` = '2503.369141', `spawn_position_y` = '2311.801758', `spawn_position_z` = '123.298042', `spawn_orientation` = '5.223751',`position_x` = '2503.369141', `position_y` = '2311.801758', `position_z` = '123.298042', `orientation` = '5.223751' WHERE `guid` = '59331';
UPDATE `creature` SET `spawn_position_x` = '2495.962158', `spawn_position_y` = '2305.795898', `spawn_position_z` = '122.582764', `spawn_orientation` = '4.469769',`position_x` = '2495.962158', `position_y` = '2305.795898', `position_z` = '122.582764', `orientation` = '4.469769' WHERE `guid` = '59121';
UPDATE `creature` SET `spawn_position_x` = '2489.474854', `spawn_position_y` = '2306.837158', `spawn_position_z` = '123.143585', `spawn_orientation` = '4.736803',`position_x` = '2489.474854', `position_y` = '2306.837158', `position_z` = '123.143585', `orientation` = '4.736803' WHERE `guid` = '59123';
UPDATE `creature` SET `spawn_position_x` = '2481.709229', `spawn_position_y` = '2306.209473', `spawn_position_z` = '123.369598', `spawn_orientation` = '4.968495',`position_x` = '2481.709229', `position_y` = '2306.209473', `position_z` = '123.369598', `orientation` = '4.968495' WHERE `guid` = '59111';
UPDATE `creature` SET `spawn_position_x` = '2503.815430', `spawn_position_y` = '2268.424072', `spawn_position_z` = '119.212959', `spawn_orientation` = '4.493330',`position_x` = '2503.815430', `position_y` = '2268.424072', `position_z` = '119.212959', `orientation` = '4.493330' WHERE `guid` = '59116';
UPDATE `creature` SET `spawn_position_x` = '2139.024414', `spawn_position_y` = '2213.317871', `spawn_position_z` = '73.955910', `spawn_orientation` = '0.211113',`position_x` = '2139.024414', `position_y` = '2213.317871', `position_z` = '73.955910', `orientation` = '0.211113' WHERE `guid` = '59241';
UPDATE `creature` SET `spawn_position_x` = '2143.851563', `spawn_position_y` = '2208.746094', `spawn_position_z` = '73.507050', `spawn_orientation` = '0.749110',`position_x` = '2143.851563', `position_y` = '2208.746094', `position_z` = '73.507050', `orientation` = '0.749110' WHERE `guid` = '59274';
UPDATE `creature` SET `spawn_position_x` = '2155.462402', `spawn_position_y` = '2221.375244', `spawn_position_z` = '73.389694', `spawn_orientation` = '3.705995',`position_x` = '2155.462402', `position_y` = '2221.375244', `position_z` = '73.389694', `orientation` = '3.705995' WHERE `guid` = '59281';
UPDATE `creature` SET `spawn_position_x` = '2300.610107', `spawn_position_y` = '2150.297607', `spawn_position_z` = '89.043404', `spawn_orientation` = '5.515872',`position_x` = '2300.610107', `position_y` = '2150.297607', `position_z` = '89.043404', `orientation` = '5.515872' WHERE `guid` = '59279';
UPDATE `creature` SET `spawn_position_x` = '2287.324951', `spawn_position_y` = '2146.718506', `spawn_position_z` = '86.533783', `spawn_orientation` = '3.595575',`position_x` = '2287.324951', `position_y` = '2146.718506', `position_z` = '86.533783', `orientation` = '3.595575' WHERE `guid` = '59263';
UPDATE `creature` SET `spawn_position_x` = '2107.811523', `spawn_position_y` = '2209.030029', `spawn_position_z` = '74.148399', `spawn_orientation` = '5.780129',`position_x` = '2107.811523', `position_y` = '2209.030029', `position_z` = '74.148399', `orientation` = '5.780129' WHERE `guid` = '59233';
UPDATE `creature` SET `spawn_position_x` = '2432.458008', `spawn_position_y` = '2128.195313', `spawn_position_z` = '88.052002', `spawn_orientation` = '3.184049',`position_x` = '2432.458008', `position_y` = '2128.195313', `position_z` = '88.052002', `orientation` = '3.184049' WHERE `guid` = '59140';
UPDATE `creature` SET `spawn_position_x` = '2558.731201', `spawn_position_y` = '2476.634277', `spawn_position_z` = '115.272102', `spawn_orientation` = '6.108540',`position_x` = '2558.731201', `position_y` = '2476.634277', `position_z` = '115.272102', `orientation` = '6.108540' WHERE `guid` = '59387';
UPDATE `creature` SET `spawn_position_x` = '2590.158936', `spawn_position_y` = '2477.638916', `spawn_position_z` = '112.671738', `spawn_orientation` = '6.167993',`position_x` = '2590.158936', `position_y` = '2477.638916', `position_z` = '112.671738', `orientation` = '6.167993' WHERE `guid` = '59075';
UPDATE `creature` SET `spawn_position_x` = '3038.510742', `spawn_position_y` = '2317.231201', `spawn_position_z` = '138.665298', `spawn_orientation` = '2.273499',`position_x` = '3038.510742', `position_y` = '2317.231201', `position_z` = '138.665298', `orientation` = '2.273499' WHERE `guid` = '59024';
UPDATE `creature` SET `spawn_position_x` = '3053.986084', `spawn_position_y` = '2337.029541', `spawn_position_z` = '138.657211', `spawn_orientation` = '0.985446',`position_x` = '3053.986084', `position_y` = '2337.029541', `position_z` = '138.657211', `orientation` = '0.985446' WHERE `guid` = '59041';
UPDATE `creature` SET `spawn_position_x` = '2996.596924', `spawn_position_y` = '2381.947754', `spawn_position_z` = '138.293610', `spawn_orientation` = '4.267528',`position_x` = '2996.596924', `position_y` = '2381.947754', `position_z` = '138.293610', `orientation` = '4.267528' WHERE `guid` = '59034';
UPDATE `creature` SET `spawn_position_x` = '2978.044922', `spawn_position_y` = '2356.876953', `spawn_position_z` = '152.397110', `spawn_orientation` = '4.850270',`position_x` = '2978.044922', `position_y` = '2356.876953', `position_z` = '152.397110', `orientation` = '4.850270' WHERE `guid` = '59016';
UPDATE `creature` SET `spawn_position_x` = '2981.666992', `spawn_position_y` = '2342.718262', `spawn_position_z` = '156.140625', `spawn_orientation` = '4.850269',`position_x` = '2981.666992', `position_y` = '2342.718262', `position_z` = '156.140625', `orientation` = '4.850269' WHERE `guid` = '59038';
UPDATE `creature` SET `spawn_position_x` = '2988.580811', `spawn_position_y` = '2335.887695', `spawn_position_z` = '159.610367', `spawn_orientation` = '4.669628',`position_x` = '2988.580811', `position_y` = '2335.887695', `position_z` = '159.610367', `orientation` = '4.669628' WHERE `guid` = '59040';
UPDATE `creature` SET `spawn_position_x` = '3011.195068', `spawn_position_y` = '3654.585693', `spawn_position_z` = '129.923813', `spawn_orientation` = '4.120724',`position_x` = '3011.195068', `position_y` = '3654.585693', `position_z` = '129.923813', `orientation` = '4.120724' WHERE `guid` = '59552';
UPDATE `creature` SET `spawn_position_x` = '3015.571045', `spawn_position_y` = '3655.489990', `spawn_position_z` = '129.138474', `spawn_orientation` = '0.013089',`position_x` = '3015.571045', `position_y` = '3655.489990', `position_z` = '129.138474', `orientation` = '0.013089' WHERE `guid` = '59553';
UPDATE `creature` SET `spawn_position_x` = '3212.647949', `spawn_position_y` = '3533.083252', `spawn_position_z` = '124.825394', `spawn_orientation` = '3.672178',`position_x` = '3212.647949', `position_y` = '3533.083252', `position_z` = '124.825394', `orientation` = '3.672178' WHERE `guid` = '58626';
UPDATE `creature` SET `spawn_position_x` = '3215.107910', `spawn_position_y` = '3525.951660', `spawn_position_z` = '122.397339', `spawn_orientation` = '4.995574',`position_x` = '3215.107910', `position_y` = '3525.951660', `position_z` = '122.397339', `orientation` = '4.995574' WHERE `guid` = '58622';
UPDATE `creature` SET `spawn_position_x` = '3229.270752', `spawn_position_y` = '3526.281250', `spawn_position_z` = '122.341194', `spawn_orientation` = '5.985176',`position_x` = '3229.270752', `position_y` = '3526.281250', `position_z` = '122.341194', `orientation` = '5.985176' WHERE `guid` = '58617';
UPDATE `creature` SET `spawn_position_x` = '3241.790283', `spawn_position_y` = '3530.685547', `spawn_position_z` = '121.168259', `spawn_orientation` = '5.368641',`position_x` = '3241.790283', `position_y` = '3530.685547', `position_z` = '121.168259', `orientation` = '5.368641' WHERE `guid` = '87547';
UPDATE `creature` SET `spawn_position_x` = '3220.113770', `spawn_position_y` = '3563.024658', `spawn_position_z` = '126.065620', `spawn_orientation` = '1.901108',`position_x` = '3220.113770', `position_y` = '3563.024658', `position_z` = '126.065620', `orientation` = '1.901108' WHERE `guid` = '58624';
UPDATE `creature` SET `spawn_position_x` = '3217.168701', `spawn_position_y` = '3555.095459', `spawn_position_z` = '125.826431', `spawn_orientation` = '2.965322',`position_x` = '3217.168701', `position_y` = '3555.095459', `position_z` = '125.826431', `orientation` = '2.965322' WHERE `guid` = '58629';
UPDATE `creature` SET `spawn_position_x` = '3212.822021', `spawn_position_y` = '3548.140381', `spawn_position_z` = '125.876625', `spawn_orientation` = '3.028152',`position_x` = '3212.822021', `position_y` = '3548.140381', `position_z` = '125.876625', `orientation` = '3.028152' WHERE `guid` = '58623';
UPDATE `creature` SET `spawn_position_x` = '3212.303711', `spawn_position_y` = '3541.584473', `spawn_position_z` = '125.087486', `spawn_orientation` = '2.933905',`position_x` = '3212.303711', `position_y` = '3541.584473', `position_z` = '125.087486', `orientation` = '2.933905' WHERE `guid` = '58632';
UPDATE `creature` SET `spawn_position_x` = '3203.471680', `spawn_position_y` = '3545.746826', `spawn_position_z` = '128.714111', `spawn_orientation` = '6.181525',`position_x` = '3203.471680', `position_y` = '3545.746826', `position_z` = '128.714111', `orientation` = '6.181525' WHERE `guid` = '58628';
UPDATE `creature` SET `spawn_position_x` = '3204.558105', `spawn_position_y` = '3554.179932', `spawn_position_z` = '128.657227', `spawn_orientation` = '5.749557',`position_x` = '3204.558105', `position_y` = '3554.179932', `position_z` = '128.657227', `orientation` = '5.749557' WHERE `guid` = '58625';
UPDATE `creature` SET `spawn_position_x` = '3208.421875', `spawn_position_y` = '3560.604004', `spawn_position_z` = '127.747162', `spawn_orientation` = '5.722069',`position_x` = '3208.421875', `position_y` = '3560.604004', `position_z` = '127.747162', `orientation` = '5.722069' WHERE `guid` = '58630';
UPDATE `creature` SET `spawn_position_x` = '-1235.729858', `spawn_position_y` = '2738.065430', `spawn_position_z` = '-15.093173', `spawn_orientation` = '5.050540',`position_x` = '-1235.729858', `position_y` = '2738.065430', `position_z` = '-15.093173', `orientation` = '5.050540' WHERE `guid` = '58472';
UPDATE `creature` SET `spawn_position_x` = '-1268.114014', `spawn_position_y` = '2747.746338', `spawn_position_z` = '-21.767342', `spawn_orientation` = '2.385273',`position_x` = '-1268.114014', `position_y` = '2747.746338', `position_z` = '-21.767342', `orientation` = '2.385273' WHERE `guid` = '58486';
UPDATE `creature` SET `spawn_position_x` = '-1267.016968', `spawn_position_y` = '2752.098633', `spawn_position_z` = '-22.611460', `spawn_orientation` = '2.416689',`position_x` = '-1267.016968', `position_y` = '2752.098633', `position_z` = '-22.611460', `orientation` = '2.416689' WHERE `guid` = '58485';
UPDATE `creature` SET `spawn_position_x` = '-1316.213501', `spawn_position_y` = '2763.737793', `spawn_position_z` = '-27.164286', `spawn_orientation` = '4.216714',`position_x` = '-1316.213501', `position_y` = '2763.737793', `position_z` = '-27.164286', `orientation` = '4.216714' WHERE `guid` = '58446';
UPDATE `creature` SET `spawn_position_x` = '-1303.224121', `spawn_position_y` = '2765.278320', `spawn_position_z` = '-26.986261', `spawn_orientation` = '6.015278',`position_x` = '-1303.224121', `position_y` = '2765.278320', `position_z` = '-26.986261', `orientation` = '6.015278' WHERE `guid` = '58444';
UPDATE `creature` SET `spawn_position_x` = '-1306.859009', `spawn_position_y` = '2762.124512', `spawn_position_z` = '-26.978437', `spawn_orientation` = '1.833032',`position_x` = '-1306.859009', `position_y` = '2762.124512', `position_z` = '-26.978437', `orientation` = '1.833032' WHERE `guid` = '58445';
UPDATE `creature` SET `spawn_position_x` = '-1353.757690', `spawn_position_y` = '2758.097656', `spawn_position_z` = '-32.170044', `spawn_orientation` = '2.497520',`position_x` = '-1353.757690', `position_y` = '2758.097656', `position_z` = '-32.170044', `orientation` = '2.497520' WHERE `guid` = '58437';
UPDATE `creature` SET `spawn_position_x` = '-1369.542603', `spawn_position_y` = '2764.354736', `spawn_position_z` = '-40.523087', `spawn_orientation` = '5.914787',`position_x` = '-1369.542603', `position_y` = '2764.354736', `position_z` = '-40.523087', `orientation` = '5.914787' WHERE `guid` = '58436';
UPDATE `creature` SET `spawn_position_x` = '-1261.464111', `spawn_position_y` = '2708.154053', `spawn_position_z` = '-8.105718', `spawn_orientation` = '0.447577',`position_x` = '-1261.464111', `position_y` = '2708.154053', `position_z` = '-8.105718', `orientation` = '0.447577' WHERE `guid` = '58424';
UPDATE `creature` SET `spawn_position_x` = '-1270.995117', `spawn_position_y` = '2707.268066', `spawn_position_z` = '-8.352066', `spawn_orientation` = '1.668871',`position_x` = '-1270.995117', `position_y` = '2707.268066', `position_z` = '-8.352066', `orientation` = '1.668871' WHERE `guid` = '58455';
UPDATE `creature` SET `spawn_position_x` = '-1285.857422', `spawn_position_y` = '2714.304199', `spawn_position_z` = '-12.900892', `spawn_orientation` = '0.184469',`position_x` = '-1285.857422', `position_y` = '2714.304199', `position_z` = '-12.900892', `orientation` = '0.184469' WHERE `guid` = '58457';
UPDATE `creature` SET `spawn_position_x` = '-1283.637939', `spawn_position_y` = '2723.467041', `spawn_position_z` = '-16.229334', `spawn_orientation` = '3.506702',`position_x` = '-1283.637939', `position_y` = '2723.467041', `position_z` = '-16.229334', `orientation` = '3.506702' WHERE `guid` = '58482';
UPDATE `creature` SET `spawn_position_x` = '-1258.467896', `spawn_position_y` = '2721.129395', `spawn_position_z` = '-12.693962', `spawn_orientation` = '6.122078',`position_x` = '-1258.467896', `position_y` = '2721.129395', `position_z` = '-12.693962', `orientation` = '6.122078' WHERE `guid` = '58479';
UPDATE `creature` SET `spawn_position_x` = '-1424.034912', `spawn_position_y` = '2778.324219', `spawn_position_z` = '-49.206642', `spawn_orientation` = '2.447112',`position_x` = '-1424.034912', `position_y` = '2778.324219', `position_z` = '-49.206642', `orientation` = '2.447112' WHERE `guid` = '58419';
UPDATE `creature` SET `spawn_position_x` = '-1696.305908', `spawn_position_y` = '3803.775391', `spawn_position_z` = '41.140118', `spawn_orientation` = '4.912621',`position_x` = '-1696.305908', `position_y` = '3803.775391', `position_z` = '41.140118', `orientation` = '4.912621' WHERE `guid` = '58326';
UPDATE `creature` SET `spawn_position_x` = '-1609.033447', `spawn_position_y` = '3694.432617', `spawn_position_z` = '31.230963', `spawn_orientation` = '2.903186',`position_x` = '-1609.033447', `position_y` = '3694.432617', `position_z` = '31.230963', `orientation` = '2.903186' WHERE `guid` = '58340';
UPDATE `creature` SET `spawn_position_x` = '-1530.539307', `spawn_position_y` = '3618.335449', `spawn_position_z` = '39.988411', `spawn_orientation` = '3.459659',`position_x` = '-1530.539307', `position_y` = '3618.335449', `position_z` = '39.988411', `orientation` = '3.459659' WHERE `guid` = '58348';
UPDATE `creature` SET `spawn_position_x` = '-725.995789', `spawn_position_y` = '2729.741699', `spawn_position_z` = '95.379829', `spawn_orientation` = '4.006928',`position_x` = '-725.995789', `position_y` = '2729.741699', `position_z` = '95.379829', `orientation` = '4.006928' WHERE `guid` = '58555';
UPDATE `creature` SET `spawn_position_x` = '7178.122070', `spawn_position_y` = '-7082.134766', `spawn_position_z` = '57.100216', `spawn_orientation` = '2.278960',`position_x` = '7178.122070', `position_y` = '-7082.134766', `position_z` = '57.100216', `orientation` = '2.278960' WHERE `guid` = '57244';
UPDATE `creature` SET `spawn_position_x` = '-2539.237549', `spawn_position_y` = '-12208.229492', `spawn_position_z` = '27.921366', `spawn_orientation` = '2.007568',`position_x` = '-2539.237549', `position_y` = '-12208.229492', `position_z` = '27.921366', `orientation` = '2.007568' WHERE `guid` = '56458';
UPDATE `creature` SET `spawn_position_x` = '-2521.174072', `spawn_position_y` = '-12197.931641', `spawn_position_z` = '28.085581', `spawn_orientation` = '1.837834',`position_x` = '-2521.174072', `position_y` = '-12197.931641', `position_z` = '28.085581', `orientation` = '1.837834' WHERE `guid` = '70960';
UPDATE `creature` SET `spawn_position_x` = '-2515.664063', `spawn_position_y` = '-12299.469727', `spawn_position_z` = '14.178923', `spawn_orientation` = '3.237146',`position_x` = '-2515.664063', `position_y` = '-12299.469727', `position_z` = '14.178923', `orientation` = '3.237146' WHERE `guid` = '70957';
DELETE FROM `creature` WHERE `guid` = '55493';
DELETE FROM `creature_addon` WHERE `guid` = '55493';
DELETE FROM `creature_movement` WHERE `id` = '55493';
UPDATE `creature` SET `spawn_position_x` = '-11245.691406', `spawn_position_y` = '-1721.389282', `spawn_position_z` = '290.346466', `spawn_orientation` = '3.764911',`position_x` = '-11245.691406', `position_y` = '-1721.389282', `position_z` = '290.346466', `orientation` = '3.764911' WHERE `guid` = '55530';
DELETE FROM `creature` WHERE `guid` = '55522';
DELETE FROM `creature_addon` WHERE `guid` = '55522';
DELETE FROM `creature_movement` WHERE `id` = '55522';
DELETE FROM `creature` WHERE `guid` = '55519';
DELETE FROM `creature_addon` WHERE `guid` = '55519';
DELETE FROM `creature_movement` WHERE `id` = '55519';
DELETE FROM `creature` WHERE `guid` = '55500';
DELETE FROM `creature_addon` WHERE `guid` = '55500';
DELETE FROM `creature_movement` WHERE `id` = '55500';
UPDATE `creature` SET `spawn_position_x` = '-11260.218750', `spawn_position_y` = '-1716.016724', `spawn_position_z` = '290.347137', `spawn_orientation` = '3.643173',`position_x` = '-11260.218750', `position_y` = '-1716.016724', `position_z` = '290.347137', `orientation` = '3.643173' WHERE `guid` = '55516';
DELETE FROM `creature` WHERE `guid` = '55495';
DELETE FROM `creature_addon` WHERE `guid` = '55495';
DELETE FROM `creature_movement` WHERE `id` = '55495';
DELETE FROM `creature` WHERE `guid` = '55496';
DELETE FROM `creature_addon` WHERE `guid` = '55496';
DELETE FROM `creature_movement` WHERE `id` = '55496';
DELETE FROM `creature` WHERE `guid` = '55544';
DELETE FROM `creature_addon` WHERE `guid` = '55544';
DELETE FROM `creature_movement` WHERE `id` = '55544';
DELETE FROM `creature` WHERE `guid` = '55150';
DELETE FROM `creature_addon` WHERE `guid` = '55150';
DELETE FROM `creature_movement` WHERE `id` = '55150';
DELETE FROM `creature` WHERE `guid` = '55543';
DELETE FROM `creature_addon` WHERE `guid` = '55543';
DELETE FROM `creature_movement` WHERE `id` = '55543';
DELETE FROM `creature` WHERE `guid` = '55540';
DELETE FROM `creature_addon` WHERE `guid` = '55540';
DELETE FROM `creature_movement` WHERE `id` = '55540';
UPDATE `creature` SET `spawn_position_x` = '-11252.070313', `spawn_position_y` = '-1693.331421', `spawn_position_z` = '290.347137', `spawn_orientation` = '6.274255',`position_x` = '-11252.070313', `position_y` = '-1693.331421', `position_z` = '290.347137', `orientation` = '6.274255' WHERE `guid` = '55541';
UPDATE `creature` SET `spawn_position_x` = '-11185.554688', `spawn_position_y` = '-1806.591919', `spawn_position_z` = '136.024002', `spawn_orientation` = '3.309120',`position_x` = '-11185.554688', `position_y` = '-1806.591919', `position_z` = '136.024002', `orientation` = '3.309120' WHERE `guid` = '55033';
UPDATE `creature` SET `spawn_position_x` = '-11222.715820', `spawn_position_y` = '-1786.946167', `spawn_position_z` = '135.948029', `spawn_orientation` = '3.371952',`position_x` = '-11222.715820', `position_y` = '-1786.946167', `position_z` = '135.948029', `orientation` = '3.371952' WHERE `guid` = '55450';
UPDATE `creature` SET `spawn_position_x` = '-11241.894531', `spawn_position_y` = '-1798.216187', `spawn_position_z` = '135.821716', `spawn_orientation` = '4.930966',`position_x` = '-11241.894531', `position_y` = '-1798.216187', `position_z` = '135.821716', `orientation` = '4.930966' WHERE `guid` = '55446';
UPDATE `creature` SET `spawn_position_x` = '-11265.294922', `spawn_position_y` = '-1828.422974', `spawn_position_z` = '135.715790', `spawn_orientation` = '1.761881',`position_x` = '-11265.294922', `position_y` = '-1828.422974', `position_z` = '135.715790', `orientation` = '1.761881' WHERE `guid` = '55459';
UPDATE `creature` SET `spawn_position_x` = '-11155.363281', `spawn_position_y` = '-1801.985596', `spawn_position_z` = '136.024002', `spawn_orientation` = '3.984574',`position_x` = '-11155.363281', `position_y` = '-1801.985596', `position_z` = '136.024002', `orientation` = '3.984574' WHERE `guid` = '55428';
UPDATE `creature` SET `spawn_position_x` = '-762.379456', `spawn_position_y` = '376.446136', `spawn_position_z` = '-272.579376', `spawn_orientation` = '1.287633',`position_x` = '-762.379456', `position_y` = '376.446136', `position_z` = '-272.579376', `orientation` = '1.287633' WHERE `guid` = '52974';
UPDATE `creature` SET `spawn_position_x` = '79.237190', `spawn_position_y` = '-29.375505', `spawn_position_z` = '-26.522900', `spawn_orientation` = '1.431185',`position_x` = '79.237190', `position_y` = '-29.375505', `position_z` = '-26.522900', `orientation` = '1.431185' WHERE `guid` = '51693';
UPDATE `creature` SET `spawn_position_x` = '159.073364', `spawn_position_y` = '-41.391071', `spawn_position_z` = '-34.856201', `spawn_orientation` = '2.868976',`position_x` = '159.073364', `position_y` = '-41.391071', `position_z` = '-34.856201', `orientation` = '2.868976' WHERE `guid` = '51692';
UPDATE `creature` SET `spawn_position_x` = '-538.609253', `spawn_position_y` = '194.715469', `spawn_position_z` = '-193.721466', `spawn_orientation` = '3.994186',`position_x` = '-538.609253', `position_y` = '194.715469', `position_z` = '-193.721466', `orientation` = '3.994186' WHERE `guid` = '50609';
UPDATE `creature` SET `spawn_position_x` = '-552.307190', `spawn_position_y` = '185.262848', `spawn_position_z` = '-193.730270', `spawn_orientation` = '5.282239',`position_x` = '-552.307190', `position_y` = '185.262848', `position_z` = '-193.730270', `orientation` = '5.282239' WHERE `guid` = '50605';
UPDATE `creature` SET `spawn_position_x` = '-551.345276', `spawn_position_y` = '177.490936', `spawn_position_z` = '-193.731735', `spawn_orientation` = '5.612106',`position_x` = '-551.345276', `position_y` = '177.490936', `position_z` = '-193.731735', `orientation` = '5.612106' WHERE `guid` = '50607';
UPDATE `creature` SET `spawn_position_x` = '-763.193726', `spawn_position_y` = '40.242210', `spawn_position_z` = '-255.107300', `spawn_orientation` = '4.736382',`position_x` = '-763.193726', `position_y` = '40.242210', `position_z` = '-255.107300', `orientation` = '4.736382' WHERE `guid` = '50262';
UPDATE `creature` SET `spawn_position_x` = '-11538.605469', `spawn_position_y` = '-1484.390381', `spawn_position_z` = '73.534035', `spawn_orientation` = '2.568046',`position_x` = '-11538.605469', `position_y` = '-1484.390381', `position_z` = '73.534035', `orientation` = '2.568046' WHERE `guid` = '49011';
UPDATE `creature` SET `spawn_position_x` = '-11976.290039', `spawn_position_y` = '-1645.692871', `spawn_position_z` = '34.636387', `spawn_orientation` = '0.126888',`position_x` = '-11976.290039', `position_y` = '-1645.692871', `position_z` = '34.636387', `orientation` = '0.126888' WHERE `guid` = '48980';
UPDATE `creature` SET `spawn_position_x` = '2300.988770', `spawn_position_y` = '-5336.659668', `spawn_position_z` = '90.880318', `spawn_orientation` = '3.721567',`position_x` = '2300.988770', `position_y` = '-5336.659668', `position_z` = '90.880318', `orientation` = '3.721567' WHERE `guid` = '85503';
DELETE FROM `creature` WHERE `id`=19179;
DELETE FROM `creature` WHERE `id`=18654;
DELETE FROM `creature` WHERE `id`=18555;
DELETE FROM `creature` WHERE `id`=21959;
DELETE FROM `creature` WHERE `id`=20764;
DELETE FROM `creature` WHERE `id`=20782;
DELETE FROM `creature` WHERE `id`=21417;
DELETE FROM `creature` WHERE `id`=23585;
DELETE FROM `creature` WHERE `id`=16137;
DELETE FROM `creature` WHERE `id`=22798;
DELETE FROM `creature` WHERE `id`=22799;
DELETE FROM `creature` WHERE `id`=22800;
DELETE FROM `creature` WHERE `id`=22801;
DELETE FROM `creature` WHERE `guid` IN (283049,283063,283050,283053);
DELETE FROM `creature_template_addon` WHERE `entry`=19144;
DELETE FROM `creature_addon` WHERE `guid` IN (62264,62282,75211,76243,103024,103026,103027,62150,63760,63769,63794,63802,70613,70614,70621,70624);
DELETE FROM `creature` WHERE `id`=17316;
DELETE FROM `creature` WHERE `id`=17886;
DELETE FROM `creature` WHERE `id`=22023;
DELETE FROM `creature` WHERE `id`=22116;
DELETE FROM `creature` WHERE `id`=22356;
DELETE FROM `creature` WHERE `id`=22367;
DELETE FROM `creature` WHERE `id`=22368;
DELETE FROM `creature` WHERE `id`=22447;


# Y2kCat
UPDATE `gameobject_template` SET `type`='5',`data0`='1',`data1`='1' WHERE entry in (172961,172960,172958,172992,172985,173044,172986);
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE type=65536;
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE type=5 and data0<11;
UPDATE `gameobject_template` SET `data1`='0' WHERE entry in (181585,181587,180471,180472);
DELETE FROM `gameobject` WHERE (`guid`='1387');
DELETE FROM `creature` WHERE (`guid`='284638');
UPDATE `creature` SET `MovementType`='0' WHERE guid in (71223,69226,71236,71235,71229,56405,69225,69223,71231,69222,56406);
UPDATE `quest_template` SET `PrevQuestId`='0',`NextQuestId`='10991' WHERE (`entry`='10990');
UPDATE `quest_template` SET `NextQuestId`='10992' WHERE (`entry`='10991');
UPDATE `quest_template` SET `NextQuestId`='10993' WHERE (`entry`='10992');
UPDATE `quest_template` SET `NextQuestId`='10994' WHERE (`entry`='10993');
UPDATE `quest_template` SET `NextQuestId`='11001' WHERE (`entry`='10994');


# LOTAR
UPDATE `quest_template` SET `ZoneOrSort` = 1769, `RequiredMinRepFaction` = 576, `RequiredMinRepValue` = 42000 WHERE `entry` = 8481;
UPDATE `quest_template` SET `OfferRewardText` = 'It\'s good to see you again, $N. Your triumph over the raven god counts for far more than any test or rite of passage that I might set for you.$B$BYou have truly proven yourself worthy of the knowledge guarded by the Druids of the Talon for countless generations.' WHERE `entry` = 11001;
UPDATE `quest_template` SET `OfferRewardText` = '<The sparrowhawk dutifully conveys Arthorn\'s words.>$B$BWell done, $N. I\'d feared that the falcon\'s prison had been destroyed in the explosion of Auchindoun. We\'re almost prepared to confront Anzu, $N. I\'d love to go with you, to be there when this self-styled "god" is cast back into the pit that spawned him!' WHERE `entry` = 10991;


# QUEST
UPDATE `quest_template` SET `SrcItemId`='18489' WHERE `entry` IN ('7509');
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (10612, 3520, 67, 69, 0, 1101, 0, 0, 0, 0, 0, 0, 0, 0, 300, 8, 0, 10606, 10744, 0, 10744, 0, 0, 0, 'The Fel and the Furious', '<Plexi leafs through the manual.>$B$BWell, this has everything we need, but there\'s just one problem. Fel Reavers aren\'t really built to respond to remote control.$B$BWe can modify one for you to use for a short time, but you\'ll have to work fast, or there\'s no telling what might happen! I wouldn\'t be surprised if your little stunt with the fel reaver catches the attention of the Legion\'s lackeys, either. Keep an eye out, and whatever you do, don\'t forget to destroy as much as you can!', 'Use a Fel Reaver Control Console to take control of a Fel Reaver Sentinel. Destroy 60 Deathforged Infernals before your fel reaver fails. When your mission is complete, report to Plexi at Invasion Point: Cataclysm.', 'Amazing! You\'ve managed to do what all the gryphonriders in Wildhammer Stronghold couldn\'t! You\'ve broken the back of the Burning Legion\'s advance and spared us from annihilation at the hands of their infernals. You have our deepest gratitude for your service, $N.', 'You\'re back, so I\'ll assume the operation went well. What\'ve you got to report?', '', 'Deathforged Infernal Destroyed', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -184979, 0, 0, 0, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 41000, 15400, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (10613, 3520, 67, 69, 0, 690, 0, 0, 0, 0, 0, 0, 0, 0, 300, 8, 0, 10611, 10745, 0, 10745, 0, 0, 0, 'The Fel and the Furious', '<Nakansi leafs through the manual.>$B$BAll the information is here, but be warned. These things weren\'t built to be controlled remotely.$B$BWe can modify one for you to use for a short time, but you\'ll have to work fast, or there\'s no telling what might happen! I wouldn\'t be surprised if your little stunt with the fel reaver catches the attention of the Legion scum, either. Try to keep yourself safe, but remember, the mission and the safety of Shadowmoon Village come first!', 'Use a Fel Reaver Control Console to take control of a Fel Reaver Sentinel. Destroy 60 Deathforged Infernals before your fel reaver fails. When your mission is complete, report to Nakansi at Invasion Point: Cataclysm.', 'I\'ll admit it, $N. I\'m impressed by all you\'ve managed to accomplish. Destroying the Legion\'s ability to make war in Shadowmoon will give us the opportunity to turn the tide elsewhere.', '', '', 'Deathforged Infernal destroyed', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -184979, 0, 0, 0, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 41000, 15400, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (633, 11, 28, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 632, 634, 0, 634, 0, 0, 0, 'The Thandol Span', 'Heavens no!  Poor Rustlocke.  \'Tis quite a tragedy indeed.$B$BWe must not let his death pass in vain.  This parchment you discovered indicates that Kam Deepfury, the mastermind behind the original attack, arranged for a cache of explosives to be stashed just across the Thandol Span, in Arathi Highlands.$B$BIf those explosives make it to the bridge, our major supply line to the north will be severed!  The cache must be destroyed, $N!  Return to me when your mission is complete.$B$BYou\'re our only hope.', 'Destroy the cache of explosives.', 'The remaining bridge is saved! You have done a great service to King Magni and the people of Khaz Modan.$B$BNow if we can only hold out long enough for reinforcements to show...', '', '', 'Cache of Explosives Destroyed', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -2704, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 4504, 4505, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 47, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 1500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (6395, 154, 3, 5, 0, 690, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 'Marla\'s Last Wish', 'My friend Marla Fipps lived with her husband Samuel before the plague, but when the plague came Samuel succumbed and joined the Scourge\'s ranks.$B$BMarla was spared an undeath only to die at the hands of her now mindless husband.  So strong was her love, however, that her last dying wish was to be buried with her beloved Samuel.$B$BSamuel Fipps roams at a ruined camp along the road northeast of Deathknell.  Defeat him and grant Marla\'s wish: bury him at her grave, in the first row of our graveyard.', 'Bring Samuel Fipps\' Remains to Marla\'s Grave, then return to Novice Elreth.', 'You have done a good deed today, Ganis. Although our struggle against the Scourge continues, let us hope that Marla and Samuel will find peace together in their final resting place.', 'We must respect our dead, $N. It is one of the ways in which we differ from the Scourge...', '', 'Samuel\'s Remains Buried', '', '', '', 16333, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -178090, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 270, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (957, 148, 11, 13, 0, 1101, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 956, 0, 0, 0, 5338, 1, 0, 'Bashal\'Aran', 'It was the craft of one of the most powerful of the Highborne that created the seal that formed my prison. In Ameth\'Aran, the ruins to the south that are twin to these, persists even today an ancient flame, blue in color. In this flame this seal could be destroyed.$B$BBe wary in the ruins, $N...', 'Destroy the Ancient Moonstone Seal at the ancient flame in Ameth\'Aran, then return to Asterion in Bashal\'Aran.', 'I am freed, $N! I can now see with my own eyes the changes that have come to our world... Only bits and pieces have I known. To think that when I last walked freely, the Well still stood and the Highborne held court with Azshara, our beloved queen.$B$BI sense that my jailor, my former master, Athrikus, still lives... Already my feelings of hopelessness will give way into thoughts of vengeance.', '', '', 'Destroy the seal at the ancient flame', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -16393, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 7229, 5617, 5604, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 69, 0, 0, 0, 0, 150, 0, 0, 0, 0, 0, 420, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);


# GO
INSERT INTO `gameobject` VALUES ( 71797, 179562, 249, -44.1702, -202.663, -86.0018, 5.79224, 0, 0, 0.243014, -0.970023, 600, 0, 1);
DELETE FROM `gameobject_loot_template` WHERE (`entry`=179562) AND (`item`=18488);
INSERT INTO `gameobject_loot_template` (`entry`, `item`, `ChanceOrRef`, `QuestChanceOrGroup`, `mincount`, `maxcount`, `freeforall`, `lootcondition`, `condition_value1`, `condition_value2`) VALUES (179562, 18488, 100, 0, 1, 1, 1, 0, 0, 0);
REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (138492, 2, 1667, 'Shards of Myzrael', 0, 0, 1, 5, 635, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (184979, 10, 7248, 'Deathforged Infernal', 0, 0, 1, 43, 10612, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (138492, 2, 1667, 'Shards of Myzrael', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (2704, 10, 243, 'Cache of Explosives', 0, 0, 1, 93, 633, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO `gameobject` (`guid`, `id`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `spawntimesecs`, `animprogress`, `state`) VALUES (19892, 2704, 0, -2238.62, -2615.54, 77.77, 0.75, 0, 0, 0, 0, 600, 100, 1);
REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (178090, 10, 20, 'Marla\'s Grave', 0, 0, 1, 43, 6395, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (16393, 10, 249, 'Ancient Flame', 84, 0, 1, 43, 957, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');



# NPC
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (4277, 2421, 0, 2421, 0, 'Eye of Kilrogg', '', 70, 71, 9396, 10000, 728, 750, 1232, 35, 35, 0, 1.03, 0, 1050, 1700, 0, 107, 1790, 1969, 0, 0, 0, 0, 0, 0, 0, 34.6544, 47.6498, 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 1, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (8202, 7509, 0, 7509, 0, 'Cyclok the Mad', '', 48, 48, 1800, 1800, 4140, 4140, 851, 32, 32, 0, 1.69, 4, 410, 575, 0, 1083, 1250, 1375, 0, 0, 0, 0, 0, 0, 0, 53.9, 74.1125, 100, 7, 0, 0, 8202, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 459, 715, '', 1, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (8207, 7349, 0, 7349, 0, 'Greater Firebird', '', 46, 46, 2400, 2400, 0, 0, 807, 73, 73, 0, 2.17, 4, 390, 550, 0, 1017, 1266, 1393, 0, 0, 7, 0, 0, 0, 0, 52.3768, 72.0181, 100, 1, 0, 16, 8207, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 1, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (8982, 9189, 0, 9189, 0, 'Ironhand Guardian', '', 56, 56, 5440, 5440, 0, 0, 74, 14, 14, 0, 1.27, 1, 240, 320, 0, 47, 1666, 1833, 0, 0, 0, 0, 0, 0, 0, 4.13793, 5.17241, 100, 4, 0, 0, 0, 0, 0, 290, 58, 290, 58, 58, 58, 0, 0, 0, 0, 71, 71, '', 0, 3, 0, 1, 0, '');
DELETE FROM `creature_loot_template` WHERE (`entry`=6412);
INSERT INTO `creature_loot_template` VALUES 
(6412, 2771, 16, 0, 1, 1, 0, 0, 0, 0),
(6412, 929, 19, 0, 1, 1, 0, 0, 0, 0),
(6412, 3385, 19, 0, 1, 1, 0, 0, 0, 0),
(6412, 4538, 16, 0, 1, 1, 0, 0, 0, 0),
(6412, 2836, 9, 0, 1, 1, 0, 0, 0, 0),
(6412, 4606, 19, 0, 1, 1, 0, 0, 0, 0),
(6412, 858, 16, 0, 1, 1, 0, 0, 0, 0),
(6412, 1205, 12, 0, 1, 1, 0, 0, 0, 0),
(6412, 3770, 9, 0, 1, 1, 0, 0, 0, 0),
(6412, 2455, 6, 0, 1, 1, 0, 0, 0, 0),
(6412, 2838, 6, 0, 1, 1, 0, 0, 0, 0),
(6412, 2997, 9, 0, 1, 1, 0, 0, 0, 0),
(6412, 4306, 6, 0, 1, 1, 0, 0, 0, 0),
(6412, 4542, 6, 0, 1, 1, 0, 0, 0, 0);
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (15623, 11341, 0, 11341, 0, 'Xandivious', '', 62, 62, 20000, 21000, 7704, 7704, 1105, 14, 14, 0, 1, 1, 161, 271, 0, 1516, 18, 26, 0, 0, 0, 0, 0, 0, 0, 130.345, 168.276, 0, 3, 0, 0, 15623, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4323, 4323, '', 0, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (16027, 12349, 0, 12349, 0, 'Living Poison', '', 60, 61, 13000, 14000, 0, 0, 74, 14, 14, 0, 1, 1, 300, 500, 0, 47, 18, 26, 0, 0, 0, 0, 0, 0, 0, 4.13793, 5.17241, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 71, 71, '', 0, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (16124, 16608, 0, 16608, 0, 'Unrelenting Trainee', '', 60, 60, 4900, 4900, 0, 0, 968, 14, 14, 0, 1, 0, 400, 600, 0, 485, 6, 9, 0, 0, 0, 0, 0, 0, 0, 41.7241, 53.7931, 0, 7, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 186, 619, '', 0, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (16126, 10729, 0, 10729, 0, 'Unrelenting Rider', '', 62, 62, 25000, 25000, 12840, 12840, 1105, 14, 14, 0, 1, 1, 399, 456, 0, 1516, 18, 26, 0, 0, 0, 0, 0, 0, 0, 130.345, 168.276, 0, 6, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4321, 4321, '', 0, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (16148, 16611, 0, 16611, 0, 'Spectral Deathknight', '', 62, 63, 12000, 16000, 0, 0, 1105, 14, 14, 0, 1, 1, 350, 430, 0, 1491, 18, 26, 0, 0, 0, 0, 0, 0, 0, 128.276, 165.517, 0, 6, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4358, 4413, '', 0, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (16150, 16614, 0, 16614, 0, 'Spectral Rider', '', 63, 63, 10100, 10100, 0, 0, 1132, 14, 14, 0, 1, 1, 345, 425, 0, 1538, 18, 26, 0, 0, 0, 0, 0, 0, 0, 132.414, 170.69, 0, 6, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4392, 4392, '', 0, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (21138, 19062, 0, 19062, 0, 'Infinite Executioner', '', 70, 70, 7600, 7600, 9465, 9500, 600, 14, 14, 0, 1.48, 0, 300, 500, 0, 7, 1400, 1900, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 1, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (21136, 19061, 0, 19061, 0, 'Infinite Chronomancer', '', 70, 70, 4300, 4300, 9465, 9500, 450, 14, 14, 0, 1.48, 0, 400, 500, 0, 7, 1400, 1900, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 1, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (21148, 20102, 0, 20102, 0, 'Rift Keeper', '', 71, 71, 51000, 51000, 32310, 32500, 74, 14, 14, 0, 1.48, 1, 450, 550, 0, 24, 1400, 1900, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 2, 0, 0, 21148, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3300, 3300, '', 1, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (16120, 11397, 0, 11397, 0, 'Bone Mage', '', 60, 60, 5100, 5100, 2434, 2434, 1054, 14, 14, 0, 1, 1, 156, 262, 0, 1467, 18, 26, 0, 0, 0, 0, 0, 0, 0, 126.207, 162.759, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4187, 4188, '', 0, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (20117, 18088, 0, 18088, 0, 'Vengeful Unyielding Knight', '', 60, 60, 4600, 4600, 0, 0, 968, 35, 35, 0, 1, 0, 300, 450, 0, 485, 750, 1056, 0, 0, 0, 0, 0, 0, 0, 41.7241, 53.7931, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 175, 602, '', 0, 3, 0, 1, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `ScriptName`) VALUES (20495, 5050, 0, 5050, 0, 'Skeletal Stallion', '', 68, 68, 6600, 6600, 0, 0, 1177, 7, 7, 0, 1, 0, 250, 350, 0, 667, 850, 1197, 0, 0, 0, 0, 0, 0, 0, 56.2069, 75.1724, 0, 6, 0, 0, 20495, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 3, 0, 1, 0, '');


# ITEM
REPLACE INTO `item_template` (`entry`, `class`, `subclass`, `unk0`, `name`, `displayid`, `Quality`, `Flags`, `BuyCount`, `BuyPrice`, `SellPrice`, `InventoryType`, `AllowableClass`, `AllowableRace`, `ItemLevel`, `RequiredLevel`, `RequiredSkill`, `RequiredSkillRank`, `requiredspell`, `requiredhonorrank`, `RequiredCityRank`, `RequiredReputationFaction`, `RequiredReputationRank`, `maxcount`, `stackable`, `ContainerSlots`, `stat_type1`, `stat_value1`, `stat_type2`, `stat_value2`, `stat_type3`, `stat_value3`, `stat_type4`, `stat_value4`, `stat_type5`, `stat_value5`, `stat_type6`, `stat_value6`, `stat_type7`, `stat_value7`, `stat_type8`, `stat_value8`, `stat_type9`, `stat_value9`, `stat_type10`, `stat_value10`, `dmg_min1`, `dmg_max1`, `dmg_type1`, `dmg_min2`, `dmg_max2`, `dmg_type2`, `dmg_min3`, `dmg_max3`, `dmg_type3`, `dmg_min4`, `dmg_max4`, `dmg_type4`, `dmg_min5`, `dmg_max5`, `dmg_type5`, `armor`, `holy_res`, `fire_res`, `nature_res`, `frost_res`, `shadow_res`, `arcane_res`, `delay`, `ammo_type`, `RangedModRange`, `spellid_1`, `spelltrigger_1`, `spellcharges_1`, `spellppmRate_1`, `spellcooldown_1`, `spellcategory_1`, `spellcategorycooldown_1`, `spellid_2`, `spelltrigger_2`, `spellcharges_2`, `spellppmRate_2`, `spellcooldown_2`, `spellcategory_2`, `spellcategorycooldown_2`, `spellid_3`, `spelltrigger_3`, `spellcharges_3`, `spellppmRate_3`, `spellcooldown_3`, `spellcategory_3`, `spellcategorycooldown_3`, `spellid_4`, `spelltrigger_4`, `spellcharges_4`, `spellppmRate_4`, `spellcooldown_4`, `spellcategory_4`, `spellcategorycooldown_4`, `spellid_5`, `spelltrigger_5`, `spellcharges_5`, `spellppmRate_5`, `spellcooldown_5`, `spellcategory_5`, `spellcategorycooldown_5`, `bonding`, `description`, `PageText`, `LanguageID`, `PageMaterial`, `startquest`, `lockid`, `Material`, `sheath`, `RandomProperty`, `RandomSuffix`, `block`, `itemset`, `MaxDurability`, `area`, `Map`, `BagFamily`, `TotemCategory`, `socketColor_1`, `socketContent_1`, `socketColor_2`, `socketContent_2`, `socketColor_3`, `socketContent_3`, `socketBonus`, `GemProperties`, `ExtendedCost`, `RequiredArenaRank`, `RequiredDisenchantSkill`, `ArmorDamageModifier`, `ScriptName`, `DisenchantID`, `FoodType`, `minMoneyLoot`, `maxMoneyLoot`, `Duration`) VALUES (33953, 4, 9, -1, 'Vengeful Gladiator\'s Totem of Survival', 25246, 4, 32768, 1, 0, 0, 28, 32767, -1, 146, 70, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 43862, 1, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 1, '', 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1435, 0, -1, 0, '', 0, 0, 0, 0, 0);


# Brain and Soul
UPDATE `item_template` SET `spellcharges_1` = 1 WHERE `entry` = 23361;
UPDATE `gameobject_template` SET `data0`='1650' WHERE (`entry`='181556');
UPDATE `quest_template` SET `ReqCreatureOrGOId1`='-183123', `ReqCreatureOrGOCount1`='1', `ReqSpellCast1`='32979' WHERE `entry` IN ('10078');
UPDATE `quest_template` SET `ReqCreatureOrGOId2`='-183123', `ReqCreatureOrGOCount2`='1', `ReqSpellCast2`='32979' WHERE `entry` IN ('10078');
UPDATE `quest_template` SET `ReqCreatureOrGOId3`='-183123', `ReqCreatureOrGOCount3`='1', `ReqSpellCast3`='32979' WHERE `entry` IN ('10078');
UPDATE `quest_template` SET `ReqCreatureOrGOId4`='-183123', `ReqCreatureOrGOCount4`='1', `ReqSpellCast4`='32979' WHERE `entry` IN ('10078');

# Demosfen
DELETE FROM `creature` WHERE `guid` = '69';
DELETE FROM `creature_addon` WHERE `guid` = '69';
DELETE FROM `creature_movement` WHERE `id` = '69';

# KiriX
UPDATE `creature_template` SET `minhealth`='6400',`maxhealth`='6400',`faction_A`='35',`faction_H`='35' WHERE (`entry`='23139');
UPDATE `creature_template` SET `minhealth`='71',`maxhealth`='85' WHERE (`entry`='1989');
UPDATE `creature_template` SET `minhealth`='55',`maxhealth`='73' WHERE (`entry`='1988');
UPDATE `creature_template` SET `mingold`='0',`maxgold`='0' WHERE (`entry`='1933');
UPDATE creature SET spawn_position_x = '10710.305664', spawn_position_y = '1035.674072', spawn_position_z = '1347.615479', spawn_orientation = '4.901765',position_x = '10710.305664', position_y = '1035.674072', position_z = '1347.615479', orientation = '4.901765' WHERE guid = '47632';
UPDATE creature SET spawn_position_x = '9814.818359', spawn_position_y = '-6698.271484', spawn_position_z = '2.607294', spawn_orientation = '0.376988',position_x = '9814.818359', position_y = '-6698.271484', position_z = '2.607294', orientation = '0.376988' WHERE guid = '70490';
UPDATE `creature_template` SET `MovementType`='0' WHERE (`entry`='15949');
DELETE FROM `creature_template` WHERE (`entry`='1542001');
DELETE FROM `creature` WHERE (`id`='1542001');

# KiriX & andalit
UPDATE `quest_template` SET `MinLevel`='20', `RewMoneyMaxLevel`='600' WHERE (`entry`='1651');
UPDATE `quest_template` SET `MinLevel`='20', `RewMoneyMaxLevel`='1530' WHERE (`entry`='1652');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='495' WHERE (`entry`='1653');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1650' WHERE (`entry`='96');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1110' WHERE (`entry`='1650');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1170' WHERE (`entry`='2359');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1170' WHERE (`entry`='2478');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='3366');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='5645');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8162');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8155');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8171');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8168');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='7789');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1170' WHERE (`entry`='9504');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='465' WHERE (`entry`='1716');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='930' WHERE (`entry`='1738');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='1739');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='1788');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='2458');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='2609');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='3567');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='5061');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='930' WHERE (`entry`='9501');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='450' WHERE (`entry`='6124');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='450' WHERE (`entry`='6125');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='450' WHERE (`entry`='6129');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='585' WHERE (`entry`='6130');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='126' WHERE (`entry`='6962');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='900' WHERE (`entry`='8389');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='435' WHERE (`entry`='8386');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='555' WHERE (`entry`='9691');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='930' WHERE (`entry`='9686');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='930' WHERE (`entry`='9503');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='9561');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1110' WHERE (`entry`='9508');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1410' WHERE (`entry`='9509');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='525' WHERE (`entry`='30');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='31');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='840' WHERE (`entry`='63');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='780' WHERE (`entry`='100');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='525' WHERE (`entry`='272');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='585' WHERE (`entry`='822');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='930' WHERE (`entry`='1474');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='930' WHERE (`entry`='1476');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='465' WHERE (`entry`='1510');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='930' WHERE (`entry`='1511');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='1513');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='1515');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='1526');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='1527');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='465' WHERE (`entry`='1528');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='465' WHERE (`entry`='1529');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='840' WHERE (`entry`='1534');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='525' WHERE (`entry`='1535');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='780' WHERE (`entry`='1536');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='5000' WHERE (`entry`='708');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1470' WHERE (`entry`='1531');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1470' WHERE (`entry`='1532');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='690' WHERE (`entry`='1703');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1470' WHERE (`entry`='1719');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1470' WHERE (`entry`='1795');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1470' WHERE (`entry`='1802');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1470' WHERE (`entry`='1804');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1470' WHERE (`entry`='1805');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='630' WHERE (`entry`='2479');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='2880' WHERE (`entry`='2932');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='2790' WHERE (`entry`='2945');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1650' WHERE (`entry`='2948');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='11000' WHERE (`entry`='8161');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1350' WHERE (`entry`='8384');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='4500' WHERE (`entry`='8393');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='900' WHERE (`entry`='8390');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='900' WHERE (`entry`='8391');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='110000' WHERE (`entry`='8156');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8436');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8170');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0',`RewOrReqMoney`='5000' WHERE (`entry`='708');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8161');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8156');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8167');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8427');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8399');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8400');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='7874');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='7871');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1470' WHERE (`entry`='1797');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='360' WHERE (`entry`='9547');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='7140' WHERE (`entry`='105');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='7140' WHERE (`entry`='211');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='3810' WHERE (`entry`='8418');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='6840' WHERE (`entry`='1446');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='5070' WHERE (`entry`='2521');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='6540' WHERE (`entry`='2681');
UPDATE `quest_template` SET `MinLevel`='60',`QuestLevel`='60' WHERE (`entry`='8364');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='94800' WHERE (`entry`='11101');
UPDATE `quest_template` SET `MinLevel`='40',`RewMoneyMaxLevel`='2790' WHERE (`entry`='50');
UPDATE `quest_template` SET `MinLevel`='40',`RewMoneyMaxLevel`='2790' WHERE (`entry`='51');
UPDATE `quest_template` SET `MinLevel`='40',`RewMoneyMaxLevel`='3360' WHERE (`entry`='53');
UPDATE `quest_template` SET `MinLevel`='18',`RewMoneyMaxLevel`='1470' WHERE (`entry`='58');
UPDATE `quest_template` SET `MinLevel`='39' WHERE (`entry`='82');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1650' WHERE (`entry`='96');
UPDATE `quest_template` SET `MinLevel`='14',`RewMoneyMaxLevel`='294' WHERE (`entry`='120');
UPDATE `quest_template` SET `MinLevel`='14',`RewMoneyMaxLevel`='294' WHERE (`entry`='143');
UPDATE `quest_template` SET `MinLevel`='18' WHERE (`entry`='145');
UPDATE `quest_template` SET `MinLevel`='18',`RewMoneyMaxLevel`='204' WHERE (`entry`='146');
UPDATE `quest_template` SET `MinLevel`='20',`RewMoneyMaxLevel`='294' WHERE (`entry`='149');
UPDATE `quest_template` SET `MinLevel`='20',`RewMoneyMaxLevel`='930' WHERE (`entry`='150');
UPDATE `quest_template` SET `MinLevel`='20',`RewMoneyMaxLevel`='870' WHERE (`entry`='157');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='216' WHERE (`entry`='182');
UPDATE `quest_template` SET `MinLevel`='20' WHERE (`entry`='262');
UPDATE `quest_template` SET `MinLevel`='20' WHERE (`entry`='322');
UPDATE `quest_template` SET `MinLevel`='20' WHERE (`entry`='325');
UPDATE `quest_template` SET `MinLevel`='43',`RewMoneyMaxLevel`='3780' WHERE (`entry`='351');
UPDATE `quest_template` SET `MinLevel`='10' WHERE (`entry`='430');
UPDATE `quest_template` SET `MinLevel`='10',`RewMoneyMaxLevel`='345' WHERE (`entry`='440');
UPDATE `quest_template` SET `MinLevel`='10',`RewMoneyMaxLevel`='264' WHERE (`entry`='449');
UPDATE `quest_template` SET `MinLevel`='14',`RewMoneyMaxLevel`='405' WHERE (`entry`='461');
UPDATE `quest_template` SET `MinLevel`='19',`RewMoneyMaxLevel`='690' WHERE (`entry`='493');
UPDATE `quest_template` SET `MinLevel`='10',`RewMoneyMaxLevel`='930' WHERE (`entry`='530');
UPDATE `quest_template` SET `QuestLevel`='1',`RewMoneyMaxLevel`='0' WHERE (`entry`='579');
UPDATE `quest_template` SET `MinLevel`='32',`RewMoneyMaxLevel`='264' WHERE (`entry`='641');
UPDATE `quest_template` SET `MinLevel`='30',`RewMoneyMaxLevel`='1950' WHERE (`entry`='653');
UPDATE `quest_template` SET `MinLevel`='35',`RewMoneyMaxLevel`='2610' WHERE (`entry`='673');
UPDATE `quest_template` SET `MinLevel`='7',`RewMoneyMaxLevel`='525' WHERE (`entry`='744');
UPDATE `quest_template` SET `MinLevel`='5' WHERE (`entry`='786');
UPDATE `quest_template` SET `MinLevel`='5' WHERE (`entry`='817');
UPDATE `quest_template` SET `MinLevel`='3' WHERE (`entry`='825');
UPDATE `quest_template` SET `MinLevel`='4',`RewMoneyMaxLevel`='276' WHERE (`entry`='829');
UPDATE `quest_template` SET `MinLevel`='4',`RewMoneyMaxLevel`='405' WHERE (`entry`='832');
UPDATE `quest_template` SET `MinLevel`='5' WHERE (`entry`='930');
UPDATE `quest_template` SET `MinLevel`='38' WHERE (`entry`='992');
UPDATE `quest_template` SET `MinLevel`='13',`RewMoneyMaxLevel`='810' WHERE (`entry`='1065');
UPDATE `quest_template` SET `MinLevel`='13',`RewMoneyMaxLevel`='1110' WHERE (`entry`='1066');
UPDATE `quest_template` SET `MinLevel`='30',`RewMoneyMaxLevel`='2610' WHERE (`entry`='1109');
UPDATE `quest_template` SET `MinLevel`='30',`RewMoneyMaxLevel`='1980' WHERE (`entry`='1113');
UPDATE `quest_template` SET `MinLevel`='20',`RewMoneyMaxLevel`='1470' WHERE (`entry`='1131');
UPDATE `quest_template` SET `MinLevel`='26',`RewMoneyMaxLevel`='3330' WHERE (`entry`='1136');
UPDATE `quest_template` SET `MinLevel`='30' WHERE (`entry`='1240');
UPDATE `quest_template` SET `MinLevel`='10',`RewMoneyMaxLevel`='630' WHERE (`entry`='1358');
UPDATE `quest_template` SET `MinLevel`='38',`RewMoneyMaxLevel`='3180' WHERE (`entry`='1429');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='102' WHERE (`entry`='1470');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='216' WHERE (`entry`='1485');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='216' WHERE (`entry`='1598');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='270' WHERE (`entry`='1599');
UPDATE `quest_template` SET `MinLevel`='45',`RewMoneyMaxLevel`='4080' WHERE (`entry`='2601');
UPDATE `quest_template` SET `MinLevel`='44',`RewMoneyMaxLevel`='3930' WHERE (`entry`='2605');
UPDATE `quest_template` SET `MinLevel`='45',`RewMoneyMaxLevel`='3930' WHERE (`entry`='2623');
UPDATE `quest_template` SET `MinLevel`='44',`RewMoneyMaxLevel`='3930' WHERE (`entry`='2641');
UPDATE `quest_template` SET `MinLevel`='40',`RewMoneyMaxLevel`='3330' WHERE (`entry`='2766');
UPDATE `quest_template` SET `MinLevel`='40',`RewMoneyMaxLevel`='3330' WHERE (`entry`='2873');
UPDATE `quest_template` SET `MinLevel`='40',`RewMoneyMaxLevel`='3330' WHERE (`entry`='2874');
UPDATE `quest_template` SET `MinLevel`='38',`RewMoneyMaxLevel`='3330' WHERE (`entry`='2875');
UPDATE `quest_template` SET `MinLevel`='25',`RewMoneyMaxLevel`='0',`RewOrReqMoney`='300' WHERE (`entry`='2951');
UPDATE `quest_template` SET `MinLevel`='25',`RewMoneyMaxLevel`='1470' WHERE (`entry`='2952');
UPDATE `quest_template` SET `MinLevel`='45',`RewMoneyMaxLevel`='4080' WHERE (`entry`='2954');
UPDATE `quest_template` SET `MinLevel`='45',`RewMoneyMaxLevel`='2820' WHERE (`entry`='2966');
UPDATE `quest_template` SET `MinLevel`='45',`RewMoneyMaxLevel`='4080' WHERE (`entry`='3362');
UPDATE `quest_template` SET `MinLevel`='45',`RewMoneyMaxLevel`='2190' WHERE (`entry`='3568');
UPDATE `quest_template` SET `MinLevel`='45',`RewMoneyMaxLevel`='435' WHERE (`entry`='3569');
UPDATE `quest_template` SET `MinLevel`='47',`RewMoneyMaxLevel`='4080' WHERE (`entry`='3761');
UPDATE `quest_template` SET `MinLevel`='47',`RewMoneyMaxLevel`='4080' WHERE (`entry`='3786');
UPDATE `quest_template` SET `MinLevel`='48',`RewMoneyMaxLevel`='3660' WHERE (`entry`='4103');
UPDATE `quest_template` SET `MinLevel`='40' WHERE (`entry`='4135');
UPDATE `quest_template` SET `MinLevel`='48',`RewMoneyMaxLevel`='4740' WHERE (`entry`='4504');
UPDATE `quest_template` SET `MinLevel`='50',`RewMoneyMaxLevel`='4740' WHERE (`entry`='4507');
UPDATE `quest_template` SET `MinLevel`='50',`RewMoneyMaxLevel`='4740' WHERE (`entry`='5051');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='5656');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='5657');
UPDATE `quest_template` SET `MinLevel`='9' WHERE (`entry`='5723');
UPDATE `quest_template` SET `MinLevel`='9',`RewMoneyMaxLevel`='1050' WHERE (`entry`='5724');
UPDATE `quest_template` SET `MinLevel`='9',`RewMoneyMaxLevel`='1050' WHERE (`entry`='5725');
UPDATE `quest_template` SET `MinLevel`='9',`RewMoneyMaxLevel`='1050' WHERE (`entry`='5761');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='926');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='3762');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='3784');
UPDATE `quest_template` SET `MinLevel`='44',`RewMoneyMaxLevel`='3930' WHERE (`entry`='5863');
UPDATE `quest_template` SET `MinLevel`='48',`RewMoneyMaxLevel`='2430' WHERE (`entry`='5904');
UPDATE `quest_template` SET `MinLevel`='44' WHERE (`entry`='2606');
UPDATE `quest_template` SET `MinLevel`='44' WHERE (`entry`='2661');
UPDATE `quest_template` SET `MinLevel`='47',`QuestLevel`='405' WHERE (`entry`='3782');
UPDATE `quest_template` SET `MinLevel`='10',`RewMoneyMaxLevel`='630' WHERE (`entry`='6285');
UPDATE `quest_template` SET `MinLevel`='28' WHERE (`entry`='6521');
UPDATE `quest_template` SET `MinLevel`='28' WHERE (`entry`='6522');
UPDATE `quest_template` SET `MinLevel`='28' WHERE (`entry`='6626');
UPDATE `quest_template` SET `MinLevel`='40',`RewMoneyMaxLevel`='3330' WHERE (`entry`='8365');
UPDATE `quest_template` SET `MinLevel`='40',`RewMoneyMaxLevel`='3330' WHERE (`entry`='8366');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0',`RewOrReqMoney`='24500' WHERE (`entry`='3911');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='5653');
UPDATE `quest_template` SET `MinLevel`='18',`RewMoneyMaxLevel`='465' WHERE (`entry`='9425');
UPDATE `quest_template` SET `MinLevel`='63',`RewMoneyMaxLevel`='11520' WHERE (`entry`='9943');
UPDATE `quest_template` SET `MinLevel`='64',`RewMoneyMaxLevel`='114520' WHERE (`entry`='9947');
UPDATE `quest_template` SET `MinLevel`='42',`RewMoneyMaxLevel`='4320' WHERE (`entry`='9475');
UPDATE `quest_template` SET `MinLevel`='1',`RewMoneyMaxLevel`='90' WHERE (`entry`='9389');
UPDATE `quest_template` SET `MinLevel`='1',`RewMoneyMaxLevel`='90' WHERE (`entry`='9388');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='11335');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='11336');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='11337');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='11338');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='11339');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='11340');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='11341');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='11342');
UPDATE `quest_template` SET `MinLevel`='1',`RewMoneyMaxLevel`='0' WHERE (`entry`='11558');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='7222');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8290');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8295');
UPDATE `quest_template` SET `MinLevel`='40',`RewMoneyMaxLevel`='0' WHERE (`entry`='10356');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='10357');
UPDATE `quest_template` SET `MinLevel`='26',`RewMoneyMaxLevel`='0' WHERE (`entry`='10360');
UPDATE `quest_template` SET `MinLevel`='40',`RewMoneyMaxLevel`='0' WHERE (`entry`='10361');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='10362');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='10352');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='636');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='779');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='1036');
UPDATE `quest_template` SET `MinLevel`='48',`RewMoneyMaxLevel`='0' WHERE (`entry`='4221');
UPDATE `quest_template` SET `MinLevel`='42',`RewMoneyMaxLevel`='0' WHERE (`entry`='1127');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='1288');
UPDATE `quest_template` SET `MinLevel`='25',`QuestLevel`='25',`RewMoneyMaxLevel`='7590' WHERE (`entry`='1658');
UPDATE `quest_template` SET `MinLevel`='42',`RewMoneyMaxLevel`='0' WHERE (`entry`='2748');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='6120' WHERE (`entry`='2770');
UPDATE `quest_template` SET `MinLevel`='28',`QuestLevel`='35',`RewMoneyMaxLevel`='1650' WHERE (`entry`='2950');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='3381');
UPDATE `quest_template` SET `MinLevel`='40',`QuestLevel`='40',`RewMoneyMaxLevel`='0' WHERE (`entry`='3581');
UPDATE `quest_template` SET `MinLevel`='62',`QuestLevel`='64' WHERE (`entry`='9904');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='3660' WHERE (`entry`='4104');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='2520' WHERE (`entry`='4105');
UPDATE `quest_template` SET `QuestLevel`='55',`RewMoneyMaxLevel`='3660' WHERE (`entry`='4106');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='2520' WHERE (`entry`='4107');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='4108');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='4109');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4110');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='4111');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4112');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4114');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4113');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='330' WHERE (`entry`='4117');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='3363');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='330' WHERE (`entry`='4119');
UPDATE `quest_template` SET `MinLevel`='48',`RewMoneyMaxLevel`='0' WHERE (`entry`='1514');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4443');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4444');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4445');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4446');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4447');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4448');
UPDATE `quest_template` SET `MinLevel`='48',`RewMoneyMaxLevel`='0' WHERE (`entry`='4461');
UPDATE `quest_template` SET `MinLevel`='48',`RewMoneyMaxLevel`='0' WHERE (`entry`='4462');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='2878');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='9510');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='9346');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='9733');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='9734');
UPDATE `quest_template` SET `MinLevel`='25',`QuestLevel`='25',`RewMoneyMaxLevel`='1890' WHERE (`entry`='8373');
UPDATE `quest_template` SET `MinLevel`='25',`QuestLevel`='25',`RewMoneyMaxLevel`='1890' WHERE (`entry`='1657');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='24120' WHERE (`entry`='9588');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='24120' WHERE (`entry`='9391');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='24120' WHERE (`entry`='9340');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='24120' WHERE (`entry`='9410');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='24120' WHERE (`entry`='9401');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='24120' WHERE (`entry`='9438');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='24120' WHERE (`entry`='9406');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='24120' WHERE (`entry`='9400');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='11760' WHERE (`entry`='9361');
UPDATE `quest_template` SET `MinLevel`='62',`RewMoneyMaxLevel`='24960' WHERE (`entry`='9992');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='37440' WHERE (`entry`='10028');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='330' WHERE (`entry`='2523');
UPDATE `quest_template` SET `MinLevel`='48',`RewMoneyMaxLevel`='0' WHERE (`entry`='998');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='4561');
UPDATE `quest_template` SET `MinLevel`='25',`RewMoneyMaxLevel`='0' WHERE (`entry`='4606');
UPDATE `quest_template` SET `MinLevel`='50',`RewMoneyMaxLevel`='330' WHERE (`entry`='5401');
UPDATE `quest_template` SET `MinLevel`='50',`RewMoneyMaxLevel`='0' WHERE (`entry`='5405');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='6984');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='7045');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='5910' WHERE (`entry`='7603');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1320' WHERE (`entry`='7735');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8397');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8392');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8441');
UPDATE `quest_template` SET `MinLevel`='48',`QuestLevel`='55',`RewMoneyMaxLevel`='0' WHERE (`entry`='4401');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8442');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8434');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8433');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8406');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='0' WHERE (`entry`='8407');
UPDATE `quest_template` SET `QuestLevel`='42',`RewMoneyMaxLevel`='0' WHERE (`entry`='8551');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='75900' WHERE (`entry`='10962');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='75900' WHERE (`entry`='10966');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='75900' WHERE (`entry`='10954');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='75900' WHERE (`entry`='10952');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='75900' WHERE (`entry`='10950');
UPDATE `quest_template` SET `RewMoneyMaxLevel`='46620' WHERE (`entry`='9490');

# JODE
DROP TABLE IF EXISTS `game_graveyard_zone`;
SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for game_graveyard_zone
-- ----------------------------
CREATE TABLE `game_graveyard_zone` (
  `id` int(11) unsigned NOT NULL default '0',
  `ghost_zone` int(11) unsigned NOT NULL default '0',
  `faction` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`,`ghost_zone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Trigger System';
-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `game_graveyard_zone` (id,ghost_zone,`faction`) VALUES
(5,1,469),#Dun Morogh<-Dun Morogh [Alliance]
(7,1,67),#Wetlands, Crossroads<-Dun Morogh [Horde]
(100,1,0),#Dun Morogh, Anvilmar<-Dun Morogh
(101,1,0),#Dun Morogh, Kharanos<-Dun Morogh
(852,1,0),#Dun Morogh, Gates of Ironforge<-Dun Morogh
(8,3,0),#Badlands, Graveyard NE <-Badlands
(103,3,67),#Badlands, Kargath<-Badlands [Horde]
(1288,3,0),#Badlands, South GY<-Badlands
(370,4,0),#Blasted Lands, Dreadmaul Hold<-Blasted Lands
(108,8,0),#Swamp of Sorrows, Stonard<-Swamp of Sorrows
(3,10,469),#Duskwood, Darkshire<-Duskwood [Alliance]
(911,10,0),#Duskwood, Ravenhill<-Duskwood
(7,11,0),#Wetlands, Crossroads<-Wetlands
(489,11,469),#Wetlands, Baradin Bay<-Wetlands [Alliance]
(105,12,469),#Elwynn Forest, Northshire<-Elwynn Forest [Alliance]
(106,12,0),#Elwynn Forest, Goldshire<-Elwynn Forest
(854,12,0),#Elwynn Forest, Eastvale Logging Camp<-Elwynn Forest
(911,12,67),#Duskwood, Ravenhill<-Elwynn Forest [Horde]
(32,14,67),#Durotar, Razor Hill<-Durotar [Horde]
(249,14,469),#The Barrens, Ratchet<-Durotar [Alliance]
(649,14,67),#Durotar, Sen'jin Village<-Durotar [Horde]
(709,14,67),#Durotar, Valley of Trials<-Durotar [Horde]
(850,14,67),#Durotar, Northern Durotar<-Durotar [Horde]
(189,15,469),#Dustwallow Marsh, Theramore Isle<-Dustwallow Marsh [Alliance]
(631,15,67),#Dustwallow Marsh, Brackenwall Village<-Dustwallow Marsh [Horde]
(1264,15,0),#Dustwallow Marsh, Tabetha's<-Dustwallow Marsh
(1265,15,0),#Dustwallow Marsh, Mudsprocket<-Dustwallow Marsh
(369,16,469),#Azshara, Talrendis Point<-Azshara [Alliance]
(609,16,0),#Azshara, Southridge Beach<-Azshara
(630,16,0),#Azshara, Legash Encampment<-Azshara
(10,17,67),#The Barrens, The Crossroads<-The Barrens [Horde]
(39,17,469),#Thousand Needles, The Great Lift<-The Barrens [Alliance]
(229,17,67),#The Barrens, Camp Taurajo<-The Barrens [Horde]
(249,17,0),#The Barrens, Ratchet<-The Barrens
(1289,17,0),#The Barrens, South GY<-The Barrens
(529,22,0),#Programmer Isle<-Programmer Isle
(669,22,0),#Programmer Isle, Bucklers Cemetery 2<-Programmer Isle
(670,22,0),#Programmer Isle, Bucklers Cemetery 1<-Programmer Isle
(671,22,0),#Programmer Isle, Bucklers Cemetery 3<-Programmer Isle
(509,28,469),#Western Plaguelands, Chillwind Camp<-Western Plaguelands [Alliance]
(569,28,67),#Western Plaguelands, Bulwark<-Western Plaguelands [Horde]
(1286,28,0),#Western Plaguelands, Central GY<-Western Plaguelands
(109,33,0),#Stranglethorn Vale, Booty Bay<-Stranglethorn Vale
(389,33,469),#Stranglethorn Vale, Northern Stranglethorn<-Stranglethorn Vale [Alliance]
(98,36,67),#Hillsbrad Foothills, Tarren Mill<-Alterac Mountains [Horde]
(149,36,469),#Hillsbrad Foothills, Southshore<-Alterac Mountains [Alliance]
(1285,36,0),#Alterac Mountains, Central GY<-Alterac Mountains
(6,38,469),#Loch Modan, Thelsamar<-Loch Modan [Alliance]
(7,38,67),#Wetlands, Crossroads<-Loch Modan [Horde]
(4,40,469),#Westfall, Sentinel Hill<-Westfall [Alliance]
(911,40,67),#Duskwood, Ravenhill<-Westfall [Horde]
(36,41,0),#Deadwind Pass, Morgan's Plot<-Deadwind Pass
(104,44,469),#Redridge Mountains, Lakeshire<-Redridge Mountains [Alliance]
(911,44,67),#Duskwood, Ravenhill<-Redridge Mountains [Horde]
(99,45,0),#Arathi Highlands<-Arathi Highlands
(632,46,0),#Burning Steppes, Flame Crest<-Burning Steppes
(349,47,469),#The Hinterlands, Aerie Peak<-The Hinterlands [Alliance]
(789,47,0),#The Hinterlands, The Overlook Cliffs<-The Hinterlands
(636,51,0),#Searing Gorge, Thorium Point<-Searing Gorge
(1287,51,0),#Searing Gorge, SE GY<-Searing Gorge
(94,85,67),#Tirisfal Glades, Deathknell<-Tirisfal Glades [Horde]
(289,85,67),#Tirisfal Glades, Brill<-Tirisfal Glades [Horde]
(569,85,67),#Western Plaguelands, Bulwark<-Tirisfal Glades [Horde]
(1256,85,469),#Silverpine Forest, South GY<-Tirisfal Glades [Alliance]
(97,130,67),#Silverpine Forest, The Sepulcher<-Silverpine Forest [Horde]
(1256,130,0),#Silverpine Forest, South GY<-Silverpine Forest
(510,139,0),#Eastern Plaguelands, Light's Hope Chapel<-Eastern Plaguelands
(634,139,0),#Eastern Plaguelands, Darrowshire<-Eastern Plaguelands
(909,139,0),#Eastern Plaguelands, Blackwood Lake<-Eastern Plaguelands
(927,139,0),#Eastern Plaguelands, Graveyard CG Tower<-Eastern Plaguelands
(90,141,469),#Teldrassil, Darnassus<-Teldrassil [Alliance]
(91,141,469),#Teldrassil, Dolanaar<-Teldrassil [Alliance]
(93,141,469),#Teldrassil, Aldrassil<-Teldrassil [Alliance]
(129,141,469),#Teldrassil, Rut'theran Village<-Teldrassil [Alliance]
(512,141,67),#Ashenvale, Kargathia<-Teldrassil [Horde]
(35,148,469),#Darkshore, Auberdine<-Darkshore [Alliance]
(469,148,469),#Darkshore, Twilight Vale<-Darkshore [Alliance]
(512,148,67),#Ashenvale, Kargathia<-Darkshore [Horde]
(1256,209,0),#Silverpine Forest, South GY<-Shadowfang Keep
(4,214,469),#Westfall, Sentinel Hill<-The Great Sea [Alliance]
(97,214,67),#Silverpine Forest, The Sepulcher<-The Great Sea [Horde]
(34,215,67),#Mulgore, Red Cloud Mesa<-Mulgore [Horde]
(89,215,67),#Mulgore, Bloodhoof Village<-Mulgore [Horde]
(249,215,469),#The Barrens, Ratchet<-Mulgore [Alliance]
(851,215,67),#Mulgore, Thunder Bluff<-Mulgore [Horde]
(98,267,67),#Hillsbrad Foothills, Tarren Mill<-Hillsbrad Foothills [Horde]
(149,267,469),#Hillsbrad Foothills, Southshore<-Hillsbrad Foothills [Alliance]
(92,331,469),#Ashenvale, Astranaar<-Ashenvale [Alliance]
(512,331,67),#Ashenvale, Kargathia<-Ashenvale [Horde]
(35,332,469),#Darkshore, Auberdine<-The Great Sea [Alliance]
(649,332,67),#Durotar, Sen'jin Village<-The Great Sea [Horde]
(309,357,469),#Feralas, Feathermoon Stronghold<-Feralas [Alliance]
(310,357,67),#Feralas, Camp Mojache<-Feralas [Horde]
(849,357,0),#Feralas, Dire Maul<-Feralas
(449,361,0),#Felwood, Morlos'Aran<-Felwood
(635,361,0),#Felwood, Irontree Woods<-Felwood
(39,400,0),#Thousand Needles, The Great Lift<-Thousand Needles
(329,400,0),#Thousand Needles, Shimmering Flats<-Thousand Needles
(31,405,0),#Desolace, Ghost Walker Post<-Desolace
(409,406,0),#Stonetalon Mountains, Webwinder Path<-Stonetalon Mountains
(1279,406,0),#Stonetalon Mountains, Charred Vale<-Stonetalon Mountains
(1280,406,0),#Stonetalon Mountains, Peak GY<-Stonetalon Mountains
(209,440,0),#Tanaris, Gadgetzan<-Tanaris
(1281,440,0),#Tanaris, Pirate GY<-Tanaris
(1282,440,0),#Tanaris, Central GY<-Tanaris
(450,490,0),#Un'Goro Crater, The Marshlands<-Un'Goro Crater
(1277,490,0),#Un'Goro Crater, Central GY<-Un'Goro Crater
(1278,490,0),#Un'Goro Crater, Marshal's GY<-Un'Goro Crater
(39,491,0),#Thousand Needles, The Great Lift<-Razorfen Kraul
(1289,491,0),#The Barrens, South GY<-Razorfen Kraul
(633,493,0),#Moonglade<-Moonglade
(511,618,0),#Winterspring, Everlook<-Winterspring
(1283,618,0),#Winterspring, South GY<-Winterspring
(1284,618,0),#Winterspring, West GY<-Winterspring
(106,717,0),#Elwynn Forest, Goldshire<-The Stockade
(10,718,0),#The Barrens, The Crossroads<-Wailing Caverns
(92,719,0),#Ashenvale, Astranaar<-Blackfathom Deeps
(512,719,0),#Ashenvale, Kargathia<-Blackfathom Deeps
(100,721,0),#Dun Morogh, Anvilmar<-Gnomeregan
(101,721,0),#Dun Morogh, Kharanos<-Gnomeregan
(102,721,0),#Dun Morogh, Ironforge<-Gnomeregan
(39,722,0),#Thousand Needles, The Great Lift<-Razorfen Downs
(1289,722,0),#The Barrens, South GY<-Razorfen Downs
(429,796,0),#Tirisfal Glades, Faol's Rest<-Scarlet Monastery
(589,876,0),#GM Island<-GM Island
(209,1176,0),#Tanaris, Gadgetzan<-Zul'Farrak
(8,1337,0),#Badlands, Graveyard NE <-Uldaman
(70,1377,0),#Silithus, Valor's Rest<-Silithus
(910,1377,0),#Silithus, Cenarion Hold<-Silithus
(108,1417,0),#Swamp of Sorrows, Stonard<-Sunken Temple
(108,1477,0),#Swamp of Sorrows, Stonard<-The Temple of Atal'Hakkar
(309,1477,0),#Feralas, Feathermoon Stronghold<-The Temple of Atal'Hakkar
(789,1477,0),#The Hinterlands, The Overlook Cliffs<-The Temple of Atal'Hakkar
(289,1497,67),#Tirisfal Glades, Brill<-Undercity [Horde]
(106,1519,0),#Elwynn Forest, Goldshire<-Stormwind City
(107,1519,469),#Elwynn Forest, Stormwind<-Stormwind City [Alliance]
(852,1537,469),#Dun Morogh, Gates of Ironforge<-Ironforge [Alliance]
(4,1581,0),#Westfall, Sentinel Hill<-The Deadmines
(389,1581,0),#Stranglethorn Vale, Northern Stranglethorn<-The Deadmines
(632,1583,0),#Burning Steppes, Flame Crest<-Blackrock Spire
(632,1584,0),#Burning Steppes, Flame Crest<-Blackrock Depths
(39,1637,469),#Thousand Needles, The Great Lift<-Orgrimmar [Alliance]
(850,1637,0),#Durotar, Northern Durotar<-Orgrimmar
(39,1638,469),#Thousand Needles, The Great Lift<-Thunder Bluff [Alliance]
(89,1638,67),#Mulgore, Bloodhoof Village<-Thunder Bluff [Horde]
(851,1638,0),#Mulgore, Thunder Bluff<-Thunder Bluff
(90,1657,0),#Teldrassil, Darnassus<-Darnassus
(512,1657,67),#Ashenvale, Kargathia<-Darnassus [Horde]
(209,1941,0),#Tanaris, Gadgetzan<-Caverns of Time
(389,1977,0),#Stranglethorn Vale, Northern Stranglethorn<-Zul'Gurub
(909,2017,0),#Eastern Plaguelands, Blackwood Lake<-Stratholme
(629,2057,0),#TEST for GM Client Only - Do Not Bug<-Scholomance
(869,2057,0),#Western Plaguelands, Caer Darrow<-Scholomance
(31,2100,0),#Desolace, Ghost Walker Post<-Maraudon
(631,2159,0),#Dustwallow Marsh, Brackenwall Village<-Onyxia's Lair
(1249,2366,0),#Tanaris, CoT<-The Black Morass
(1249,2367,0),#Tanaris, CoT<-Old Hillsbrad Foothills
(850,2437,0),#Durotar, Northern Durotar<-Ragefire Chasm
(849,2557,0),#Feralas, Dire Maul<-Dire Maul
(632,2677,0),#Burning Steppes, Flame Crest<-Blackwing Lair
(632,2717,0),#Burning Steppes, Flame Crest<-Molten Core
(913,3428,0),#Silithus, Scarab Wall (AQ Only)<-Ahn'Qiraj
(913,3429,0),#Silithus, Scarab Wall (AQ Only)<-Ruins of Ahn'Qiraj
(909,3430,0),#Eastern Plaguelands, Blackwood Lake<-Eversong Woods
(912,3430,67),#Eversong Woods, Sunstrider Isle<-Eversong Woods [Horde]
(914,3430,67),#Eversong Woods, Farstrider Lodge GY<-Eversong Woods [Horde]
(921,3430,67),#Eversong Woods, Silvermoon City<-Eversong Woods [Horde]
(922,3430,67),#Eversong Woods, Fairbreeze GY<-Eversong Woods [Horde]
(909,3433,0),#Eastern Plaguelands, Blackwood Lake<-Ghostlands
(915,3433,67),#Ghostlands, Tranquillien<-Ghostlands [Horde]
(916,3433,67),#Ghostlands, Sanctum<-Ghostlands [Horde]
(922,3455,0),#Eversong Woods, Fairbreeze GY<-The North Sea
(909,3456,0),#Eastern Plaguelands, Blackwood Lake<-Naxxramas
(36,3457,0),#Deadwind Pass, Morgan's Plot<-Karazhan
(1265,3459,0),#Dustwallow Marsh, Mudsprocket<-City
(913,3478,0),#Silithus, Scarab Wall (AQ Only)<-Gates of Ahn'Qiraj
(924,3479,0),#Azuremyst, Stillpine GY<-The Veiled Sea
(919,3483,67),#Hellfire Peninsula, Thrallmar<-Hellfire Peninsula [Horde]
(920,3483,469),#Hellfire Peninsula, Honor Hold<-Hellfire Peninsula [Alliance]
(933,3483,469),#Hellfire Peninsula, Temple<-Hellfire Peninsula [Alliance]
(934,3483,67),#Hellfire Peninsula, Falcon Watch<-Hellfire Peninsula [Horde]
(1040,3483,67),#Hellfire Peninsula, Throne of Kil'Jaedan<-Hellfire Peninsula [Horde]
(1041,3483,0),#Hellfire Peninsula, Dark Portal<-Hellfire Peninsula
(1240,3483,469),#Hellfire Peninsula, Force Camps (Alliance)<-Hellfire Peninsula [Alliance]
(1248,3483,67),#Hellfire Peninsula, Spinebreaker GY<-Hellfire Peninsula [Horde]
(921,3487,67),#Eversong Woods, Silvermoon City<-Silvermoon City [Horde]
(930,3518,0),#Nagrand, SE Graveyard<-Nagrand
(992,3518,0),#Nagrand, Northwind Cleft<-Nagrand
(993,3518,0),#Nagrand, Halaa GY<-Nagrand
(1037,3518,0),#Nagrand, Portal Plateau<-Nagrand
(1038,3518,0),#Nagrand, Elemental Plateau<-Nagrand
(1039,3518,0),#Nagrand, SW Graveyard<-Nagrand
(994,3519,0),#Terokkar Forest, Shattrath GY<-Terokkar Forest
(995,3519,0),#Terokkar Forest, Wilderness GY<-Terokkar Forest
(1042,3519,0),#Terokkar Forest, Bone Wastes GY<-Terokkar Forest
(1051,3519,0),#Terokkar Forest, Skettis GY<-Terokkar Forest
(1257,3519,0),#Terokkar Forest, Ogre GY<-Terokkar Forest
(1047,3520,67),#Shadowmoon Valley, Shadowmoon Village GY<-Shadowmoon Valley [Horde]
(1048,3520,469),#Shadowmoon Valley, Wildhammer GY<-Shadowmoon Valley [Alliance]
(1250,3520,0),#Shadowmoon Valley, Altar GY<-Shadowmoon Valley
(1251,3520,0),#Shadowmoon Valley, Sanctum GY<-Shadowmoon Valley
(928,3521,67),#Zangarmarsh, Zabra'jin GY<-Zangarmarsh [Horde]
(969,3521,0),#Zangarmarsh, PvP GY<-Zangarmarsh
(970,3521,469),#Zangarmarsh, Telredor GY<-Zangarmarsh [Alliance]
(973,3521,0),#Zangarmarsh, Cenarion GY<-Zangarmarsh
(1043,3521,469),#Zangarmarsh, Harborage GY<-Zangarmarsh [Alliance]
(1044,3521,0),#Zangarmarsh, Sporeggar GY<-Zangarmarsh
(1049,3522,469),#Blade's Edge, Sylvanaar GY<-Blade's Edge Mountains [Alliance]
(1050,3522,67),#Blade's Edge, Thunderlord GY<-Blade's Edge Mountains [Horde]
(1241,3522,0),#Blade's Edge, Evergrove GY<-Blade's Edge Mountains
(1242,3522,0),#Blade's Edge, North Ridge GY<-Blade's Edge Mountains
(1243,3522,0),#Blade's Edge, West Ridge GY<-Blade's Edge Mountains
(1244,3522,0),#Blade's Edge, East Ridge GY<-Blade's Edge Mountains
(1253,3522,469),#Blade's Edge, Toshley GY<-Blade's Edge Mountains [Alliance]
(1254,3522,0),#Blade's Edge, Raven Wood GY<-Blade's Edge Mountains
(1255,3522,0),#Blade's Edge, NE Ridge GY<-Blade's Edge Mountains
(1045,3523,0),#Netherstorm, Stormspire GY<-Netherstorm
(1046,3523,0),#Netherstorm, Area 52 GY<-Netherstorm
(1247,3523,0),#Netherstorm, Cosmowrench GY<-Netherstorm
(1252,3523,0),#Netherstorm, Kirin'Var GY<-Netherstorm
(512,3524,0),#Ashenvale, Kargathia<-Azuremyst Isle
(918,3524,469),#Azuremyst Isle, Ammen Vale<-Azuremyst Isle [Alliance]
(923,3524,469),#Azuremyst, Azure Watch GY<-Azuremyst Isle [Alliance]
(924,3524,469),#Azuremyst, Stillpine GY<-Azuremyst Isle [Alliance]
(512,3525,0),#Ashenvale, Kargathia<-Bloodmyst Isle
(925,3525,469),#Bloodmyst, Blood Watch GY<-Bloodmyst Isle [Alliance]
(926,3525,469),#Bloodmyst, Wilderness GY<-Bloodmyst Isle [Alliance]
(919,3535,0),#Hellfire Peninsula, Thrallmar<-Hellfire Citadel
(920,3535,0),#Hellfire Peninsula, Honor Hold<-Hellfire Citadel
(1041,3540,0),#Hellfire Peninsula, Dark Portal<-Twisting Nether
(1240,3540,469),#Hellfire Peninsula, Force Camps (Alliance)<-Twisting Nether [Alliance]
(1248,3540,67),#Hellfire Peninsula, Spinebreaker GY<-Twisting Nether [Horde]
(1044,3540,0),#Zangarmarsh, Sporeggar GY<-Twisting Nether
(1037,3540,0),#Nagrand, Portal Plateau<-Twisting Nether
(1039,3540,0),#Nagrand, SW Graveyard<-Twisting Nether
(995,3540,0),#Terokkar Forest, Wilderness GY<-Twisting Nether
(1042,3540,0),#Terokkar Forest, Bone Wastes GY<-Twisting Nether
(1243,3540,0),#Blade's Edge, West Ridge GY<-Twisting Nether
(1244,3540,0),#Blade's Edge, East Ridge GY<-Twisting Nether
(1242,3540,0),#Blade's Edge, North Ridge GY<-Twisting Nether
(1254,3540,0),#Blade's Edge, Raven Wood GY<-Twisting Nether
(1046,3540,0),#Netherstorm, Area 52 GY<-Twisting Nether
(1252,3540,0),#Netherstorm, Kirin'Var GY<-Twisting Nether
(1247,3540,0),#Netherstorm, Cosmowrench GY<-Twisting Nether
(1045,3540,0),#Netherstorm, Stormspire GY<-Twisting Nether
(1250,3540,0),#Shadowmoon Valley, Altar GY<-Twisting Nether
(1251,3540,0),#Shadowmoon Valley, Sanctum GY<-Twisting Nether
(1047,3540,67),#Shadowmoon Valley, Shadowmoon Village GY<-Twisting Nether [Horde]
(1048,3540,469),#Shadowmoon Valley, Wildhammer GY<-Twisting Nether [Alliance]
(923,3557,469),#Azuremyst, Azure Watch GY<-The Exodar [Alliance]
(919,3562,0),#Hellfire Peninsula, Thrallmar<-Hellfire Ramparts
(920,3562,0),#Hellfire Peninsula, Honor Hold<-Hellfire Ramparts
(1249,3606,0),#Tanaris, CoT<-Hyjal Summit
(969,3607,0),#Zangarmarsh, PvP GY<-Serpentshrine Cavern
(994,3703,0),#Terokkar Forest, Shattrath GY<-Shattrath City
(919,3713,0),#Hellfire Peninsula, Thrallmar<-The Blood Furnace
(920,3713,0),#Hellfire Peninsula, Honor Hold<-The Blood Furnace
(969,3715,0),#Zangarmarsh, PvP GY<-The Steamvault
(969,3716,0),#Zangarmarsh, PvP GY<-The Underbog
(969,3717,0),#Zangarmarsh, PvP GY<-The Slave Pens
(1042,3789,0),#Terokkar Forest, Bone Wastes GY<-Shadow Labyrinth
(1042,3790,0),#Terokkar Forest, Bone Wastes GY<-Auchenai Crypts
(1042,3791,0),#Terokkar Forest, Bone Wastes GY<-Sethekk Halls
(1042,3792,0),#Terokkar Forest, Bone Wastes GY<-Mana-Tombs
(917,3805,0),#Ghostlands, Amani Pass<-Zul'Aman
(919,3836,0),#Hellfire Peninsula, Thrallmar<-Magtheridon's Lair
(920,3836,0),#Hellfire Peninsula, Honor Hold<-Magtheridon's Lair
(1247,3845,0),#Netherstorm, Cosmowrench GY<-Tempest Keep
(1247,3847,0),#Netherstorm, Cosmowrench GY<-The Botanica
(1247,3848,0),#Netherstorm, Cosmowrench GY<-The Arcatraz
(1247,3849,0),#Netherstorm, Cosmowrench GY<-The Mechanar
(1242,3923,0),#Blade's Edge, North Ridge GY<-Gruul's Lair
(1262,3959,0);#Black Temple, Horde GY<-Black Temple

INSERT INTO `creature_template_addon` VALUES ('3617', '0', '0', '0', '0', '0', '16380 0');
INSERT INTO `creature_template_addon` VALUES ('18240', '0', '512', '7', '4097', '0', '');
INSERT INTO `creature_template_addon` VALUES ('16090', '0', '512', '8', '4097', '0', '');
INSERT INTO `creature_template_addon` VALUES ('23721', '0', '16777472', '0', '4097', '10', '');
INSERT INTO `creature_template_addon` VALUES ('3094', '0', '0', '0', '0', '0', '16380 0');
INSERT INTO `creature_template_addon` VALUES ('12936', '0', '512', '3', '4097', '0', '');
INSERT INTO `creature_template_addon` VALUES ('12937', '0', '512', '3', '4097', '0', '');
INSERT INTO `creature_template_addon` VALUES ('12938', '0', '512', '3', '4097', '0', '');
INSERT INTO `event_scripts` VALUES ('13052', '3', '10', '18430', '100000', '', '2534.55', '4007.9', '133.209', '4.06749');
INSERT INTO `event_scripts` VALUES ('13052', '15', '10', '18431', '100000', '', '2531.86', '4013.56', '133.815', '4.35965');
INSERT INTO `event_scripts` VALUES ('13052', '30', '10', '18394', '100000', '', '2533.75', '4007.99', '133.208', '3.41796');
INSERT INTO `event_scripts` VALUES ('13052', '45', '10', '18430', '100000', '', '2528.13', '3999.24', '132.698', '0.89761');
INSERT INTO `event_scripts` VALUES ('13052', '60', '10', '18431', '100000', '', '2532.62', '4002.53', '132.828', '1.9312');
INSERT INTO `event_scripts` VALUES ('13052', '75', '10', '18394', '100000', '', '2529.32', '4001.44', '132.815', '1.40734');
INSERT INTO `event_scripts` VALUES ('13052', '90', '10', '18430', '100000', '', '2526.62', '4008.99', '133.473', '5.46628');
INSERT INTO `event_scripts` VALUES ('13052', '105', '10', '18431', '100000', '', '2522.55', '4005.96', '133.451', '5.5943');
INSERT INTO `event_scripts` VALUES ('13052', '120', '10', '18394', '100000', '', '2525.31', '4007.75', '133.42', '5.94066');
INSERT INTO `event_scripts` VALUES ('3301', '0', '10', '7664', '900000', '', '-11239', '-2849', '157.945', '1.353');
INSERT INTO `event_scripts` VALUES ('3301', '20', '10', '7734', '900000', '', '-11230', '-2847', '157.866', '2.582');
INSERT INTO `event_scripts` VALUES ('3301', '40', '10', '7735', '900000', '', '-11243', '-2841', '158.019', '0.006');
INSERT INTO `npc_text` VALUES ('10076', 'Ah, seeking training, are you? There are several instructors who are camped in Azure Watch... what are you after?', 'Ah, seeking training, are you? There are several instructors who are camped in Azure Watch... what are you after?', '7', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('10085', 'You\'re one of the shaman? Hm. I suppose you are free to choose your own path... whatever that path may be. Tuluun has an isolated, small camp in the northwest of Azure Watch.', 'You\'re one of the shaman? Hm. I suppose you are free to choose your own path... whatever that path may be. Tuluun has an isolated, small camp in the northwest of Azure Watch.', '7', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('9162', 'The draenei champion walks among us. This is a celebration for the savior of Azuremyst and Bloodmyst!', '', '0', '0', '1', '0', '1', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('9014', 'Greetings, young shaman.  Make yourself at home within my reef.', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('9015', 'Together we will deal with this corruption of the water.', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('8801', '', 'Is this city not beautiful, $c?  It warms my heart that we have found such good friends in these night elves.', '0', '0', '6', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('9016', 'You have done a great thing, $N.  You are welcome here at any time.', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('10950', 'Stand at attention, captain!', '', '0', '0', '113', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('10940', '<The Murkblood overseer grunts.>', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('10849', 'Sometimes those damnable blood elves stop by and require some inane reagent or poison. I must keep my stock of such items full at all times lest Lord Illidan get word of the Dragonmaw not cooperating...$B$B<Rumpus swallows hard.>$B$BWe don\'t want that...', 'Sometimes those damnable blood elves stop by and require some inane reagent or poison. I must keep my stock of such items full at all times lest Lord Illidan get word of the Dragonmaw not cooperating...$B$B<Rumpus swallows hard.>$B$BWe don\'t want that...', '0', '0', '1', '0', '1', '0', '274', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('11090', 'Drakes is my business, $N. I\'m authorized to sell them to our highest ranking officers.', '', '0', '0', '1', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('10848', 'You no make dis your home. Maybe you want eat someting?', '', '0', '0', '274', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('10947', 'I must leave this place at once!', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `npc_text` VALUES ('10877', 'Be quiet \'bout what you hear and see around here, $r.', '', '0', '0', '1', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `page_text` VALUES ('1992', 'As the fires of the Second War died down, the Alliance took aggressive steps to contain the orcish threat. A number of large internment camps, meant to house the captive orcs, were constructed in southern Lordaeron. Guarded by both the paladins and the veteran soldiers of the Alliance, \r\nthe camps proved to be a great success.\r\nThough the captive orcs were tense and anxious to do battle once more, the various camp wardens, based at the old prison-fortress of Durnholde, kept the peace and maintained a strong semblance of order.', '1993');
INSERT INTO `page_text` VALUES ('1993', 'However, on the hellish world of Draenor, a new orcish army prepared to strike at the unsuspecting Alliance. Ner\'zhul, the former mentor of Gul\'dan, rallied the remaining orc clans under his dark banner. \r\nAided by the Shadowmoon clan, the old shaman planned to open a number of portals on Draenor that would lead the Horde to new, unspoiled worlds.\r\n', '1994');
INSERT INTO `page_text` VALUES ('1994', 'To power his new portals, he needed a number of enchanted artifacts from Azeroth. \r\nTo procure them, Ner\'zhul reopened the Dark Portal and sent his ravenous servants charging through it.\r\n', '1995');
INSERT INTO `page_text` VALUES ('1995', 'The new Horde, led by veteran chieftains such as Grom Hellscream and Kilrogg Deadeye (of the Bleeding Hollow clan), surprised the Alliance defense forces and rampaged through the countryside. \r\nUnder Ner\'zhul\'s surgical command, the orcs quickly rounded up the artifacts that they needed and fled back to the safety of Draenor.\r\n', '1996');
INSERT INTO `page_text` VALUES ('1996', 'King Terenas of Lordaeron, convinced that the orcs were preparing a new invasion of Azeroth, assembled his most trusted lieutenants. \r\nHe ordered General Turalyon and the archmage, Khadgar, to lead an expedition through the Dark Portal to put an end to the orcish threat once and for all. \r\nTuralyon and Khadgar\'s forces marched into Draenor and repeatedly clashed with Ner\'zhul\'s clans upon the ravaged Hellfire Peninsula.', '1997');
INSERT INTO `page_text` VALUES ('1997', 'Even with the aid of the high elf Alleria Windrunner, the dwarf Kurdran Wildhammer, and the veteran soldier Danath Trollbane, Khadgar was unable to prevent Ner\'zhul from opening his portals to other worlds.', '1998');
INSERT INTO `page_text` VALUES ('1998', 'Ner\'zhul finally opened his portals to other worlds, but he did not foresee the terrible price he would pay. \r\nThe portals\' tremendous energies began to tear the very fabric of Draenor apart. \r\nAs Turalyon\'s forces fought desperately to return home to Azeroth, the world of Draenor began to buckle in upon itself. \r\nGrom Hellscream and Kilrogg Deadeye, realizing that Ner\'zhul\'s mad plans would doom their entire race, rallied the remaining orcs and escaped back to the relative safety of Azeroth.', '1999');
INSERT INTO `page_text` VALUES ('1999', 'On Draenor, Turalyon and Khadgar agreed to make the ultimate sacrifice by destroying the Dark Portal from their side. \r\nThough it would cost their lives, and the lives of their companions, they knew that it was the only way to ensure Azeroth\'s survival. \r\nEven as Hellscream and Deadeye hacked their way through the human ranks in a desperate bid for freedom, the Dark Portal exploded behind them. \r\nFor them, and the remaining orcs on Azeroth, there would be no going back.', '2000');
INSERT INTO `page_text` VALUES ('2000', 'Ner\'zhul and his loyal Shadowmoon clan passed through the largest of the newly created portals, as massive volcanic eruptions began to break Draenor\'s continents apart. \r\nThe burning seas rose up and roiled the shattered landscape as the tortured world was finally consumed in a massive, apocalyptic explosion.', '0');

# SUSANIN
DELETE FROM `quest_start_scripts` WHERE `id`='618';
UPDATE `quest_template` SET `StartScript`='0' WHERE `entry`='618';

# KiriX
UPDATE `event_scripts` SET `datalong`='15623' WHERE (`id`='9571');
UPDATE `creature_template` SET `faction_A`='14',`faction_H`='14' WHERE (`entry`='15623');


DELETE FROM `db_version`;
INSERT INTO `db_version` VALUES ('YTDB_092_r33.02_rev5264');
