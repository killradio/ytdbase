# KiriX
UPDATE `creature_template` SET `spell1`='745',`spell2`='6751',`spell3`='0' WHERE (`entry`='1986');
UPDATE `creature_template` SET `spell1`='745',`spell2`='6751',`spell3`='0' WHERE (`entry`='2001');
DELETE FROM gameobject WHERE guid = '779548';
DELETE FROM game_event_gameobject WHERE guid = '779548';
DELETE FROM gameobject WHERE guid = '779569';
DELETE FROM game_event_gameobject WHERE guid = '779569';
DELETE FROM gameobject WHERE guid = '779570';
DELETE FROM game_event_gameobject WHERE guid = '779570';
DELETE FROM gameobject WHERE guid = '779568';
DELETE FROM game_event_gameobject WHERE guid = '779568';
DELETE FROM gameobject WHERE guid = '779589';
DELETE FROM game_event_gameobject WHERE guid = '779589';
DELETE FROM gameobject WHERE guid = '779586';
DELETE FROM game_event_gameobject WHERE guid = '779586';
DELETE FROM gameobject WHERE guid = '779676';
DELETE FROM game_event_gameobject WHERE guid = '779676';
DELETE FROM gameobject WHERE guid = '779604';
DELETE FROM game_event_gameobject WHERE guid = '779604';
DELETE FROM gameobject WHERE guid = '779593';
DELETE FROM game_event_gameobject WHERE guid = '779593';
DELETE FROM gameobject WHERE guid = '779594';
DELETE FROM game_event_gameobject WHERE guid = '779594';
DELETE FROM gameobject WHERE guid = '779597';
DELETE FROM game_event_gameobject WHERE guid = '779597';
DELETE FROM gameobject WHERE guid = '779598';
DELETE FROM game_event_gameobject WHERE guid = '779598';
DELETE FROM gameobject WHERE guid = '779655';
DELETE FROM game_event_gameobject WHERE guid = '779655';
DELETE FROM gameobject WHERE guid = '779653';
DELETE FROM game_event_gameobject WHERE guid = '779653';
DELETE FROM gameobject WHERE guid = '779652';
DELETE FROM game_event_gameobject WHERE guid = '779652';
DELETE FROM gameobject WHERE guid = '779654';
DELETE FROM game_event_gameobject WHERE guid = '779654';
DELETE FROM gameobject WHERE guid = '779656';
DELETE FROM game_event_gameobject WHERE guid = '779656';
DELETE FROM gameobject WHERE guid = '779704';
DELETE FROM game_event_gameobject WHERE guid = '779704';
DELETE FROM gameobject WHERE guid = '779707';
DELETE FROM game_event_gameobject WHERE guid = '779707';
DELETE FROM gameobject WHERE guid = '779705';
DELETE FROM game_event_gameobject WHERE guid = '779705';
DELETE FROM gameobject WHERE guid = '779708';
DELETE FROM game_event_gameobject WHERE guid = '779708';
DELETE FROM gameobject WHERE guid = '779702';
DELETE FROM game_event_gameobject WHERE guid = '779702';
DELETE FROM gameobject WHERE guid = '779698';
DELETE FROM game_event_gameobject WHERE guid = '779698';
DELETE FROM gameobject WHERE guid = '779696';
DELETE FROM game_event_gameobject WHERE guid = '779696';
DELETE FROM gameobject WHERE guid = '779706';
DELETE FROM game_event_gameobject WHERE guid = '779706';
DELETE FROM gameobject WHERE guid = '779709';
DELETE FROM game_event_gameobject WHERE guid = '779709';
DELETE FROM gameobject WHERE guid = '779697';
DELETE FROM game_event_gameobject WHERE guid = '779697';
DELETE FROM gameobject WHERE guid = '779732';
DELETE FROM game_event_gameobject WHERE guid = '779732';
DELETE FROM gameobject WHERE guid = '779739';
DELETE FROM game_event_gameobject WHERE guid = '779739';
DELETE FROM gameobject WHERE guid = '782184';
DELETE FROM game_event_gameobject WHERE guid = '782184';
DELETE FROM gameobject WHERE guid = '782183';
DELETE FROM game_event_gameobject WHERE guid = '782183';
DELETE FROM gameobject WHERE guid = '775118';
DELETE FROM game_event_gameobject WHERE guid = '775118';
DELETE FROM gameobject WHERE guid = '779786';
DELETE FROM game_event_gameobject WHERE guid = '779786';
DELETE FROM gameobject WHERE guid = '779785';
DELETE FROM game_event_gameobject WHERE guid = '779785';
DELETE FROM gameobject WHERE guid = '779809';
DELETE FROM game_event_gameobject WHERE guid = '779809';
DELETE FROM gameobject WHERE guid = '779808';
DELETE FROM game_event_gameobject WHERE guid = '779808';
DELETE FROM gameobject WHERE guid = '779807';
DELETE FROM game_event_gameobject WHERE guid = '779807';
DELETE FROM gameobject WHERE guid = '779873';
DELETE FROM game_event_gameobject WHERE guid = '779873';
DELETE FROM gameobject WHERE guid = '779592';
DELETE FROM game_event_gameobject WHERE guid = '779592';
DELETE FROM gameobject WHERE guid = '775746';
DELETE FROM game_event_gameobject WHERE guid = '775746';
DELETE FROM gameobject WHERE guid = '775747';
DELETE FROM game_event_gameobject WHERE guid = '775747';
DELETE FROM gameobject WHERE guid = '775887';
DELETE FROM game_event_gameobject WHERE guid = '775887';
DELETE FROM gameobject WHERE guid = '775888';
DELETE FROM game_event_gameobject WHERE guid = '775888';
DELETE FROM gameobject WHERE guid = '775305';
DELETE FROM game_event_gameobject WHERE guid = '775305';
DELETE FROM gameobject WHERE guid = '7863';
DELETE FROM game_event_gameobject WHERE guid = '7863';
DELETE FROM gameobject WHERE guid = '10640';
DELETE FROM game_event_gameobject WHERE guid = '10640';
DELETE FROM gameobject WHERE guid = '13393';
DELETE FROM game_event_gameobject WHERE guid = '13393';
DELETE FROM gameobject WHERE guid = '10638';
DELETE FROM game_event_gameobject WHERE guid = '10638';
DELETE FROM gameobject WHERE guid = '74578';
DELETE FROM game_event_gameobject WHERE guid = '74578';
DELETE FROM gameobject WHERE guid = '74603';
DELETE FROM game_event_gameobject WHERE guid = '74603';
DELETE FROM gameobject WHERE guid = '14001';
DELETE FROM game_event_gameobject WHERE guid = '14001';
DELETE FROM gameobject WHERE guid = '4601';
DELETE FROM game_event_gameobject WHERE guid = '4601';
DELETE FROM gameobject WHERE guid = '74337';
DELETE FROM game_event_gameobject WHERE guid = '74337';
DELETE FROM gameobject WHERE guid = '74335';
DELETE FROM game_event_gameobject WHERE guid = '74335';
DELETE FROM gameobject WHERE guid = '74339';
DELETE FROM game_event_gameobject WHERE guid = '74339';
DELETE FROM gameobject WHERE guid = '16190';
DELETE FROM game_event_gameobject WHERE guid = '16190';
DELETE FROM gameobject WHERE guid = '74355';
DELETE FROM game_event_gameobject WHERE guid = '74355';
DELETE FROM gameobject WHERE guid = '7189';
DELETE FROM game_event_gameobject WHERE guid = '7189';
DELETE FROM gameobject WHERE guid = '8616';
DELETE FROM game_event_gameobject WHERE guid = '8616';
DELETE FROM gameobject WHERE guid = '16995';
DELETE FROM game_event_gameobject WHERE guid = '16995';
DELETE FROM gameobject WHERE guid = '10230';
DELETE FROM game_event_gameobject WHERE guid = '10230';
DELETE FROM gameobject WHERE guid = '16183';
DELETE FROM game_event_gameobject WHERE guid = '16183';
DELETE FROM gameobject WHERE guid = '3883';
DELETE FROM game_event_gameobject WHERE guid = '3883';
DELETE FROM gameobject WHERE guid = '6169';
DELETE FROM game_event_gameobject WHERE guid = '6169';
DELETE FROM gameobject WHERE guid = '74444';
DELETE FROM game_event_gameobject WHERE guid = '74444';
DELETE FROM gameobject WHERE guid = '13223';
DELETE FROM game_event_gameobject WHERE guid = '13223';
DELETE FROM gameobject WHERE guid = '10886';
DELETE FROM game_event_gameobject WHERE guid = '10886';
DELETE FROM gameobject WHERE guid = '17545';
DELETE FROM game_event_gameobject WHERE guid = '17545';
DELETE FROM gameobject WHERE guid = '74533';
DELETE FROM game_event_gameobject WHERE guid = '74533';
DELETE FROM gameobject WHERE guid = '74397';
DELETE FROM game_event_gameobject WHERE guid = '74397';
DELETE FROM gameobject WHERE guid = '9976';
DELETE FROM game_event_gameobject WHERE guid = '9976';
DELETE FROM gameobject WHERE guid = '4800';
DELETE FROM game_event_gameobject WHERE guid = '4800';
DELETE FROM gameobject WHERE guid = '74415';
DELETE FROM game_event_gameobject WHERE guid = '74415';
DELETE FROM gameobject WHERE guid = '74448';
DELETE FROM game_event_gameobject WHERE guid = '74448';
DELETE FROM gameobject WHERE guid = '5834';
DELETE FROM game_event_gameobject WHERE guid = '5834';
DELETE FROM gameobject WHERE guid = '74450';
DELETE FROM game_event_gameobject WHERE guid = '74450';
DELETE FROM gameobject WHERE guid = '9197';
DELETE FROM game_event_gameobject WHERE guid = '9197';
DELETE FROM gameobject WHERE guid = '74383';
DELETE FROM game_event_gameobject WHERE guid = '74383';
DELETE FROM gameobject WHERE guid = '775979';
DELETE FROM game_event_gameobject WHERE guid = '775979';
DELETE FROM gameobject WHERE guid = '74664';
DELETE FROM game_event_gameobject WHERE guid = '74664';
DELETE FROM gameobject WHERE guid = '74668';
DELETE FROM game_event_gameobject WHERE guid = '74668';
DELETE FROM gameobject WHERE guid = '14293';
DELETE FROM game_event_gameobject WHERE guid = '14293';
DELETE FROM gameobject WHERE guid = '14788';
DELETE FROM game_event_gameobject WHERE guid = '14788';
DELETE FROM gameobject WHERE guid = '17001';
DELETE FROM game_event_gameobject WHERE guid = '17001';
DELETE FROM gameobject WHERE guid = '14580';
DELETE FROM game_event_gameobject WHERE guid = '14580';
DELETE FROM gameobject WHERE guid = '74643';
DELETE FROM game_event_gameobject WHERE guid = '74643';
DELETE FROM gameobject WHERE guid = '74644';
DELETE FROM game_event_gameobject WHERE guid = '74644';
DELETE FROM gameobject WHERE guid = '74741';
DELETE FROM game_event_gameobject WHERE guid = '74741';
DELETE FROM gameobject WHERE guid = '74740';
DELETE FROM game_event_gameobject WHERE guid = '74740';
DELETE FROM gameobject WHERE guid = '74739';
DELETE FROM game_event_gameobject WHERE guid = '74739';
DELETE FROM gameobject WHERE guid = '74738';
DELETE FROM game_event_gameobject WHERE guid = '74738';
DELETE FROM gameobject WHERE guid = '74743';
DELETE FROM game_event_gameobject WHERE guid = '74743';
DELETE FROM gameobject WHERE guid = '74744';
DELETE FROM game_event_gameobject WHERE guid = '74744';
DELETE FROM gameobject WHERE guid = '74753';
DELETE FROM game_event_gameobject WHERE guid = '74753';
DELETE FROM gameobject WHERE guid = '601';
DELETE FROM game_event_gameobject WHERE guid = '601';
DELETE FROM gameobject WHERE guid = '74011';
DELETE FROM game_event_gameobject WHERE guid = '74011';
DELETE FROM gameobject WHERE guid = '74007';
DELETE FROM game_event_gameobject WHERE guid = '74007';
DELETE FROM gameobject WHERE guid = '74009';
DELETE FROM game_event_gameobject WHERE guid = '74009';
DELETE FROM gameobject WHERE guid = '74010';
DELETE FROM game_event_gameobject WHERE guid = '74010';
DELETE FROM gameobject WHERE guid = '74008';
DELETE FROM game_event_gameobject WHERE guid = '74008';
DELETE FROM gameobject WHERE guid = '74006';
DELETE FROM game_event_gameobject WHERE guid = '74006';
DELETE FROM gameobject WHERE guid = '74005';
DELETE FROM game_event_gameobject WHERE guid = '74005';
DELETE FROM gameobject WHERE guid = '74023';
DELETE FROM game_event_gameobject WHERE guid = '74023';
DELETE FROM gameobject WHERE guid = '74021';
DELETE FROM game_event_gameobject WHERE guid = '74021';
DELETE FROM gameobject WHERE guid = '74022';
DELETE FROM game_event_gameobject WHERE guid = '74022';
DELETE FROM gameobject WHERE guid = '74069';
DELETE FROM game_event_gameobject WHERE guid = '74069';
DELETE FROM gameobject WHERE guid = '783388';
DELETE FROM game_event_gameobject WHERE guid = '783388';
DELETE FROM gameobject WHERE guid = '74062';
DELETE FROM game_event_gameobject WHERE guid = '74062';
DELETE FROM gameobject WHERE guid = '74071';
DELETE FROM game_event_gameobject WHERE guid = '74071';
DELETE FROM gameobject WHERE guid = '12072';
DELETE FROM game_event_gameobject WHERE guid = '12072';
DELETE FROM gameobject WHERE guid = '74073';
DELETE FROM game_event_gameobject WHERE guid = '74073';
DELETE FROM gameobject WHERE guid = '74074';
DELETE FROM game_event_gameobject WHERE guid = '74074';
DELETE FROM gameobject WHERE guid = '74079';
DELETE FROM game_event_gameobject WHERE guid = '74079';
DELETE FROM gameobject WHERE guid = '74076';
DELETE FROM game_event_gameobject WHERE guid = '74076';
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182326');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182320');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182322');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182327');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182324');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182321');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182334');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='190007');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182318');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182328');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182319');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='182333');
UPDATE `gameobject_template` SET `size`='1.34' WHERE (`name`='Old Town');
UPDATE `gameobject_template` SET `size`='1.34' WHERE (`name`='SI:7');
UPDATE `gameobject` SET `position_z`='99.4834' WHERE (`guid`='779591');
UPDATE `gameobject_template` SET `data0`='1',`data1`='1' WHERE (`entry`='179731');
UPDATE `gameobject_template` SET `size`='1.34' WHERE (`name`='Command Center');
UPDATE `gameobject_template` SET `size`='1.34' WHERE (`name`='Champions\' Hall');
UPDATE `gameobject_template` SET `size`='1.34' WHERE (`name`='Dwarven District');
UPDATE `gameobject_template` SET `size`='1.34' WHERE (`name`='Mage Quarter'); # '
UPDATE `gameobject` SET `id`='3197' WHERE (`guid`='74020');
UPDATE `creature` SET `spawndist`='0',`MovementType`='0' WHERE (`id`='21997');
UPDATE `creature_template` SET `speed`='1' WHERE (`entry`='1642');
UPDATE `creature_template` SET `resistance1`='0';
UPDATE `creature_template` SET `faction_A`='65',`faction_H`='65' WHERE (`entry`='7234');
UPDATE `creature_template` SET `mindmg`='3',`maxdmg`='6',`attackpower`='30' WHERE (`entry`='7235');

# Kanabiz
UPDATE `creature_template` SET `npcflag` = 128 WHERE `entry` = 26378;
DELETE FROM `npc_vendor` WHERE `entry` = '26378';
INSERT INTO `npc_vendor` (entry, item, maxcount, incrtime, ExtendedCost) VALUES 
(26378, 34985, 0, 0, 1758),
(26378, 34986, 0, 0, 2364),
(26378, 34987, 0, 0, 2360),
(26378, 34988, 0, 0, 2363),
(26378, 34989, 0, 0, 2360),
(26378, 34995, 0, 0, 2363),
(26378, 34996, 0, 0, 2362),
(26378, 34997, 0, 0, 2360),
(26378, 35008, 0, 0, 2342),
(26378, 35014, 0, 0, 2361),
(26378, 35015, 0, 0, 2360),
(26378, 35016, 0, 0, 2342),
(26378, 35017, 0, 0, 2363),
(26378, 35018, 0, 0, 2360),
(26378, 35019, 0, 0, 1758),
(26378, 35020, 0, 0, 1758),
(26378, 35021, 0, 0, 1758),
(26378, 35032, 0, 0, 2342),
(26378, 35033, 0, 0, 2365),
(26378, 35034, 0, 0, 2366),
(26378, 35035, 0, 0, 2359),
(26378, 35036, 0, 0, 2337),
(26378, 35037, 0, 0, 2363),
(26378, 35038, 0, 0, 2363),
(26378, 35039, 0, 0, 1758),
(26378, 35040, 0, 0, 1758),
(26378, 35041, 0, 0, 1758),
(26378, 35047, 0, 0, 2360),
(26378, 35058, 0, 0, 2363),
(26378, 35064, 0, 0, 2360),
(26378, 35065, 0, 0, 1758),
(26378, 35071, 0, 0, 2362),
(26378, 35072, 0, 0, 2363),
(26378, 35073, 0, 0, 2364),
(26378, 35074, 0, 0, 2342),
(26378, 35075, 0, 0, 2360),
(26378, 35076, 0, 0, 2362),
(26378, 35082, 0, 0, 2361),
(26378, 35093, 0, 0, 2362),
(26378, 35094, 0, 0, 2364),
(26378, 35095, 0, 0, 2363),
(26378, 35101, 0, 0, 2362),
(26378, 35102, 0, 0, 2361),
(26378, 35103, 0, 0, 2360),
(26378, 35104, 0, 0, 1758),
(26378, 35105, 0, 0, 1758),
(26378, 35106, 0, 0, 1758),
(26378, 35107, 0, 0, 1758),
(26378, 35108, 0, 0, 1758),
(26378, 35109, 0, 0, 2360),
(26378, 34990, 0, 0, 2364),
(26378, 34991, 0, 0, 1432),
(26378, 34992, 0, 0, 2364),
(26378, 34993, 0, 0, 2364),
(26378, 34994, 0, 0, 2359),
(26378, 36737, 0, 0, 2356),
(26378, 35110, 0, 0, 2356);
UPDATE `creature_template` SET `npcflag` = 128 WHERE `entry` = 26352;
DELETE FROM `npc_vendor` WHERE `entry` = '26352';
INSERT INTO `npc_vendor` (entry, item, maxcount, incrtime, ExtendedCost) VALUES 
(26352, 34985, 0, 0, 1758),
(26352, 34986, 0, 0, 2364),
(26352, 34987, 0, 0, 2360),
(26352, 34988, 0, 0, 2363),
(26352, 34989, 0, 0, 2360),
(26352, 34990, 0, 0, 2364),
(26352, 34991, 0, 0, 1432),
(26352, 34992, 0, 0, 2364),
(26352, 34993, 0, 0, 2364),
(26352, 34994, 0, 0, 2359),
(26352, 34995, 0, 0, 2363),
(26352, 34996, 0, 0, 2362),
(26352, 34997, 0, 0, 2360),
(26352, 34998, 0, 0, 2363),
(26352, 34999, 0, 0, 2365),
(26352, 35000, 0, 0, 2365),
(26352, 35001, 0, 0, 2359),
(26352, 35002, 0, 0, 2337),
(26352, 35003, 0, 0, 2363),
(26352, 35004, 0, 0, 2365),
(26352, 35005, 0, 0, 2366),
(26352, 35006, 0, 0, 2359),
(26352, 35007, 0, 0, 2337),
(26352, 35008, 0, 0, 2342),
(26352, 35009, 0, 0, 2359),
(26352, 35010, 0, 0, 2365),
(26352, 35011, 0, 0, 2363),
(26352, 35012, 0, 0, 2337),
(26352, 35013, 0, 0, 2366),
(26352, 35014, 0, 0, 2361),
(26352, 35015, 0, 0, 2360),
(26352, 35016, 0, 0, 2342),
(26352, 35017, 0, 0, 2363),
(26352, 35018, 0, 0, 2360),
(26352, 35019, 0, 0, 1758),
(26352, 35020, 0, 0, 1758),
(26352, 35021, 0, 0, 1758),
(26352, 35022, 0, 0, 2363),
(26352, 35023, 0, 0, 2365),
(26352, 35024, 0, 0, 2366),
(26352, 35025, 0, 0, 2359),
(26352, 35026, 0, 0, 2337),
(26352, 35027, 0, 0, 2337),
(26352, 35028, 0, 0, 2363),
(26352, 35029, 0, 0, 2365),
(26352, 35030, 0, 0, 2366),
(26352, 35031, 0, 0, 2359),
(26352, 35032, 0, 0, 2342),
(26352, 35033, 0, 0, 2365),
(26352, 35034, 0, 0, 2366),
(26352, 35035, 0, 0, 2359),
(26352, 35036, 0, 0, 2337),
(26352, 35037, 0, 0, 2363),
(26352, 35038, 0, 0, 2363),
(26352, 35039, 0, 0, 1758),
(26352, 35040, 0, 0, 1758),
(26352, 35041, 0, 0, 1758),
(26352, 35042, 0, 0, 2337),
(26352, 35043, 0, 0, 2363),
(26352, 35044, 0, 0, 2365),
(26352, 35045, 0, 0, 2366),
(26352, 35046, 0, 0, 2359),
(26352, 35047, 0, 0, 2360),
(26352, 35048, 0, 0, 2337),
(26352, 35049, 0, 0, 2363),
(26352, 35050, 0, 0, 2365),
(26352, 35051, 0, 0, 2366),
(26352, 35052, 0, 0, 2359),
(26352, 35053, 0, 0, 2363),
(26352, 35054, 0, 0, 2365),
(26352, 35055, 0, 0, 2366),
(26352, 35056, 0, 0, 2359),
(26352, 35057, 0, 0, 2337),
(26352, 35058, 0, 0, 2363),
(26352, 35059, 0, 0, 2337),
(26352, 35060, 0, 0, 2363),
(26352, 35061, 0, 0, 2365),
(26352, 35062, 0, 0, 2366),
(26352, 35063, 0, 0, 2359),
(26352, 35064, 0, 0, 2360),
(26352, 35065, 0, 0, 1758),
(26352, 35066, 0, 0, 2337),
(26352, 35067, 0, 0, 2338),
(26352, 35068, 0, 0, 2365),
(26352, 35069, 0, 0, 2366),
(26352, 35070, 0, 0, 2359),
(26352, 35071, 0, 0, 2362),
(26352, 35072, 0, 0, 2363),
(26352, 35073, 0, 0, 2364),
(26352, 35074, 0, 0, 2362),
(26352, 35075, 0, 0, 2360),
(26352, 35076, 0, 0, 2362),
(26352, 35077, 0, 0, 2337),
(26352, 35078, 0, 0, 2363),
(26352, 35079, 0, 0, 2365),
(26352, 35080, 0, 0, 2366),
(26352, 35081, 0, 0, 2359),
(26352, 35082, 0, 0, 2361),
(26352, 35083, 0, 0, 2363),
(26352, 35084, 0, 0, 2365),
(26352, 35085, 0, 0, 2366),
(26352, 35086, 0, 0, 2359),
(26352, 35087, 0, 0, 2337),
(26352, 35088, 0, 0, 2337),
(26352, 35089, 0, 0, 2363),
(26352, 35090, 0, 0, 2365),
(26352, 35091, 0, 0, 2366),
(26352, 35092, 0, 0, 2359),
(26352, 35093, 0, 0, 2362),
(26352, 35094, 0, 0, 2364),
(26352, 35095, 0, 0, 2363),
(26352, 35096, 0, 0, 2359),
(26352, 35097, 0, 0, 2365),
(26352, 35098, 0, 0, 2363),
(26352, 35099, 0, 0, 2337),
(26352, 35100, 0, 0, 2366),
(26352, 35102, 0, 0, 2361),
(26352, 35103, 0, 0, 2360),
(26352, 35104, 0, 0, 1758),
(26352, 35105, 0, 0, 1758),
(26352, 35106, 0, 0, 1758),
(26352, 35107, 0, 0, 1758),
(26352, 35109, 0, 0, 2360),
(26352, 35110, 0, 0, 2356),
(26352, 35111, 0, 0, 2363),
(26352, 35112, 0, 0, 2365),
(26352, 35113, 0, 0, 2366),
(26352, 35114, 0, 0, 2359),
(26352, 35115, 0, 0, 2365),
(26352, 37739, 0, 0, 2361),
(26352, 37740, 0, 0, 2361);
UPDATE `creature_template` SET `npcflag` = 128 WHERE `entry` = 27721;
DELETE FROM `npc_vendor` WHERE `entry` = '27721';
INSERT INTO `npc_vendor` (entry, item, maxcount, incrtime, ExtendedCost) VALUES 
(27721, 34986, 0, 0, 2364),
(27721, 34985, 0, 0, 1758),
(27721, 34987, 0, 0, 2360),
(27721, 34988, 0, 0, 2363),
(27721, 34989, 0, 0, 2360),
(27721, 34995, 0, 0, 2363),
(27721, 34996, 0, 0, 2362),
(27721, 34997, 0, 0, 2360),
(27721, 35008, 0, 0, 2342),
(27721, 35014, 0, 0, 2361),
(27721, 35015, 0, 0, 2360),
(27721, 35016, 0, 0, 2342),
(27721, 35017, 0, 0, 2363),
(27721, 35018, 0, 0, 2360),
(27721, 35019, 0, 0, 1758),
(27721, 35020, 0, 0, 1758),
(27721, 35021, 0, 0, 1758),
(27721, 35037, 0, 0, 2363),
(27721, 35038, 0, 0, 2363),
(27721, 35039, 0, 0, 1758),
(27721, 35040, 0, 0, 1758),
(27721, 35041, 0, 0, 1758),
(27721, 35047, 0, 0, 2360),
(27721, 35058, 0, 0, 2363),
(27721, 35064, 0, 0, 2360),
(27721, 35065, 0, 0, 1758),
(27721, 35071, 0, 0, 2362),
(27721, 35072, 0, 0, 2363),
(27721, 35073, 0, 0, 2364),
(27721, 35074, 0, 0, 2362),
(27721, 35075, 0, 0, 2360),
(27721, 35076, 0, 0, 2362),
(27721, 35082, 0, 0, 2361),
(27721, 35093, 0, 0, 2362),
(27721, 35094, 0, 0, 2364),
(27721, 35095, 0, 0, 2363),
(27721, 35101, 0, 0, 2362),
(27721, 35102, 0, 0, 2361),
(27721, 35103, 0, 0, 2360),
(27721, 35104, 0, 0, 1758),
(27721, 35105, 0, 0, 1758),
(27721, 35106, 0, 0, 1758),
(27721, 35107, 0, 0, 1758),
(27721, 35108, 0, 0, 1758),
(27721, 35109, 0, 0, 2360),
(27721, 35081, 0, 0, 2359),
(27721, 35080, 0, 0, 2366),
(27721, 35079, 0, 0, 2365),
(27721, 35078, 0, 0, 2363),
(27721, 35077, 0, 0, 2337),
(27721, 35052, 0, 0, 2359),
(27721, 35051, 0, 0, 2366),
(27721, 35050, 0, 0, 2365),
(27721, 35048, 0, 0, 2337),
(27721, 35046, 0, 0, 2359),
(27721, 35045, 0, 0, 2366),
(27721, 35044, 0, 0, 2365),
(27721, 35043, 0, 0, 2363),
(27721, 35042, 0, 0, 2364);
UPDATE `creature_template` SET `npcflag` = 128 WHERE `entry` = 27722;
DELETE FROM `npc_vendor` WHERE `entry` = '27722';
INSERT INTO `npc_vendor` (entry, item, maxcount, incrtime, ExtendedCost) VALUES 
(27722, 34986, 0, 0, 2364),
(27722, 34985, 0, 0, 1758),
(27722, 34987, 0, 0, 2360),
(27722, 34988, 0, 0, 2363),
(27722, 34989, 0, 0, 2360),
(27722, 34991, 0, 0, 1432),
(27722, 34995, 0, 0, 2363),
(27722, 34996, 0, 0, 2362),
(27722, 34997, 0, 0, 2360),
(27722, 35008, 0, 0, 2342),
(27722, 35014, 0, 0, 2361),
(27722, 35015, 0, 0, 2360),
(27722, 35016, 0, 0, 2342),
(27722, 35017, 0, 0, 2363),
(27722, 35018, 0, 0, 2360),
(27722, 35019, 0, 0, 1758),
(27722, 35020, 0, 0, 1758),
(27722, 35021, 0, 0, 1758),
(27722, 35037, 0, 0, 2363),
(27722, 35038, 0, 0, 2363),
(27722, 35039, 0, 0, 1758),
(27722, 35040, 0, 0, 1758),
(27722, 35041, 0, 0, 1758),
(27722, 35047, 0, 0, 2360),
(27722, 35058, 0, 0, 2363),
(27722, 35064, 0, 0, 2360),
(27722, 35065, 0, 0, 1758),
(27722, 35071, 0, 0, 2362),
(27722, 35072, 0, 0, 2363),
(27722, 35073, 0, 0, 2364),
(27722, 35074, 0, 0, 2362),
(27722, 35075, 0, 0, 2360),
(27722, 35076, 0, 0, 2362),
(27722, 35082, 0, 0, 2361),
(27722, 35093, 0, 0, 2362),
(27722, 35094, 0, 0, 2364),
(27722, 35095, 0, 0, 2363),
(27722, 35101, 0, 0, 2362),
(27722, 35102, 0, 0, 2361),
(27722, 35103, 0, 0, 2360),
(27722, 35104, 0, 0, 1758),
(27722, 35105, 0, 0, 1758),
(27722, 35106, 0, 0, 1758),
(27722, 35107, 0, 0, 1758),
(27722, 35108, 0, 0, 1758),
(27722, 35109, 0, 0, 2360),
(27722, 35027, 0, 0, 2337),
(27722, 35028, 0, 0, 2363),
(27722, 35029, 0, 0, 2365),
(27722, 35030, 0, 0, 2366),
(27722, 35031, 0, 0, 2359),
(27722, 35059, 0, 0, 2337),
(27722, 35060, 0, 0, 2363),
(27722, 35061, 0, 0, 2365),
(27722, 35062, 0, 0, 2366),
(27722, 35063, 0, 0, 2359),
(27722, 35088, 0, 0, 2337),
(27722, 35089, 0, 0, 2363),
(27722, 35090, 0, 0, 2365),
(27722, 35091, 0, 0, 2366),
(27722, 35092, 0, 0, 2359);
UPDATE `creature_template` SET `npcflag` = 128 WHERE `entry` = 25177;
DELETE FROM `npc_vendor` WHERE `entry` = '25177';
INSERT INTO `npc_vendor` (entry, item, maxcount, incrtime, ExtendedCost) VALUES 
(25177, 30486, 0, 0, 22),
(25177, 30487, 0, 0, 21),
(25177, 30488, 0, 0, 22),
(25177, 30489, 0, 0, 22),
(25177, 30490, 0, 0, 24),
(25177, 31958, 0, 0, 21),
(25177, 31959, 0, 0, 26),
(25177, 31960, 0, 0, 22),
(25177, 31961, 0, 0, 21),
(25177, 31962, 0, 0, 22),
(25177, 31963, 0, 0, 22),
(25177, 31964, 0, 0, 24),
(25177, 31965, 0, 0, 133),
(25177, 31966, 0, 0, 26),
(25177, 31967, 0, 0, 21),
(25177, 31968, 0, 0, 22),
(25177, 31969, 0, 0, 22),
(25177, 31971, 0, 0, 24),
(25177, 31972, 0, 0, 22),
(25177, 31973, 0, 0, 21),
(25177, 31974, 0, 0, 22),
(25177, 31975, 0, 0, 22),
(25177, 31976, 0, 0, 24),
(25177, 31977, 0, 0, 22),
(25177, 31978, 0, 0, 21),
(25177, 31979, 0, 0, 24),
(25177, 31980, 0, 0, 22),
(25177, 31981, 0, 0, 21),
(25177, 31982, 0, 0, 22),
(25177, 31983, 0, 0, 22),
(25177, 31984, 0, 0, 26),
(25177, 31985, 0, 0, 21),
(25177, 31986, 0, 0, 26),
(25177, 31987, 0, 0, 21),
(25177, 31988, 0, 0, 22),
(25177, 31989, 0, 0, 22),
(25177, 31990, 0, 0, 24),
(25177, 31991, 0, 0, 22),
(25177, 31992, 0, 0, 22),
(25177, 31993, 0, 0, 21),
(25177, 31995, 0, 0, 22),
(25177, 31996, 0, 0, 24),
(25177, 31997, 0, 0, 22),
(25177, 31998, 0, 0, 21),
(25177, 31999, 0, 0, 22),
(25177, 32000, 0, 0, 22),
(25177, 32001, 0, 0, 24),
(25177, 32002, 0, 0, 22),
(25177, 32003, 0, 0, 21),
(25177, 32004, 0, 0, 22),
(25177, 32005, 0, 0, 21),
(25177, 32006, 0, 0, 22),
(25177, 32007, 0, 0, 22),
(25177, 32008, 0, 0, 24),
(25177, 32009, 0, 0, 22),
(25177, 32010, 0, 0, 21),
(25177, 32011, 0, 0, 22),
(25177, 32012, 0, 0, 22),
(25177, 32013, 0, 0, 24),
(25177, 32014, 0, 0, 26),
(25177, 32015, 0, 0, 21),
(25177, 32016, 0, 0, 22),
(25177, 32017, 0, 0, 22),
(25177, 32018, 0, 0, 24),
(25177, 32019, 0, 0, 22),
(25177, 32020, 0, 0, 22),
(25177, 32021, 0, 0, 21),
(25177, 32022, 0, 0, 22),
(25177, 32023, 0, 0, 22),
(25177, 32024, 0, 0, 24),
(25177, 32025, 0, 0, 26),
(25177, 32026, 0, 0, 133),
(25177, 32027, 0, 0, 21),
(25177, 32028, 0, 0, 133),
(25177, 32029, 0, 0, 22),
(25177, 32030, 0, 0, 21),
(25177, 32031, 0, 0, 22),
(25177, 32032, 0, 0, 22),
(25177, 32033, 0, 0, 24),
(25177, 32034, 0, 0, 21),
(25177, 32035, 0, 0, 22),
(25177, 32036, 0, 0, 22),
(25177, 32037, 0, 0, 24),
(25177, 32038, 0, 0, 22),
(25177, 32039, 0, 0, 22),
(25177, 32040, 0, 0, 21),
(25177, 32041, 0, 0, 22),
(25177, 32042, 0, 0, 22),
(25177, 32043, 0, 0, 24),
(25177, 32044, 0, 0, 133),
(25177, 32045, 0, 0, 22),
(25177, 32046, 0, 0, 21),
(25177, 32047, 0, 0, 24),
(25177, 32048, 0, 0, 22),
(25177, 32049, 0, 0, 21),
(25177, 32050, 0, 0, 22),
(25177, 32051, 0, 0, 22),
(25177, 32052, 0, 0, 133),
(25177, 32053, 0, 0, 148),
(25177, 32054, 0, 0, 146),
(25177, 32055, 0, 0, 26),
(25177, 32056, 0, 0, 21),
(25177, 32057, 0, 0, 22),
(25177, 32058, 0, 0, 22),
(25177, 32059, 0, 0, 24),
(25177, 32060, 0, 0, 22),
(25177, 32961, 0, 0, 21),
(25177, 32962, 0, 0, 146),
(25177, 32963, 0, 0, 148),
(25177, 32964, 0, 0, 148),
(25177, 33076, 0, 0, 146),
(25177, 33077, 0, 0, 146),
(25177, 33078, 0, 0, 146),
(25177, 33309, 0, 0, 22),
(25177, 33313, 0, 0, 22),
(25177, 33937, 0, 0, 146),
(25177, 33940, 0, 0, 146),
(25177, 33943, 0, 0, 146),
(25177, 33946, 0, 0, 146),
(25177, 33949, 0, 0, 146),
(25177, 33952, 0, 0, 146),
(25177, 34986, 0, 0, 2364),
(25177, 34985, 0, 0, 1758),
(25177, 34987, 0, 0, 2360),
(25177, 34988, 0, 0, 2363),
(25177, 34989, 0, 0, 2360),
(25177, 34995, 0, 0, 2363),
(25177, 34996, 0, 0, 2362),
(25177, 34997, 0, 0, 2360),
(25177, 35008, 0, 0, 2342),
(25177, 35014, 0, 0, 2361),
(25177, 35015, 0, 0, 2360),
(25177, 35016, 0, 0, 2342),
(25177, 35017, 0, 0, 2363),
(25177, 35018, 0, 0, 2360),
(25177, 35019, 0, 0, 1758),
(25177, 35020, 0, 0, 1758),
(25177, 35021, 0, 0, 1758),
(25177, 35037, 0, 0, 2363),
(25177, 35038, 0, 0, 2363),
(25177, 35039, 0, 0, 1758),
(25177, 35040, 0, 0, 1758),
(25177, 35041, 0, 0, 1758),
(25177, 35047, 0, 0, 2360),
(25177, 35058, 0, 0, 2363),
(25177, 35064, 0, 0, 2360),
(25177, 35065, 0, 0, 1758),
(25177, 35071, 0, 0, 2362),
(25177, 35072, 0, 0, 2363),
(25177, 35073, 0, 0, 2364),
(25177, 35074, 0, 0, 2362),
(25177, 35075, 0, 0, 2360),
(25177, 35076, 0, 0, 2362),
(25177, 35082, 0, 0, 2361),
(25177, 35093, 0, 0, 2362),
(25177, 35094, 0, 0, 2364),
(25177, 35095, 0, 0, 2363),
(25177, 35101, 0, 0, 2362),
(25177, 35102, 0, 0, 2361),
(25177, 35103, 0, 0, 2360),
(25177, 35104, 0, 0, 1758),
(25177, 35105, 0, 0, 1758),
(25177, 35106, 0, 0, 1758),
(25177, 35107, 0, 0, 1758),
(25177, 35108, 0, 0, 1758),
(25177, 35109, 0, 0, 2360);
UPDATE `creature_template` SET `npcflag` = 128 WHERE `entry` = 25176;
DELETE FROM `npc_vendor` WHERE (`entry`=25176);
INSERT INTO `npc_vendor` (entry, item, maxcount, incrtime, ExtendedCost) VALUES 
(25176, 30486, 0, 0, 22),
(25176, 30487, 0, 0, 21),
(25176, 30488, 0, 0, 22),
(25176, 30489, 0, 0, 22),
(25176, 30490, 0, 0, 24),
(25176, 31958, 0, 0, 21),
(25176, 31959, 0, 0, 26),
(25176, 31960, 0, 0, 22),
(25176, 31961, 0, 0, 21),
(25176, 31962, 0, 0, 22),
(25176, 31963, 0, 0, 22),
(25176, 31964, 0, 0, 24),
(25176, 31965, 0, 0, 133),
(25176, 31966, 0, 0, 26),
(25176, 31967, 0, 0, 21),
(25176, 31968, 0, 0, 22),
(25176, 31969, 0, 0, 22),
(25176, 31971, 0, 0, 24),
(25176, 31972, 0, 0, 22),
(25176, 31973, 0, 0, 21),
(25176, 31974, 0, 0, 22),
(25176, 31975, 0, 0, 22),
(25176, 31976, 0, 0, 24),
(25176, 31977, 0, 0, 22),
(25176, 31978, 0, 0, 21),
(25176, 31979, 0, 0, 24),
(25176, 31980, 0, 0, 22),
(25176, 31981, 0, 0, 21),
(25176, 31982, 0, 0, 22),
(25176, 31983, 0, 0, 22),
(25176, 31984, 0, 0, 26),
(25176, 31985, 0, 0, 21),
(25176, 31986, 0, 0, 26),
(25176, 31987, 0, 0, 21),
(25176, 31988, 0, 0, 22),
(25176, 31989, 0, 0, 22),
(25176, 31990, 0, 0, 24),
(25176, 31991, 0, 0, 22),
(25176, 31992, 0, 0, 22),
(25176, 31993, 0, 0, 21),
(25176, 31995, 0, 0, 22),
(25176, 31996, 0, 0, 24),
(25176, 31997, 0, 0, 22),
(25176, 31998, 0, 0, 21),
(25176, 31999, 0, 0, 22),
(25176, 32000, 0, 0, 22),
(25176, 32001, 0, 0, 24),
(25176, 32002, 0, 0, 22),
(25176, 32003, 0, 0, 21),
(25176, 32004, 0, 0, 22),
(25176, 32005, 0, 0, 21),
(25176, 32006, 0, 0, 22),
(25176, 32007, 0, 0, 22),
(25176, 32008, 0, 0, 24),
(25176, 32009, 0, 0, 22),
(25176, 32010, 0, 0, 21),
(25176, 32011, 0, 0, 22),
(25176, 32012, 0, 0, 22),
(25176, 32013, 0, 0, 24),
(25176, 32014, 0, 0, 26),
(25176, 32015, 0, 0, 21),
(25176, 32016, 0, 0, 22),
(25176, 32017, 0, 0, 22),
(25176, 32018, 0, 0, 24),
(25176, 32019, 0, 0, 22),
(25176, 32020, 0, 0, 22),
(25176, 32021, 0, 0, 21),
(25176, 32022, 0, 0, 22),
(25176, 32023, 0, 0, 22),
(25176, 32024, 0, 0, 24),
(25176, 32025, 0, 0, 26),
(25176, 32026, 0, 0, 133),
(25176, 32027, 0, 0, 21),
(25176, 32028, 0, 0, 133),
(25176, 32029, 0, 0, 22),
(25176, 32030, 0, 0, 21),
(25176, 32031, 0, 0, 22),
(25176, 32032, 0, 0, 22),
(25176, 32033, 0, 0, 24),
(25176, 32034, 0, 0, 21),
(25176, 32035, 0, 0, 22),
(25176, 32036, 0, 0, 22),
(25176, 32037, 0, 0, 24),
(25176, 32038, 0, 0, 22),
(25176, 32039, 0, 0, 22),
(25176, 32040, 0, 0, 21),
(25176, 32041, 0, 0, 22),
(25176, 32042, 0, 0, 22),
(25176, 32043, 0, 0, 24),
(25176, 32044, 0, 0, 133),
(25176, 32045, 0, 0, 22),
(25176, 32046, 0, 0, 21),
(25176, 32047, 0, 0, 24),
(25176, 32048, 0, 0, 22),
(25176, 32049, 0, 0, 21),
(25176, 32050, 0, 0, 22),
(25176, 32051, 0, 0, 22),
(25176, 32052, 0, 0, 133),
(25176, 32053, 0, 0, 148),
(25176, 32054, 0, 0, 146),
(25176, 32055, 0, 0, 26),
(25176, 32056, 0, 0, 21),
(25176, 32057, 0, 0, 22),
(25176, 32058, 0, 0, 22),
(25176, 32059, 0, 0, 24),
(25176, 32060, 0, 0, 22),
(25176, 32961, 0, 0, 21),
(25176, 32962, 0, 0, 146),
(25176, 32963, 0, 0, 148),
(25176, 32964, 0, 0, 148),
(25176, 33076, 0, 0, 146),
(25176, 33077, 0, 0, 146),
(25176, 33078, 0, 0, 146),
(25176, 33309, 0, 0, 22),
(25176, 33313, 0, 0, 22),
(25176, 33937, 0, 0, 146),
(25176, 33940, 0, 0, 146),
(25176, 33943, 0, 0, 146),
(25176, 33946, 0, 0, 146),
(25176, 33949, 0, 0, 146),
(25176, 33952, 0, 0, 146),
(25176, 34986, 0, 0, 2364),
(25176, 34985, 0, 0, 1758),
(25176, 34987, 0, 0, 2360),
(25176, 34988, 0, 0, 2363),
(25176, 34989, 0, 0, 2360),
(25176, 34990, 0, 0, 2364),
(25176, 34991, 0, 0, 1432),
(25176, 34992, 0, 0, 2364),
(25176, 34993, 0, 0, 2364),
(25176, 34994, 0, 0, 2359),
(25176, 34995, 0, 0, 2363),
(25176, 34996, 0, 0, 2362),
(25176, 34997, 0, 0, 2360),
(25176, 34998, 0, 0, 2363),
(25176, 35003, 0, 0, 2363),
(25176, 35008, 0, 0, 2342),
(25176, 35011, 0, 0, 2363),
(25176, 35014, 0, 0, 2361),
(25176, 35015, 0, 0, 2360),
(25176, 35016, 0, 0, 2342),
(25176, 35017, 0, 0, 2363),
(25176, 35018, 0, 0, 2360),
(25176, 35019, 0, 0, 1758),
(25176, 35020, 0, 0, 1758),
(25176, 35021, 0, 0, 1758),
(25176, 35022, 0, 0, 2363),
(25176, 35028, 0, 0, 2363),
(25176, 35032, 0, 0, 2342),
(25176, 35037, 0, 0, 2363),
(25176, 35038, 0, 0, 2363),
(25176, 35039, 0, 0, 1758),
(25176, 35040, 0, 0, 1758),
(25176, 35041, 0, 0, 1758),
(25176, 35047, 0, 0, 2360),
(25176, 35053, 0, 0, 2363),
(25176, 35058, 0, 0, 2363),
(25176, 35060, 0, 0, 2363),
(25176, 35064, 0, 0, 2360),
(25176, 35065, 0, 0, 1758),
(25176, 35067, 0, 0, 2338),
(25176, 35071, 0, 0, 2363),
(25176, 35072, 0, 0, 2363),
(25176, 35073, 0, 0, 2364),
(25176, 35074, 0, 0, 2362),
(25176, 35075, 0, 0, 2360),
(25176, 35076, 0, 0, 2362),
(25176, 35082, 0, 0, 2361),
(25176, 35083, 0, 0, 2363),
(25176, 35089, 0, 0, 2363),
(25176, 35093, 0, 0, 2362),
(25176, 35094, 0, 0, 2364),
(25176, 35095, 0, 0, 2363),
(25176, 35101, 0, 0, 2362),
(25176, 35102, 0, 0, 2361),
(25176, 35103, 0, 0, 1758),
(25176, 35104, 0, 0, 1758),
(25176, 35105, 0, 0, 1758),
(25176, 35106, 0, 0, 1758),
(25176, 35107, 0, 0, 1758),
(25176, 35108, 0, 0, 1758),
(25176, 35109, 0, 0, 2360),
(25176, 35110, 0, 0, 2356),
(25176, 35111, 0, 0, 2363);
UPDATE `creature_template` SET `npcflag` = 128 WHERE `entry` = 27668;
DELETE FROM `npc_vendor` WHERE (`entry`=27668);
INSERT INTO `npc_vendor` (entry, item, maxcount, incrtime, ExtendedCost) VALUES 
(27668, 34986, 0, 0, 2364),
(27668, 34985, 0, 0, 1758),
(27668, 34987, 0, 0, 2360),
(27668, 34988, 0, 0, 2363),
(27668, 34989, 0, 0, 2360),
(27668, 34990, 0, 0, 2364),
(27668, 34991, 0, 0, 1432),
(27668, 34992, 0, 0, 2364),
(27668, 34993, 0, 0, 2364),
(27668, 34994, 0, 0, 2359),
(27668, 34995, 0, 0, 2363),
(27668, 34996, 0, 0, 2362),
(27668, 34997, 0, 0, 2360),
(27668, 34998, 0, 0, 2363),
(27668, 34999, 0, 0, 2365),
(27668, 35000, 0, 0, 2365),
(27668, 35001, 0, 0, 2359),
(27668, 35002, 0, 0, 2337),
(27668, 35003, 0, 0, 2363),
(27668, 35008, 0, 0, 2342),
(27668, 35011, 0, 0, 2363),
(27668, 35014, 0, 0, 2361),
(27668, 35015, 0, 0, 2360),
(27668, 35016, 0, 0, 2342),
(27668, 35017, 0, 0, 2363),
(27668, 36737, 0, 0, 2356),
(27668, 35018, 0, 0, 2360),
(27668, 35019, 0, 0, 1758),
(27668, 35020, 0, 0, 1758),
(27668, 35021, 0, 0, 1758),
(27668, 35022, 0, 0, 2363),
(27668, 35023, 0, 0, 2365),
(27668, 35024, 0, 0, 2366),
(27668, 35025, 0, 0, 2359),
(27668, 35026, 0, 0, 2337),
(27668, 35027, 0, 0, 2337),
(27668, 35028, 0, 0, 2363),
(27668, 35029, 0, 0, 2365),
(27668, 35030, 0, 0, 2366),
(27668, 35031, 0, 0, 2359),
(27668, 35032, 0, 0, 2342),
(27668, 35033, 0, 0, 2365),
(27668, 35034, 0, 0, 2366),
(27668, 35035, 0, 0, 2359),
(27668, 35036, 0, 0, 2337),
(27668, 35037, 0, 0, 2363),
(27668, 35038, 0, 0, 2363),
(27668, 35039, 0, 0, 1758),
(27668, 35040, 0, 0, 1758),
(27668, 35041, 0, 0, 1758),
(27668, 35042, 0, 0, 2365),
(27668, 35043, 0, 0, 2363),
(27668, 35044, 0, 0, 2365),
(27668, 35045, 0, 0, 2366),
(27668, 35046, 0, 0, 2359),
(27668, 35047, 0, 0, 2360),
(27668, 35048, 0, 0, 2337),
(27668, 35049, 0, 0, 2363),
(27668, 35050, 0, 0, 2365),
(27668, 35051, 0, 0, 2366),
(27668, 35052, 0, 0, 2359),
(27668, 35053, 0, 0, 2363),
(27668, 35054, 0, 0, 2365),
(27668, 35055, 0, 0, 2366),
(27668, 35056, 0, 0, 2359),
(27668, 35057, 0, 0, 2337),
(27668, 35058, 0, 0, 2363),
(27668, 35059, 0, 0, 2337),
(27668, 35060, 0, 0, 2363),
(27668, 35061, 0, 0, 2365),
(27668, 35062, 0, 0, 2366),
(27668, 35063, 0, 0, 2359),
(27668, 35064, 0, 0, 2360),
(27668, 35065, 0, 0, 1758),
(27668, 35066, 0, 0, 2337),
(27668, 35067, 0, 0, 2338),
(27668, 35068, 0, 0, 2365),
(27668, 35069, 0, 0, 2366),
(27668, 35070, 0, 0, 2359),
(27668, 35071, 0, 0, 2362),
(27668, 35072, 0, 0, 2363),
(27668, 35073, 0, 0, 2364),
(27668, 35074, 0, 0, 2362),
(27668, 35075, 0, 0, 2360),
(27668, 35076, 0, 0, 2362),
(27668, 35077, 0, 0, 2337),
(27668, 35078, 0, 0, 2363),
(27668, 35079, 0, 0, 2365),
(27668, 35080, 0, 0, 2366),
(27668, 35081, 0, 0, 2359),
(27668, 35082, 0, 0, 2361),
(27668, 35083, 0, 0, 2363),
(27668, 35084, 0, 0, 2365),
(27668, 35085, 0, 0, 2366),
(27668, 35086, 0, 0, 2359),
(27668, 35087, 0, 0, 2337),
(27668, 35088, 0, 0, 2337),
(27668, 35089, 0, 0, 2363),
(27668, 35090, 0, 0, 2365),
(27668, 35091, 0, 0, 2366),
(27668, 35092, 0, 0, 2359),
(27668, 35093, 0, 0, 2362),
(27668, 35094, 0, 0, 2364),
(27668, 35095, 0, 0, 2363),
(27668, 35096, 0, 0, 2359),
(27668, 35097, 0, 0, 2365),
(27668, 35098, 0, 0, 2363),
(27668, 35099, 0, 0, 2337),
(27668, 35100, 0, 0, 2366),
(27668, 35101, 0, 0, 2362),
(27668, 35102, 0, 0, 2361),
(27668, 35103, 0, 0, 2360),
(27668, 35104, 0, 0, 1758),
(27668, 35105, 0, 0, 1758),
(27668, 35106, 0, 0, 1758),
(27668, 35107, 0, 0, 1758),
(27668, 35108, 0, 0, 1758),
(27668, 35109, 0, 0, 2360),
(27668, 35110, 0, 0, 2356),
(27668, 35111, 0, 0, 2363),
(27668, 35112, 0, 0, 2365),
(27668, 35113, 0, 0, 2366),
(27668, 35114, 0, 0, 2359),
(27668, 35115, 0, 0, 2365);

# Serker
INSERT INTO `spell_elixir` VALUES ('45373','1');

# Frankir
UPDATE `creature_template` SET
`mindmg` = 2750, 
`maxdmg` = 3750, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=19872;
UPDATE `creature_template` SET
`mindmg` = 1250, 
`maxdmg` = 1750, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0',
`spell1` = '0',
`spell2` = '0' WHERE `entry`=17067;
UPDATE `creature_template` SET
`mindmg` = 1750, 
`maxdmg` = 3500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16424;
UPDATE `creature_template` SET
`mindmg` = 2750, 
`maxdmg` = 3500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16460;
UPDATE `creature_template` SET
`mindmg` = 2750, 
`maxdmg` = 3500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16461;
UPDATE `creature_template` SET
`mindmg` = 3000, 
`maxdmg` = 3750, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16459;
UPDATE `creature_template` SET `armor` = '8000',
`mindmg` = 6000, 
`maxdmg` = 8000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16457;
UPDATE `creature_template` SET
`mindmg` = 1750, 
`maxdmg` = 2500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16171;
UPDATE `creature_template` SET
`mindmg` = 750, 
`maxdmg` = 1250, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16170;
UPDATE `creature_template` SET
`mindmg` = 1750, 
`maxdmg` = 2250, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16173;
UPDATE `creature_template` SET
`mindmg` = 1750, 
`maxdmg` = 2250, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16175;
UPDATE `creature_template` SET
`mindmg` = 1750, 
`maxdmg` = 2250, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16174;
UPDATE `creature_template` SET
`mindmg` = 3250, 
`maxdmg` = 4250, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16177;
UPDATE `creature_template` SET
`mindmg` = 2500, 
`maxdmg` = 3500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16176;
UPDATE `creature_template` SET
`mindmg` = 2500, 
`maxdmg` = 3500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16178;
UPDATE `creature_template` SET
`mindmg` = 7500, 
`maxdmg` = 9500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16481;
UPDATE `creature_template` SET
`mindmg` = 5500, 
`maxdmg` = 7500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16482;
UPDATE `creature_template` SET
`mindmg` = 5000, 
`maxdmg` = 6500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16485;
UPDATE `creature_template` SET `dmgschool` = '6',
`mindmg` = 2750, 
`maxdmg` = 3750,
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16488;
UPDATE `creature_template` SET
`mindmg` = 1250, 
`maxdmg` = 1750, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7) 
WHERE `entry`=16492;
UPDATE `creature_template` SET `armor` = '8000',
`mindmg` = 5000, 
`maxdmg` = 7500,
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`resistance6` = '600',
`spell1` = '0',
`spell2` = '0' WHERE `entry`=15691;
UPDATE `creature_template` SET `speed` = '1.5',
`baseattacktime` = '10000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0',
`mechanic_immune_mask` = '80428891' WHERE `entry`=17096;
UPDATE `creature_template` SET
`mindmg` = 6500, 
`maxdmg` = 8000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`mechanic_immune_mask`=267386875
WHERE `entry`=19872;
UPDATE `creature_template` SET
`mindmg` = 5250, 
`maxdmg` = 6750, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16471;
UPDATE `creature_template` SET
`mindmg` = 5000, 
`maxdmg` = 6000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16473;
UPDATE `creature_template` SET
`mindmg` = 1000, 
`maxdmg` = 1500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16468;
UPDATE `creature_template` SET
`mindmg` = 4000, 
`maxdmg` = 5500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16470;
UPDATE `creature_template` SET `armor` = '6000',
`speed` = '1.8',
`mindmg` = 4000, 
`maxdmg` = 6000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0' WHERE `entry`=17521;
UPDATE `creature_template` SET `armor` = '4000',
`speed` = '1.8',
`mindmg` = 4000, 
`maxdmg` = 5000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '1000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0' WHERE `entry`=17533;
UPDATE `creature_template` SET `armor` = '3000',
`speed` = '1.8',
`mindmg` = 4000, 
`maxdmg` = 5000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0' WHERE `entry`=17534;
UPDATE `creature_template` SET `armor` = '3000',
`speed` = '1.8',
`mindmg` = 1500, 
`maxdmg` = 2500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0' WHERE `entry`=17535;
UPDATE `creature_template` SET
`speed` = '1.8',
`mindmg` = 600, 
`maxdmg` = 900, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0' WHERE `entry`=17548;
UPDATE `creature_template` SET  `armor` = '3000',
`speed` = '1.8',
`mindmg` = 2500, 
`maxdmg` = 3500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0',
`spell1` = '0',
`spell2` = '0' WHERE `entry`=17546;
UPDATE `creature_template` SET  `armor` = '3000',
`speed` = '1.8',
`mindmg` = 3500, 
`maxdmg` = 4500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0',
`spell1` = '0',
`spell2` = '0' WHERE `entry`=17543;
UPDATE `creature_template` SET  `armor` = '5000',
`speed` = '1.8',
`mindmg` = 3500, 
`maxdmg` = 4500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0',
`spell1` = '0',
`spell2` = '0' WHERE `entry`=17547;
UPDATE `creature_template` SET  `armor` = '3000',
`speed` = '1.8',
`mindmg` = 5000, 
`maxdmg` = 6000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0' WHERE `entry`=18168;
UPDATE `creature_template` SET `minlevel` = '70',
`maxlevel` = '70' WHERE `entry`=18412;
UPDATE `creature_template` SET
`mindmg` = 7500, 
`maxdmg` = 10000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16504;
UPDATE `creature_template` SET `dmgschool` = '6',
`mindmg` = 2500, 
`maxdmg` = 3500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16489;
UPDATE `creature_template` SET
`mindmg` = 750, 
`maxdmg` = 1250, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16491;
UPDATE `creature_template` SET `dmgschool` = '6',
`mindmg` = 1000, 
`maxdmg` = 2000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16530;
UPDATE `creature_template` SET `dmgschool` = '6',
`mindmg` = 2500, 
`maxdmg` = 3500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16529;
UPDATE `creature_template` SET
`mindmg` = 2500, 
`maxdmg` = 3500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16525;
UPDATE `creature_template` SET
`mindmg` = 1750, 
`maxdmg` = 2250, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16540;
UPDATE `creature_template` SET
`mindmg` = 2500, 
`maxdmg` = 3500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16526;
UPDATE `creature_template` SET
`mindmg` = 5000, 
`maxdmg` = 7500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16544;
UPDATE `creature_template` SET
`mindmg` = 5000, 
`maxdmg` = 7500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16545;
UPDATE `creature_template` SET
`mindmg` = 4250, 
`maxdmg` = 5750, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16595;
UPDATE `creature_template` SET
`mindmg` = 6000, 
`maxdmg` = 9000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=16596;
UPDATE `creature_template` SET `armor` = '1000',
`speed` = '1.8',
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0',
`resistance4` = '400',
`spell1` = '0' WHERE `entry`=17167;
UPDATE `creature_template` SET `minlevel` = '73',
`maxlevel` = '73',
`baseattacktime` = '2000' WHERE `entry`=18254;
UPDATE `creature_template` SET `minlevel` = '70',
`maxlevel` = '70' WHERE `entry`=17161;
UPDATE `creature_template` SET `armor` = '6000',
`mindmg` = 3500, 
`maxdmg` = 6500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=15688;
UPDATE `creature_template` SET `baseattacktime` = '2000',
`mindmg` = 400, 
`maxdmg` = 600, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0',
`spell1` = '0',
`ScriptName` = 'mob_karazhan_imp' WHERE `entry`=17267;
UPDATE `creature_template` SET `armor` = '2000',
`mindmg` = 1500, 
`maxdmg` = 2500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`spell1` = '0' WHERE `entry`=17229;
UPDATE `creature_template` SET `armor` = '6000',
`mindmg` = 7000, 
`maxdmg` = 9000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`spell1` = '0' WHERE `entry`=15689;
UPDATE `creature_template` SET `armor` = '8000',
`mindmg` = 6000, 
`maxdmg` = 9000, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`spell1` = '0',
`spell2` = '0',
`spell3` = '0',
`spell4` = '0' WHERE `entry`=15690;
UPDATE `creature_template` SET `minlevel` = '70',
`maxlevel` = '70' WHERE `entry`=17646;
UPDATE `creature_template` SET `minlevel` = '70',
`maxlevel` = '70',
`mindmg` = 500, 
`maxdmg` = 750, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0' WHERE `entry` =17650;
UPDATE `creature_template` SET `armor` = '8000',
`mindmg` = 8500, 
`maxdmg` = 11500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7)
WHERE `entry`=17225;
UPDATE `creature_template` SET
`mindmg` = 1000, 
`maxdmg` = 1500, 
`attackpower` = ROUND((`mindmg` + `maxdmg`) / 4 * 7), 
`mindmg` = ROUND(`mindmg` - `attackpower` / 7), 
`maxdmg` = ROUND(`maxdmg` - `attackpower` / 7),
`baseattacktime` = '2000',
`rangeattacktime` = '0',
`minrangedmg` = '0',
`maxrangedmg` = '0' WHERE `entry`=17261;

# KreK
UPDATE `creature_template` SET `maxlevel` = 66, `maxhealth` = 1600, `armor` = 2070, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 300, `maxrangedmg` = 418 WHERE `entry` = 18429;
UPDATE `creature_template` SET `maxlevel` = 66, `minhealth` = 7157, `maxhealth` = 7157, `armor` = 3096, `faction_A` = 14, `faction_H` = 14 WHERE `entry` = 18430;
UPDATE `creature_template` SET `maxlevel` = 65, `minhealth` = 3515, `maxhealth` = 3515, `armor` = 0, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 425 WHERE `entry` = 18431;
UPDATE `creature_template` SET `maxlevel` = 65, `minhealth` = 16178, `maxhealth` = 16178, `armor` = 3158, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 300, `maxrangedmg` = 418 WHERE `entry` = 18311;
UPDATE `creature_template` SET `maxlevel` = 66, `minhealth` = 12070, `maxhealth` = 12070, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 425, `mechanic_immune_mask` = 0 WHERE `entry` = 18331;
UPDATE `creature_template` SET `maxlevel` = 65, `minhealth` = 11796, `maxhealth` = 11796, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 300, `maxrangedmg` = 425, `resistance1` = 100, `mechanic_immune_mask` = 0 WHERE `entry` = 18317;
UPDATE `creature_template` SET `resistance5` = 100 WHERE `entry` = 18331;
UPDATE `creature_template` SET `maxlevel` = 66, `minhealth` = 15793, `maxhealth` = 15793, `armor` = 4158, `faction_A` = 14, `faction_H` = 14, `mindmg` = 475, `maxdmg` = 555, `attackpower` = 3680, `minrangedmg` = 300, `maxrangedmg` = 418, `mechanic_immune_mask` = 0 WHERE `entry` = 18309;
UPDATE `creature_template` SET `maxlevel` = 66, `minhealth` = 11760, `maxhealth` = 11760, `armor` = 2158, `faction_A` = 14, `faction_H` = 14, `mindmg` = 273, `attackpower` = 2694, `minrangedmg` = 300, `maxrangedmg` = 425, `resistance6` = 100, `mechanic_immune_mask` = 0 WHERE `entry` = 18313;
UPDATE `creature_template` SET `maxlevel` = 66, `faction_A` = 14, `faction_H` = 14, `mindmg` = 275, `maxdmg` = 416, `attackpower` = 2720, `minrangedmg` = 305, `maxrangedmg` = 432, `resistance2` = 100 WHERE `entry` = 18312;
UPDATE `creature_template` SET `maxlevel` = 66, `minhealth` = 11978, `maxhealth` = 11978, `faction_A` = 14, `faction_H` = 14, `mindmg` = 280, `maxdmg` = 414, `attackpower` = 2733, `minrangedmg` = 309, `maxrangedmg` = 432, `resistance2` = 100, `mechanic_immune_mask` = 0 WHERE `entry` = 18315;
UPDATE `creature_template` SET `maxlevel` = 64, `maxhealth` = 4000, `faction_A` = 14, `faction_H` = 14, `resistance5` = 100 WHERE `entry` = 18394;
UPDATE `creature_template` SET `maxlevel` = 65, `maxhealth` = 4500, `armor` = 0, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 300, `maxrangedmg` = 418 WHERE `entry` = 19306;
UPDATE `creature_template` SET `maxlevel` = 66, `minhealth` = 17354, `maxhealth` = 17354, `armor` = 4185, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 432, `mechanic_immune_mask` = 0 WHERE `entry` = 18314;
UPDATE `creature_template` SET `maxlevel` = 65, `minhealth` = 30457, `maxhealth` = 30457, `armor` = 5158, `faction_A` = 14, `faction_H` = 14, `mindmg` = 300, `maxdmg` = 500, `attackpower` = 2680, `mechanic_immune_mask` = 0 WHERE `entry` = 19307;
UPDATE `creature_template` SET `faction_A` = 35, `faction_H` = 35, `minrangedmg` = 138, `maxrangedmg` = 178, `mechanic_immune_mask` = 0 WHERE `entry` = 19666;
UPDATE `creature_template` SET `maxlevel` = 66, `maxhealth` = 73000, `armor` = 7212, `faction_A` = 14, `faction_H` = 14, `mindmg` = 450, `maxdmg` = 700, `attackpower` = 2733, `minrangedmg` = 309, `maxrangedmg` = 432 WHERE `entry` = 18341;
DELETE FROM `creature_loot_template` WHERE (`entry`=18341);
INSERT INTO `creature_loot_template` VALUES 
(18341, 25939, 0, 1, 1, 1, 0, 0, 0),
(18341, 25940, 0, 1, 1, 1, 0, 0, 0),
(18341, 25941, 0, 1, 1, 1, 0, 0, 0),
(18341, 25942, 0, 1, 1, 1, 0, 0, 0),
(18341, 25943, 0, 1, 1, 1, 0, 0, 0),
(18341, 28166, 0, 1, 1, 1, 0, 0, 0),
(18341, 28558, 70, 0, 1, 1, 0, 0, 0);
UPDATE `creature_template` SET `maxlevel` = 66, `maxhealth` = 91000, `armor` = 9212, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 309, `maxrangedmg` = 432 WHERE `entry` = 18343;
DELETE FROM `creature_loot_template` WHERE (`entry`=18343);
INSERT INTO `creature_loot_template` VALUES 
(18343, 25944, 0, 1, 1, 1, 0, 0, 0),
(18343, 25945, 0, 1, 1, 1, 0, 0, 0),
(18343, 25946, 0, 1, 1, 1, 0, 0, 0),
(18343, 25947, 0, 1, 1, 1, 0, 0, 0),
(18343, 25950, 0, 1, 1, 1, 0, 0, 0),
(18343, 25952, 0, 1, 1, 1, 0, 0, 0),
(18343, 28558, 64, 0, 1, 1, 0, 0, 0);
UPDATE `creature_template` SET `maxlevel` = 67, `minhealth` = 86469, `maxhealth` = 86469, `armor` = 3212, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 208, `maxrangedmg` = 291 WHERE `entry` = 18344;
DELETE FROM `creature_loot_template` WHERE (`entry`=18344);
INSERT INTO `creature_loot_template` VALUES 
(18344, 22921, 1.3, 0, 1, 1, 0, 0, 0),
(18344, 23572, 5, 0, 1, 1, 0, 0, 0),
(18344, 25953, 0, 1, 1, 1, 0, 0, 0),
(18344, 25954, 0, 1, 1, 1, 0, 0, 0),
(18344, 25955, 0, 1, 1, 1, 0, 0, 0),
(18344, 25956, 0, 1, 1, 1, 0, 0, 0),
(18344, 25957, 0, 1, 1, 1, 0, 0, 0),
(18344, 25962, 0, 1, 1, 1, 0, 0, 0),
(18344, 28490, -100, 0, 1, 1, 0, 0, 0),
(18344, 28558, 58, 0, 1, 1, 0, 0, 0);
UPDATE `gameobject` SET `spawntimesecs` = 43200, `animprogress` = 100 WHERE `guid` = 784410;
DELETE FROM `gameobject` WHERE `id`=184194;
DELETE FROM `gameobject` WHERE `id`=184193;
INSERT INTO `gameobject` (`guid`, `id`, `map`, `spawnMask`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `spawntimesecs`, `animprogress`, `state`) VALUES (73710, 184526, 530, 1, -3074.46, 4943.09, -101.047, 3.1584, 0, 0, 0.999965, -0.00840205, 25, 0, 1);
INSERT INTO `gameobject` (`guid`, `id`, `map`, `spawnMask`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `spawntimesecs`, `animprogress`, `state`) VALUES (16976, 184526, 557, 1, 6.07158, 0.972772, -0.9543, 3.06414, 0, 0, 0.99925, 0.038717, 25, 0, 1);
DELETE FROM `creature` WHERE `id`=18311;
DELETE FROM `creature` WHERE `id`=18331;
DELETE FROM `creature` WHERE `id`=18317;
DELETE FROM `creature` WHERE `id`=18309;
DELETE FROM `creature` WHERE `id`=18313;
DELETE FROM `creature` WHERE `id`=18312;
DELETE FROM `creature` WHERE `id`=18315;
DELETE FROM `creature` WHERE `id`=19306;
DELETE FROM `creature` WHERE `id`=18314;
DELETE FROM `creature` WHERE `id`=19307;
DELETE FROM `creature` WHERE `id`=18394;
DELETE FROM `creature` WHERE `id`=18430;
DELETE FROM `creature_movement` WHERE `id`=103458;
DELETE FROM `creature` WHERE `id`=18429;
DELETE FROM `creature_addon` WHERE `guid` NOT IN (SELECT `guid` FROM `creature`);
DELETE FROM `creature_movement` WHERE `id` NOT IN (SELECT `guid` FROM `creature`);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(103427, 18311, 557, 1, 0, 0, -41.1866, -4.11049, -0.95306, 0.058894, 7200, 0, 0, 16000, 0, 0, 0),
(103428, 18311, 557, 1, 0, 0, -65.339, -61.7986, -0.171944, 1.82604, 7200, 0, 0, 16000, 0, 0, 0),
(84302, 18311, 557, 1, 0, 0, -70.7096, -38.7137, -0.953707, 1.3862, 7200, 0, 0, 27000, 0, 0, 0),
(84303, 18311, 557, 1, 0, 0, -42.208, 4.15009, -0.95306, 6.28317, 7200, 0, 0, 21500, 0, 0, 0),
(84304, 18311, 557, 1, 0, 0, -69.7698, -189.521, -1.9347, 1.66895, 7200, 0, 0, 19666, 0, 0, 0),
(84305, 18311, 557, 1, 0, 0, -93.5885, -88.4268, -2.10267, 0.369112, 7200, 0, 0, 16000, 0, 0, 0),
(84306, 18311, 557, 1, 0, 0, -64.3622, -170.323, -0.955649, 1.63754, 7200, 0, 0, 21500, 0, 0, 0),
(84307, 18311, 557, 1, 0, 0, -99.8663, -93.8683, -0.875195, 0.938517, 7200, 0, 0, 27000, 0, 0, 0),
(84308, 18311, 557, 1, 0, 0, -65.0537, -39.3684, -0.953707, 1.55507, 7200, 0, 0, 27000, 0, 0, 0),
(84309, 18311, 557, 1, 0, 0, -115.577, -201.681, -1.37975, 4.8624, 7200, 0, 0, 25166, 0, 0, 0),
(84310, 18311, 557, 1, 0, 0, -370.283, -40.7129, -0.958738, 4.7566, 7200, 0, 0, 19666, 0, 0, 0),
(84311, 18311, 557, 1, 0, 0, -375.739, -40.6139, -0.958738, 4.70555, 7200, 0, 0, 19666, 0, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84312, 18331, 557, 1, 0, 0, -182.03, -220.304, -0.955078, 6.24941, 7200, 0, 0, 14499, 7183, 0, 0),
(103455, 18331, 557, 1, 0, 0, -223.489, -219.92, -1.06663, 6.23761, 7200, 0, 0, 12000, 6443, 0, 0),
(103464, 18331, 557, 1, 0, 0, -388.401, -168.221, -0.960508, 5.53021, 7200, 0, 0, 12000, 6443, 0, 0),
(103465, 18331, 557, 1, 0, 0, -391.7, -171.625, -0.969147, 1.82706, 7200, 0, 0, 12000, 6443, 0, 0),
(84313, 18331, 557, 1, 0, 0, -250.525, -181.122, -0.952719, 5.87829, 7200, 0, 0, 13500, 6887, 0, 0),
(84314, 18331, 557, 1, 0, 0, -350.581, -168.126, -0.986619, 3.38215, 7200, 0, 0, 13000, 6739, 0, 0),
(84315, 18331, 557, 1, 0, 0, -200.008, -204.462, 2.08217, 4.51366, 7200, 0, 0, 14499, 7183, 0, 0),
(84316, 18331, 557, 1, 0, 0, -201.476, -203.903, 1.93924, 4.52152, 7200, 0, 0, 12500, 6591, 0, 0),
(84317, 18331, 557, 1, 0, 0, -222.179, -174.663, -1.05019, 5.72907, 7200, 0, 0, 14000, 7035, 0, 0),
(84318, 18331, 557, 1, 0, 0, -252.837, -187.662, -0.951819, 6.05108, 7200, 0, 0, 12500, 6591, 0, 0),
(84319, 18331, 557, 1, 0, 0, -263.54, -160.213, -1.44557, 6.21995, 7200, 0, 0, 14499, 7183, 0, 0),
(84320, 18331, 557, 1, 0, 0, -296.482, -204.856, -1.80512, 0.934204, 7200, 0, 0, 14000, 7035, 0, 0),
(84321, 18331, 557, 1, 0, 0, -298.837, -209.225, -1.80611, 6.05107, 7200, 0, 0, 12500, 6591, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84322, 18317, 557, 1, 0, 0, -66.2259, -191.729, -1.89648, 1.63753, 7200, 0, 0, 12000, 32232, 0, 0),
(84409, 18317, 557, 1, 0, 0, -77.7406, -226.566, -0.0940885, 0.0329964, 7200, 0, 0, 12000, 32232, 0, 0),
(84323, 18317, 557, 1, 0, 0, -104.394, -239.683, 0.808555, 0.4914, 7200, 0, 0, 11000, 31495, 0, 0),
(84324, 18317, 557, 1, 0, 0, -254.93, -183.599, -0.952759, 5.95291, 7200, 0, 0, 16000, 35184, 0, 0),
(84325, 18317, 557, 1, 0, 0, -224.34, -228.44, -0.954599, 0.0525876, 7200, 0, 0, 13000, 32970, 0, 0),
(84326, 18317, 557, 1, 0, 0, -182.038, -226.936, -0.955078, 6.2337, 7200, 0, 0, 17000, 35922, 0, 0),
(84327, 18317, 557, 1, 0, 0, -36.7666, -197.282, -0.325905, 2.93811, 7200, 0, 0, 13000, 32970, 0, 0),
(84328, 18317, 557, 1, 0, 0, -27.0483, -224.562, 0.154883, 2.93976, 7200, 0, 0, 11000, 31495, 0, 0),
(84329, 18317, 557, 1, 0, 0, -91.7892, -230.047, 0.145808, 2.34285, 7200, 0, 0, 11000, 31495, 0, 0),
(84330, 18317, 557, 1, 0, 0, -90.7249, -229.296, 0.132493, 2.3939, 7200, 0, 0, 18000, 36660, 0, 0),
(84331, 18317, 557, 1, 0, 0, -113.963, -199.13, -1.36609, 4.95272, 7200, 0, 0, 18000, 36660, 0, 0),
(84332, 18317, 557, 1, 0, 0, -118.104, -200.047, -1.1957, 5.02341, 7200, 0, 0, 13000, 32970, 0, 0),
(84333, 18317, 557, 1, 0, 0, -161.16, -223.463, -0.955078, 0.115451, 7200, 0, 0, 14000, 33708, 0, 0),
(84334, 18317, 557, 1, 0, 0, -224.838, -173.005, -1.07284, 3.88732, 7200, 0, 0, 14000, 33708, 0, 0),
(84335, 18317, 557, 1, 0, 0, -268.788, -160.779, -1.92309, 5.28139, 7200, 0, 0, 12000, 32232, 0, 0),
(84336, 18317, 557, 1, 0, 0, -373.109, -235.44, -0.957896, 4.7308, 7200, 0, 0, 11000, 31495, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(103429, 18309, 557, 1, 0, 0, -36.1763, -94.8715, -0.572682, 2.12448, 7200, 0, 0, 16000, 0, 0, 0),
(84337, 18309, 557, 1, 0, 0, -41.9901, -86.4757, -2.22579, 1.18986, 7200, 0, 0, 20999, 0, 0, 0),
(84338, 18309, 557, 1, 0, 0, -39.0903, -0.189282, -0.953836, 0.015691, 7200, 0, 0, 18000, 0, 0, 0),
(84339, 18309, 557, 1, 0, 0, -39.3673, 1.55992, -0.953836, 0.08245, 7200, 0, 0, 19000, 0, 0, 0),
(84340, 18309, 557, 1, 0, 0, -100.54, -98.9886, -0.919255, 1.05241, 7200, 0, 0, 20999, 0, 0, 0),
(84341, 18309, 557, 1, 0, 0, -104.857, -235.399, 1.20778, 0.524655, 7200, 0, 0, 19000, 0, 0, 0),
(84342, 18309, 557, 1, 0, 0, -69.9356, -62.0941, -0.964752, 1.53937, 7200, 0, 0, 16000, 0, 0, 0),
(84343, 18309, 557, 1, 0, 0, -63.2713, -188.941, -1.65939, 1.6179, 7200, 0, 0, 17000, 0, 0, 0),
(84344, 18309, 557, 1, 0, 0, -186.028, -224.574, -0.955078, 0.0133424, 7200, 0, 0, 20999, 0, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84345, 18313, 557, 1, 0, 0, -29.2612, -221.361, 0.0627827, 3.04893, 7200, 0, 0, 12714, 43445, 0, 0),
(84346, 18313, 557, 1, 0, 0, -93.0405, -89.8435, -2.07859, 0.172762, 7200, 0, 0, 16142, 67345, 0, 0),
(103434, 18313, 557, 1, 0, 0, -95.9343, -100.648, -0.713801, 1.1977, 7200, 0, 0, 11000, 31495, 0, 0),
(84347, 18313, 557, 1, 0, 0, -77.2725, -224.673, -0.1353, 6.24157, 7200, 0, 0, 15285, 61370, 0, 0),
(84348, 18313, 557, 1, 0, 0, -98.4399, -240.149, 0.27052, 0.614976, 7200, 0, 0, 14428, 55395, 0, 0),
(84349, 18313, 557, 1, 0, 0, -158.764, -219.389, -0.955078, 0.123305, 7200, 0, 0, 17000, 73320, 0, 0),
(84350, 18313, 557, 1, 0, 0, -221.685, -224.871, -0.954986, 6.2808, 7200, 0, 0, 12714, 43445, 0, 0),
(84351, 18313, 557, 1, 0, 0, -158.694, -227.678, -0.955078, 0.150008, 7200, 0, 0, 15285, 61370, 0, 0),
(84352, 18313, 557, 1, 0, 0, -350.436, -172.383, -1.00589, 2.91091, 7200, 0, 0, 15285, 61370, 0, 0),
(84353, 18313, 557, 1, 0, 0, -71.0262, -170.228, -0.955649, 1.51973, 7200, 0, 0, 13571, 49420, 0, 0),
(84354, 18313, 557, 1, 0, 0, -40.757, -92.1505, -2.11541, 2.17946, 7200, 0, 0, 11857, 37470, 0, 0),
(84355, 18313, 557, 1, 0, 0, -395.561, -168.942, -0.965749, 0.362294, 7200, 0, 0, 17000, 73320, 0, 0),
(84356, 18313, 557, 1, 0, 0, -67.6727, -63.8303, -0.802501, 1.6179, 7200, 0, 0, 11857, 37470, 0, 0),
(84357, 18313, 557, 1, 0, 0, -42.0967, -198.437, -0.215628, 2.84701, 7200, 0, 0, 14428, 55395, 0, 0),
(84358, 18313, 557, 1, 0, 0, -35.5946, -193.242, -0.619096, 3.23185, 7200, 0, 0, 13571, 49420, 0, 0),
(84359, 18313, 557, 1, 0, 0, -30.7199, -226.721, -0.0238113, 2.95075, 7200, 0, 0, 17000, 73320, 0, 0),
(84360, 18313, 557, 1, 0, 0, -185.724, -222.007, -0.955078, 6.28082, 7200, 0, 0, 15285, 61370, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84361, 18312, 557, 1, 0, 0, -352.173, -72.3842, -0.960694, 3.54317, 7200, 0, 0, 12428, 38327, 0, 0),
(84362, 18312, 557, 1, 0, 0, -313.594, 9.6242, 16.8241, 6.17993, 7200, 0, 0, 12428, 38327, 0, 0),
(84363, 18312, 557, 1, 0, 0, -376.339, -112.174, -0.960199, 4.7409, 7200, 0, 0, 12428, 38327, 0, 0),
(84364, 18312, 557, 1, 0, 0, -389.702, -71.2697, -0.969852, 6.14283, 7200, 0, 0, 12428, 38327, 0, 0),
(84365, 18312, 557, 1, 0, 0, -372.069, -37.6002, -0.958738, 4.71752, 7200, 0, 0, 12428, 38327, 0, 0),
(84366, 18312, 557, 1, 0, 0, -374.09, -37.1733, -0.958738, 4.83533, 7200, 0, 0, 14142, 62775, 0, 0),
(84367, 18312, 557, 1, 0, 0, -313.879, 8.14753, 16.7919, 6.28203, 7200, 0, 0, 14142, 62775, 0, 0),
(84368, 18312, 557, 1, 0, 0, -286.126, -8.95556, 16.6855, 6.17993, 7200, 0, 0, 12000, 32215, 0, 0),
(84369, 18312, 557, 1, 0, 0, -281.328, -15.5461, 16.7233, 1.21622, 7200, 0, 0, 12857, 44439, 0, 0),
(84370, 18312, 557, 1, 0, 0, -259.883, 5.64009, 16.7864, 3.1483, 7200, 0, 0, 13285, 50551, 0, 0),
(84371, 18312, 557, 1, 0, 0, -259.938, 3.93999, 16.7864, 3.10903, 7200, 0, 0, 12428, 38327, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84372, 18315, 557, 1, 0, 0, -263.211, 1.69989, 16.7864, 3.10118, 7200, 0, 0, 14666, 46960, 0, 0),
(84373, 18315, 557, 1, 0, 0, -279.118, -1.87782, 17.3037, 4.71517, 7200, 0, 0, 13333, 39950, 0, 0),
(84374, 18315, 557, 1, 0, 0, -263.284, 7.53734, 16.7864, 3.15616, 7200, 0, 0, 20000, 75000, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(103436, 19306, 557, 1, 0, 0, -74.1126, -234.037, 0.351747, 4.15635, 7200, 0, 0, 4500, 2705, 0, 0),
(103437, 19306, 557, 1, 0, 0, -5.62019, -220.625, 1.90254, 3.52018, 7200, 0, 0, 4500, 2705, 0, 0),
(103439, 19306, 557, 1, 0, 0, -83.3448, -242.706, -0.68087, 0.625985, 7200, 0, 0, 4500, 2705, 0, 0),
(103440, 19306, 557, 1, 0, 0, -82.4194, -240.833, -0.474224, 1.63915, 7200, 0, 0, 4500, 2705, 0, 0),
(103441, 19306, 557, 1, 0, 0, -75.6589, -240.69, -0.148829, 0.543518, 7200, 0, 0, 4500, 2705, 0, 0),
(103443, 19306, 557, 1, 0, 0, -4.11661, -224.239, 1.71306, 4.96924, 7200, 0, 0, 4500, 2705, 0, 0),
(103444, 19306, 557, 1, 0, 0, -6.92058, -227.669, 1.66961, 4.03069, 7200, 0, 0, 4500, 2705, 0, 0),
(103445, 19306, 557, 1, 0, 0, -79.4614, -236.585, 0.092618, 5.4601, 7200, 0, 0, 4500, 2705, 0, 0),
(103446, 19306, 557, 1, 0, 0, -9.56577, -218.707, 1.30273, 2.93898, 7200, 0, 0, 4500, 2705, 0, 0),
(103447, 19306, 557, 1, 0, 0, -12.434, -226.788, 2.1165, 2.31852, 7200, 0, 0, 4500, 2705, 0, 0),
(84375, 19306, 557, 1, 0, 0, -377.858, -222.899, -0.95841, 2.06517, 7200, 0, 0, 4933, 2780, 0, 0),
(84376, 19306, 557, 1, 0, 0, -243.523, -170.431, -0.845092, 5.32459, 7200, 0, 0, 5366, 2855, 0, 0),
(84377, 19306, 557, 1, 0, 0, -240.858, -175.159, -0.953717, 4.5117, 7200, 0, 0, 6233, 3005, 0, 0),
(84378, 19306, 557, 1, 0, 0, -236.753, -172.115, -0.953717, 0.63969, 7200, 0, 0, 5366, 2855, 0, 0),
(84379, 19306, 557, 1, 0, 0, -378.679, -218.966, -0.95841, 5.35991, 7200, 0, 0, 6666, 3079, 0, 0),
(84380, 19306, 557, 1, 0, 0, -380.944, -221.128, -0.95841, 6.03536, 7200, 0, 0, 7100, 3155, 0, 0),
(84381, 19306, 557, 1, 0, 0, -217.79, -4.25579, 16.7463, 3.02264, 7200, 0, 0, 5366, 2855, 0, 0),
(84382, 19306, 557, 1, 0, 0, -219.255, -7.22149, 16.717, 4.1222, 7200, 0, 0, 7100, 3155, 0, 0),
(84383, 19306, 557, 1, 0, 0, -220.035, -12.2439, 16.6851, 2.6103, 7200, 0, 0, 6233, 3005, 0, 0),
(84384, 19306, 557, 1, 0, 0, -217.021, -12.8694, 16.6851, 0.446529, 7200, 0, 0, 4500, 2705, 0, 0),
(84385, 19306, 557, 1, 0, 0, -213.442, -7.29288, 16.7312, 2.91268, 7200, 0, 0, 5366, 2855, 0, 0),
(84386, 19306, 557, 1, 0, 0, -221.373, -7.8621, 16.7088, 2.64957, 7200, 0, 0, 5800, 2930, 0, 0),
(84387, 19306, 557, 1, 0, 0, -219.664, 24.9886, 16.756, 1.43221, 7200, 0, 0, 5800, 2930, 0, 0),
(84388, 19306, 557, 1, 0, 0, -222.487, 25.8247, 16.7758, 4.69554, 7200, 0, 0, 4500, 2705, 0, 0),
(84389, 19306, 557, 1, 0, 0, -219.321, 29.0473, 16.7178, 4.617, 7200, 0, 0, 4500, 2705, 0, 0),
(84390, 19306, 557, 1, 0, 0, -218.892, 32.5065, 16.7749, 0.132377, 7200, 0, 0, 4933, 2780, 0, 0),
(84391, 19306, 557, 1, 0, 0, -215.033, 24.7897, 16.7222, 4.43636, 7200, 0, 0, 7100, 3155, 0, 0),
(84392, 19306, 557, 1, 0, 0, -221.347, 28.2273, 16.7384, 2.1862, 7200, 0, 0, 7100, 3155, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84393, 18314, 557, 1, 0, 0, -370.462, -130.369, -0.960249, 4.82336, 7200, 0, 0, 17000, 0, 0, 0),
(84394, 18314, 557, 1, 0, 0, -373.226, -126.269, -0.960249, 4.73304, 7200, 0, 0, 27285, 0, 0, 0),
(84395, 18314, 557, 1, 0, 0, -348.004, -69.335, -0.965187, 3.33504, 7200, 0, 0, 29000, 0, 0, 0),
(84402, 18314, 557, 1, 0, 0, -387.653, -167.484, -0.960508, 5.49094, 7200, 0, 0, 17000, 0, 0, 0),
(84403, 18314, 557, 1, 0, 0, -352.537, -67.3998, -0.966029, 3.20937, 7200, 0, 0, 17000, 0, 0, 0),
(84396, 18314, 557, 1, 0, 0, -375.789, -130.331, -0.960249, 4.65843, 7200, 0, 0, 22142, 0, 0, 0),
(84397, 18314, 557, 1, 0, 0, -369.872, -112.057, -0.960246, 4.75661, 7200, 0, 0, 22142, 0, 0, 0),
(84398, 18314, 557, 1, 0, 0, -371.098, -233.149, -0.957896, 4.66796, 7200, 0, 0, 22142, 0, 0, 0),
(84399, 18314, 557, 1, 0, 0, -374.246, -232.754, -0.957896, 4.66011, 7200, 0, 0, 20428, 0, 0, 0),
(84400, 18314, 557, 1, 0, 0, -388.826, -66.7126, -0.969734, 6.04859, 7200, 0, 0, 23857, 0, 0, 0),
(84401, 18314, 557, 1, 0, 0, -394.681, -68.8709, -0.907808, 5.98575, 7200, 0, 0, 18714, 0, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(103435, 19307, 557, 1, 0, 0, -32.6407, -223.731, -0.166912, 3.03819, 7200, 0, 0, 30000, 0, 0, 2),
(84404, 19307, 557, 1, 0, 0, -355.789, -167.795, -0.975333, 2.22761, 7200, 0, 0, 30000, 0, 0, 0),
(84405, 19307, 557, 1, 0, 0, -209.278, -249.618, -0.956738, 1.64303, 7200, 0, 0, 30000, 0, 0, 0),
(84406, 19307, 557, 1, 0, 0, -388.927, -63.7564, -0.959777, 6.26063, 7200, 0, 0, 42666, 0, 0, 0),
(84407, 19307, 557, 1, 0, 0, -361.955, -80.0922, -0.944992, 3.19366, 7200, 0, 0, 30000, 0, 0, 0),
(84408, 19307, 557, 1, 0, 0, -273.712, 30.0797, 23.9211, 4.30284, 7200, 0, 0, 42666, 0, 0, 0);
DELETE FROM `creature` WHERE (`guid`=92290);
INSERT INTO `creature` (`guid`, `id`, `map`, `spawnMask`, `modelid`, `equipment_id`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`, `spawndist`, `currentwaypoint`, `curhealth`, `curmana`, `DeathState`, `MovementType`) VALUES (92290, 18341, 557, 1, 0, 0, -68.1309, -108.441, -0.323933, 1.53543, 43200, 10, 0, 73000, 0, 0, 1);
DELETE FROM `creature` WHERE (`guid`=103458);
INSERT INTO `creature` (`guid`, `id`, `map`, `spawnMask`, `modelid`, `equipment_id`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`, `spawndist`, `currentwaypoint`, `curhealth`, `curmana`, `DeathState`, `MovementType`) VALUES (103458, 18343, 557, 1, 0, 0, -322.452, -223.507, -0.955587, 0.030986, 43200, 0, 0, 91000, 0, 0, 0);
DELETE FROM `creature` WHERE (`guid`=77065);
INSERT INTO `creature` (`guid`, `id`, `map`, `spawnMask`, `modelid`, `equipment_id`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`, `spawndist`, `currentwaypoint`, `curhealth`, `curmana`, `DeathState`, `MovementType`) VALUES (77065, 18344, 557, 1, 0, 0, -203.222, 8.24252, 16.7946, 3.14919, 43200, 0, 0, 86000, 28460, 0, 0);
UPDATE `creature`, `creature_template` SET `creature`.`curhealth`=`creature_template`.`minhealth`,`creature`.`curmana`=`creature_template`.`minmana` WHERE `creature`.`id`=`creature_template`.`entry`;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84338;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84339;
DELETE FROM `creature_movement` WHERE `id`=84338;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84338, 1, -39, 0, -0.953846, 0, '', '', '', '', '', 0, 0, 0, 0.015691, 0, 0),
(84338, 2, -49, -1, -0.94995, 0, '', '', '', '', '', 0, 0, 0, 3.24367, 0, 0),
(84338, 3, -64, -18, -0.944449, 0, '', '', '', '', '', 0, 0, 0, 3.92304, 0, 0),
(84338, 4, -49, -1, -0.94995, 0, '', '', '', '', '', 0, 0, 0, 3.24367, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84339;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84339, 1, -39, 1, -0.953846, 0, '', '', '', '', '', 0, 0, 0, 0.015691, 0, 0),
(84339, 2, -49, 0, -0.94995, 0, '', '', '', '', '', 0, 0, 0, 3.24367, 0, 0),
(84339, 3, -64, -17, -0.944449, 0, '', '', '', '', '', 0, 0, 0, 3.92304, 0, 0),
(84339, 4, -49, 0, -0.94995, 0, '', '', '', '', '', 0, 0, 0, 3.24367, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84346;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84305;
DELETE FROM `creature_movement` WHERE `id`=84346;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84346, 1, -93, -90, -2.07859, 0, '', '', '', '', '', 0, 0, 0, 0.172762, 0, 0),
(84346, 2, -48, -79, -2.31989, 0, '', '', '', '', '', 0, 0, 0, 0.227738, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84305;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84305, 1, -93, -88, -2.07859, 0, '', '', '', '', '', 0, 0, 0, 0.172762, 0, 0),
(84305, 2, -48, -77, -2.31989, 0, '', '', '', '', '', 0, 0, 0, 0.227738, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 103435;
DELETE FROM `creature_movement` WHERE `id`=103435;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(103435, 1, -32.6407, -223.731, -0.166912, 0, '', '', '', '', '', 0, 0, 0, 3.03819, 0, 0),
(103435, 2, -52.6774, -220.224, 0.223178, 0, '', '', '', '', '', 0, 0, 0, 2.97536, 0, 0),
(103435, 3, -81.7883, -217.554, -0.490706, 0, '', '', '', '', '', 0, 0, 0, 2.9086, 0, 0),
(103435, 4, -84.5835, -216.542, -1.77318, 0, '', '', '', '', '', 0, 0, 0, 2.89289, 0, 0),
(103435, 5, -107.288, -209.474, -1.51641, 0, '', '', '', '', '', 0, 0, 0, 2.72403, 0, 0),
(103435, 6, -106.175, -224.699, 0.037004, 0, '', '', '', '', '', 0, 0, 0, 5.88918, 0, 0),
(103435, 7, -74.4607, -224.087, -0.170633, 0, '', '', '', '', '', 0, 0, 0, 0.030112, 0, 0);
UPDATE `creature` SET `spawndist` = 3, `MovementType` = 1 WHERE `id` = 19306;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84347;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84409;
DELETE FROM `creature_movement` WHERE `id`=84347;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84347, 1, -77, -224, -0.1353, 0, '', '', '', '', '', 0, 0, 0, 6.24157, 0, 0),
(84347, 2, -34, -223, -0.246379, 0, '', '', '', '', '', 0, 0, 0, 0.017284, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84409;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84409, 1, -77, -226, -0.1353, 0, '', '', '', '', '', 0, 0, 0, 6.24157, 0, 0),
(84409, 2, -34, -225, -0.246379, 0, '', '', '', '', '', 0, 0, 0, 0.017284, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84330;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84329;
DELETE FROM `creature_movement` WHERE `id`=84330;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84330, 1, -91, -229, 0.132493, 0, '', '', '', '', '', 0, 0, 0, 2.3939, 0, 0),
(84330, 2, -110, -208, -1.45776, 0, '', '', '', '', '', 0, 0, 0, 2.30751, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84329;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84329, 1, -92, -230, 0.132493, 0, '', '', '', '', '', 0, 0, 0, 2.3939, 0, 0),
(84329, 2, -111, -209, -1.45776, 0, '', '', '', '', '', 0, 0, 0, 2.30751, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 103435;
DELETE FROM `creature_movement` WHERE `id`=103435;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(103435, 1, -32.6407, -223.731, -0.166912, 0, '', '', '', '', '', 0, 0, 0, 3.03819, 0, 0),
(103435, 2, -52.6774, -220.224, 0.223178, 0, '', '', '', '', '', 0, 0, 0, 2.97536, 0, 0),
(103435, 3, -81.7883, -217.554, -0.490706, 0, '', '', '', '', '', 0, 0, 0, 2.9086, 0, 0),
(103435, 4, -84.5835, -216.542, -1.77318, 0, '', '', '', '', '', 0, 0, 0, 2.89289, 0, 0),
(103435, 5, -107.288, -209.474, -1.51641, 0, '', '', '', '', '', 0, 0, 0, 2.72403, 0, 0),
(103435, 6, -106.175, -224.699, 0.037004, 0, '', '', '', '', '', 0, 0, 0, 5.88918, 0, 0),
(103435, 7, -74.4607, -224.087, -0.170633, 0, '', '', '', '', '', 0, 0, 0, 0.030112, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84316;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84315;
DELETE FROM `creature_movement` WHERE `id`=84316;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84316, 1, -201, -204, 1.93924, 0, '', '', '', '', '', 0, 0, 0, 4.52152, 0, 0),
(84316, 2, -213, -238, -0.955472, 0, '', '', '', '', '', 0, 0, 0, 4.38015, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84315;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84315, 1, -201, -204, 1.93924, 0, '', '', '', '', '', 0, 0, 0, 4.52152, 0, 0),
(84315, 2, -213, -238, -0.955472, 0, '', '', '', '', '', 0, 0, 0, 4.38015, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84336;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84399;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84398;
DELETE FROM `creature_movement` WHERE `id`=84336;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84336, 1, -373, -235, -0.957896, 0, '', '', '', '', '', 0, 0, 0, 4.7308, 0, 0),
(84336, 2, -373, -203, -0.957896, 0, '', '', '', '', '', 0, 0, 0, 1.58135, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84399;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84399, 1, -374, -233, -0.957896, 0, '', '', '', '', '', 0, 0, 0, 4.7308, 0, 0),
(84399, 2, -374, -201, -0.957896, 0, '', '', '', '', '', 0, 0, 0, 1.58135, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84398;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84398, 1, -372, -233, -0.957896, 0, '', '', '', '', '', 0, 0, 0, 4.7308, 0, 0),
(84398, 2, -372, -201, -0.957896, 0, '', '', '', '', '', 0, 0, 0, 1.58135, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 103464;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84402;
DELETE FROM `creature_movement` WHERE `id`=103464;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(103464, 1, -388, -168, -0.960508, 0, '', '', '', '', '', 0, 0, 0, 5.53021, 0, 0),
(103464, 2, -372, -180, -0.959961, 0, '', '', '', '', '', 0, 0, 0, 0.103106, 0, 0),
(103464, 3, -360, -165, -0.960014, 0, '', '', '', '', '', 0, 0, 0, 1.41079, 0, 0),
(103464, 4, -373, -149, -0.960014, 0, '', '', '', '', '', 0, 0, 0, 2.48286, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84402;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84402, 1, -387, -167, -0.960508, 0, '', '', '', '', '', 0, 0, 0, 5.53021, 0, 0),
(84402, 2, -371, -179, -0.959961, 0, '', '', '', '', '', 0, 0, 0, 0.103106, 0, 0),
(84402, 3, -359, -164, -0.960014, 0, '', '', '', '', '', 0, 0, 0, 1.41079, 0, 0),
(84402, 4, -372, -148, -0.960014, 0, '', '', '', '', '', 0, 0, 0, 2.48286, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84404;
DELETE FROM `creature_movement` WHERE `id`=84404;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84404, 1, -355.789, -167.795, -0.975333, 0, '', '', '', '', '', 0, 0, 0, 2.22761, 0, 0),
(84404, 2, -370.02, -149.635, -0.960076, 0, '', '', '', '', '', 0, 0, 0, 2.23547, 0, 0),
(84404, 3, -389.991, -164.493, -0.957847, 0, '', '', '', '', '', 0, 0, 0, 3.80626, 0, 0),
(84404, 4, -370.862, -149.399, -0.958743, 0, '', '', '', '', '', 0, 0, 0, 0.36229, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84407;
DELETE FROM `creature_movement` WHERE `id`=84407;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84407, 1, -361.955, -80.0922, -0.944992, 0, '', '', '', '', '', 0, 0, 0, 3.19366, 0, 0),
(84407, 2, -381.927, -82.6505, -0.958739, 0, '', '', '', '', '', 0, 0, 0, 3.24864, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84406;
DELETE FROM `creature_movement` WHERE `id`=84406;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84406, 1, -388.927, -63.7564, -0.959777, 0, '', '', '', '', '', 0, 0, 0, 6.26063, 0, 0),
(84406, 2, -355.342, -66.1591, -0.967629, 0, '', '', '', '', '', 0, 0, 0, 6.08392, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84408;
DELETE FROM `creature_movement` WHERE `id`=84408;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84408, 1, -273.712, 30.0797, 23.9211, 0, '', '', '', '', '', 0, 0, 0, 4.30284, 0, 0),
(84408, 2, -279.691, 8.97218, 16.7868, 0, '', '', '', '', '', 0, 0, 0, 4.43636, 0, 0),
(84408, 3, -282.022, -6.84492, 16.6851, 0, '', '', '', '', '', 0, 0, 0, 4.56595, 0, 0),
(84408, 4, -279.987, 8.63882, 16.7869, 0, '', '', '', '', '', 0, 0, 0, 1.14947, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84362;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84367;
DELETE FROM `creature_movement` WHERE `id`=84362;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84362, 1, -313, 9, 16.8241, 0, '', '', '', '', '', 0, 0, 0, 6.17993, 0, 0),
(84362, 2, -284, 6, 16.7885, 0, '', '', '', '', '', 0, 0, 0, 6.18386, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84367;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84367, 1, -313, 8, 16.8241, 0, '', '', '', '', '', 0, 0, 0, 6.17993, 0, 0),
(84367, 2, -284, 5, 16.7885, 0, '', '', '', '', '', 0, 0, 0, 6.18386, 0, 0);
DELETE FROM `creature_template_addon` WHERE (`entry`=18331);
INSERT INTO `creature_template_addon` (`entry`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (18331, 0, 0, 0, 0, 0, 0, '16592 0');
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84405;
DELETE FROM `creature_movement` WHERE `id`=84405;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84405, 1, -209.278, -249.618, -0.956738, 0, '', '', '', '', '', 0, 0, 0, 1.64303, 0, 0),
(84405, 2, -216.34, -207.151, 0.300485, 0, '', '', '', '', '', 0, 0, 0, 1.73728, 0, 0);
DELETE FROM `creature` WHERE `id`=22928;
DELETE FROM `creature` WHERE `id`=19673;
DELETE FROM `creature` WHERE `id`=19672;
DELETE FROM `creature` WHERE `id`=19671;
DELETE FROM `creature` WHERE `id`=19666;
UPDATE `creature_template` SET `maxlevel` = 67, `minhealth` = 16473, `maxhealth` = 16473, `armor` = 0, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 309, `maxrangedmg` = 432, `resistance5` = 50, `mechanic_immune_mask` = 8388624 WHERE `entry` = 18524;
UPDATE `creature_template` SET `maxlevel` = 66, `minhealth` = 18943, `maxhealth` = 18943, `armor` = 5185, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 432, `mechanic_immune_mask` = 109124509 WHERE `entry` = 18497;
UPDATE `creature_template` SET `maxlevel` = 67, `minhealth` = 20497, `maxhealth` = 20497, `maxmana` = 8538, `armor` = 5212, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 314, `maxrangedmg` = 438, `mechanic_immune_mask` = 0 WHERE `entry` = 18702;
UPDATE `creature_template` SET `maxlevel` = 67, `armor` = 4185, `faction_A` = 14, `faction_H` = 14, `mindmg` = 275, `maxdmg` = 516, `attackpower` = 2720, `minrangedmg` = 305, `maxrangedmg` = 432, `resistance5` = 100, `mechanic_immune_mask` = 0 WHERE `entry` = 18493;
UPDATE `creature_template` SET `maxlevel` = 66, `minhealth` = 13127, `maxhealth` = 13127, `armor` = 4185, `faction_A` = 14, `faction_H` = 14, `mindmg` = 275, `maxdmg` = 516, `attackpower` = 2720, `minrangedmg` = 305, `maxrangedmg` = 432, `resistance5` = 50, `mechanic_immune_mask` = 0 WHERE `entry` = 18495;
UPDATE `creature_template` SET `minhealth` = 30179, `maxhealth` = 30179, `armor` = 7239, `faction_A` = 14, `faction_H` = 14, `mindmg` = 483, `maxdmg` = 819, `attackpower` = 4757, `minrangedmg` = 314, `maxrangedmg` = 438, `mechanic_immune_mask` = 75570076 WHERE `entry` = 18478;
UPDATE `creature_template` SET `maxlevel` = 67, `minhealth` = 1279, `maxhealth` = 1279, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 45, `maxrangedmg` = 58, `mechanic_immune_mask` = 8388624 WHERE `entry` = 18503;
UPDATE `creature_template` SET `maxlevel` = 65, `minhealth` = 1549, `maxhealth` = 1549, `armor` = 0, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 432, `resistance1` = 100, `mechanic_immune_mask` = 8388624 WHERE `entry` = 18557;
UPDATE `creature_template` SET `maxlevel` = 65, `minhealth` = 6499, `maxhealth` = 6499, `armor` = 3096, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 432, `mechanic_immune_mask` = 8388624 WHERE `entry` = 18556;
UPDATE `creature_template` SET `maxlevel` = 66, `minhealth` = 4997, `maxhealth` = 4997, `armor` = 0, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 425, `resistance2` = 50, `resistance5` = 50, `spell3` = 22424 WHERE `entry` = 18558;
UPDATE `creature_template` SET `maxlevel` = 66, `minhealth` = 4489, `maxhealth` = 4489, `armor` = 3096, `faction_A` = 14, `faction_H` = 14, `baseattacktime` = 1500, `rangeattacktime` = 2000, `minrangedmg` = 238, `maxrangedmg` = 315, `rangedattackpower` = 1000 WHERE `entry` = 18559;
UPDATE `creature_template` SET `maxlevel` = 67, `minhealth` = 16050, `maxhealth` = 16050, `armor` = 3212, `faction_A` = 14, `faction_H` = 14, `mindmg` = 278, `maxdmg` = 520, `attackpower` = 2747, `minrangedmg` = 309, `maxrangedmg` = 438, `resistance5` = 50, `mechanic_immune_mask` = 8388624 WHERE `entry` = 18521;
UPDATE `creature_template` SET `maxlevel` = 65, `maxhealth` = 2600, `armor` = 0, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 432, `spell2` = 0 WHERE `entry` = 18506;
UPDATE `creature_template` SET `minlevel` = 65, `maxlevel` = 65, `minhealth` = 3300, `maxhealth` = 3300, `armor` = 0, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 309, `maxrangedmg` = 438, `lootid` = 0 WHERE `entry` = 18700;
UPDATE `creature_template` SET `maxlevel` = 67, `maxhealth` = 5000, `armor` = 0, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 46, `spell2` = 0, `spell3` = 0, `mechanic_immune_mask` = 8912912 WHERE `entry` = 18441;
UPDATE `creature_template` SET `maxlevel` = 65, `maxhealth` = 6800, `armor` = 0, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 309, `maxrangedmg` = 432, `resistance1` = 100, `spell3` = 0, `spell4` = 0 WHERE `entry` = 18500;
UPDATE `creature_template` SET `maxlevel` = 65, `maxhealth` = 7600, `armor` = 3096, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 425 WHERE `entry` = 18498;
UPDATE `creature_template` SET `maxhealth` = 5800, `armor` = 0, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 432, `resistance2` = 50, `resistance5` = 50, `spell3` = 0 WHERE `entry` = 18499;
UPDATE `creature_template` SET `maxlevel` = 65, `maxhealth` = 6400, `faction_A` = 14, `faction_H` = 14, `minrangedmg` = 305, `maxrangedmg` = 425, `spell2` = 37551 WHERE `entry` = 18501;
UPDATE `creature_template` SET `spell1` = 32846, `spell2` = 32849, `spell3` = 32854, `spell4` = 32855 WHERE `entry` = 18497;
UPDATE `creature_template` SET `spell3` = 32858, `spell4` = 32857, `spell1` = 32859, `spell2` = 32860 WHERE `entry` = 18493;
UPDATE `creature_template` SET `spell3` = 32853, `spell4` = 32854, `spell1` = 17289, `spell2` = 32861 WHERE `entry` = 18495;
UPDATE `creature_template` SET `spell1` = 0 WHERE `entry` = 18503;
UPDATE `gameobject_template` SET `size` = 0.5 WHERE `entry` = 183441;
UPDATE `creature_template` SET `faction_A` = 7, `faction_H` = 7 WHERE `entry` = 18556;
UPDATE `creature_template` SET `faction_A` = 7, `faction_H` = 7 WHERE `entry` = 18557;
UPDATE `creature_template` SET `faction_A` = 7, `faction_H` = 7 WHERE `entry` = 18558;
UPDATE `creature_template` SET `faction_A` = 7, `faction_H` = 7 WHERE `entry` = 18559;
UPDATE `creature_template` SET `maxlevel` = 67, `maxhealth` = 76000, `armor` = 5212, `faction_A` = 14, `faction_H` = 14, `mindmg` = 1180, `maxdmg` = 1314, `attackpower` = 3733, `minrangedmg` = 309, `maxrangedmg` = 432, `mechanic_immune_mask` = 109525855 WHERE `entry` = 18371;
DELETE FROM `creature_loot_template` WHERE (`entry`=18371);
INSERT INTO `creature_loot_template` VALUES 
(18371, 25964, 0, 1, 1, 1, 0, 0, 0),
(18371, 26055, 0, 1, 1, 1, 0, 0, 0),
(18371, 27408, 0, 1, 1, 1, 0, 0, 0),
(18371, 27409, 0, 1, 1, 1, 0, 0, 0),
(18371, 27410, 0, 1, 1, 1, 0, 0, 0),
(18371, 28558, 64, 0, 1, 1, 0, 0, 0);
UPDATE `creature_template` SET `maxlevel` = 67, `maxhealth` = 82000, `armor` = 9239, `faction_A` = 14, `faction_H` = 14, `mindmg` = 1183, `maxdmg` = 1319, `attackpower` = 3757, `minrangedmg` = 314, `maxrangedmg` = 438, `mechanic_immune_mask` = 75971419 WHERE `entry` = 18373;
DELETE FROM `creature_loot_template` WHERE (`entry`=18373);
INSERT INTO `creature_loot_template` VALUES 
(18373, 23572, 5, 0, 1, 1, 0, 0, 0),
(18373, 27411, 0, 1, 1, 1, 0, 0, 0),
(18373, 27412, 0, 1, 1, 1, 0, 0, 0),
(18373, 27413, 0, 1, 1, 1, 0, 0, 0),
(18373, 27414, 0, 1, 1, 1, 0, 0, 0),
(18373, 27415, 0, 1, 1, 1, 0, 0, 0),
(18373, 27416, 0, 1, 1, 1, 0, 0, 0),
(18373, 28558, 60, 0, 1, 1, 0, 0, 0);
INSERT INTO `gameobject` (`guid`, `id`, `map`, `spawnMask`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `spawntimesecs`, `animprogress`, `state`) VALUES (73727, 184526, 558, 1, -28.0019, 0.120984, -0.1206, 6.27843, 0, 0, 0.00237766, -0.999997, 25, 0, 1);
INSERT INTO `gameobject` (`guid`, `id`, `map`, `spawnMask`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `spawntimesecs`, `animprogress`, `state`) VALUES (73728, 184526, 530, 1, -3361.94, 5230.63, -101.048, 4.73389, 0, 0, 0.699464, -0.714668, 25, 0, 1);
DELETE FROM `gameobject` WHERE `id`=183441;
INSERT INTO `gameobject` (`guid`,`id`,`map`,`spawnMask`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(73729, 183441, 558, 1, 224.327, 29.343, 4.30752, 1.59257, 0, 0, 0.714762, 0.699367, 25, 0, 1),
(73730, 183441, 558, 1, 236.882, 29.3927, 4.63918, 1.46693, 0, 0, 0.669447, 0.742859, 25, 0, 1);
DELETE FROM `creature` WHERE `id`=18478;
DELETE FROM `creature` WHERE `id`=19412;
DELETE FROM `creature` WHERE `id`=18558;
DELETE FROM `creature` WHERE `id`=18441;
DELETE FROM `creature` WHERE `id`=18500;
DELETE FROM `creature` WHERE `id`=18498;
DELETE FROM `creature` WHERE `id`=18499;
DELETE FROM `creature` WHERE `id`=18501;
DELETE FROM `creature` WHERE `id`=18524;
DELETE FROM `creature` WHERE `id`=18503;
DELETE FROM `creature` WHERE `id`=18700;
DELETE FROM `creature` WHERE `id`=18506;
DELETE FROM `creature` WHERE `id`=18521;
DELETE FROM `creature` WHERE `id`=18559;
DELETE FROM `creature` WHERE `id`=18556;
DELETE FROM `creature` WHERE `id`=18557;
DELETE FROM `creature` WHERE `id`=18495;
DELETE FROM `creature` WHERE `id`=18493;
DELETE FROM `creature` WHERE `id`=18497;
DELETE FROM `creature` WHERE `id`=18702;
DELETE FROM `creature` WHERE `id`=18371;
DELETE FROM `creature_addon` WHERE `guid` NOT IN (SELECT `guid` FROM `creature`);
DELETE FROM `creature_movement` WHERE `id` NOT IN (SELECT `guid` FROM `creature`);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84410, 18524, 558, 1, 0, 0, -124.576, -272.196, 26.1336, 4.65304, 7200, 0, 0, 16473, 0, 0, 0),
(84411, 18524, 558, 1, 0, 0, -123.079, -270.761, 26.3943, 1.28369, 7200, 0, 0, 16473, 0, 0, 0),
(84412, 18524, 558, 1, 0, 0, -167.76, -277.377, 29.345, 3.17649, 7200, 0, 0, 16473, 0, 0, 0),
(84413, 18524, 558, 1, 0, 0, -162.958, -283.333, 26.9486, 3.95404, 7200, 0, 0, 16473, 0, 0, 0),
(84414, 18524, 558, 1, 0, 0, -155.702, -276.376, 26.614, 5.02218, 7200, 0, 0, 16473, 0, 0, 0),
(84415, 18524, 558, 1, 0, 0, -157.426, -267.584, 25.8674, 4.29176, 7200, 0, 0, 16473, 0, 0, 0),
(84416, 18524, 558, 1, 0, 0, -154.702, -241.398, 29.118, 0.741767, 7200, 0, 0, 16473, 0, 0, 0),
(84417, 18524, 558, 1, 0, 0, -156.096, -238.574, 29.5669, 0.836015, 7200, 0, 0, 16473, 0, 0, 0),
(84418, 18524, 558, 1, 0, 0, -150.863, -239.307, 29.2343, 6.01179, 7200, 0, 0, 16473, 0, 0, 0),
(84419, 18524, 558, 1, 0, 0, -151.758, -236.116, 29.3149, 2.01804, 7200, 0, 0, 16473, 0, 0, 0),
(84420, 18524, 558, 1, 0, 0, -151.061, -242.675, 28.9425, 2.24188, 7200, 0, 0, 16473, 0, 0, 0),
(84421, 18524, 558, 1, 0, 0, -127.569, -274.223, 25.8646, 5.36383, 7200, 0, 0, 16473, 0, 0, 0),
(84422, 18524, 558, 1, 0, 0, -164.593, -273.794, 27.226, 5.67013, 7200, 0, 0, 16473, 0, 0, 0),
(84423, 18524, 558, 1, 0, 0, -121.777, -279.15, 27.5488, 1.90022, 7200, 0, 0, 16473, 0, 0, 0),
(84424, 18524, 558, 1, 0, 0, -126.733, -278.186, 27.0191, 1.51538, 7200, 0, 0, 16473, 0, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(74134, 18497, 558, 1, 17912, 0, 237.462, -71.1569, 26.5921, 1.51957, 7200, 0, 0, 18943, 0, 0, 0),
(74136, 18497, 558, 1, 0, 0, 252.273, -26.3411, 2.25327, 2.2469, 7200, 0, 0, 18943, 0, 0, 0),
(74153, 18497, 558, 1, 17912, 0, 226.768, 17.6071, -0.0705926, 5.35316, 7200, 0, 0, 18943, 0, 0, 0),
(74154, 18497, 558, 1, 0, 0, 83.758, 35.174, 1.78938, 1.58328, 7200, 0, 0, 18943, 0, 0, 0),
(84425, 18497, 558, 1, 17912, 0, 147.923, 35.8223, 2.31793, 1.54401, 7200, 0, 0, 18943, 0, 0, 0),
(84426, 18497, 558, 1, 0, 0, 174.731, 0.608368, -0.135641, 1.70895, 7200, 0, 0, 18943, 0, 0, 0),
(84427, 18497, 558, 1, 0, 0, 115.902, 1.19976, 0.00687454, 3.10305, 7200, 0, 0, 18943, 0, 0, 0),
(84428, 18497, 558, 1, 17912, 0, 9.00909, -159.548, 12.6541, 6.27516, 7200, 0, 0, 18943, 0, 0, 0),
(84429, 18497, 558, 1, 17912, 0, 161.803, -162.758, 26.0179, 3.1375, 7200, 0, 0, 18943, 0, 0, 0),
(84430, 18497, 558, 1, 17912, 0, 228.724, -162.047, 26.5921, 0.00374126, 7200, 0, 0, 18943, 0, 0, 0),
(84431, 18497, 558, 1, 17912, 0, 8.95446, -166.351, 12.6541, 6.27123, 7200, 0, 0, 18943, 0, 0, 0);
DELETE FROM `creature_template_addon` WHERE (`entry`=18497);
INSERT INTO `creature_template_addon` (`entry`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (18497, 0, 0, 0, 0, 0, 0, '38168 0');
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(103512, 18702, 558, 1, 0, 0, -53.0039, -402.919, 30.9842, 2.68562, 7200, 5, 0, 20000, 8538, 0, 1),
(103525, 18702, 558, 1, 0, 0, -26.6179, -364.252, 26.5898, 3.33356, 7200, 5, 0, 20000, 8538, 0, 1),
(103549, 18702, 558, 1, 0, 0, 16.6444, -409.677, 26.5866, 2.90552, 7200, 5, 0, 20000, 8538, 0, 1);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(74131, 18493, 558, 1, 0, 0, 69.4134, 4.79423, -0.106698, 1.58251, 7200, 0, 0, 17500, 9031, 0, 0),
(74132, 18493, 558, 1, 17926, 0, 68.4175, -28.3488, -0.0762487, 0.0117059, 7200, 0, 0, 13000, 8370, 0, 0),
(84432, 18493, 558, 1, 0, 0, 82.3804, 41.0604, 4.2616, 4.66205, 7200, 0, 0, 22000, 9693, 0, 0),
(84433, 18493, 558, 1, 17926, 0, 231.499, 18.4052, -0.0651013, 3.92374, 7200, 0, 0, 17500, 9031, 0, 0),
(84434, 18493, 558, 1, 0, 0, 173.743, 6.24273, -0.299721, 4.86625, 7200, 0, 0, 13000, 8370, 0, 0),
(84435, 18493, 558, 1, 17926, 0, 146.616, 40.4528, 4.26093, 4.74845, 7200, 0, 0, 13000, 8370, 0, 0),
(84436, 18493, 558, 1, 17926, 0, 143.095, -20.2822, 7.91571, 1.66184, 7200, 0, 0, 17500, 9031, 0, 0),
(84437, 18493, 558, 1, 0, 0, 112.804, -1.84498, -0.00720795, 3.16588, 7200, 0, 0, 17500, 9031, 0, 0),
(84438, 18493, 558, 1, 0, 0, 82.949, -40.3589, 4.26021, 1.37124, 7200, 0, 0, 13000, 8370, 0, 0),
(84439, 18493, 558, 1, 17926, 0, 88.9187, 7.35381, -0.072958, 1.53145, 7200, 0, 0, 22000, 9693, 0, 0),
(84440, 18493, 558, 1, 0, 0, 81.8499, -7.81464, -0.0673912, 4.64163, 7200, 0, 0, 22000, 9693, 0, 0),
(84441, 18493, 558, 1, 0, 0, 241.579, -71.2993, 26.5921, 1.54706, 7200, 0, 0, 22000, 9693, 0, 0),
(84442, 18493, 558, 1, 17926, 0, 248.094, -24.0137, -0.283807, 0.0791975, 7200, 0, 0, 22000, 9693, 0, 0),
(84443, 18493, 558, 1, 17926, 0, 161.781, -164.669, 26.02, 3.12965, 7200, 0, 0, 17500, 9031, 0, 0),
(84444, 18493, 558, 1, 17926, 0, 229.86, -158.29, 26.5921, 5.78035, 7200, 0, 0, 13000, 8370, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84445, 18495, 558, 1, 0, 0, 84.5594, 41.2589, 4.26173, 4.6699, 7200, 0, 0, 13127, 8370, 0, 0),
(84446, 18495, 558, 1, 0, 0, 80.9356, -40.3937, 4.26021, 1.37517, 7200, 0, 0, 13127, 8370, 0, 0),
(84447, 18495, 558, 1, 0, 0, 84.5857, -7.67985, -0.0672463, 4.71624, 7200, 0, 0, 13127, 9693, 0, 0),
(84448, 18495, 558, 1, 17944, 0, 85.9449, 6.98868, -0.075464, 1.50082, 7200, 0, 0, 13127, 8370, 0, 0),
(84449, 18495, 558, 1, 0, 0, 176.317, 3.12773, -0.208845, 3.15801, 7200, 0, 0, 13127, 9693, 0, 0),
(84450, 18495, 558, 1, 17944, 0, 149.173, 40.4476, 4.25967, 4.76023, 7200, 0, 0, 13127, 8370, 0, 0),
(84451, 18495, 558, 1, 0, 0, 146.211, -17.7519, 8.15182, 3.09519, 7200, 0, 0, 13127, 9693, 0, 0),
(84452, 18495, 558, 1, 0, 0, 140.15, -17.525, 7.92934, 0.0125024, 7200, 0, 0, 13127, 8370, 0, 0),
(84453, 18495, 558, 1, 17944, 0, 112.583, 4.01591, 0.506741, 3.22479, 7200, 0, 0, 13127, 9693, 0, 0),
(84454, 18495, 558, 1, 17944, 0, 254.26, -21.5761, -1.59846, 3.68025, 7200, 0, 0, 13127, 9693, 0, 0),
(84455, 18495, 558, 1, 17944, 0, 228.852, -166.058, 26.5921, 0.486761, 7200, 0, 0, 13127, 8370, 0, 0),
(84456, 18495, 558, 1, 0, 0, 161.787, -160.916, 26.0173, 3.05503, 7200, 0, 0, 13127, 9693, 0, 0),
(84457, 18495, 558, 1, 17944, 0, 232.695, -159.494, 26.5913, 4.17815, 7200, 0, 0, 13127, 8370, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84458, 18557, 558, 1, 17930, 0, 243.301, -117.127, 26.5913, 1.53099, 7200, 0, 0, 1549, 8370, 0, 0),
(84459, 18557, 558, 1, 0, 0, 229.463, 14.517, -0.0677823, 1.67237, 7200, 0, 0, 1549, 8370, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(103488, 18556, 558, 1, 0, 0, 134.878, 17.7827, 0.039311, 4.80184, 7200, 0, 0, 6000, 0, 0, 0),
(84460, 18556, 558, 1, 17922, 0, -97.8572, -159.644, 26.5903, 3.10661, 7200, 0, 0, 6499, 0, 0, 0);
DELETE FROM `creature` WHERE `id`=18558;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84461, 18558, 558, 1, 0, 0, 43.1372, 30.1599, -0.123805, 4.63846, 7200, 0, 0, 4997, 8370, 0, 0),
(84462, 18558, 558, 1, 0, 0, 101.446, -25.5502, -0.0418365, 1.54792, 7200, 0, 0, 4997, 9693, 0, 0),
(84463, 18558, 558, 1, 0, 0, 139.031, -154.143, 12.6004, 4.6726, 7200, 0, 0, 4997, 9693, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84464, 18559, 558, 1, 17940, 0, 165.991, -19.1418, 3.23161, 1.50004, 7200, 0, 0, 4489, 8370, 0, 0),
(84465, 18559, 558, 1, 17940, 0, -147.669, -333.758, 26.5916, 4.6609, 7200, 0, 0, 4489, 8370, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(103506, 18521, 558, 1, 0, 0, -152.552, -239.456, 29.5918, 1.12661, 7200, 0, 0, 16000, 0, 0, 0),
(103510, 18521, 558, 1, 0, 0, -160.681, -275.745, 26.825, 0.565051, 7200, 0, 0, 16000, 0, 0, 0),
(103511, 18521, 558, 1, 0, 0, -122.032, -274.361, 26.6219, 0.022684, 7200, 0, 0, 16000, 0, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(84466, 18506, 558, 1, 0, 0, 87.3881, -174.388, 15.2957, 1.07547, 7200, 0, 0, 2600, 2790, 0, 0),
(84467, 18506, 558, 1, 0, 0, 64.8552, -151.087, 15.3944, 4.84146, 7200, 0, 0, 2600, 2790, 0, 0),
(84468, 18506, 558, 1, 0, 0, 48.8347, -161.421, 15.1685, 6.07846, 7200, 0, 0, 2600, 2790, 0, 0),
(84469, 18506, 558, 1, 0, 0, 33.0733, -153.275, 14.4364, 4.8768, 7200, 0, 0, 2600, 2790, 0, 0),
(84470, 18506, 558, 1, 0, 0, 106.396, -163.477, 14.7743, 6.2748, 7200, 0, 0, 2600, 2790, 0, 0);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(103513, 18700, 558, 1, 0, 0, -51.771, -400.161, 30.1923, 2.61885, 7200, 0, 0, 4200, 0, 0, 0),
(103514, 18700, 558, 1, 0, 0, 6.57576, -395.51, 19.4104, 3.39203, 7200, 0, 0, 4200, 0, 0, 0),
(103515, 18700, 558, 1, 0, 0, -11.404, -396.33, 19.4096, 2.95221, 7200, 0, 0, 4200, 0, 0, 0),
(103516, 18700, 558, 1, 0, 0, -50.2298, -404.041, 30.0857, 2.73968, 7200, 0, 0, 4200, 0, 0, 0),
(103517, 18700, 558, 1, 0, 0, -51.6189, -405.43, 30.419, 4.32316, 7200, 0, 0, 4200, 0, 0, 0),
(103518, 18700, 558, 1, 0, 0, -29.13, -414.548, 26.607, 1.42504, 7200, 0, 0, 4200, 0, 0, 0),
(103519, 18700, 558, 1, 0, 0, -24.5358, -388.268, 19.4101, 2.98755, 7200, 0, 0, 4200, 0, 0, 0),
(103520, 18700, 558, 1, 0, 0, -56.8777, -402.21, 30.2111, 4.14633, 7200, 0, 0, 4200, 0, 0, 0),
(103521, 18700, 558, 1, 0, 0, -55.1617, -407.223, 30.1522, 5.3904, 7200, 0, 0, 4200, 0, 0, 0),
(103522, 18700, 558, 1, 0, 0, -3.79775, -396.17, 19.4098, 2.99541, 7200, 0, 0, 4200, 0, 0, 0),
(103523, 18700, 558, 1, 0, 0, -50.1918, -402.052, 30.0909, 5.41094, 7200, 0, 0, 4200, 0, 0, 0),
(103524, 18700, 558, 1, 0, 0, -54.7479, -398.689, 29.4566, 3.47718, 7200, 0, 0, 4200, 0, 0, 0),
(103529, 18700, 558, 1, 0, 0, 17.4298, -385.122, 20.1516, 2.9797, 7200, 0, 0, 4200, 0, 0, 0),
(103530, 18700, 558, 1, 0, 0, -15.039, -378.733, 19.4101, 3.27815, 7200, 0, 0, 4200, 0, 0, 0),
(103531, 18700, 558, 1, 0, 0, 7.62437, -378.402, 19.4101, 3.09358, 7200, 0, 0, 4200, 0, 0, 0),
(103532, 18700, 558, 1, 0, 0, 18.5908, -391.395, 21.0443, 3.12893, 7200, 0, 0, 4200, 0, 0, 0),
(103533, 18700, 558, 1, 0, 0, 39.055, -369.266, 30.8385, 3.74197, 7200, 0, 0, 4200, 0, 0, 0),
(103534, 18700, 558, 1, 0, 0, 41.0832, -367.141, 30.3041, 0.160551, 7200, 0, 0, 4200, 0, 0, 0),
(103535, 18700, 558, 1, 0, 0, -3.62681, -378.2, 19.4101, 3.27815, 7200, 0, 0, 4200, 0, 0, 0),
(103536, 18700, 558, 1, 0, 0, 12.4698, -380.797, 19.4116, 3.00719, 7200, 0, 0, 4200, 0, 0, 0),
(103537, 18700, 558, 1, 0, 0, 13.3976, -411.113, 26.5875, 3.19653, 7200, 0, 0, 4200, 0, 0, 0),
(103538, 18700, 558, 1, 0, 0, 13.27, -408.792, 26.586, 3.19653, 7200, 0, 0, 4200, 0, 0, 0),
(103541, 18700, 558, 1, 0, 0, 15.2441, -408.712, 26.5854, 3.19653, 7200, 0, 0, 4200, 0, 0, 0),
(103542, 18700, 558, 1, 0, 0, 15.3786, -411.158, 26.5883, 3.19653, 7200, 0, 0, 4200, 0, 0, 0),
(103543, 18700, 558, 1, 0, 0, 18.079, -411.009, 26.5883, 3.19653, 7200, 0, 0, 4200, 0, 0, 0),
(103544, 18700, 558, 1, 0, 0, 17.9395, -408.472, 26.5854, 3.19653, 7200, 0, 0, 4200, 0, 0, 0),
(103545, 18700, 558, 1, 0, 0, -53.3856, -405.636, 30.8289, 2.20653, 7200, 0, 0, 4200, 0, 0, 0),
(103547, 18700, 558, 1, 0, 0, 20.2911, -408.455, 26.5855, 3.19653, 7200, 0, 0, 4200, 0, 0, 0),
(103548, 18700, 558, 1, 0, 0, 20.431, -410.999, 26.5885, 3.19653, 7200, 0, 0, 4200, 0, 0, 0),
(81115, 18700, 558, 1, 0, 0, 15.3559, -413.187, 26.5896, 3.11681, 7200, 0, 0, 4200, 0, 0, 0),
(81117, 18700, 558, 1, 0, 0, 39.055, -369.266, 30.8385, 3.01155, 7200, 0, 0, 4200, 0, 0, 0),
(81118, 18700, 558, 1, 0, 0, 10.3393, -367.845, 26.5833, 3.16, 7200, 0, 0, 4200, 0, 0, 0),
(81119, 18700, 558, 1, 0, 0, 13.2728, -367.791, 26.5835, 3.16, 7200, 0, 0, 4200, 0, 0, 0),
(81120, 18700, 558, 1, 0, 0, 16.2918, -367.735, 26.5839, 3.16, 7200, 0, 0, 4200, 0, 0, 0),
(81121, 18700, 558, 1, 0, 0, 19.9452, -367.668, 26.5844, 3.16, 7200, 0, 0, 4200, 0, 0, 0),
(81122, 18700, 558, 1, 0, 0, 10.9688, -365.182, 26.5915, 3.07361, 7200, 0, 0, 4200, 0, 0, 0),
(81123, 18700, 558, 1, 0, 0, 13.8845, -365.14, 26.5923, 3.15608, 7200, 0, 0, 4200, 0, 0, 0),
(81124, 18700, 558, 1, 0, 0, 16.3457, -365.105, 26.5926, 3.15608, 7200, 0, 0, 4200, 0, 0, 0),
(81125, 18700, 558, 1, 0, 0, 20.1928, -365.049, 26.593, 3.15608, 7200, 0, 0, 4200, 0, 0, 0),
(81126, 18700, 558, 1, 0, 0, 11.2097, -362.039, 26.6031, 3.10895, 7200, 0, 0, 4200, 0, 0, 0),
(81127, 18700, 558, 1, 0, 0, 14.8277, -362.03, 26.6031, 3.1443, 7200, 0, 0, 4200, 0, 0, 0),
(81128, 18700, 558, 1, 0, 0, 17.8112, -362.022, 26.6031, 3.1443, 7200, 0, 0, 4200, 0, 0, 0),
(81129, 18700, 558, 1, 0, 0, 35.758, -365.454, 29.9289, 3.1215, 7200, 0, 0, 4200, 0, 0, 0),
(81132, 18700, 558, 1, 0, 0, -28.9583, -361.995, 26.5939, 5.20283, 7200, 0, 0, 4200, 0, 0, 0),
(81134, 18700, 558, 1, 0, 0, -25.7137, -361.55, 26.5939, 4.67661, 7200, 0, 0, 4200, 0, 0, 0),
(81137, 18700, 558, 1, 0, 0, -32.2729, -366.098, 26.5876, 3.14822, 7200, 0, 0, 4200, 0, 0, 0),
(81138, 18700, 558, 1, 0, 0, -28.4255, -366.072, 26.5876, 3.14822, 7200, 0, 0, 4200, 0, 0, 0),
(81139, 18700, 558, 1, 0, 0, -24.7851, -366.048, 26.5876, 3.14822, 7200, 0, 0, 4200, 0, 0, 0),
(81142, 18700, 558, 1, 0, 0, -32.0041, -363.447, 26.5919, 3.14429, 7200, 0, 0, 4200, 0, 0, 0),
(81143, 18700, 558, 1, 0, 0, -27.8146, -363.436, 26.5919, 3.14429, 7200, 0, 0, 4200, 0, 0, 0),
(81144, 18700, 558, 1, 0, 0, -24.0346, -363.426, 26.5919, 3.14429, 7200, 0, 0, 4200, 0, 0, 0),
(81148, 18700, 558, 1, 0, 0, -27.863, -360.714, 26.5963, 3.22283, 7200, 0, 0, 4200, 0, 0, 0),
(81149, 18700, 558, 1, 0, 0, -23.7129, -361.121, 26.595, 3.10109, 7200, 0, 0, 4200, 0, 0, 0),
(81156, 18700, 558, 1, 0, 0, -30.0299, -408.448, 26.5883, 3.04219, 7200, 0, 0, 4200, 0, 0, 0),
(81157, 18700, 558, 1, 0, 0, -25.1928, -408.816, 26.5883, 3.06575, 7200, 0, 0, 4200, 0, 0, 0),
(81160, 18700, 558, 1, 0, 0, -30.8562, -411.927, 26.5998, 3.05005, 7200, 0, 0, 4200, 0, 0, 0),
(81161, 18700, 558, 1, 0, 0, -24.9769, -412.467, 26.5998, 3.05005, 7200, 0, 0, 4200, 0, 0, 0),
(81163, 18700, 558, 1, 0, 0, -26.9575, -410.391, 26.5941, 2.88195, 7200, 0, 0, 4200, 0, 0, 0),
(81165, 18700, 558, 1, 0, 0, -28.0837, -407.224, 26.5841, 3.08931, 7200, 0, 0, 4200, 0, 0, 0),
(81166, 18700, 558, 1, 0, 0, -28.3511, -411.037, 26.5958, 2.92203, 7200, 0, 0, 4200, 0, 0, 0);
UPDATE `creature` SET `spawndist` = 3, `MovementType` = 1 WHERE `id` = 18700;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(280242, 18556, 558, 1, 0, 0, 85.5783, -154.645, 15.2756, 4.88673, 7200, 0, 0, 1200, 19329, 0, 0),
(280244, 18559, 558, 1, 0, 0, 167.352, -177.206, 26.5169, 1.36643, 7200, 0, 0, 1200, 19329, 0, 0);
UPDATE `creature`, `creature_template` SET `creature`.`curhealth`=`creature_template`.`minhealth`,`creature`.`curmana`=`creature_template`.`minmana` WHERE `creature`.`id`=`creature_template`.`entry`;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(93799, 18371, 558, 1, 0, 0, -54.3539, -162.79, 26.3958, 6.27569, 7200, 0, 0, 76000, 14230, 0, 2);
UPDATE `creature` SET `spawndist` = 3, `MovementType` = 1 WHERE `id` = 18524;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84461;
DELETE FROM `creature_movement` WHERE `id`=84461;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84461, 1, 43.1372, 30.1599, -0.123805, 0, '', '', '', '', '', 0, 0, 0, 4.63846, 0, 0),
(84461, 2, 42.3855, 5.99182, -0.132539, 0, '', '', '', '', '', 0, 0, 0, 4.70129, 0, 0),
(84461, 3, 6.5345, 5.14911, -0.119299, 0, '', '', '', '', '', 0, 0, 0, 3.16584, 0, 0),
(84461, 4, 6.79024, -3.422, -0.119299, 0, '', '', '', '', '', 0, 0, 0, 4.74448, 0, 0),
(84461, 5, 41.848, -3.83218, -0.158658, 0, '', '', '', '', '', 0, 0, 0, 0.016381, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 74131;
DELETE FROM `creature_movement` WHERE `id`=74131;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(74131, 1, 69.4134, 4.79423, -0.106737, 0, '', '', '', '', '', 0, 0, 0, 1.58251, 0, 0),
(74131, 2, 68.6832, 28.0788, -0.126944, 0, '', '', '', '', '', 0, 0, 0, 1.60214, 0, 0),
(74131, 3, 98.4617, 28.3957, -0.123928, 0, '', '', '', '', '', 0, 0, 0, 6.26741, 0, 0),
(74131, 4, 98.4158, 5.34189, -0.077384, 0, '', '', '', '', '', 0, 0, 0, 4.48456, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 74132;
DELETE FROM `creature_movement` WHERE `id`=74132;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(74132, 1, 68.4175, -28.3488, -0.076249, 0, '', '', '', '', '', 0, 0, 0, 0.011706, 0, 0),
(74132, 2, 99.3005, -28.1803, -0.03207, 0, '', '', '', '', '', 0, 0, 0, 0.149151, 0, 0),
(74132, 3, 99.9917, -5.05814, 0.001221, 0, '', '', '', '', '', 0, 0, 0, 3.1101, 0, 0),
(74132, 4, 69.1663, -5.22074, -0.10786, 0, '', '', '', '', '', 0, 0, 0, 3.1533, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84462;
DELETE FROM `creature_movement` WHERE `id`=84462;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84462, 1, 101.446, -25.5502, -0.041837, 10000, '', '', '', '', '', 0, 0, 0, 1.54792, 0, 0),
(84462, 2, 101.372, -0.131407, -0.109474, 0, '', '', '', '', '', 0, 0, 0, 1.62254, 0, 0),
(84462, 3, 43.3161, 0.040926, -0.148998, 0, '', '', '', '', '', 0, 0, 0, 3.24438, 0, 0),
(84462, 4, 42.9824, -31.7986, -0.123058, 10000, '', '', '', '', '', 0, 0, 0, 1.46545, 0, 0),
(84462, 5, 44.1553, -0.255878, -0.153092, 0, '', '', '', '', '', 0, 0, 0, 1.49687, 0, 0),
(84462, 6, 101.42, 0.233295, -0.124108, 0, '', '', '', '', '', 0, 0, 0, 0.008542, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 74154;
DELETE FROM `creature_movement` WHERE `id`=74154;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(74154, 1, 83.758, 35.174, 1.78841, 10000, '', '', '', '', '', 16, 0, 0, 1.58328, 0, 0),
(74154, 2, 83.9831, 30.9594, -0.110026, 0, '', '', '', '', '', 0, 0, 0, 4.76022, 0, 0),
(74154, 3, 102.46, 30.073, -0.124454, 0, '', '', '', '', '', 0, 0, 0, 6.07969, 0, 0),
(74154, 4, 103.928, 0.419281, -0.098976, 0, '', '', '', '', '', 0, 0, 0, 4.86625, 0, 0),
(74154, 5, 110.895, 0.932297, -0.031422, 10000, '', '', '', '', '', 16, 0, 0, 0.083172, 0, 0),
(74154, 6, 102.195, 0.602988, -0.07346, 0, '', '', '', '', '', 0, 0, 0, 3.15801, 0, 0),
(74154, 7, 104.427, 29.704, -0.127644, 0, '', '', '', '', '', 0, 0, 0, 1.62648, 0, 0),
(74154, 8, 83.6419, 30.3443, -0.114722, 0, '', '', '', '', '', 0, 0, 0, 3.11874, 0, 0);
DELETE FROM `creature_addon` WHERE (`guid`=84440);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84440, 0, 0, 0, 0, 68, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84439);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84439, 0, 0, 0, 0, 68, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84448);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84448, 0, 0, 0, 0, 68, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84447);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84447, 0, 0, 0, 0, 68, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84453);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84453, 0, 0, 0, 0, 68, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84437);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84437, 0, 0, 0, 0, 68, 0, '');
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 103488;
DELETE FROM `creature_movement` WHERE `id`=103488;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(103488, 1, 134.878, 17.7827, 0.039301, 0, '', '', '', '', '', 0, 0, 0, 4.80184, 0, 0),
(103488, 2, 136.086, 4.84647, -0.128735, 0, '', '', '', '', '', 0, 0, 0, 4.79398, 0, 0),
(103488, 3, 161.711, 5.1277, -0.127323, 0, '', '', '', '', '', 0, 0, 0, 0.0109, 0, 0),
(103488, 4, 162.464, 28.4255, -0.127146, 0, '', '', '', '', '', 0, 0, 0, 1.5385, 0, 0),
(103488, 5, 132.429, 29.1266, -0.11659, 0, '', '', '', '', '', 0, 0, 0, 3.12108, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84425;
DELETE FROM `creature_movement` WHERE `id`=84425;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84425, 1, 147.923, 35.8223, 2.31793, 10000, '', '', '', '', '', 16, 0, 0, 1.54401, 0, 0),
(84425, 2, 148.162, 32.0639, -0.091705, 0, '', '', '', '', '', 0, 0, 0, 4.77593, 0, 0),
(84425, 3, 165.462, 30.8032, -0.119968, 0, '', '', '', '', '', 0, 0, 0, 6.12681, 0, 0),
(84425, 4, 167.208, 3.90707, -0.12599, 0, '', '', '', '', '', 0, 0, 0, 4.772, 0, 0),
(84425, 5, 171.611, 3.47654, -0.219525, 10000, '', '', '', '', '', 16, 0, 0, 6.18571, 0, 0),
(84425, 6, 163.932, 4.12583, -0.125462, 0, '', '', '', '', '', 0, 0, 0, 3.06376, 0, 0),
(84425, 7, 165.155, 30.9149, -0.118622, 0, '', '', '', '', '', 0, 0, 0, 1.52437, 0, 0),
(84425, 8, 148.498, 31.3276, -0.100048, 0, '', '', '', '', '', 0, 0, 0, 3.06768, 0, 0);
DELETE FROM `creature_addon` WHERE (`guid`=84452);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84452, 0, 0, 0, 0, 68, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84451);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84451, 0, 0, 0, 0, 68, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84434);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84434, 0, 0, 0, 0, 68, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84444);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84444, 0, 0, 0, 0, 68, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84431);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84431, 0, 0, 0, 0, 68, 0, '');
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84459;
DELETE FROM `creature_movement` WHERE `id`=84459;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84459, 1, 229.463, 14.517, -0.067782, 10000, '', '', '', '', '', 68, 0, 0, 1.67237, 0, 0),
(84459, 2, 229.519, -3.80618, 0.284739, 0, '', '', '', '', '', 0, 0, 0, 4.65689, 0, 0),
(84459, 3, 264.713, -7.83347, -0.049441, 0, '', '', '', '', '', 0, 0, 0, 6.18449, 0, 0),
(84459, 4, 263.649, -23.706, -0.494494, 10000, '', '', '', '', '', 0, 0, 0, 4.7001, 0, 0),
(84459, 5, 262.939, -5.88148, -0.049519, 0, '', '', '', '', '', 0, 0, 0, 3.14501, 0, 0),
(84459, 6, 230.311, -3.45749, 0.253776, 0, '', '', '', '', '', 0, 0, 0, 3.16857, 0, 0);
DELETE FROM `creature_addon` WHERE (`guid`=84442);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84442, 0, 0, 0, 0, 68, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84454);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84454, 0, 0, 0, 0, 68, 0, '');
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84441;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 74134;
DELETE FROM `creature_movement` WHERE `id`=84441;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84441, 1, 241, -71, 26.5921, 0, '', '', '', '', '', 0, 0, 0, 1.54706, 0, 0),
(84441, 2, 241, -115, 26.5921, 0, '', '', '', '', '', 0, 0, 0, 4.71221, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=74134;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(74134, 1, 237, -71, 26.5921, 0, '', '', '', '', '', 0, 0, 0, 1.54706, 0, 0),
(74134, 2, 237, -115, 26.5921, 0, '', '', '', '', '', 0, 0, 0, 4.71221, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84458;
DELETE FROM `creature_movement` WHERE `id`=84458;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84458, 1, 243, -117, 26.5913, 0, '', '', '', '', '', 0, 0, 0, 1.53099, 0, 0),
(84458, 2, 243, -62, 26.5913, 0, '', '', '', '', '', 0, 0, 0, 1.55455, 0, 0),
(84458, 3, 235, -62, 26.5913, 0, '', '', '', '', '', 0, 0, 0, 3.10571, 0, 0),
(84458, 4, 235, -117, 26.5913, 0, '', '', '', '', '', 0, 0, 0, 4.77468, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84458;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84458, 1, 243, -117, 26.5913, 0, '', '', '', '', '', 0, 0, 0, 1.53099, 0, 0),
(84458, 2, 243, -62, 26.5913, 0, '', '', '', '', '', 0, 0, 0, 1.55455, 0, 0),
(84458, 3, 235, -62, 26.5913, 0, '', '', '', '', '', 0, 0, 0, 3.10571, 0, 0),
(84458, 4, 235, -117, 26.5913, 0, '', '', '', '', '', 0, 0, 0, 4.77468, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 280244;
DELETE FROM `creature_movement` WHERE `id`=280244;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(280244, 1, 167.352, -177.206, 26.5169, 0, '', '', '', '', '', 0, 0, 0, 1.36643, 0, 0),
(280244, 2, 189.785, -178.375, 26.5911, 0, '', '', '', '', '', 0, 0, 0, 6.24375, 0, 0),
(280244, 3, 191.622, -150.85, 26.5913, 0, '', '', '', '', '', 0, 0, 0, 1.51958, 0, 0),
(280244, 4, 167.148, -151.47, 26.297, 0, '', '', '', '', '', 0, 0, 0, 4.77113, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84429;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84443;
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84456;
DELETE FROM `creature_movement` WHERE `id`=84429;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84429, 1, 162, -163, 26.0179, 0, '', '', '', '', '', 0, 0, 0, 3.1375, 0, 0),
(84429, 2, 144, -163, 12.5566, 0, '', '', '', '', '', 0, 0, 0, 3.15321, 0, 0),
(84429, 3, 104, -163, 14.8812, 0, '', '', '', '', '', 0, 0, 0, 3.15713, 0, 0),
(84429, 4, 144, -163, 12.5564, 0, '', '', '', '', '', 0, 0, 0, 0.003748, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84456;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84456, 1, 162, -161, 26.0179, 0, '', '', '', '', '', 0, 0, 0, 3.1375, 0, 0),
(84456, 2, 144, -161, 12.5566, 0, '', '', '', '', '', 0, 0, 0, 3.15321, 0, 0),
(84456, 3, 104, -161, 14.8812, 0, '', '', '', '', '', 0, 0, 0, 3.15713, 0, 0),
(84456, 4, 144, -161, 12.5564, 0, '', '', '', '', '', 0, 0, 0, 0.003748, 0, 0);
DELETE FROM `creature_movement` WHERE `id`=84443;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84443, 1, 162, -165, 26.0179, 0, '', '', '', '', '', 0, 0, 0, 3.1375, 0, 0),
(84443, 2, 144, -165, 12.5566, 0, '', '', '', '', '', 0, 0, 0, 3.15321, 0, 0),
(84443, 3, 104, -165, 14.8812, 0, '', '', '', '', '', 0, 0, 0, 3.15713, 0, 0),
(84443, 4, 144, -165, 12.5564, 0, '', '', '', '', '', 0, 0, 0, 0.003748, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84463;
DELETE FROM `creature_movement` WHERE `id`=84463;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84463, 1, 139.031, -154.143, 12.6004, 10000, '', '', '', '', '', 0, 0, 0, 4.6726, 0, 0),
(84463, 2, 137.87, -169.913, 12.6071, 0, '', '', '', '', '', 0, 0, 0, 4.64118, 0, 0),
(84463, 3, 82.2734, -166.049, 15.3542, 0, '', '', '', '', '', 0, 0, 0, 3.09002, 0, 0),
(84463, 4, 81.0956, -174.069, 15.3669, 10000, '', '', '', '', '', 0, 0, 0, 4.56657, 0, 0),
(84463, 5, 82.0162, -167.201, 15.3357, 0, '', '', '', '', '', 0, 0, 0, 1.44068, 0, 0),
(84463, 6, 134.647, -169.274, 12.64, 0, '', '', '', '', '', 0, 0, 0, 6.23554, 0, 0),
(84463, 7, 136.832, -169.112, 12.6177, 0, '', '', '', '', '', 0, 0, 0, 6.27088, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 280242;
DELETE FROM `creature_movement` WHERE `id`=280242;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(280242, 1, 85.5783, -154.645, 15.2756, 10000, '', '', '', '', '', 0, 0, 0, 4.88673, 0, 0),
(280242, 2, 85.2369, -161.503, 15.3483, 0, '', '', '', '', '', 0, 0, 0, 4.80819, 0, 0),
(280242, 3, 58.0072, -163.041, 15.3605, 0, '', '', '', '', '', 0, 0, 0, 3.15885, 0, 0),
(280242, 4, 58.2646, -151.347, 15.3396, 10000, '', '', '', '', '', 0, 0, 0, 1.54879, 0, 0),
(280242, 5, 56.5287, -162.036, 15.3248, 0, '', '', '', '', '', 0, 0, 0, 4.55293, 0, 0),
(280242, 6, 84.3742, -161.859, 15.3677, 0, '', '', '', '', '', 0, 0, 0, 0.048666, 0, 0);
DELETE FROM `creature_addon` WHERE (`guid`=84431);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84431, 0, 0, 0, 0, 45, 0, '');
DELETE FROM `creature_addon` WHERE (`guid`=84428);
INSERT INTO `creature_addon` (`guid`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (84428, 0, 0, 0, 0, 45, 0, '');
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 93799;
DELETE FROM `creature_movement` WHERE `id`=93799;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(93799, 1, -54.3539, -162.79, 26.3958, 0, '', '', '', '', '', 0, 0, 0, 6.27569, 0, 0),
(93799, 2, -17.8845, -162.278, 26.0184, 0, '', '', '', '', '', 0, 0, 0, 0.000359, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84460;
DELETE FROM `creature_movement` WHERE `id`=84460;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84460, 1, -97.8572, -159.644, 26.5903, 0, '', '', '', '', '', 0, 0, 0, 3.10661, 0, 0),
(84460, 2, -147.499, -158.321, 26.589, 0, '', '', '', '', '', 0, 0, 0, 4.76379, 0, 0),
(84460, 3, -147.337, -201.986, 26.5895, 0, '', '', '', '', '', 0, 0, 0, 4.70882, 0, 0),
(84460, 4, -146.808, -159.268, 26.5899, 0, '', '', '', '', '', 0, 0, 0, 6.1461, 0, 0);
UPDATE `creature` SET `MovementType` = 2 WHERE `guid` = 84465;
DELETE FROM `creature_movement` WHERE `id`=84465;
INSERT INTO `creature_movement` (`id`,`point`,`position_x`,`position_y`,`position_z`,`waittime`,`text1`,`text2`,`text3`,`text4`,`text5`,`emote`,`spell`,`wpguid`,`orientation`,`model1`,`model2`) VALUES
(84465, 1, -147.669, -333.758, 26.5916, 0, '', '', '', '', '', 0, 0, 0, 4.6609, 0, 0),
(84465, 2, -150.086, -388.349, 26.5888, 0, '', '', '', '', '', 0, 0, 0, 0.011333, 0, 0),
(84465, 3, -104.699, -388.982, 26.5891, 0, '', '', '', '', '', 0, 0, 0, 6.24739, 0, 0),
(84465, 4, -148.552, -388.271, 26.5891, 0, '', '', '', '', '', 0, 0, 0, 1.54679, 0, 0);
UPDATE `creature` SET `spawndist` = 0, `MovementType` = 0 WHERE `id` = 18702;


# NPC
UPDATE `creature_template` SET `minlevel` = 70, `maxlevel` = 70, `minhealth` = 11000, `maxhealth` = 11000, `faction_A` = 35, `faction_H` = 35 WHERE `entry` = 25305;
DELETE FROM `creature_template_addon` WHERE (`entry`=25305);
INSERT INTO `creature_template_addon` (`entry`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (25305, 0, 0, 0, 0, 10, 0, '');
UPDATE `creature_template` SET `spell1` = 47057, `spell2` = 45423, `spell3` = 45427, `ScriptName` = 'generic_creature' WHERE `entry` = 25305;
UPDATE `creature_template` SET `minlevel` = 70, `maxlevel` = 70, `minhealth` = 4900, `maxhealth` = 4900, `spell1` = 46828, `ScriptName` = 'generic_creature' WHERE `entry` = 26267;
INSERT INTO `creature` (`guid`, `id`, `map`, `spawnMask`, `modelid`, `equipment_id`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`, `spawndist`, `currentwaypoint`, `curhealth`, `curmana`, `DeathState`, `MovementType`) VALUES ('82589','6491','0','1','0','0','1819.41','219.233','60.0732','0.337883','25','0','0','4900','0','0','0');
UPDATE `creature_template` SET `minlevel` = 65, `maxlevel` = 70, `minhealth` = 3400, `maxhealth` = 4000 WHERE `entry` = 26124;
UPDATE `creature_template` SET `npcflag` = 128 WHERE `entry` = 26124;
DELETE FROM `npc_vendor` WHERE (`entry`=26124);
INSERT INTO `npc_vendor` (entry, item, maxcount, incrtime, ExtendedCost) VALUES (26124, 23083, 0, 0, 2353), (26124, 23211, 5, 7200, 2349), (26124, 23215, 0, 0, 2349), (26124, 23246, 5, 7200, 2349), (26124, 23324, 0, 0, 2351), (26124, 23326, 0, 0, 2349), (26124, 23327, 5, 7200, 2348), (26124, 23435, 5, 7200, 2349), (26124, 34599, 0, 0, 2349), (26124, 34683, 0, 0, 2352), (26124, 34684, 0, 0, 2348), (26124, 34685, 0, 0, 2351), (26124, 34686, 0, 0, 2353);
UPDATE `event_scripts` SET `datatext` = 'I have failed... I have failed in my duty... failed my people... The worgen run rampant, and the Scythe of my goddess is lost.' WHERE `id` = '664';
INSERT INTO `creature` (`guid`,`id`, `map`, `spawnMask`, `modelid`, `equipment_id`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`, `spawndist`, `currentwaypoint`, `curhealth`, `curmana`, `DeathState`, `MovementType`) VALUES
('82590','6118','1','1','0','0','2832.88','-3947.98','97.0875','4.2604','600','0','0','2600','0','0','2');
INSERT INTO `creature_movement` (`id`, `point`, `position_x`, `position_y`, `position_z`, `waittime`, `orientation`) VALUES 
('82590','1','2833.14','-3948.19','97.0343','20000','6.20426'),
('82590','2','2856','-3956.25','98.7139','0','5.91759'),
('82590','3','2897.45','-3977.4','114.84','0','5.76837'),
('82590','4','2913.13','-3990.32','120.61','0','5.44636'),
('82590','5','2903.33','-4005.69','128.919','0','4.14495'),
('82590','6','2890.58','-4017.31','137.143','0','3.76404'),
('82590','7','2852.33','-4026.45','140.535','0','5.71574'),
('82590','8','2845.83','-4022.84','141.618','20000','2.80977'),
('82590','9','2852.4','-4026.69','140.51','0','5.56652'),
('82590','10','2892.16','-4017.03','136.836','0','0.253305'),
('82590','11','2903.15','-4005.66','128.982','0','0.802532'),
('82590','12','2912.81','-3990.39','120.658','0','0.833948'),
('82590','13','2897.19','-3976.98','114.624','0','2.43223'),
('82590','14','2855.45','-3956.15','98.5593','0','2.66393'),
('82590','15','2833.78','-3946.53','97.5501','0','0.053263');
DELETE FROM `creature` WHERE `id` = '23427';
INSERT INTO `creature` (`guid`, `id`, `map`, `spawnMask`, `modelid`, `equipment_id`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`, `spawndist`, `currentwaypoint`, `curhealth`, `curmana`, `DeathState`, `MovementType`) VALUES
('82591', '23427', '530', '1', '0', '0', '-5090.21', '578.258', '86.7974', '1.87148', '90', '0', '0', '5589', '3155', '0', '0');
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(82592, 21235, 0, 1, 0, 0, -8398.59, 265.196, 120.886, 2.27139, 25, 0, 0, 6900, 0, 0, 0);
UPDATE `creature_template` SET `flag1` = 0 WHERE `entry` = 4947;
DELETE FROM `creature` WHERE `id`=26124;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(82593, 26124, 1, 1, 0, 0, 1914.22, -4342.91, 20.7326, 2.81564, 1200, 0, 0, 4000, 0, 0, 0),
(82594, 26124, 530, 1, 0, 0, 9800.2, -7257.32, 26.2343, 1.83782, 1200, 0, 0, 3520, 0, 0, 0),
(82595, 26124, 1, 1, 0, 0, -1024.74, 294.716, 135.746, 1.97134, 1200, 0, 0, 3760, 0, 0, 0),
(82596, 26124, 0, 1, 0, 0, 1794.91, 231.265, 60.5868, 0.310226, 1200, 0, 0, 3880, 0, 0, 0);
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=26124;
UPDATE `creature_template` SET `minhealth` = 120000, `maxhealth` = 120000 WHERE `entry` = 25740;
UPDATE `creature_template` SET `minlevel` = 70, `maxlevel` = 70, `minhealth` = 72000, `maxhealth` = 72000, `faction_A` = 14, `faction_H` = 14, `mindmg` = 1500, `maxdmg` = 1600, `attackpower` = 4500, `spell1` = 46542, `spell2` = 2676, `spell3` = 46885, `ScriptName` = 'generic_creature' WHERE `entry` = 25755;
UPDATE `creature_template` SET `minlevel` = 70, `maxlevel` = 70, `minhealth` = 21000, `maxhealth` = 21000, `faction_A` = 14, `faction_H` = 14, `mindmg` = 1300, `maxdmg` = 1500, `attackpower` = 3700, `spell1` = 46406, `spell2` = 46887, `ScriptName` = 'generic_creature' WHERE `entry` = 25756;
UPDATE `creature_template` SET `minlevel` = 70, `maxlevel` = 70, `minhealth` = 17000, `maxhealth` = 17000, `minmana` = 3155, `maxmana` = 3200, `faction_A` = 14, `faction_H` = 14, `mindmg` = 1300, `maxdmg` = 1500, `attackpower` = 3500, `spell1` = 12550, `spell2` = 46568, `ScriptName` = 'generic_creature' WHERE `entry` = 25757;
UPDATE `creature_template` SET `faction_A` = 714, `faction_H` = 714 WHERE `entry` = 20269;
UPDATE `creature_template` SET `faction_A` = 714, `faction_H` = 714 WHERE `entry` = 20276;
UPDATE `creature_template` SET `faction_A` = 714, `faction_H` = 714 WHERE `entry` = 20274;
UPDATE `creature_template` SET `faction_A` = 714, `faction_H` = 714 WHERE `entry` = 20384;
UPDATE `creature_template` SET `minlevel` = 60, `maxlevel` = 60, `minhealth` = 8400, `maxhealth` = 8400 WHERE `entry` = 26401;
UPDATE `creature_template` SET `minlevel` = 60, `maxlevel` = 60, `minhealth` = 1000, `maxhealth` = 1000 WHERE `entry` = 26520;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(82597, 25975, 530, 1, 0, 0, -3780.95, -11486.3, -134.53, 4.13905, 1200, 0, 0, 10000, 0, 0, 0);
INSERT IGNORE INTO `game_event_creature` (`guid`, `event`) VALUES ('82597', '1');
DELETE FROM `creature` WHERE `id`=25994;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(82598, 25994, 1, 1, 0, 0, -378.452, -2670.39, 96.3748, 4.27928, 600, 0, 0, 10000, 0, 0, 0),
(82599, 25994, 1, 1, 0, 0, -2322.2, -608.405, -9.34533, 0.526326, 600, 0, 0, 10000, 0, 0, 0),
(82600, 25994, 0, 1, 0, 0, 603.436, 1338.35, 88.5123, 5.87362, 600, 0, 0, 10000, 0, 0, 0),
(82601, 25994, 530, 1, 0, 0, -1761.83, 5336.39, -12.428, 5.43102, 600, 0, 0, 10000, 0, 0, 0),
(82602, 25994, 1, 1, 0, 0, 170.846, -4765.47, 13.5399, 6.12373, 600, 0, 0, 10000, 0, 0, 0),
(82603, 25994, 1, 1, 0, 0, -7129, -3811.42, 8.86276, 5.09306, 600, 0, 0, 10000, 0, 0, 0),
(82604, 25994, 530, 1, 0, 0, -2600.75, 4375.24, 31.7684, 0.613213, 600, 0, 0, 10000, 0, 0, 0),
(82605, 25994, 530, 1, 0, 0, -1237.98, 7506.36, 20.021, 5.65836, 600, 0, 0, 10000, 0, 0, 0),
(82606, 25994, 530, 1, 0, 0, 7612.51, -6823.65, 82.0008, 0.834839, 600, 0, 0, 10000, 0, 0, 0),
(82607, 25994, 530, 1, 0, 0, 69.2068, 2550.59, 64.8449, 2.90409, 600, 0, 0, 10000, 0, 0, 0),
(82608, 25994, 0, 1, 0, 0, -156.058, -872.543, 57.013, 2.16546, 600, 0, 0, 10000, 0, 0, 0),
(103701, 25994, 530, 1, 0, 0, 9357.88, -6790.55, 16.1095, 1.57909, 600, 0, 0, 10000, 0, 0, 0),
(82609, 25994, 1, 1, 0, 0, 1924.72, -2319.41, 92.9298, 5.26917, 600, 0, 0, 10000, 0, 0, 0),
(82610, 25994, 0, 1, 0, 0, 2286.63, 403.383, 33.9185, 5.40354, 600, 0, 0, 10000, 0, 0, 0);
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=25994;
UPDATE `creature_template` SET `npcflag` = 4224 WHERE `entry` = 12799;
DELETE FROM `npc_vendor` WHERE (`entry`=12799);
INSERT INTO `npc_vendor` (entry, item, maxcount, incrtime, ExtendedCost) VALUES 
(12799, 15197, 0, 0, 1007),
(12799, 15200, 0, 0, 838),
(12799, 16335, 0, 0, 491),
(12799, 16341, 0, 0, 986),
(12799, 16486, 0, 0, 492),
(12799, 16497, 0, 0, 492),
(12799, 16532, 0, 0, 492),
(12799, 18427, 0, 0, 1050),
(12799, 18428, 0, 0, 930),
(12799, 18429, 0, 0, 492),
(12799, 18430, 0, 0, 931),
(12799, 18432, 0, 0, 931),
(12799, 18434, 0, 0, 492),
(12799, 18435, 0, 0, 931),
(12799, 18436, 0, 0, 931),
(12799, 18437, 0, 0, 931),
(12799, 18461, 0, 0, 774),
(12799, 18675, 0, 0, 0),
(12799, 18834, 0, 0, 634),
(12799, 18845, 0, 0, 634),
(12799, 18846, 0, 0, 634),
(12799, 18849, 0, 0, 634),
(12799, 18850, 0, 0, 634),
(12799, 18851, 0, 0, 634),
(12799, 18852, 0, 0, 634),
(12799, 18853, 0, 0, 634);
DELETE FROM `creature` WHERE (`guid`=103189);
UPDATE `creature_template` SET `npcflag` = 2 WHERE `entry` = 19169;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(103189, 19169, 530, 1, 0, 0, 9366.08, -7133.75, 8.37003, 2.63283, 300, 0, 0, 90, 0, 0, 0);
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=19169;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(82611, 19176, 1, 1, 0, 0, -1256.88, 77.9092, 128.053, 1.72002, 600, 0, 0, 650, 0, 0, 0);
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=19176;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=19175;
UPDATE `creature_template` SET `minlevel` = 60, `maxlevel` = 60, `npcflag` = 2 WHERE `entry` = 19177;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=19177;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=19178;
UPDATE `creature_template` SET `minlevel` = 60, `maxlevel` = 60, `npcflag` = 2 WHERE `entry` = 20102;
DELETE FROM `creature` WHERE `id`=20102;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(82612, 20102, 530, 1, 0, 0, -1757.57, 5337.92, -12.4273, 3.75028, 300, 0, 0, 2300, 0, 0, 0),
(82613, 20102, 1, 1, 0, 0, -7132.28, -3862.87, 9.88554, 3.42107, 300, 0, 0, 2300, 0, 0, 0),
(82614, 20102, 1, 1, 0, 0, -895.814, -3760.96, 11.9967, 2.04504, 300, 0, 0, 2300, 0, 0, 0),
(82615, 20102, 530, 1, 0, 0, 3034.73, 3624.05, 144.554, 2.07171, 300, 0, 0, 2300, 0, 0, 0),
(57373, 20102, 0, 1, 22368, 0, -14469.6, 462.223, 36.9248, 0.279253, 300, 0, 0, 2300, 0, 0, 0);
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=20102;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=19172;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=18927;
DELETE FROM `creature` WHERE `id`=19148;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(82616, 19148, 0, 1, 0, 0, -4915.33, -953.892, 501.498, 2.25016, 3000, 0, 0, 3900, 0, 0, 0);
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=19148;
UPDATE `creature_template` SET `name` = 'Draenei Commoner', `npcflag` = 2 WHERE `entry` = 19171;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=19171;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=19173;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'1' FROM `creature` WHERE `id`=26221;
DELETE FROM `creature_template` WHERE (`entry`=3462);
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15557;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15559;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15560;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15567;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15570;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15573;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15581;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15583;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15584;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15585;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15588;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15593;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15596;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15600;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15602;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15606;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'7' FROM `creature` WHERE `id`=15607;
DELETE FROM `creature` WHERE `id`=10737;
INSERT INTO `creature` (`guid`, `id`, `map`, `spawnMask`, `modelid`, `equipment_id`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`, `spawndist`, `currentwaypoint`, `curhealth`, `curmana`, `DeathState`, `MovementType`) VALUES 
('82617','5891','1','1','12110','0','-3031.36','-720.833','44.8901','3.04866','120','0','0','174','0','0','0'),
('82618','5890','1','1','0','0','-3011.84','-689.38','42.6605','6.28066','120','0','0','64','0','0','2'),
('82619','5890','1','1','0','0','-3024.69','-739.484','46.2851','6.17854','120','0','0','64','0','0','2'),
('82620','5890','1','1','0','0','-3018.78','-687.172','42.187','5.45912','120','20','0','64','0','0','1'),
('82621','5890','1','1','0','0','-2998.81','-703.206','44.0987','3.36758','120','0','0','64','0','0','2'),
('82622','5890','1','1','0','0','-3039.04','-740.04','43.3674','0.563712','120','20','0','64','0','0','1');
INSERT INTO `creature_movement` (`id`, `point`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
('82619','1','-3023.68','-739.855','46.3692','6.02852'),
('82619','2','-3010.87','-737.813','46.0078','0.181235'),
('82619','3','-2996.79','-728.649','44.5938','0.578647'),
('82621','1','-2998.81','-703.206','44.0987','2.85786'),
('82621','2','-3011.81','-699.973','44.5473','3.23878'),
('82621','3','-3018.53','-707.105','45.368','3.95663'),
('82618','1','-3001.38','-697.587','43.5509','5.47564'),
('82618','2','-2994.44','-718.777','44.2939','4.32503'),
('82618','3','-3010.69','-737.562','45.9906','3.73598'),
('82618','4','-3027.34','-735.305','45.8003','3.01341'),
('82618','5','-3044.84','-721.996','41.686','2.25157'),
('82618','6','-3030.96','-701.612','43.7678','1.00279');
DELETE FROM `creature_addon` WHERE `guid` IN (SELECT `guid` FROM `creature` WHERE `id` IN ('5890', '5891'));
INSERT INTO `creature_template_addon` (`entry`, `mount`, `bytes0`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES
('5890','0','16908544','0','4097','0','0','8203 0'),
('5891','0','16908544','0','4097','0','0','8203 0');
DELETE FROM `creature` WHERE `id`=23761;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(46419, 23761, 530, 1, 0, 0, 6765.75, -7613.08, 128.318, 5.14041, 300, 0, 0, 11000, 0, 0, 0);
DELETE FROM `creature` WHERE `id`=23858;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(82623, 23858, 530, 1, 0, 0, 6792.42, -7572.7, 127.173, 4.08403, 300, 0, 0, 6700, 0, 0, 0);
INSERT INTO `creature` VALUES 
(82624, 17076, 530, 1, 0, 0, -1883.62, 5420.01, -12.4279, 0.519128, 25, 0, 0, 7000, 31550, 0, 1);
UPDATE `creature_template` SET `minhealth` = 19000, `maxhealth` = 19000 WHERE `entry` = 19671;
UPDATE `creature_template` SET `spell1` = 20464, `spell2` = 20463, `spell3` = 20735, `spell4` = 20672 WHERE `entry` = 10181;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 10249;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 10551;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 10593;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 10696;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 10744;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 10811;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 10914;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 10967;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 10975;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 11022;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 11034;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 11037;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 11051;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 11063;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 11080;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 11020;
UPDATE `creature` SET `map` = 1 WHERE `guid` = 11054;
UPDATE `creature_template` SET `lootid` = 0 WHERE `entry` = 18700;
DELETE FROM `creature_loot_template` WHERE (`entry`=18700);
DELETE FROM `creature` WHERE `id`=2992;
DELETE FROM `creature_loot_template` WHERE (`entry`=2992);
UPDATE `creature_template` SET `lootid` = 0 WHERE `entry` = 2992;
UPDATE `creature_template` SET `lootid` = 0 WHERE `entry` = 3560;
DELETE FROM `creature_loot_template` WHERE (`entry`=3560);
DELETE FROM `creature` WHERE `id`=3560;
DELETE FROM `creature_loot_template` WHERE (`entry`=3844);
UPDATE `creature_template` SET `lootid` = 0 WHERE `entry` = 3844;
DELETE FROM `creature` WHERE `id`=3844;
DELETE FROM `creature_loot_template` WHERE (`entry`=10218);
UPDATE `creature_template` SET `lootid` = 0 WHERE `entry` = 10218;
DELETE FROM `creature` WHERE `id`=10218;
UPDATE `creature_template` SET `minhealth` = 150, `maxhealth` = 150 WHERE `entry` = 14664;
DELETE FROM `creature` WHERE `id`=14987;
UPDATE `creature_template` SET `minhealth` = 120000, `maxhealth` = 120000 WHERE `entry` = 25740;
DELETE FROM `creature_loot_template` WHERE (`entry`=25740);
INSERT INTO `creature_loot_template` VALUES 
(25740, 34955, 2, 0, 1, 1, 0, 0, 0),
(25740, 35494, 0, 1, 1, 1, 0, 0, 0),
(25740, 35495, 0, 1, 1, 1, 0, 0, 0),
(25740, 35496, 0, 1, 1, 1, 0, 0, 0),
(25740, 35497, 0, 1, 1, 1, 0, 0, 0),
(25740, 35498, 7, 0, 1, 1, 0, 0, 0),
(25740, 35514, 1, 0, 1, 1, 0, 0, 0),
(25740, 35557, 22, 0, 1, 2, 0, 0, 0),
(25740, 35723, 100, 0, 1, 1, 0, 0, 0);
UPDATE `creature_template` SET `faction_A` = 14 WHERE `faction_A` = 168;
UPDATE `creature_template` SET `faction_H` = 14 WHERE `faction_H` = 168;
UPDATE `creature_template` SET `subname` = '', `npcflag` = 0, `flag1` = 0 WHERE `entry` = 22022;
UPDATE `creature_template` SET `faction_A` = 35, `faction_H` = 35 WHERE `entry` = 17209;
UPDATE `creature_template` SET `faction_A` = 84, `faction_H` = 168 WHERE `entry` = 24885;
UPDATE `creature_template` SET `faction_A` = 35, `faction_H` = 35 WHERE `entry` = 18716;
UPDATE `creature_template` SET `faction_A` = 35, `faction_H` = 35 WHERE `entry` = 18717;
UPDATE `creature_template` SET `faction_A` = 35, `faction_H` = 168 WHERE `entry` = 18197;
UPDATE `creature_template` SET `civilian` = 1 WHERE `entry` = 22083;
UPDATE `creature` SET `spawntimesecs` = 600 WHERE `id` = 4996;
UPDATE `creature` SET `spawntimesecs` = 600 WHERE `id` = 6491;
UPDATE `creature` SET `spawntimesecs` = 600 WHERE `id` = 27666;
UPDATE `creature` SET `spawntimesecs` = 600 WHERE `id` = 23948;
UPDATE `creature` SET `spawntimesecs` = 1200 WHERE `id` = 23721;
UPDATE `creature` SET `spawntimesecs` = 7200 WHERE `guid` = 282592;
UPDATE `creature` SET `spawntimesecs` = 7200 WHERE `guid` = 282593;
UPDATE `creature` SET `spawntimesecs` = 7200 WHERE `guid` = 282591;
DELETE FROM `creature` WHERE `id` = 23699;
INSERT INTO `creature` (`guid`, `id`, `map`, `spawnMask`, `modelid`, `equipment_id`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`, `spawndist`, `currentwaypoint`, `curhealth`, `curmana`, `DeathState`, `MovementType`) VALUES
('82625', 23699, 530, 1, 0, 1322, -1876.13, 5186.02, -50.5879, 2.09316, 25, 0, 0, 7900, 0, 0, 2);
INSERT INTO `creature_movement` (`id`, `point`, `position_x`, `position_y`, `position_z`, `waittime`, `text1`, `text2`, `text3`, `text4`, `text5`, `emote`, `spell`, `wpguid`, `orientation`, `model1`, `model2`) VALUES
('82625', 1, -1875.29, 5185.91, -50.6312, 0, '', '', '', '', '', 0, 0, 0, 2.41832, 0, 0),
('82625', 2, -1889.19, 5200.86, -50.2496, 0, '', '', '', '', '', 0, 0, 0, 2.4678, 0, 0),
('82625', 3, -1912.98, 5214.72, -48.0922, 0, '', '', '', '', '', 0, 0, 0, 2.77017, 0, 0),
('82625', 4, -1942.5, 5219.21, -47.5635, 0, '', '', '', '', '', 0, 0, 0, 3.03721, 0, 0),
('82625', 5, -1974.74, 5234.64, -45.9318, 0, '', '', '', '', '', 0, 0, 0, 2.59739, 0, 0),
('82625', 6, -1926.51, 5216.49, -47.4111, 0, '', '', '', '', '', 0, 0, 0, 6.21258, 0, 0),
('82625', 7, -1905.66, 5212.28, -48.9839, 0, '', '', '', '', '', 0, 0, 0, 5.63138, 0, 0);
UPDATE `creature` SET `DeathState` = '1' WHERE `id` = '16804';
UPDATE npc_trainer SET spell = 2575 WHERE spell = 2581;
UPDATE npc_trainer SET spell = 2576 WHERE spell = 2582;
UPDATE npc_trainer SET spell = 3564 WHERE spell = 3568;
UPDATE npc_trainer SET spell = 10248 WHERE spell = 10249;
UPDATE `npc_trainer` SET `spell` = '4036' WHERE `spell` = '4039' AND `entry` = '8736';
UPDATE `npc_trainer` SET `spell` = '4037' WHERE `spell` = '4040' AND `entry` = '8736';
UPDATE `npc_trainer` SET `spell` = '4038' WHERE `spell` = '4041' AND `entry` = '8736';
UPDATE `npc_trainer` SET `spell` = '12656' WHERE `spell` = '12657' AND `entry` = '8736';
UPDATE `npc_trainer` SET `spell` = '7731' WHERE `spell` = '7734' AND `entry` = '3028';
UPDATE `npc_trainer` SET `spell` = '7731' WHERE `spell` = '7734' AND `entry` = '3332';
UPDATE `npc_trainer` SET `spell` = '22815' WHERE `spell` = '22816' AND `entry` = '11097';
DELETE FROM `creature` WHERE `id` = 23858;
INSERT INTO `creature` (`guid`, `id`, `map`, `spawnMask`, `modelid`, `equipment_id`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`, `spawndist`, `currentwaypoint`, `curhealth`, `curmana`, `DeathState`, `MovementType`) VALUES
('82626', 23858, 530, 1, 0, 0, 6764.76, -7610.55, 128.535, 5.18269, 25, 0, 1, 6700, 0, 0, 2);
INSERT IGNORE INTO `creature_movement` (`id`, `point`, `position_x`, `position_y`, `position_z`, `waittime`, `text1`, `text2`, `text3`, `text4`, `text5`, `emote`, `spell`, `wpguid`, `orientation`, `model1`, `model2`) VALUES
('82626', 1, 6764.76, -7610.55, 128.535, 10000, '', '', '', '', '', 0, 0, 0, 0.935795, 0, 0),
('82626', 2, 6757.96, -7613.65, 128.073, 120000, '', '', '', '', '', 28, 0, 0, 0.935795, 0, 0),
('82626', 3, 6764.76, -7610.55, 128.535, 900000, '', '', '', '', '', 0, 0, 0, 0.935795, 0, 0),
('82626', 4, 6770.57, -7607.24, 128.457, 120000, '', '', '', '', '', 28, 0, 0, 2.92678, 0, 0);
DELETE FROM `skinning_loot_template` WHERE (`entry`=3875);
UPDATE creature_template SET skinloot=0 WHERE entry=3875;
INSERT IGNORE INTO `spell_script_target` VALUES ('12699', '2', '5307'), ('12699', '2', '5308');
UPDATE `creature_template` SET `faction_A` = 1638, `faction_H` = 1638, `npcflag` = 147 WHERE `entry` = 17101;
DELETE FROM `creature` WHERE `id`=19792;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(76794, 19792, 530, 1, 0, 0, -4185.85, 1492.83, 118.013, 3.06137, 300, 5, 0, 5233, 2991, 0, 1),
(76797, 19792, 530, 1, 0, 0, -4140.25, 1522.06, 104.254, 0.139626, 300, 0, 0, 5233, 2991, 0, 0),
(76803, 19792, 530, 1, 0, 0, -4140.49, 1507.05, 104.602, 0.122173, 300, 0, 0, 5233, 2991, 0, 0),
(76831, 19792, 530, 1, 0, 0, -4274.95, 1552.6, 136.092, 5.48033, 300, 0, 0, 5233, 2991, 0, 0),
(76832, 19792, 530, 1, 0, 0, -4288.06, 1538.87, 138.217, 5.44543, 300, 0, 0, 5233, 2991, 0, 0),
(82627, 19792, 530, 1, 0, 0, -4261.46, 1566.25, 131.238, 2.52623, 300, 5, 0, 5233, 2991, 0, 1),
(82628, 19792, 530, 1, 0, 0, -4170.33, 1551.56, 109.148, 5.91321, 300, 5, 0, 5233, 2991, 0, 1),
(82629, 19792, 530, 1, 0, 0, -4335.49, 1624.79, 151.953, 5.79449, 300, 0, 0, 5233, 2991, 0, 0),
(82630, 19792, 530, 1, 0, 0, -4385.64, 1687.34, 157.903, 5.86996, 300, 0, 0, 5233, 2991, 0, 0),
(82631, 19792, 530, 1, 0, 0, -4348.55, 1607.36, 152.506, 5.61996, 300, 0, 0, 5233, 2991, 0, 0),
(82632, 19792, 530, 1, 0, 0, -4374.76, 1609.82, 161.876, 2.07694, 300, 0, 0, 5233, 2991, 0, 0),
(82633, 19792, 530, 1, 0, 0, -4393.78, 1604.31, 163.976, 0.733038, 300, 0, 0, 5233, 2991, 0, 0),
(82634, 19792, 530, 1, 0, 0, -4448.95, 1600.42, 164.39, 3.35103, 300, 0, 0, 5233, 2991, 0, 0),
(82635, 19792, 530, 1, 0, 0, -4426.62, 1706.02, 158.562, 1.37881, 300, 0, 0, 5233, 2991, 0, 0),
(82636, 19792, 530, 1, 0, 0, -4434.65, 1570.83, 164.958, 1.11701, 300, 0, 0, 5233, 2991, 0, 0),
(82637, 19792, 530, 1, 0, 0, -4482.16, 1630.12, 165.213, 0.750492, 300, 0, 0, 5233, 2991, 0, 0),
(82638, 19792, 530, 1, 0, 0, -4477.07, 1619.04, 164.858, 2.05949, 300, 0, 0, 5233, 2991, 0, 0),
(82639, 19792, 530, 1, 0, 0, -4555.5, 1609.37, 175.611, 1.97222, 300, 0, 0, 5233, 2991, 0, 0),
(82640, 19792, 530, 1, 0, 0, -4545.74, 1625.85, 175.28, 1.69297, 300, 0, 0, 5233, 2991, 0, 0),
(82641, 19792, 530, 1, 0, 0, -4501.39, 1742.21, 160.096, 0.073688, 300, 0, 0, 5233, 2991, 0, 0),
(82642, 19792, 530, 1, 0, 0, -4510.63, 1680.89, 170.58, 0.139626, 300, 0, 0, 5233, 2991, 0, 0),
(82643, 19792, 530, 1, 0, 0, -4510.3, 1661.31, 170.582, 0.279253, 300, 0, 0, 5233, 2991, 0, 0),
(82644, 19792, 530, 1, 0, 0, -4531.72, 1698.04, 174.936, 5.13127, 300, 0, 0, 5233, 2991, 0, 0),
(82645, 19792, 530, 1, 0, 0, -4576.97, 1639.06, 175.106, 5.95157, 300, 0, 0, 5233, 2991, 0, 0),
(82646, 19792, 530, 1, 0, 0, -4586.23, 1727.45, 174.745, 0, 300, 0, 0, 5233, 2991, 0, 0),
(82647, 19792, 530, 1, 0, 0, -4587.68, 1713.55, 175.109, 6.19592, 300, 0, 0, 5233, 2991, 0, 0),
(82648, 19792, 530, 1, 0, 0, -4558.35, 1719.7, 175.239, 3.19395, 300, 0, 0, 5233, 2991, 0, 0),
(82649, 19792, 530, 1, 0, 0, -4609.28, 1764.06, 169.017, 1.057, 300, 5, 0, 5233, 2991, 0, 1),
(82650, 19792, 530, 1, 0, 0, -4366.06, 1736.28, 156.82, 3.79426, 300, 5, 0, 5233, 2991, 0, 1),
(82651, 19792, 530, 1, 0, 0, -4407.29, 1785.25, 155.79, 1.29154, 300, 0, 0, 5233, 2991, 0, 0),
(82652, 19792, 530, 1, 0, 0, -4428.48, 1794.5, 159.416, 1.16937, 300, 0, 0, 5233, 2991, 0, 0),
(82653, 19792, 530, 1, 0, 0, -4383.78, 1725.9, 157.452, 5.84685, 300, 0, 0, 5233, 2991, 0, 0),
(82654, 19792, 530, 1, 0, 0, -4329.26, 1757.65, 148.58, 2.19457, 300, 5, 0, 5233, 2991, 0, 1);
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(82655, 19806, 530, 1, 0, 0, -4137.81, 1518.9, 103.254, 2.19925, 300, 0, 0, 10684, 0, 0, 0),
(82656, 19806, 530, 1, 0, 0, -4311.7, 1584.43, 142.611, 2.2141, 300, 5, 0, 10684, 0, 0, 1),
(82657, 19806, 530, 1, 0, 0, -4382.89, 1686.13, 157.85, 2.72837, 300, 5, 0, 10684, 0, 0, 1),
(82658, 19806, 530, 1, 0, 0, -4443.15, 1583.94, 163.903, 2.60201, 300, 5, 0, 10684, 0, 0, 1),
(82659, 19806, 530, 1, 0, 0, -4555.15, 1638.48, 174.33, 4.23101, 300, 5, 0, 10684, 0, 0, 1),
(82660, 19806, 530, 1, 0, 0, -4416.45, 1791.87, 156.612, 1.35636, 300, 5, 0, 10684, 0, 0, 1);
DELETE FROM `creature` WHERE `id`=19796;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(76801, 19796, 530, 1, 0, 0, -4092.91, 1493.31, 96.5598, 3.26377, 300, 0, 0, 5229, 2991, 0, 0),
(76835, 19796, 530, 1, 0, 0, -4234.69, 1496.32, 127.328, 2.14675, 300, 0, 0, 5229, 2991, 0, 0),
(82661, 19796, 530, 1, 0, 0, -4162.61, 1544.51, 108.878, 4.01426, 300, 0, 0, 5229, 2991, 0, 0),
(82662, 19796, 530, 1, 0, 0, -4288.84, 1598.95, 136.992, 3.90954, 300, 0, 0, 5229, 2991, 0, 0),
(82663, 19796, 530, 1, 0, 0, -4394.37, 1695.86, 157.779, 0.523606, 300, 0, 0, 5229, 2991, 0, 0),
(82664, 19796, 530, 1, 0, 0, -4381.37, 1643.24, 159.277, 6.10865, 300, 5, 0, 5229, 2991, 0, 1),
(82665, 19796, 530, 1, 0, 0, -4418.83, 1566.92, 164.814, 1.41372, 300, 5, 0, 5229, 2991, 0, 1),
(82666, 19796, 530, 1, 0, 0, -4447.8, 1665.69, 163.551, 3.03687, 300, 0, 0, 5229, 2991, 0, 0),
(82667, 19796, 530, 1, 0, 0, -4485.73, 1647.33, 165.472, 0.314159, 300, 5, 0, 5229, 2991, 0, 1),
(82668, 19796, 530, 1, 0, 0, -4455.88, 1628.55, 163.035, 3.12414, 300, 0, 0, 5229, 2991, 0, 0),
(82669, 19796, 530, 1, 0, 0, -4538.56, 1633.76, 174.954, 2.81591, 300, 5, 0, 5229, 2991, 0, 1),
(82670, 19796, 530, 1, 0, 0, -4498.56, 1742.42, 159.721, 3.23835, 300, 5, 0, 5229, 2991, 0, 1),
(82671, 19796, 530, 1, 0, 0, -4485.7, 1692.84, 164.861, 0.174533, 300, 5, 0, 5229, 2991, 0, 1),
(82672, 19796, 530, 1, 0, 0, -4488.76, 1728.99, 161.141, 0.523599, 300, 0, 0, 5229, 2991, 0, 0),
(82673, 19796, 530, 1, 0, 0, -4489.87, 1714.28, 161.148, 0.296706, 300, 0, 0, 5229, 2991, 0, 0),
(82674, 19796, 530, 1, 0, 0, -4524.77, 1708.84, 175.073, 3.24631, 300, 0, 0, 5229, 2991, 0, 0),
(82675, 19796, 530, 1, 0, 0, -4574.51, 1654.76, 174.894, 2.63653, 300, 5, 0, 5229, 2991, 0, 1),
(82676, 19796, 530, 1, 0, 0, -4539.33, 1729.32, 174.81, 4.59022, 300, 5, 0, 5229, 2991, 0, 1),
(82677, 19796, 530, 1, 0, 0, -4574.43, 1692.16, 175.296, 6.12611, 300, 0, 0, 5229, 2991, 0, 0),
(82678, 19796, 530, 1, 0, 0, -4355.15, 1724.12, 157.56, 3.50811, 300, 5, 0, 5229, 2991, 0, 1);
UPDATE `creature_template` SET `faction_A` = 14, `faction_H` = 14 WHERE `entry` = 1410;
UPDATE `creature_template` SET `faction_A` = 7, `faction_H` = 7 WHERE `entry` = 5202;
UPDATE creature_template SET dmgschool='2' WHERE entry IN (8908, 8909,8910, 8911, 9017);
UPDATE `creature_template` SET `npcflag` = 130 WHERE `entry` = 4453;
DELETE FROM `npc_vendor` WHERE `entry`='4453';
INSERT INTO `npc_vendor` (`entry`, `item`, `maxcount`, `incrtime`) VALUES ('4453', '5956', '0', '0'), ('4453', '10648', '0', '0'), ('4453', '10647', '0', '0'), ('4453', '4400', '0', '0'), ('4453', '2901', '0', '0'), ('4453', '3466', '0', '0'), ('4453', '2880', '0', '0'), ('4453', '4399', '0', '0');
DELETE FROM `creature` WHERE `id`=8996;
DELETE FROM `creature` WHERE `id`=18778;
DELETE FROM `creature` WHERE (`guid`=74144);
DELETE FROM `creature` WHERE (`guid`=74248);
DELETE FROM `creature` WHERE (`guid`=74138);
DELETE FROM `creature` WHERE (`guid`=74247);
DELETE FROM `creature` WHERE (`guid`=74122);
DELETE FROM `creature` WHERE (`guid`=74249);
UPDATE `creature_template` SET `flag1` = 0 WHERE `entry` = 12922;
UPDATE `creature_template` SET `minhealth` = 980000, `maxhealth` = 980000, `minmana` = 0, `maxmana` = 0, `mingold` = 629880, `maxgold` = 987890 WHERE `entry` = 14601;
UPDATE `creature` SET `spawntimesecs` = 600, `MovementType` = 0 WHERE `guid` = 82624;


# QUEST
UPDATE `quest_template` SET `ReqSpellCast1` = 21050 WHERE `entry` = 6661;
UPDATE `quest_template` SET `QuestFlags` = 8 WHERE `entry` = 4921;
UPDATE `quest_template` SET `Details` = 'There were doubts about our capabilities among our potential new allies.  Of what use could we be to them when perceived as unable to deal with our problems at home?$B$BThis changes everything.  No longer will our power be questioned.  We''ll be able to join the Horde as equals.$B$BTake this letter to Sylvanas, ruler of the Forsaken.  She''s already on our side but the news of Dar''Khan''s death will be music to her ears.  Prepare for a long trip, $N.  If all goes well she will send you to Orgrimmar.', `Objectives` = 'Bring the Letter from Lor''themar Theron to Lady Sylvanas Windrunner in Undercity, the Forsaken capital in Tirisfal Glades.' WHERE `entry` = 9812;
UPDATE `quest_template` SET `SpecialFlags` = 0, `RewMoneyMaxLevel` = 5550 WHERE `entry` = 8323;
UPDATE `quest_template` SET `Objectives` = 'Kill the group of Shadow Silk Poachers that wander the Searing Gorge. Nilith has reason to believe that there are five of them that need to be exterminated. Return to Nilith in the Searing Gorge when this task is complete.' WHERE `entry` = 3379;
DELETE FROM `creature_questrelation` WHERE `quest` = 11886;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 11886;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 11886;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (26221, 11886);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 26221;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 11886;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 11886;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (25324, 11886);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=25324;
DELETE FROM `creature_questrelation` WHERE `quest` = 10162;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 10162;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 10162;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (19273, 10162);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 19273;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 10162;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 10162;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (19273, 10162);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=19273;
DELETE FROM `quest_end_scripts` WHERE `id`=11691;
INSERT INTO `quest_end_scripts` (`id`, `delay`, `command`, `datalong`, `datalong2`, `datatext`, `x`, `y`, `z`, `o`) VALUES 
(11691, 1, 10, 25740, 900000, '', -124.088, -314.997, -1.51007, 1.00287),
(11691, 40, 10, 25755, 900000, '', -112.063, -296.341, -1.59046, 3.9207),
(11691, 20, 10, 25756, 900000, '', -104.573, -309.177, -1.57995, 3.26096),
(11691, 20, 10, 25756, 900000, '', -126.279, -294.739, -1.58925, 4.89066),
(11691, 10, 10, 25757, 900000, '', -105.456, -306.195, -1.58619, 3.51229),
(11691, 10, 10, 25757, 900000, '', -123.378, -293.783, -1.58925, 4.69431);
DELETE FROM `creature_questrelation` WHERE `quest` = 11882;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 11882;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 11882;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (25962, 11882);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 25962;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 11882;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 11882;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (25975, 11882);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=25975;
UPDATE `quest_template` SET `RequiredRaces` = 1101 WHERE `entry` = 11882;
DELETE FROM `creature_questrelation` WHERE `quest` = 11933;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 11933;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 11933;
UPDATE `item_template` SET `startquest`=11933 WHERE `entry` = 35569;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (16818, 11933);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 16818;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 11933;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 11933;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (16818, 11933);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=16818;
DELETE FROM `creature_questrelation` WHERE `quest` = 11935;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 11935;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 11935;
UPDATE `item_template` SET `startquest`=11935 WHERE `entry` = 35568;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (16817, 11935);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 16817;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 11935;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 11935;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (16817, 11935);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=16817;
DELETE FROM `creature_questrelation` WHERE `quest` = 11915;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 11915;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 11915;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (25994, 11915);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 25994;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 11915;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 11915;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (26113, 11915);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=26113;
DELETE FROM `creature_questrelation` WHERE `quest` = 11971;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 11971;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 11971;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (19175, 11971);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 19175;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (19169, 11971);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 19169;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (19176, 11971);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 19176;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (19177, 11971);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 19177;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (19178, 11971);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 19178;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (20102, 11971);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 20102;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 11971;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 11971;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (16818, 11971);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=16818;
DELETE FROM `creature_questrelation` WHERE `quest` = 11970;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 11970;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 11970;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (19172, 11970);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 19172;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (18927, 11970);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 18927;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (19148, 11970);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 19148;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (19171, 11970);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 19171;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (19173, 11970);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 19173;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (20102, 11970);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 20102;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 11970;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 11970;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (16817, 11970);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=16817;
INSERT INTO `event_scripts` VALUES ('4975', '1', '7', '5056', '0', '', '0', '0', '0', '0');
UPDATE `quest_template` SET `SpecialFlags` = 2 WHERE `entry` = 5056;
UPDATE `quest_template` SET `ReqSpellCast1` = 0 WHERE `entry` = 5056;
INSERT INTO `game_event_creature_quest` ( `id`, `quest`, `event`) VALUES (18927, 11441, 26), (19148, 11441, 26), (19173, 11441, 26), (19172, 11441, 26), (19171, 11441, 26);
INSERT INTO `game_event_creature_quest` ( `id`, `quest`, `event`) VALUES (19175, 11446, 26), (19177, 11446, 26), (19178, 11446, 26), (19169, 11446, 26), (19176, 11446, 26);
UPDATE `quest_template` SET `RewSpell` = 36568 WHERE `entry` = 9180;
UPDATE `quest_template` SET `RewSpell` = 36568 WHERE `entry` = 9177;
UPDATE quest_template SET completeemote = 21 WHERE entry = 757;
UPDATE quest_template SET completescript = 1521 where entry = 1521;
INSERT INTO quest_end_scripts (id, delay, command, datalong, datatext) VALUES (1521, 0, 0, 0, "Peace and patience be with you, $N. Remain strong always.");
INSERT IGNORE INTO `spell_script_target` VALUES ('12699', '2', '5307');
UPDATE `quest_template` SET `RewChoiceItemId1` = 16886, `RewChoiceItemId2` = 16887, `RewChoiceItemCount1` = 1, `RewChoiceItemCount2` = 1, `RewRepFaction2` = 911, `RewRepValue2` = 88 WHERE `entry` = 6922;
UPDATE `quest_template` SET `SpecialFlags` = 0 WHERE `entry` = 909;
DELETE FROM `creature_questrelation` WHERE `quest` = 909;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 909;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 909;
UPDATE `item_template` SET `startquest`=909 WHERE `entry` = 16782;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 909;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 909;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (12736, 909);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=12736;
UPDATE `quest_template` SET `OfferRewardText` = 'I am sorry that you had to do that, $N. Heavy-handed violence is not the $r way, but sometimes it is the only way.$B$BThis is one of life''s truths that many do not understand until it is too late. So it was for our people, when we were slaughtered at the hands of the orcs.$B$BBecoming a Hand of Argus is a process of rebirth. And with birth comes pain... ', `ReqCreatureOrGOId2` = 17701, `ReqCreatureOrGOCount2` = 1, `ReqSpellCast2` = 30988 WHERE `entry` = 9666;
UPDATE `quest_template` SET `RequestItemsText` = 'I will keep three of the weapons you returned to me, as mementos of my pain and loss. But please, $N, choose your favorite of the heirlooms and keep it for yourself.$B$BMay it serve you greater than it served its cursed, former owners.', `RewRepFaction1` = 68, `RewRepValue1` = 17 WHERE `entry` = 1822;
UPDATE `quest_template` SET `NextQuestId` = 0, `NextQuestInChain` = 0 WHERE `entry` = 7630;
UPDATE `quest_template` SET `PrevQuestId` = 0 WHERE `entry` = 7623;
UPDATE `quest_template` SET `RequestItemsText` = 'I didn''t mean anything by the comment ''bout you being a stupid $C. We''re friends, right? No hard feelings?' WHERE `entry` = 1447;
UPDATE `quest_template` SET `OfferRewardText` = 'So, Belgrom sent you. You are just in time, $R.$B$BLet me explain the situation, and then you can decide if you are up to the challenge... But if Belgrom sent you, I am sure your courage is unquestionable.' WHERE `entry` = 2981;
UPDATE `quest_template` SET `ReqSpellCast1`=5206 WHERE `entry`=877;
# INSERT INTO `event_scripts` VALUES ('512', '2', '7', '9718', '0', 'Complete quest 9718', '0', '0', '0', '0');
INSERT INTO `event_scripts` VALUES ('10675', '2', '7', '9531', '0', 'Complete quest 9531', '0', '0', '0', '0');
UPDATE `quest_template` SET `SpecialFlags` = 2, `ReqCreatureOrGOId1` = 0, `ReqCreatureOrGOCount1` = 0 WHERE `entry` = 9531;
UPDATE `quest_template` SET `QuestFlags` = 8 WHERE `entry` = 10446;
UPDATE `quest_template` SET `ReqSpellCast2` = 35936 WHERE `entry` = 10447;
UPDATE `quest_template` SET `ReqSourceId1` = '32502', `ReqSourceCount1` = '12', `ReqSourceRef1` = '1' WHERE `entry` = '11020';


# GO
UPDATE `gameobject_template` SET `data0` = 93 WHERE `entry` = 177844;
UPDATE `gameobject_template` SET `data0` = 44870 WHERE `entry` = 187056;
REPLACE INTO `spell_target_position` VALUES (442,129,2592.55,1107.5,51.29,4.74),(444,1,-4658.12,-2526.35,82.9671,0),(446,109,-319.24,99.9,-131.85,3.19),(3561,0,-9003.46,870.031,29.6206,5.28),(3562,0,-4613.62,-915.38,501.062,3.88),(3563,0,1773.47,61.121,-46.3207,0.54),(3565,1,9660.81,2513.64,1331.66,3.06),(3566,1,-964.98,283.433,111.187,3.02),(3567,1,1469.85,-4221.52,58.9939,5.98),(17334,0,-9003.46,870.031,29.6206,5.28),(17608,1,9660.81,2513.64,1331.66,3.06),(17609,1,1469.85,-4221.52,58.9939,5.98),(17610,1,-964.98,283.433,111.187,3.02),(17611,0,1773.47,61.121,-46.3207,0.54),(18960,1,7991.88,-2679.84,512.1,0.034183),(23442,1,6755.33,-4658.09,724.8,3.4049),(32571,530,-2259.74,3114.9,136.35,3.7),(30141,530,-589.83,4079.29,143.26,4.4),(28147,532,-11100,-2001.64,49.8927,0.799535),(32268,530,-4029.93,-11572.2,-138.296,2.43),(32270,530,9998.49,-7106.78,47.7055,2.44),(32271,530,-4029.93,-11572.2,-138.296,2.43),(32272,530,9998.49,-7106.78,47.7055,2.44),(30140,530,-594.2,4079.54,93.83,5.2),(25649,0,1804.87,326.886,70.3975,1.57473),(33690,530,-1800.75,5408.09,-12.4274,2.81),(33728,530,-1800.75,5408.09,-12.4274,2.81),(35715,530,-1904.76,5443.43,-12.4272,5.96),(35718,530,-1904.76,5443.43,-12.4272,5.96),(36890,530,3092.56,3644.5,143.144,1.5796),(36941,530,2054.03,5568.99,263.572,0.9953),(12510,1,3778.74,-4611.78,227.252,4.23263),(26572,530,9334.2,-7880.19,74.9102,2.18185),(26566,530,9330.76,-7811.45,136.57,5.26268),(29273,533,3498.28,-5349.9,144.968,1.31324),(33,0,-10643,1052,34,0),(31,0,-9464,62,56,0),(34,0,-10368,-422,66,0),(35,0,-9104,-70,83,0),(427,189,1688.99,1053.48,18.6775,0.00117),(428,0,-11020,1436,44,0),(445,0,-10566,-1189,28,0),(4996,1,1552.5,-4420.66,8.94802,0),(4997,0,-14457,496.45,39.1392,0),(4998,0,-12415,207.618,31.5017,0.124875),(4999,1,-998.359,-3827.52,5.44507,4.16654),(6348,0,-3752.81,-851.558,10.1153,0),(6349,1,6581.05,767.5,5.78428,6.01616),(6483,1,5483.9,-749.881,334.621,0),(6719,1,-3615.49,-4467.34,24.3141,0),(8735,48,-151.89,106.96,-39.87,4.53),(9268,1,8786.36,967.445,30.197,3.39632),(11362,90,-332.22,-2.28,-150.86,2.77),(11409,0,-13184,334,100,0),(447,0,16229,16265,14,3.19),(3721,0,16229,16265,14,3.19),(1936,0,16229,16265,14,0),(443,0,16229,16265,14,4.74),(8195,0,16229,16265,14,3.19),(12520,1,3644.95,-4700.25,120.81,6.25),(32569,530,-2307.35,3123.92,13.69,2.15),(32568,530,-2260.39,3211.07,14.12,4.57),(32572,530,-2259.74,3215.03,-4.05,3.14),(35730,530,10021,-7014.19,49.7164,3.90972),(12241,1,-3282.15,2062.17,245.96,4.15),(31613,530,-3288.9,-12923.5,10.1061,5.92033),(6766,1,-2354.03,-1902.07,95.78,4.6),(44089,0,-4613.62,-915.38,501.062,3.88),(12885,0,-11238.4,-2831.97,157.93,5.11),(13142,0,-11238.4,-2831.97,157.93,5.11),(39567,532,-11164.5,-1909.56,232.009,3.65587),(42711,1,-3722.91,-4413.96,26.13,3.87),(30115,532,-11240.6,-1694.27,179.32,5.78958),(25725,509,-9717.2,1517.81,27.6,5.4),(37387,530,-2832.71,1950.02,201.25,4.06),(37389,530,-2742.77,2727,124.81,5.29),(37532,530,-3278.63,2831.31,123.01,1.56),(6714,1,-4884.49,-1596.2,101.2,3.17),(23441,1,-7109.1,-3825.21,10.151,2.8331),(21128,349,419.84,11.3365,-131.079,0),(41234,530,-3649.92,317.469,35.2827,2.94285),(17159,1,6106.4,-4191.1,849.74,0.0201),(17160,1,5904.2,-4045.9,596.43,0.0083),(46149,530,-1842.07,5497.17,-12.4306,4.40609),(37778,1,-8167.18,-4766.8,33.9648,5.165),(49359,1,-3730.72,-4422.21,30.4836,0.810732),(49363,0,-10442,-3291.46,20.179,1.30292),(49362,1,-3730.72,-4422.21,30.4836,0.810732),(49358,0,-10442,-3291.46,20.179,1.30292),(45038,530,833.319,2512.91,292.2,0.535559),(44870,530,12804,-6908,41.1,2.21),(34661,553,5.03811,593.451,-15.1414,4.68254),(46841,530,12888,-6876,9,0.3),(23446,1,-7109.1,-3825.21,10.151,2.8331),(36902,1,-7324.3,-3830.7,160,0);
UPDATE `gameobject` SET `animprogress` = 100 WHERE `guid` = 75245;
UPDATE `gameobject` SET `spawntimesecs` = 3200 WHERE `guid` = 68752;
INSERT INTO `gameobject` VALUES 
(73731, 186881, 0, 1, -5160.81, -564.643, 397.175, 5.05434, 0, 0, 0.576487, -0.817106, 180, 0, 1),
(73741, 186881, 1, 1, 1192.3, -4302.74, 21.2859, 3.18856, 0, 0, 0.999724, -0.0234794, 180, 0, 1);
INSERT IGNORE INTO `game_event_gameobject` SELECT `guid`,'26' FROM `gameobject` WHERE `id`=186881;
INSERT INTO `gameobject` (`guid`,`id`,`map`,`spawnMask`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(73726, 177844, 0, 1, -10172.7, 2391.19, -139.476, 5.0511, 0, 0, 0.577808, -0.816172, 50, 100, 1);
UPDATE gameobject_template SET flags=0, data8=4248 WHERE entry in (164658, 164659, 164660, 164661, 164778, 164779, 164780, 164781);
UPDATE `gameobject_template` SET `type` = 5, `data0` = 0, `data1` = 0 WHERE `entry` = 181917;
UPDATE `gameobject_template` SET `flags` = `flags`&~'4' WHERE `entry` IN ('164658', '164659', '164660', '164661', '164778', '164779', '164780', '164781');
DELETE FROM `gameobject` WHERE `id`=182066;
INSERT INTO `gameobject` (`guid`,`id`,`map`,`spawnMask`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(33314, 182066, 530, 1, -216.416, 5441.64, 22.1584, -2.18166, 0, 0, 0.887011, -0.461749, 180, 100, 1);


# ITEM
UPDATE `item_template` SET `Flags` = 524288 WHERE `entry` = 19345;


DELETE FROM `db_version`;
INSERT INTO `db_version` VALUES ('YTDB_095_R43.05_rev6251');

# UPDATE `quest_template` SET `NextQuestId`=NextQuestInChain WHERE (`NextQuestId`='0');
# update `creature_template` set ScriptName='generic_creature' WHERE `spell1` > '0' AND `ScriptName` = '';
# UPDATE `creature_template` SET `ScriptName`='' WHERE `type` = '11' AND `name` LIKE '%totem%' AND `faction_A` = '2';
# UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` IN (SELECT `id` FROM `creature_questrelation`);
# UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` IN (SELECT `id` FROM `creature_involvedrelation`);
# UPDATE `creature` SET `MovementType` = 0 WHERE `spawndist` = 0 AND `MovementType`=1;
# UPDATE `creature` SET `spawndist`=0 WHERE `MovementType`=0;
# UPDATE `quest_template` SET `SpecialFlags`=`SpecialFlags`|1 WHERE `QuestFlags`=`QuestFlags`|4096;
# delete from npc_gossip where npc_guid not in (select guid from creature);
DELETE FROM `creature_addon` WHERE `guid` NOT IN (SELECT `guid` FROM `creature`);
DELETE FROM `creature_movement` WHERE `id` NOT IN (SELECT `guid` FROM `creature`);
DELETE FROM `npc_gossip` WHERE `npc_guid` NOT IN (SELECT `guid` FROM `creature`);
DELETE FROM `game_event_gameobject` WHERE `guid` NOT IN (SELECT `guid` FROM `gameobject`);
DELETE FROM `game_event_creature` WHERE `guid` NOT IN (SELECT `guid` FROM `creature`);
UPDATE `creature`, `creature_template` SET `creature`.`curhealth`=`creature_template`.`minhealth`,`creature`.`curmana`=`creature_template`.`minmana` WHERE `creature`.`id`=`creature_template`.`entry`;
update gameobject_template, gameobject set gameobject.animprogress = 100 where gameobject_template.entry = gameobject.id and gameobject_template.type = 3;
UPDATE `creature_template` SET `ScriptName`='' WHERE `entry` in ('6172','6177','17542','17768');
