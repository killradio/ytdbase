# Y2kCat
UPDATE `quest_template` SET `NextQuestId`=NextQuestInChain WHERE (`NextQuestId`='0');

# KiriX
UPDATE `item_template` SET `Quality`='5',`dmg_min1`='131',`dmg_max1`='310',`ArmorDamageModifier`='0' WHERE (`entry`='30313');
UPDATE `creature_template` SET `lootid`='21273' WHERE (`entry`='21273');
UPDATE `creature_template` SET `lootid`='21274' WHERE (`entry`='21274');
UPDATE `creature_template` SET `faction_A`='35',`faction_H`='35' WHERE (`entry`='21657');
UPDATE `quest_template` SET `RequiredRaces`='1101' WHERE (`entry`='9803');
UPDATE `creature_template` SET `faction_A`='35' WHERE (`entry`='18197');
UPDATE `creature_template` SET `mindmg`='32',`maxdmg`='67',`attackpower`='345' WHERE (`entry`='5983');
UPDATE `creature_template` SET `mindmg`='32',`maxdmg`='67',`attackpower`='345' WHERE (`entry`='24819');
UPDATE `creature_template` SET `faction_A`='35',`faction_H`='14' WHERE (`entry`='21023');
UPDATE `quest_template` SET `RequiredRaces`='690' WHERE (`entry`='10489');

# Naleway
UPDATE `quest_template` SET `QuestFlags` = 4, `ReqItemId1` = 0, `ReqItemCount1` = 0 WHERE `entry` = 10708;
UPDATE `quest_template` SET `PrevQuestId` = 10708 WHERE `entry` = 10944;

# LOTAR
UPDATE `gameobject_template` SET `data1` = 5 WHERE `entry` = 21007;
UPDATE `quest_template` SET `OfferRewardText` = 'You\'ve been busy! I can\'t wait to cook up that wolf meat...$B$BI have some things here eou might want - take your pick!' WHERE `entry` = 33;
UPDATE `creature_template` SET `name` = 'Warden Moi\'bff Jill', `minhealth` = 4100, `maxhealth` = 4100 WHERE `entry` = 18408;

# sasmeo
UPDATE `quest_template` SET `RequiredRaces` = 690 WHERE `entry` in (10794,2460,2458);

# dmitrycrush
UPDATE item_template set Quality=2, class=7 where entry=28558;
update `creature_loot_template` set `ChanceOrRef`=`QuestChanceOrGroup`,`QuestChanceOrGroup`=0,`freeforall`=1 where `item` in (28558);
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup, `QuestChanceOrGroup`=0, freeforall=0 where item=24401 and ChanceOrRef=0;
UPDATE item_template set class=7 where entry=24401;
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup, `QuestChanceOrGroup`=0, freeforall=0 where item=24245 and ChanceOrRef=0;
UPDATE item_template set class=7 where entry=24245;
UPDATE gameobject_loot_template set ChanceOrRef=100 where entry=182053 and item=24245;
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup, `QuestChanceOrGroup`=0, freeforall=0 where item=25433 and ChanceOrRef=0;
UPDATE item_template set class=7 where entry=25433;
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup, `QuestChanceOrGroup`=0, freeforall=0 where item in (29426, 30810, 29425, 30809) and ChanceOrRef=0;
UPDATE item_template set class=7 where entry in (29426, 30810, 29425, 30809);
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup,  `QuestChanceOrGroup`=0, freeforall=0 where item=21383 and ChanceOrRef=0;
UPDATE item_template set class=7 where entry=21383;
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup,  `QuestChanceOrGroup`=0, freeforall=0 where item=13180 and ChanceOrRef=0;
UPDATE item_template set class=7 where entry=13180;
DELETE FROM `creature_questrelation` WHERE `quest` = 5505;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 5505;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 5505;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (11057, 5505);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 11057;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (11056, 5505);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 11056;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 5505;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 5505;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (11057, 5505);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=11057;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (11056, 5505);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=11056;
UPDATE quest_template set PrevQuestId=5803 where entry=5505;
UPDATE quest_template set NextQuestId=5505 WHERE entry=5803;
UPDATE creature_loot_template set QuestChanceOrGroup=5, `ChanceOrRef`=0 where item = 25490;
UPDATE creature_loot_template set QuestChanceOrGroup=5, `ChanceOrRef`=0 where item = 25509;
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup, QuestChanceOrGroup=0, freeforall=0 where item in (12840, 12841, 12843) and ChanceOrRef=0;
UPDATE creature_template set faction_A=14, faction_H=14, flags=0 where entry in (19032, 19029, 19028);
UPDATE creature_loot_template set ChanceOrRef=100 where item=8548;
update item_template set Flags=4 where entry=31522;
UPDATE `quest_template` SET `ReqCreatureOrGOId1` = 22334 WHERE `entry` = 10864;
update creature_loot_template set QuestChanceOrGroup=100, freeforall=1 where item in (24513, 24496, 24523, 24505);
update creature_loot_template set QuestChanceOrGroup=100, freeforall=1 where item in (25767, 25768, 25769);
UPDATE `creature_template` SET `faction_A` = '35', `faction_H` = '35' WHERE `entry` = '18585';
UPDATE `creature_template` SET `faction_A` = '1734', `faction_H` = '1734' WHERE `entry` = '19606';
update item_template set RequiredReputationFaction=1011 where entry=22538;
UPDATE creature_loot_template set ChanceOrRef = QuestChanceOrGroup, QuestChanceOrGroup = 0 where ChanceOrRef=0 and item in (29739, 29740);
UPDATE creature_loot_template set QuestChanceOrGroup=30 where item=20519;
UPDATE quest_template set SpecialFlags=1 where entry=2882;
UPDATE creature_loot_template set QuestChanceOrGroup=40 where item=10509 and QuestChanceOrGroup<75;
UPDATE creature_loot_template set QuestChanceOrGroup=40 where item=10511 and QuestChanceOrGroup<75;
UPDATE creature_loot_template set QuestChanceOrGroup=40 where item=10552 and QuestChanceOrGroup<75;
update quest_template set SpecialFlags=1 where Title like 'The Monogrammed Sash';
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup, QuestChanceOrGroup=0 where item=22525 and ChanceOrRef=0;
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup, QuestChanceOrGroup=0 where item=22526 and ChanceOrRef=0;
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup, QuestChanceOrGroup=0 where item=22527 and ChanceOrRef=0;
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup, QuestChanceOrGroup=0 where item=22528 and ChanceOrRef=0;
UPDATE creature_loot_template set ChanceOrRef=QuestChanceOrGroup, QuestChanceOrGroup=0 where item=22529 and ChanceOrRef=0;
UPDATE item_template set class=7 where entry in (22525, 22526, 22527, 22528, 22529);
UPDATE quest_template set SpecialFlags=1 where entry=9137;
UPDATE quest_template set SpecialFlags=1 where entry=9132;
UPDATE quest_template set SpecialFlags=1, PrevQuestId=9128 where entry=9129;
UPDATE quest_template set SpecialFlags=1 where entry=9127;
UPDATE quest_template set SpecialFlags=1 where entry=9125;
DELETE FROM `creature_loot_template` WHERE (`entry`=16143);
UPDATE creature_loot_template set ChanceOrRef=100 where item in (5138, 13250, 16304, 18422, 18423, 19002, 19003, 21220, 32385);
UPDATE creature_loot_template set QuestChanceOrGroup=100, ChanceOrRef=0 where item=15767;
update quest_template set SpecialFlags=1 where entry in (5402,5403,5404,5406,5407,5408,5508,5509,5510);


# ITEM
UPDATE `item_template` SET `subclass` = 3, `FoodType` = 0 WHERE `entry` = 33208;


# QUEST
DELETE FROM `creature_questrelation` WHERE `quest` = 8271;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 8271;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 8271;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (13816, 8271);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 13816;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 8271;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 8271;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (13816, 8271);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=13816;
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (8271, 267, 51, 60, 41, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7141, 0, 0, 0, 0, 0, 0, 'Hero of the Stormpike', '', '', 'As a hero of the Stormpike, you may choose one item from these recently plun... er, recovered treasures. ', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19107, 19106, 19108, 20648, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 47, 730, 0, 0, 0, 10, 10, 0, 0, 0, 0, 950, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
DELETE FROM `creature_questrelation` WHERE `quest` = 8272;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 8272;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 8272;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (13817, 8272);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 13817;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 8272;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 8272;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (13817, 8272);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=13817;
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (8272, 267, 51, 60, 41, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7142, 0, 0, 0, 0, 0, 0, 'Hero of the Frostwolf', '', '', 'How does it feel, $N? How does it feel to crush your enemies and watch their lines break apart? It feels good, doesn\'t it?$B$BYou should be rewarded for this heroic deed, soldier. ', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19107, 19106, 19108, 20648, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 729, 76, 0, 0, 0, 10, 10, 0, 0, 0, 0, 950, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
DELETE FROM `creature_questrelation` WHERE `quest` = 8744;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 8744;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 8744;
INSERT INTO `gameobject_questrelation` (`id`, `quest`) VALUES (180743, 8744);
DELETE FROM `creature_involvedrelation` WHERE `quest` = 8744;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 8744;
INSERT INTO `gameobject_involvedrelation` (`id`, `quest`) VALUES (180743, 8744);
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (8744, -22, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 'A Carefully Wrapped Present', '', '', 'The tag on this present reads:$B$BTo $N,$B$BMay your feast of Great-Winter be merry and bright! ', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21191, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
DELETE FROM `creature_questrelation` WHERE `quest` = 8768;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 8768;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 8768;
INSERT INTO `gameobject_questrelation` (`id`, `quest`) VALUES (180747, 8768);
DELETE FROM `creature_involvedrelation` WHERE `quest` = 8768;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 8768;
INSERT INTO `gameobject_involvedrelation` (`id`, `quest`) VALUES (180747, 8768);
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (8768, -22, 20, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 'A Gaily Wrapped Present', '', '', 'This festively-wrapped present has your name on it.$B$BWait, did it just move? ', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21310, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
DELETE FROM `creature_questrelation` WHERE `quest` = 8769;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 8769;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 8769;
INSERT INTO `gameobject_questrelation` (`id`, `quest`) VALUES (180748, 8769);
DELETE FROM `creature_involvedrelation` WHERE `quest` = 8769;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 8769;
INSERT INTO `gameobject_involvedrelation` (`id`, `quest`) VALUES (180748, 8769);
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (8769, -22, 40, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 'A Ticking Present', '', '', 'Have a joyous Feast of Great-Winter from your friends at Smokeywood Pastures. ', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21327, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
DELETE FROM `creature_questrelation` WHERE `quest` = 8803;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 8803;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 8803;
INSERT INTO `gameobject_questrelation` (`id`, `quest`) VALUES (180793, 8803);
DELETE FROM `creature_involvedrelation` WHERE `quest` = 8803;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 8803;
INSERT INTO `gameobject_involvedrelation` (`id`, `quest`) VALUES (180793, 8803);
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (8803, -22, 10, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 'A Festive Gift', '', '', 'The note on this present reads:$B$BTo $N,$B$BIn hoping this will help you spread warm tidings and holiday cheer to all of Azeroth.$B$BFrom Greatfather Winter ', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21363, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
DELETE FROM `creature_questrelation` WHERE `quest` = 9029;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 9029;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 9029;
INSERT INTO `gameobject_questrelation` (`id`, `quest`) VALUES (181073, 9029);
DELETE FROM `creature_involvedrelation` WHERE `quest` = 9029;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 9029;
INSERT INTO `gameobject_involvedrelation` (`id`, `quest`) VALUES (181073, 9029);
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (9029, 267, 1, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 'A Bubbling Cauldron', '', '', 'A pleasant smell wafts up from the cauldron. ', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22281, 22282, 22277, 22278, 22280, 22276, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
UPDATE `quest_template` SET `SrcItemId` = 19018, `SrcItemCount` = 1, `RewMoneyMaxLevel` = 0 WHERE `entry` = 7787;
UPDATE `quest_template` SET `RequiredRaces` = 0 WHERE `entry` = 3111;
DELETE FROM `creature_questrelation` WHERE `quest` = 10054;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 10054;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 10054;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (16820, 10054);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 16820;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 10054;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 10054;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (16820, 10054);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=16820;
UPDATE `quest_template` SET `RewMoneyMaxLevel` = 0 WHERE `entry` = 10886;
UPDATE `quest_template` SET `QuestFlags` = 2, `SrcSpell` = 39564, `RewMoneyMaxLevel` = 0 WHERE `entry` = 10886;
UPDATE `quest_template` SET `SrcSpell` = 32756 WHERE `entry` = 10040;
UPDATE `quest_template` SET `SrcSpell` = 32756 WHERE `entry` = 10041;
UPDATE `quest_template` SET `ReqCreatureOrGOCount1` = 10, `ReqCreatureOrGOCount2` = 5, `ReqCreatureOrGOCount3` = 5, `ReqCreatureOrGOCount4` = 5 WHERE `entry` = 7862;
UPDATE `quest_template` SET `CompleteEmote` = 1 WHERE `entry` = 11010;
UPDATE `quest_template` SET `RewOrReqMoney` = 0, `CompleteEmote` = 1 WHERE `entry` = 11023;
UPDATE `quest_template` SET `QuestFlags` = 8, `ReqCreatureOrGOId1` = -179544, `ReqCreatureOrGOCount1` = 1 WHERE `entry` = 7482;
UPDATE `quest_template` SET `QuestFlags` = 8, `ReqCreatureOrGOId1` = -179544, `ReqCreatureOrGOCount1` = 1 WHERE `entry` = 7481;
UPDATE `gameobject_template` SET `type` = 10, `data0` = 43, `data3` = 0 WHERE `entry` = 179544;
UPDATE `quest_template` SET `QuestFlags` = 10, `SpecialFlags` = 2, `ReqItemId1` = 0, `ReqItemCount1` = 0, `ReqSourceId1` = 12814, `ReqSourceCount1` = 1 WHERE `entry` = 5096;
UPDATE `gameobject_template` SET `data0` = 0 WHERE `entry` = 176087;
UPDATE `gameobject_template` SET `data1` = 960 WHERE `entry` = 176210;
REPLACE INTO `quest_template` (`entry`, `ZoneOrSort`, `MinLevel`, `QuestLevel`, `Type`, `RequiredRaces`, `RequiredSkillValue`, `RepObjectiveFaction`, `RepObjectiveValue`, `RequiredMinRepFaction`, `RequiredMinRepValue`, `RequiredMaxRepFaction`, `RequiredMaxRepValue`, `SuggestedPlayers`, `LimitTime`, `QuestFlags`, `SpecialFlags`, `PrevQuestId`, `NextQuestId`, `ExclusiveGroup`, `NextQuestInChain`, `SrcItemId`, `SrcItemCount`, `SrcSpell`, `Title`, `Details`, `Objectives`, `OfferRewardText`, `RequestItemsText`, `EndText`, `ObjectiveText1`, `ObjectiveText2`, `ObjectiveText3`, `ObjectiveText4`, `ReqItemId1`, `ReqItemId2`, `ReqItemId3`, `ReqItemId4`, `ReqItemCount1`, `ReqItemCount2`, `ReqItemCount3`, `ReqItemCount4`, `ReqSourceId1`, `ReqSourceId2`, `ReqSourceId3`, `ReqSourceId4`, `ReqSourceCount1`, `ReqSourceCount2`, `ReqSourceCount3`, `ReqSourceCount4`, `ReqSourceRef1`, `ReqSourceRef2`, `ReqSourceRef3`, `ReqSourceRef4`, `ReqCreatureOrGOId1`, `ReqCreatureOrGOId2`, `ReqCreatureOrGOId3`, `ReqCreatureOrGOId4`, `ReqCreatureOrGOCount1`, `ReqCreatureOrGOCount2`, `ReqCreatureOrGOCount3`, `ReqCreatureOrGOCount4`, `ReqSpellCast1`, `ReqSpellCast2`, `ReqSpellCast3`, `ReqSpellCast4`, `RewChoiceItemId1`, `RewChoiceItemId2`, `RewChoiceItemId3`, `RewChoiceItemId4`, `RewChoiceItemId5`, `RewChoiceItemId6`, `RewChoiceItemCount1`, `RewChoiceItemCount2`, `RewChoiceItemCount3`, `RewChoiceItemCount4`, `RewChoiceItemCount5`, `RewChoiceItemCount6`, `RewItemId1`, `RewItemId2`, `RewItemId3`, `RewItemId4`, `RewItemCount1`, `RewItemCount2`, `RewItemCount3`, `RewItemCount4`, `RewRepFaction1`, `RewRepFaction2`, `RewRepFaction3`, `RewRepFaction4`, `RewRepFaction5`, `RewRepValue1`, `RewRepValue2`, `RewRepValue3`, `RewRepValue4`, `RewRepValue5`, `RewOrReqMoney`, `RewMoneyMaxLevel`, `RewSpell`, `PointMapId`, `PointX`, `PointY`, `PointOpt`, `DetailsEmote1`, `DetailsEmote2`, `DetailsEmote3`, `DetailsEmote4`, `IncompleteEmote`, `CompleteEmote`, `OfferRewardEmote1`, `OfferRewardEmote2`, `OfferRewardEmote3`, `OfferRewardEmote4`, `StartScript`, `CompleteScript`) VALUES (5096, 85, 50, 53, 0, 690, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 2, 0, 0, 0, 0, 12807, 1, 0, 'Scarlet Diversions', 'Before Andorhal, we must tackle the advancing Scarlet Crusade menace from Hearthglen.  They\'ve made camp between Felstone Field and Dalson\'s Tears, making us risk conflict against both the Scourge and the Crusade at once.$B$BMy plan is to play them off of each other by sending you to destroy the command tent they\'ve set up; use some Flame in a Bottle from this box of incendiaries.  Once razed, plant this Scourge banner by the tent.  With some luck, they\'ll ignore us and focus on the Scourge for vengeance.', 'Proceed to the Scarlet Crusade\'s base camp between Felstone Field and Dalson\'s Tears and destroy their command tent.$B$BPlace the Scourge banner at the camp, and then return to High Executor Derrington at the Bulwark, Western Plaguelands.', 'Finely executed, $N.  Your attack on the Scarlet Crusade will buy us time.  I have sent one of my best scouts out to watch over the camp and make sure that the Crusade forces that come to reinforce the position will take the bait.$B$BWith the pressure on us lessened, we should now finally be able to risk a mission into Andorhal itself, and an important one at that.  I\'d very much like it if you\'d perform this one as well, based on your success to date.', '', 'Destroy the command tent and plant the Scourge banner in the camp', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 12814, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, -176210, 0, 0, 0, 1, 0, 0, 0, 17015, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 0, 0, 0, 0, 250, 0, 0, 0, 0, 8000, 4560, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
UPDATE `quest_template` SET `Objectives` = 'Have you obtained any more warbeads?  You''ll find plenty of ogres to the far north, near the border with Zangarmarsh. ' WHERE `entry` = 9892;


# NPC
UPDATE `creature_template` SET `minlevel` = 40, `maxlevel` = 40, `minhealth` = 3700, `maxhealth` = 3700, `minmana` = 3850, `maxmana` = 3850 WHERE `entry` = 23704;
INSERT IGNORE INTO `game_event_creature` SELECT `guid`,'26' FROM `creature` WHERE `id`=23872;
update creature_template set rank = 0 where entry in (2643, 2645, 2646, 2647);
DELETE FROM `creature_loot_template` WHERE (`entry`=14435) AND (`item`=19018);
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrRef`, `QuestChanceOrGroup`, `mincount`, `maxcount`, `freeforall`, `lootcondition`, `condition_value1`, `condition_value2`) VALUES (14435, 19018, 41, 0, 1, 1, 0, 0, 0, 0);
UPDATE `creature_template` SET `mindmg` = 3500, `maxdmg` = 4500, `baseattacktime` = 2000, `mingold` = 1477812, `maxgold` = 1477812 WHERE `entry` = 11502;
DELETE FROM `creature_loot_template` WHERE (`entry`=11502) AND (`item`=19017);
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrRef`, `QuestChanceOrGroup`, `mincount`, `maxcount`, `freeforall`, `lootcondition`, `condition_value1`, `condition_value2`) VALUES (11502, 19017, 2, 0, 1, 1, 1, 0, 0, 0);
DELETE FROM `creature` WHERE (`guid`=279574);
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `IconName`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `scale`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `mechanic_immune_mask`, `ScriptName`) VALUES (195800, 19008, 0, 19008, 0, 'Belmara', 'Kirin Tor', '', 1, 1, 1, 1, 0, 0, 7, 35, 35, 0, 1, 0, 0, 1, 2, 0, 12, 6, 9, 0, 0, 0, 0, 0, 0, 0, 1.03448, 1.37931, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 3, 0, 1, 0, 0, '');
REPLACE INTO `creature_template` (`entry`, `modelid_A`, `modelid_A2`, `modelid_H`, `modelid_H2`, `name`, `subname`, `IconName`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed`, `scale`, `rank`, `mindmg`, `maxdmg`, `dmgschool`, `attackpower`, `baseattacktime`, `rangeattacktime`, `flags`, `dynamicflags`, `family`, `trainer_type`, `trainer_spell`, `class`, `race`, `minrangedmg`, `maxrangedmg`, `rangedattackpower`, `type`, `civilian`, `flag1`, `lootid`, `pickpocketloot`, `skinloot`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `spell1`, `spell2`, `spell3`, `spell4`, `mingold`, `maxgold`, `AIName`, `MovementType`, `InhabitType`, `RacialLeader`, `RegenHealth`, `equipment_id`, `mechanic_immune_mask`, `ScriptName`) VALUES (195801, 19008, 0, 19008, 0, 'Dathric', 'Kirin Tor', '', 1, 1, 1, 1, 0, 0, 7, 35, 35, 0, 1, 0, 0, 1, 2, 0, 12, 6, 9, 0, 0, 0, 0, 0, 0, 0, 1.03448, 1.37931, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 3, 0, 1, 0, 0, '');
INSERT INTO `event_scripts` VALUES ('12610', '0', '10', '19579', '180000', 'PREVED!', '2206.17', '2413.49', '109.839', '4.25162');
INSERT INTO `event_scripts` VALUES ('12609', '0', '10', '19580', '180000', 'PREVED!', '2192.86', '2340.61', '90.3097', '5.90838');
INSERT INTO `event_scripts` VALUES ('12607', '0', '10', '195800', '180000', 'PREVED!', '2242.09', '2389.31', '112.659', '1.34696');
INSERT INTO `event_scripts` VALUES ('12608', '0', '10', '195801', '180000', 'PREVED!', '2232.39', '2312.31', '89.834', '1.81078');
UPDATE `creature` SET `MovementType`='0' WHERE (`id`='18240');
UPDATE creature SET spawn_position_x = '-2176.549072', spawn_position_y = '8297.833984', spawn_position_z = '-22.672447', spawn_orientation = '3.314373',position_x = '-2176.549072', position_y = '8297.833984', position_z = '-22.672447', orientation = '3.314373' WHERE guid = '71558';
UPDATE creature SET spawn_position_x = '-2173.238281', spawn_position_y = '8285.479492', spawn_position_z = '-21.498487', spawn_orientation = '4.333819',position_x = '-2173.238281', position_y = '8285.479492', position_z = '-21.498487', orientation = '4.333819' WHERE guid = '71559';
UPDATE creature SET spawn_position_x = '-2133.701904', spawn_position_y = '8248.263672', spawn_position_z = '-20.797861', spawn_orientation = '4.977843',position_x = '-2133.701904', position_y = '8248.263672', position_z = '-20.797861', orientation = '4.977843' WHERE guid = '71541';
UPDATE creature SET spawn_position_x = '-2100.874756', spawn_position_y = '8251.648438', spawn_position_z = '-15.655578', spawn_orientation = '0.398971',position_x = '-2100.874756', position_y = '8251.648438', position_z = '-15.655578', orientation = '0.398971' WHERE guid = '71545';
UPDATE creature SET spawn_position_x = '-2088.003662', spawn_position_y = '8292.377930', spawn_position_z = '-11.589088', spawn_orientation = '1.180443',position_x = '-2088.003662', position_y = '8292.377930', position_z = '-11.589088', orientation = '1.180443' WHERE guid = '71546';
UPDATE creature SET spawn_position_x = '-2101.355469', spawn_position_y = '8316.422852', spawn_position_z = '-12.143283', spawn_orientation = '1.353230',position_x = '-2101.355469', position_y = '8316.422852', position_z = '-12.143283', orientation = '1.353230' WHERE guid = '71543';
UPDATE creature SET spawn_position_x = '-2117.334717', spawn_position_y = '8353.362305', spawn_position_z = '-14.745498', spawn_orientation = '1.993329',position_x = '-2117.334717', position_y = '8353.362305', position_z = '-14.745498', orientation = '1.993329' WHERE guid = '71556';
UPDATE creature SET spawn_position_x = '-2150.861328', spawn_position_y = '8284.667969', spawn_position_z = '-19.452314', spawn_orientation = '4.043218',position_x = '-2150.861328', position_y = '8284.667969', position_z = '-19.452314', orientation = '4.043218' WHERE guid = '71544';
UPDATE creature SET spawn_position_x = '-2172.984619', spawn_position_y = '8248.461914', spawn_position_z = '-23.051714', spawn_orientation = '4.149247',position_x = '-2172.984619', position_y = '8248.461914', position_z = '-23.051714', orientation = '4.149247' WHERE guid = '71544';
UPDATE creature SET spawn_position_x = '-2176.885010', spawn_position_y = '8316.918945', spawn_position_z = '-24.387875', spawn_orientation = '2.535253',position_x = '-2176.885010', position_y = '8316.918945', position_z = '-24.387875', orientation = '2.535253' WHERE guid = '71555';
UPDATE creature SET spawn_position_x = '-2157.944824', spawn_position_y = '8383.558594', spawn_position_z = '-16.385574', spawn_orientation = '1.608483',position_x = '-2157.944824', position_y = '8383.558594', position_z = '-16.385574', orientation = '1.608483' WHERE guid = '71560';
UPDATE creature SET spawn_position_x = '-2193.550049', spawn_position_y = '8336.800781', spawn_position_z = '-22.508999', spawn_orientation = '6.218770',position_x = '-2193.550049', position_y = '8336.800781', position_z = '-22.508999', orientation = '6.218770' WHERE guid = '71557';
UPDATE creature SET spawn_position_x = '-2203.625244', spawn_position_y = '8381.213867', spawn_position_z = '-24.901672', spawn_orientation = '1.918715',position_x = '-2203.625244', position_y = '8381.213867', position_z = '-24.901672', orientation = '1.918715' WHERE guid = '71561';
UPDATE creature SET spawn_position_x = '-2248.252197', spawn_position_y = '8326.462891', spawn_position_z = '-30.378717', spawn_orientation = '3.155714',position_x = '-2248.252197', position_y = '8326.462891', position_z = '-30.378717', orientation = '3.155714' WHERE guid = '71549';
UPDATE creature SET spawn_position_x = '-2197.086914', spawn_position_y = '8259.150391', spawn_position_z = '-21.208883', spawn_orientation = '3.529563',position_x = '-2197.086914', position_y = '8259.150391', position_z = '-21.208883', orientation = '3.529563' WHERE guid = '71548';
UPDATE creature SET spawn_position_x = '-2109.834473', spawn_position_y = '8224.463867', spawn_position_z = '-14.794658', spawn_orientation = '5.167119',position_x = '-2109.834473', position_y = '8224.463867', position_z = '-14.794658', orientation = '5.167119' WHERE guid = '71542';
UPDATE creature SET spawn_position_x = '-2011.074219', spawn_position_y = '8297.490234', spawn_position_z = '10.936759', spawn_orientation = '2.060868',position_x = '-2011.074219', position_y = '8297.490234', position_z = '10.936759', orientation = '2.060868' WHERE guid = '71550';
UPDATE creature SET spawn_position_x = '-2035.813843', spawn_position_y = '8333.043945', spawn_position_z = '14.550858', spawn_orientation = '2.088357',position_x = '-2035.813843', position_y = '8333.043945', position_z = '14.550858', orientation = '2.088357' WHERE guid = '71550';
UPDATE creature SET spawn_position_x = '-2012.198975', spawn_position_y = '8298.462891', spawn_position_z = '10.965950', spawn_orientation = '2.151190',position_x = '-2012.198975', position_y = '8298.462891', position_z = '10.965950', orientation = '2.151190' WHERE guid = '71552';
UPDATE creature SET spawn_position_x = '-2362.066895', spawn_position_y = '7728.245117', spawn_position_z = '-22.861805', spawn_orientation = '1.361863',position_x = '-2362.066895', position_y = '7728.245117', position_z = '-22.861805', orientation = '1.361863' WHERE guid = '71431';
UPDATE creature SET spawn_position_x = '-2402.316895', spawn_position_y = '7731.390137', spawn_position_z = '-21.949938', spawn_orientation = '1.558212',position_x = '-2402.316895', position_y = '7731.390137', position_z = '-21.949938', orientation = '1.558212' WHERE guid = '71437';
UPDATE creature SET spawn_position_x = '-2450.837891', spawn_position_y = '7688.568848', spawn_position_z = '-13.784427', spawn_orientation = '3.667006',position_x = '-2450.837891', position_y = '7688.568848', position_z = '-13.784427', orientation = '3.667006' WHERE guid = '71434';
UPDATE creature SET spawn_position_x = '-2460.520264', spawn_position_y = '7658.077148', spawn_position_z = '-7.074682', spawn_orientation = '3.879064',position_x = '-2460.520264', position_y = '7658.077148', position_z = '-7.074682', orientation = '3.879064' WHERE guid = '71436';
UPDATE creature SET spawn_position_x = '-2356.844482', spawn_position_y = '7687.920898', spawn_position_z = '-12.900771', spawn_orientation = '6.050690',position_x = '-2356.844482', position_y = '7687.920898', position_z = '-12.900771', orientation = '6.050690' WHERE guid = '71433';
UPDATE creature SET spawn_position_x = '-2513.262207', spawn_position_y = '7831.112793', spawn_position_z = '-46.875328', spawn_orientation = '4.962911',position_x = '-2513.262207', position_y = '7831.112793', position_z = '-46.875328', orientation = '4.962911' WHERE guid = '71612';
UPDATE creature SET spawn_position_x = '-2481.500244', spawn_position_y = '7886.517578', spawn_position_z = '-51.707008', spawn_orientation = '0.906330',position_x = '-2481.500244', position_y = '7886.517578', position_z = '-51.707008', orientation = '0.906330' WHERE guid = '71603';
UPDATE creature SET spawn_position_x = '-2541.882080', spawn_position_y = '7915.582031', spawn_position_z = '-54.302219', spawn_orientation = '2.265069',position_x = '-2541.882080', position_y = '7915.582031', position_z = '-54.302219', orientation = '2.265069' WHERE guid = '71609';
UPDATE creature SET spawn_position_x = '-2576.359863', spawn_position_y = '7910.657227', spawn_position_z = '-54.990135', spawn_orientation = '2.539956',position_x = '-2576.359863', position_y = '7910.657227', position_z = '-54.990135', orientation = '2.539956' WHERE guid = '71608';
UPDATE creature SET spawn_position_x = '-2559.818115', spawn_position_y = '7840.365723', spawn_position_z = '-49.029671', spawn_orientation = '3.843719',position_x = '-2559.818115', position_y = '7840.365723', position_z = '-49.029671', orientation = '3.843719' WHERE guid = '71605';
UPDATE creature SET spawn_position_x = '-2557.997559', spawn_position_y = '7983.908203', spawn_position_z = '-53.421177', spawn_orientation = '1.958764',position_x = '-2557.997559', position_y = '7983.908203', position_z = '-53.421177', orientation = '1.958764' WHERE guid = '71615';
UPDATE creature SET spawn_position_x = '-2531.207275', spawn_position_y = '7873.090820', spawn_position_z = '-52.101727', spawn_orientation = '0.211248',position_x = '-2531.207275', position_y = '7873.090820', position_z = '-52.101727', orientation = '0.211248' WHERE guid = '71606';
UPDATE creature SET spawn_position_x = '-2491.058838', spawn_position_y = '7506.392090', spawn_position_z = '-4.195594', spawn_orientation = '1.754557',position_x = '-2491.058838', position_y = '7506.392090', position_z = '-4.195594', orientation = '1.754557' WHERE guid = '71423';
UPDATE creature SET spawn_position_x = '-2573.597168', spawn_position_y = '7339.099121', spawn_position_z = '10.219800', spawn_orientation = '2.001953',position_x = '-2573.597168', position_y = '7339.099121', position_z = '10.219800', orientation = '2.001953' WHERE guid = '80487';
UPDATE creature SET spawn_position_x = '-2571.015625', spawn_position_y = '7354.100098', spawn_position_z = '9.671785', spawn_orientation = '3.600239',position_x = '-2571.015625', position_y = '7354.100098', position_z = '9.671785', orientation = '3.600239' WHERE guid = '80489';
UPDATE creature SET spawn_position_x = '-1597.751953', spawn_position_y = '7881.339355', spawn_position_z = '-22.683374', spawn_orientation = '4.289813',position_x = '-1597.751953', position_y = '7881.339355', position_z = '-22.683374', orientation = '4.289813' WHERE guid = '73415';
DELETE FROM creature WHERE guid = '283043';
DELETE FROM creature_addon WHERE guid = '283043';
DELETE FROM creature_movement WHERE id = '283043';
DELETE FROM creature WHERE guid = '283045';
DELETE FROM creature_addon WHERE guid = '283045';
DELETE FROM creature_movement WHERE id = '283045';
DELETE FROM creature WHERE guid = '283046';
DELETE FROM creature_addon WHERE guid = '283046';
DELETE FROM creature_movement WHERE id = '283046';
UPDATE creature SET spawn_position_x = '-1523.018066', spawn_position_y = '7890.078613', spawn_position_z = '-20.414257', spawn_orientation = '4.278031',position_x = '-1523.018066', position_y = '7890.078613', position_z = '-20.414257', orientation = '4.278031' WHERE guid = '71392';
UPDATE creature SET spawn_position_x = '-1549.091553', spawn_position_y = '7921.837402', spawn_position_z = '-21.498619', spawn_orientation = '3.143131',position_x = '-1549.091553', position_y = '7921.837402', position_z = '-21.498619', orientation = '3.143131' WHERE guid = '80622';
UPDATE creature SET spawn_position_x = '-1509.661987', spawn_position_y = '7959.163574', spawn_position_z = '-17.695187', spawn_orientation = '3.410167',position_x = '-1509.661987', position_y = '7959.163574', position_z = '-17.695187', orientation = '3.410167' WHERE guid = '71393';
UPDATE creature SET spawn_position_x = '-860.916809', spawn_position_y = '8074.318848', spawn_position_z = '30.595919', spawn_orientation = '1.429385',position_x = '-860.916809', position_y = '8074.318848', position_z = '30.595919', orientation = '1.429385' WHERE guid = '79302';
UPDATE creature SET spawn_position_x = '-734.617920', spawn_position_y = '7827.543457', spawn_position_z = '52.155655', spawn_orientation = '1.935963',position_x = '-734.617920', position_y = '7827.543457', position_z = '52.155655', orientation = '1.935963' WHERE guid = '72268';
UPDATE creature SET spawn_position_x = '-791.150757', spawn_position_y = '7846.950195', spawn_position_z = '40.099567', spawn_orientation = '5.737290',position_x = '-791.150757', position_y = '7846.950195', position_z = '40.099567', orientation = '5.737290' WHERE guid = '72271';
UPDATE creature SET spawn_position_x = '-843.923401', spawn_position_y = '7608.696289', spawn_position_z = '46.697662', spawn_orientation = '0.769647',position_x = '-843.923401', position_y = '7608.696289', position_z = '46.697662', orientation = '0.769647' WHERE guid = '72292';
UPDATE creature SET spawn_position_x = '-821.250366', spawn_position_y = '7660.261719', spawn_position_z = '44.235813', spawn_orientation = '4.468871',position_x = '-821.250366', position_y = '7660.261719', position_z = '44.235813', orientation = '4.468871' WHERE guid = '72291';
UPDATE creature SET spawn_position_x = '-1188.749512', spawn_position_y = '7532.128418', spawn_position_z = '20.655952', spawn_orientation = '2.906711',position_x = '-1188.749512', position_y = '7532.128418', position_z = '20.655952', orientation = '2.906711' WHERE guid = '72353';
UPDATE creature SET spawn_position_x = '-1233.600830', spawn_position_y = '7533.957031', spawn_position_z = '17.738888', spawn_orientation = '6.122916',position_x = '-1233.600830', position_y = '7533.957031', position_z = '17.738888', orientation = '6.122916' WHERE guid = '72354';
UPDATE `creature_template` SET `name` = 'Thrall' WHERE `entry` = 20548;
UPDATE creature SET spawn_position_x = '-1292.260254', spawn_position_y = '7492.436523', spawn_position_z = '18.773607', spawn_orientation = '2.195925',position_x = '-1292.260254', position_y = '7492.436523', position_z = '18.773607', orientation = '2.195925' WHERE guid = '72361';
UPDATE creature SET spawn_position_x = '-1183.593872', spawn_position_y = '7306.446289', spawn_position_z = '34.147690', spawn_orientation = '1.937533',position_x = '-1183.593872', position_y = '7306.446289', position_z = '34.147690', orientation = '1.937533' WHERE guid = '72443';
UPDATE creature SET spawn_position_x = '-1193.728516', spawn_position_y = '7241.759766', spawn_position_z = '36.416969', spawn_orientation = '4.545055',position_x = '-1193.728516', position_y = '7241.759766', position_z = '36.416969', orientation = '4.545055' WHERE guid = '72516';
DELETE FROM creature WHERE guid = '72418';
DELETE FROM creature_addon WHERE guid = '72418';
DELETE FROM creature_movement WHERE id = '72418';
UPDATE creature SET spawn_position_x = '-1423.233643', spawn_position_y = '6385.778320', spawn_position_z = '36.450745', spawn_orientation = '2.357713',position_x = '-1423.233643', position_y = '6385.778320', position_z = '36.450745', orientation = '2.357713' WHERE guid = '72629';
UPDATE creature SET spawn_position_x = '-2569.386230', spawn_position_y = '6224.865723', spawn_position_z = '16.842672', spawn_orientation = '3.982498',position_x = '-2569.386230', position_y = '6224.865723', position_z = '16.842672', orientation = '3.982498' WHERE guid = '80500';
UPDATE creature SET spawn_position_x = '-2865.549072', spawn_position_y = '6899.916016', spawn_position_z = '-31.908937', spawn_orientation = '2.530294',position_x = '-2865.549072', position_y = '6899.916016', position_z = '-31.908937', orientation = '2.530294' WHERE guid = '73237';
UPDATE creature SET spawn_position_x = '-2874.410400', spawn_position_y = '6960.855957', spawn_position_z = '-33.515419', spawn_orientation = '2.467462',position_x = '-2874.410400', position_y = '6960.855957', position_z = '-33.515419', orientation = '2.467462' WHERE guid = '73254';
UPDATE creature SET spawn_position_x = '-2722.060059', spawn_position_y = '7010.318359', spawn_position_z = '-6.824825', spawn_orientation = '0.040583',position_x = '-2722.060059', position_y = '7010.318359', position_z = '-6.824825', orientation = '0.040583' WHERE guid = '73250';
UPDATE creature SET spawn_position_x = '-2421.216309', spawn_position_y = '8156.724121', spawn_position_z = '-41.272316', spawn_orientation = '2.761987',position_x = '-2421.216309', position_y = '8156.724121', position_z = '-41.272316', orientation = '2.761987' WHERE guid = '71583';
UPDATE creature SET spawn_position_x = '-2369.879150', spawn_position_y = '8301.938477', spawn_position_z = '-40.338585', spawn_orientation = '1.532839',position_x = '-2369.879150', position_y = '8301.938477', position_z = '-40.338585', orientation = '1.532839' WHERE guid = '71624';
UPDATE creature SET spawn_position_x = '-2369.879150', spawn_position_y = '8301.938477', spawn_position_z = '-40.338585', spawn_orientation = '1.532839',position_x = '-2369.879150', position_y = '8301.938477', position_z = '-40.338585', orientation = '1.532839' WHERE guid = '71624';
UPDATE creature SET spawn_position_x = '-2794.525391', spawn_position_y = '8335.173828', spawn_position_z = '-94.050674', spawn_orientation = '0.075922',position_x = '-2794.525391', position_y = '8335.173828', position_z = '-94.050674', orientation = '0.075922' WHERE guid = '71684';
UPDATE creature SET spawn_position_x = '-2807.649170', spawn_position_y = '8332.098633', spawn_position_z = '-94.056740', spawn_orientation = '4.250311',position_x = '-2807.649170', position_y = '8332.098633', position_z = '-94.056740', orientation = '4.250311' WHERE guid = '71704';
UPDATE creature SET spawn_position_x = '-2820.510742', spawn_position_y = '8323.066406', spawn_position_z = '-94.090363', spawn_orientation = '2.797324',position_x = '-2820.510742', position_y = '8323.066406', position_z = '-94.090363', orientation = '2.797324' WHERE guid = '71707';
UPDATE creature SET spawn_position_x = '-2820.175049', spawn_position_y = '8345.520508', spawn_position_z = '-94.224861', spawn_orientation = '2.483165',position_x = '-2820.175049', position_y = '8345.520508', position_z = '-94.224861', orientation = '2.483165' WHERE guid = '71705';
UPDATE creature SET spawn_position_x = '-2812.935303', spawn_position_y = '8344.528320', spawn_position_z = '-94.112473', spawn_orientation = '6.154901',position_x = '-2812.935303', position_y = '8344.528320', position_z = '-94.112473', orientation = '6.154901' WHERE guid = '71706';
UPDATE creature SET spawn_position_x = '-2521.492188', spawn_position_y = '8598.467773', spawn_position_z = '-28.916565', spawn_orientation = '1.081225',position_x = '-2521.492188', position_y = '8598.467773', position_z = '-28.916565', orientation = '1.081225' WHERE guid = '71765';
UPDATE creature SET spawn_position_x = '-2455.446045', spawn_position_y = '8554.928711', spawn_position_z = '-31.451641', spawn_orientation = '4.077520',position_x = '-2455.446045', position_y = '8554.928711', position_z = '-31.451641', orientation = '4.077520' WHERE guid = '71772';
UPDATE `creature_template` SET `maxhealth` = 100000 WHERE `entry` = 18402;
DELETE FROM `creature_loot_template` WHERE (`entry`=1824) AND (`item`=20610);
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrRef`, `QuestChanceOrGroup`, `mincount`, `maxcount`, `freeforall`, `lootcondition`, `condition_value1`, `condition_value2`) VALUES (1824, 20610, 0, 1, 1, 1, 1, 0, 0, 0);
update `creature_loot_template` set `QuestChanceOrGroup`=`ChanceOrRef`,`ChanceOrRef`=0,`freeforall`=1 where `item` in (20610,20611);
DELETE FROM `creature` WHERE (`guid`=279457);
DELETE FROM `creature_loot_template` WHERE (`entry`=1824) AND (`item`=20610);
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrRef`, `QuestChanceOrGroup`, `mincount`, `maxcount`, `freeforall`, `lootcondition`, `condition_value1`, `condition_value2`) VALUES (1824, 20610, 0, 1, 1, 1, 1, 0, 0, 0);


# GO
REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (181073, 2, 216, 'Fragrant Cauldron', 35, 0, 1.42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `gameobject` WHERE `id`=181073;
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(597, 181073, 0, 90.0641, -1719.48, 220.57, 3.55127, 0, 0, 0.979094, -0.203407, 30, 0, 1);
INSERT IGNORE INTO `game_event_gameobject` SELECT `guid`,'7' FROM `gameobject` WHERE `id`=181073;
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72030, 148516, 1, 3525.29, -5245.6, 92.2825, 2.32875, 0, 0, 0.918542, 0.395323, 240, 100, 1),
(72031, 148516, 1, 3542.82, -5148.75, 82.926, 0.0214977, 0, 0, 0.0107487, 0.999942, 90, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72032, 148513, 1, 3192.95, -5474.63, 97.1745, 2.15113, 0, 0, 0.879858, 0.475237, 240, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72033, 148514, 1, 3365.4, -5274.1, 91.4997, 1.68079, 0, 0, 0.744908, 0.667167, 240, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72034, 148515, 1, 3199.14, -5389.25, 89.1564, 1.96187, 0, 0, 0.831018, 0.556245, 240, 0, 1);
UPDATE `gameobject_template` SET `flags` = 32, `size` = 1.4994 WHERE `entry` = 170572;
UPDATE `gameobject_template` SET `flags` = 32, `size` = 1.51439 WHERE `entry` = 170575;
UPDATE `gameobject_template` SET `faction` = 0, `flags` = 32 WHERE `entry` = 170576;
UPDATE `gameobject_template` SET `faction` = 0, `flags` = 32 WHERE `entry` = 170577;
UPDATE `gameobject_template` SET `flags` = 32, `size` = 2.1507 WHERE `entry` = 175167;
UPDATE `gameobject_template` SET `flags` = 32 WHERE `entry` = 183847;
UPDATE `gameobject_template` SET `name` = 'Black Door' WHERE `entry` = 186152;
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72035, 17153, 36, -168.514, -579.861, 19.3159, 3.12414, 0, 0, 0.999962, 0.008726, 43200, 100, 1),
(72036, 17153, 36, -290.294, -536.96, 49.4353, 1.55334, 0, 0, 0.700909, 0.71325, 43200, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72037, 161461, 230, 614.021, -46.8877, -59.636, -2.63545, 0, 0, 0.968148, -0.25038, 600, 100, 1);
DELETE FROM `gameobject` WHERE `id`=161516;
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72038, 161516, 230, 702.108, -125.745, -45.7123, -2.35619, 0, 0, 0.92388, -0.382683, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72039, 170556, 230, 496.211, 121.043, 0, 3.14159, 0, 0, 1, 0, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72040, 170557, 230, 488.845, 87.2209, 0, 3.14159, 0, 0, 1, 0, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72041, 170561, 230, 404.642, -60.5172, -63.8164, -1.8326, 0, 0, -0.793354, 0.608761, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72042, 170562, 230, 284.599, -85.7571, -76.9561, -0.523598, 0, 0, -0.258819, 0.965926, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72043, 170563, 230, 319.473, -216.317, -77.7557, 1.02102, 0, 0, 0.488621, 0.872496, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72044, 170564, 230, 375.598, -189.419, -70.0353, -1.23046, 0, 0, -0.577145, 0.816642, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72045, 170565, 230, 412.167, -202.4, -65.0041, 2.24275, 0, 0, 0.900698, 0.434445, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72046, 170566, 230, 550.306, -277.685, -75.2609, 1.08211, 0, 0, 0.515038, 0.857167, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72047, 170567, 230, 556.919, -243.199, -70.249, -2.33874, 0, 0, 0.920505, -0.390731, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72048, 170568, 230, 589.74, -141.631, -68.4205, 1.20428, 0, 0, 0.566406, 0.824126, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72049, 170569, 230, 630.367, -160.274, -71.0334, 0.898845, 0, 0, 0.434445, 0.900698, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72050, 170572, 230, 1449.13, -342.325, -92.0093, -2.35619, 0, 0, 0.92388, -0.382683, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72051, 170575, 230, 1380.12, -710.482, -92.0093, -1.5708, 0, 0, -0.707107, 0.707107, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72052, 170576, 230, 1230.33, -205.21, -85.6843, -0.767945, 0, 0, -0.374607, 0.927184, 600, 100, 0);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72053, 170577, 230, 1262.85, -293.797, -78.1676, -0.785397, 0, 0, -0.382683, 0.92388, 600, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72054, 175167, 289, 174.378, 77.9398, 104.802, -3.12414, 0, 0, 0.999962, -0.008727, 7200, 100, 1);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72055, 183847, 544, -72.5866, 1.559, 0, 3.14159, 0, 0, 1, 0, 900, 100, 0);
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72056, 186152, 564, 498.708, 338.283, 112.785, 0, 0, 0, 0.00748118, -0.999972, 900, 0, 0),
(72057, 186152, 564, 499.446, 462.63, 112.785, 0, 0, 0, 0.00234163, 0.999997, 900, 0, 0),
(72058, 186152, 564, 563.265, 400.583, 112.851, 1.57079, 0, 0, 0.68196, 0.73139, 900, 0, 0),
(72059, 186152, 564, 577.861, 305.744, 272.168, 1.57079, 0, 0, 0.707624, 0.706589, 900, 0, 0),
(72060, 186152, 564, 626.933, 305.632, 271.65, 1.57079, 0, 0, 0.717269, 0.696797, 900, 0, 0),
(72061, 186152, 564, 812.408, 461.682, 192.827, 0, 0, 0, 0.027923, -0.99961, 900, 0, 0),
(72062, 186152, 564, 855.597, 392.873, 112.769, 1.57079, 0, 0, 0.703081, 0.71111, 900, 0, 0),
(72063, 186152, 564, 858.722, 149.175, 197.053, 4.71238, 0, 0, 0.692842, -0.72109, 900, 0, 0),
(72064, 186152, 564, 877.621, 420.927, 192.836, 1.57079, 0, 0, 0.693414, 0.720539, 900, 0, 0),
(72065, 186152, 564, 904.196, 148.98, 192.819, 4.71238, 0, 0, 0.702688, -0.711498, 900, 0, 0),
(72066, 186152, 564, 905.528, 420.861, 192.814, 1.57079, 0, 0, 0.704012, 0.710188, 900, 0, 0);
REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (310142, 8, 0, 'Bookcase', 0, 0, 1, 1402, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `gameobject` WHERE `id`=310142;
INSERT INTO `gameobject` (`guid`,`id`,`map`,`position_x`,`position_y`,`position_z`,`orientation`,`rotation0`,`rotation1`,`rotation2`,`rotation3`,`spawntimesecs`,`animprogress`,`state`) VALUES
(72067, 310142, 530, 2240.1, 2390.31, 112.39, 0, 0, 0, 0, 0, 180, 100, 1);
REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (176087, 5, 4092, 'Scourge Banner', 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (176210, 1, 4176, 'Command Tent', 0, 0, 1, 0, 960, 3932160, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM `gameobject` WHERE `guid`=777325;
DELETE FROM `gameobject` WHERE `guid`=777397;
DELETE FROM `gameobject` WHERE `guid`=777387;
DELETE FROM `gameobject` WHERE `guid`=777174;


DELETE FROM `db_version`;
INSERT INTO `db_version` VALUES ('YTDB_092_r35.07_rev5489');

REPLACE INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `faction`, `flags`, `size`, `data0`, `data1`, `data2`, `data3`, `data4`, `data5`, `data6`, `data7`, `data8`, `data9`, `data10`, `data11`, `data12`, `data13`, `data14`, `data15`, `data16`, `data17`, `data18`, `data19`, `data20`, `data21`, `data22`, `data23`, `ScriptName`) VALUES (177964, 3, 1027, 'Fathom Stone', 0, 4, 0.5, 43, 177964, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
