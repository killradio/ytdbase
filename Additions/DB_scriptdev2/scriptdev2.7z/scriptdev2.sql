/*
MySQL Data Transfer
Source Host: localhost
Source Database: scriptdev2
Target Host: localhost
Target Database: scriptdev2
Date: 18.02.2008 0:56:09
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for eventai_scripts
-- ----------------------------
CREATE TABLE `eventai_scripts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `creature_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Creature Template Identifier',
  `event_type` tinyint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Event Type',
  `event_inverse_phase_mask` int(11) NOT NULL DEFAULT '0' COMMENT 'Mask which phases this event will not trigger in',
  `event_param1` int(11) NOT NULL DEFAULT '0',
  `event_param2` int(11) NOT NULL DEFAULT '0',
  `event_param3` int(11) NOT NULL DEFAULT '0',
  `action1_type` tinyint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Action Type',
  `action1_param1` int(11) NOT NULL DEFAULT '0',
  `action1_param2` int(11) NOT NULL DEFAULT '0',
  `action1_param3` int(11) NOT NULL DEFAULT '0',
  `action2_type` tinyint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Action Type',
  `action2_param1` int(11) NOT NULL DEFAULT '0',
  `action2_param2` int(11) NOT NULL DEFAULT '0',
  `action2_param3` int(11) NOT NULL DEFAULT '0',
  `action3_type` tinyint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Action Type',
  `action3_param1` int(11) NOT NULL DEFAULT '0',
  `action3_param2` int(11) NOT NULL DEFAULT '0',
  `action3_param3` int(11) NOT NULL DEFAULT '0',
  `comment` varchar(255) NOT NULL DEFAULT '' COMMENT 'Event Comment',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='EventAI Scripts';

-- ----------------------------
-- Table structure for localized_texts
-- ----------------------------
CREATE TABLE `localized_texts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `locale_0` varchar(255) NOT NULL DEFAULT '',
  `locale_1` varchar(255) NOT NULL DEFAULT '',
  `locale_2` varchar(255) NOT NULL DEFAULT '',
  `locale_3` varchar(255) NOT NULL DEFAULT '',
  `locale_4` varchar(255) NOT NULL DEFAULT '',
  `locale_5` varchar(255) NOT NULL DEFAULT '',
  `locale_6` varchar(255) NOT NULL DEFAULT '',
  `locale_7` varchar(255) NOT NULL DEFAULT '',
  `comment` varchar(255) NOT NULL DEFAULT '' COMMENT 'Text Comment',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Localized Text';

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `eventai_scripts` VALUES ('1', '38', '6', '0', '70', '0', '0', '7', '1', '2', '-1', '0', '0', '0', '0', '0', '0', '0', '0', 'Defias Thug');
INSERT INTO `eventai_scripts` VALUES ('2', '257', '6', '0', '70', '0', '0', '7', '8', '9', '-1', '0', '0', '0', '0', '0', '0', '0', '0', 'Kobold Worker');
INSERT INTO `eventai_scripts` VALUES ('3', '3518', '2', '0', '180000', '0', '0', '6', '3', '4', '-1', '0', '0', '0', '0', '0', '0', '0', '0', 'Thomas Miller');
INSERT INTO `eventai_scripts` VALUES ('4', '1402', '2', '0', '180000', '0', '0', '6', '5', '6', '7', '0', '0', '0', '0', '0', '0', '0', '0', 'Topper McNabb');
INSERT INTO `eventai_scripts` VALUES ('5', '80', '6', '0', '70', '0', '0', '7', '8', '9', '-1', '0', '0', '0', '0', '0', '0', '0', '0', 'Kobold Laborer');
INSERT INTO `eventai_scripts` VALUES ('6', '1405', '2', '0', '180000', '0', '0', '6', '5', '6', '7', '0', '0', '0', '0', '0', '0', '0', '0', 'Morris Lawry');
INSERT INTO `eventai_scripts` VALUES ('7', '7917', '2', '0', '300000', '0', '0', '1', '10', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'Brother');
INSERT INTO `eventai_scripts` VALUES ('8', '1368', '2', '0', '180000', '0', '0', '6', '11', '14', '17', '0', '0', '0', '0', '0', '0', '0', '0', 'Justin');
INSERT INTO `eventai_scripts` VALUES ('9', '1370', '2', '0', '180000', '0', '0', '6', '15', '12', '19', '0', '0', '0', '0', '0', '0', '0', '0', 'Brandon');
INSERT INTO `eventai_scripts` VALUES ('10', '1371', '2', '0', '180000', '0', '0', '6', '13', '16', '18', '0', '0', '0', '0', '0', '0', '0', '0', 'Roman');
INSERT INTO `localized_texts` VALUES ('1', 'This land belongs to the Defias Brotherhood now!', 'This land belongs to the Defias Brotherhood now!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('2', 'I see those fools at the Abbey sent some fresh meat for us!', 'I see those fools at the Abbey sent some fresh meat for us!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('3', 'Fresh bread for sale!', 'Fresh bread for sale!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('4', 'Freshly baked bread for sale!', 'Freshly baked bread for sale!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('5', 'Shine yer armor for a copper?', 'Shine yer armor for a copper?', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('6', 'Help a poor bloke out?', 'Help a poor bloke out?', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('7', 'Some coin?', 'Some coin?', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('8', 'Yiieeeee! Me run!', 'Yiieeeee! Me run!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('9', 'You no take candle!', 'You no take candle!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('10', 'Greertings! Welcome to the Cathedral of Light!', 'Greetings! Welcome to the Cathedral of Light!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('11', 'And so the knights stood before the charging Horde and held their ground as a thousand berserk orcs came through the valley.', 'And so the knights stood before the charging Horde and held their ground as a thousand berserk orcs came through the valley.', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('12', 'Can you imagine?', 'Can you imagine?', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('13', 'Something smells funny.', 'Something smells funny.', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('14', 'You know why orc eyes glow red? It\'s because they drink blood!', 'You know why orc eyes glow red? It\'s because they drink blood!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('15', 'Really?', 'Really?', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('16', 'I hope that was a fish!', 'I hope that was a fish!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('17', 'And that\'s how Lothar killed thirty six orcs with his bare hands!', 'And that\'s how Lothar killed thirty six orcs with his bare hands!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('18', 'Eww... that\'s not a fish!', 'Eww... that\'s not a fish!', '', '', '', '', '', '', '');
INSERT INTO `localized_texts` VALUES ('19', 'I thought I heard something.', 'I thought I heard something.', '', '', '', '', '', '', '');
